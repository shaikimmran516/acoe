#!groovy
import hudson.triggers.*
import jenkins.model.*

properties([[$class: 'GitLabConnectionProperty', gitLabConnection: 'git.rxcorp.com']])

node ('dind-datalake-maven') {

    stage("SCM Checkout") {
        checkout scm
    }

    gitlabBuilds(builds: ["Build", "Test", "Deploy Nexus"]) {
        TENANT = "cmn"
        ASSET = "test"
        APP_PREFIX = "auto"
        APP_MODULE = "DBDataload"
        POM_GROUPID = readMavenPom().getGroupId()
        POM_VERSION = readMavenPom().getVersion()
        PRODOPS_AD_APPROVERS = "cdtg_prod_ops_sel_grp"
        DEVL_VERSION = ""
        DEVL_SUFFIX = ""
        INTG_VERSION = ""
        UACC_VERSION = ""
        PROD_VERSION = ""
        EMAIL_RECIPIENTS = "apoorv.agrawal@in.imshealth.com;NKBidi@in.imshealth.com"

        if (env.BRANCH_NAME == "develop") {
            DEVL_VERSION = "${POM_VERSION}"
            EMAIL_RECIPIENTS = EMAIL_RECIPIENTS
            updateGitlabCommitStatus name: "Deploy Edge-Node -> DEVL", state: 'pending'
        } else if (env.BRANCH_NAME =~ /release\/*/) {
            UACC_VERSION = "${POM_VERSION}"
            EMAIL_RECIPIENTS = EMAIL_RECIPIENTS
            updateGitlabCommitStatus name: "Deploy Edge-Node -> UACC", state: 'pending'
        } else if (env.BRANCH_NAME =="develop") {
            UACC_VERSION = "${POM_VERSION}"
            EMAIL_RECIPIENTS = EMAIL_RECIPIENTS
            updateGitlabCommitStatus name: "Deploy Edge-Node -> UACC", state: 'pending'
        } else if (env.BRANCH_NAME == "master") {
            PROD_VERSION = "${POM_VERSION}"
            EMAIL_RECIPIENTS = "EnterpriseProdOpssupport@in.imshealth.com,apoorv.agrawal@in.imshealth.com"
            updateGitlabCommitStatus name: "Deploy Edge-Node -> PROD", state: 'pending'
        }

        stage("Build") {
            try {
                updateGitlabCommitStatus name: "Build", state: 'running'
                sh "mvn -B clean install -DskipTests"
                updateGitlabCommitStatus name: "Build", state: 'success'
            } catch (Exception exc) {
                logError("Build", exc)
            }
        }

        stage("Test") {
            try {
                updateGitlabCommitStatus name: "Test", state: 'running'
                sh "mvn -B test -Dmaven.test.failure.ignore=true"
                updateGitlabCommitStatus name: "Test", state: 'success'
            } catch (Exception exc) {
                logError("Test", exc)
            } finally {
//                we wont have JUnit yet - may want to add when JUnit tests are available
//                junit '*/target/surefire-reports/**/*.xml'
            }
        }

        stage("Deploy Nexus") {
            try {
                if ("${PROD_VERSION}" != "") {
                    timeout(time: 10, unit: 'MINUTES') {
                        input(
                                message: "Do you want to Deploy to hadoop PROD environment ?",
                                submitter: "${PRODOPS_AD_APPROVERS}"
                        )
                    }
                }
                updateGitlabCommitStatus name: "Deploy Nexus", state: 'running'
                sh "mvn -B deploy -DskipTests"
                updateGitlabCommitStatus name: "Deploy Nexus", state: 'success'
            } catch (Exception exc) {
                logError("Deploy Nexus", exc)
            }
        }

        if ("${DEVL_VERSION}" != "") {
            stage("Deploy Edge-Node -> DEVL") {
                try {
                    updateGitlabCommitStatus name: "Deploy Edge-Node -> DEVL", state: 'running'
                    deployToEdgeNode("devl", "development", "cdts99hdbe11d.rxcorp.com", "${DEVL_VERSION}", "${DEVL_SUFFIX}")
                    deployToEdgeNode("devl", "development", "dubs07hdie01d.rxcorp.com", "${DEVL_VERSION}", "${DEVL_SUFFIX}")
                    updateGitlabCommitStatus name: "Deploy Edge-Node -> DEVL", state: 'success'
                } catch (Exception exc) {
                    logError("Deploy Edge-Node -> DEVL", exc)
                }
            }
        }
        if ("${INTG_VERSION}" != "") {
            stage("Deploy Edge-Node -> INTG") {
                try {
                    updateGitlabCommitStatus name: "Deploy Edge-Node -> INTG", state: 'running'
                   // deployToEdgeNode("intg", "integration", "cdts99hdbe11d.rxcorp.com", "${INTG_VERSION}", "")
                    deployToEdgeNode("intg", "integration", "dubs07hdie01d.rxcorp.com", "${INTG_VERSION}", "")
                    updateGitlabCommitStatus name: "Deploy Edge-Node -> INTG", state: 'success'
                } catch (Exception exc) {
                    logError("Deploy Edge-Node -> INTG", exc)
                }
            }
        }
        if ("${UACC_VERSION}" != "") {
            stage("Deploy Edge-Node -> UACC") {
                try {
                    updateGitlabCommitStatus name: "Deploy Edge-Node -> UACC", state: 'running'
                    deployToEdgeNode("uacc", "acceptance", "cdts99hdbe11d.rxcorp.com", "${UACC_VERSION}", "")
                    deployToEdgeNode("uacc", "acceptance", "dubs07hdie01d.rxcorp.com", "${UACC_VERSION}", "")
                    updateGitlabCommitStatus name: "Deploy Edge-Node -> UACC", state: 'success'
                } catch (Exception exc) {
                    logError("Deploy Edge-Node -> UACC", exc)
                }
            }
        }
        if ("${PROD_VERSION}" != "") {
            stage("Deploy Edge-Node -> PROD") {
                try {
                    updateGitlabCommitStatus name: "Deploy Edge-Node -> PROD", state: 'running'
                    deployToEdgeNode("prod", "production", "cdts99hdfe01p.rxcorp.com", "${PROD_VERSION}", "")
                    deployToEdgeNode("prod", "production", "dubs04hdhe01p.rxcorp.com", "${PROD_VERSION}", "")
                    updateGitlabCommitStatus name: "Deploy Edge-Node -> PROD", state: 'success'
                } catch (Exception exc) {
                    logError("Deploy Edge-Node -> PROD", exc)
                }
            }
        }
    }
}

def sendEmail(String status, String emailIds) {
    emailext (
            attachLog: true,
            body: """STARTED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]',
Cross check console output at '${env.BUILD_URL}' ${env.JOB_NAME} [${env.BUILD_NUMBER}]\n\n
Thanks & Regards,
${APP_MODULE} Dev Team""",
            subject: "[${APP_MODULE}]: Jenkins Job '${env.JOB_NAME}' with build #[${env.BUILD_NUMBER}] is ${status}",
            to: "${emailIds}"
    )
}

def logError(String stageName, Exception exc) {
    sendEmail("FAILED", "${EMAIL_RECIPIENTS}")
    updateGitlabCommitStatus name: "${stageName}", state: 'failed'
    error "'${env.JOB_NAME}' with build #[${env.BUILD_NUMBER}] for '${env.BRANCH_NAME}' has failed while '${stageName}' with error ${exc.toString()}, hence Exiting...! Please check Console logs for more details ...!"
}

def deployToEdgeNode(String envLifecycleShort, String envLifecycleLong, String edgeNode, String pomVersion, String pomSuffix) {
    script {
        withCredentials([
                usernamePassword(
                        credentialsId: "${TENANT}-${APP_PREFIX}-${ASSET}-${envLifecycleShort}",
                        usernameVariable: "sshUser",
                        passwordVariable: "sshPass"
                )
        ]) {
            echo "Deploying to ${envLifecycleLong} Hadoop cluster"
            sh "sshpass -p ${sshPass} ssh -o StrictHostKeyChecking=no ${sshUser}@${edgeNode} \"mkdir -p /${envLifecycleLong}/${TENANT}/apps/${APP_PREFIX}-${ASSET}\""
            sh "sshpass -p ${sshPass} ssh -o StrictHostKeyChecking=no ${sshUser}@${edgeNode} \"/${envLifecycleLong}/cmn/apps/devops-deploy/current/scripts/deploy.sh ${TENANT} ${APP_PREFIX}-${ASSET} ${POM_GROUPID} ${APP_MODULE} ${pomVersion} jar ${pomSuffix}\""
        }
    }
}
