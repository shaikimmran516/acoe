#!/bin/bash

#-----------------------------------------------------------------------------------------
#       COPYRIGHT:  IMS AMERICA CORPORATION  -  ALL RIGHTS ARE RESERVED                  #
#                                                                                        #
#               NO part of this document may be stored, reproduced,                      #
#               or otherwise copied, in any form, or by any means,                       #
#             WITHOUT THE EXPRESSED WRITTEN PERMISSION OF IMS AMERICA.                   #
#                                                                                        #
#-----------------------------------------------------------------------------------------
# Program name : appDeploy.sh  (for deploy-config-builder)
# Location     : /<env>/us9/apps/datalake-jrx/current/appDeploy.sh
# Description  : This script includes application specific instructions for deployment
#
#
#   This script is called from deploy.sh after artifacts are downloaded.
#   NOTE: Make sure your project is deployed in Jenkins in the following way:
#   /development/cmn/apps/devops-deploy/current/scripts/deploy.sh <yourAuditCd> <yourAppName> $POM_GROUPID <gitArtifactId> $POM_VERSION tar.gz
#
#   At high level, this script should do the following
#   1) Setup edge node for the application using the downloaded artifacts.
#          Refer standards for the directory layout
#             https://jiraims.rm.imshealth.com/wiki/display/BDL/Big+Data+Lake
#   2) After edge node is setup, update the necessary components on the HDFS
#
#-----------------------------------------------------------------------------------------
# VERSION DETAILS
#-----------------------------------------------------------------------------------------
#  Version   Date              Modified By           Description
#-----------------------------------------------------------------------------------------
#  1.0       Mar 07 2018       Piotr Kaczor          Initial template version of appDepoy.sh
#-----------------------------------------------------------------------------------------
# FUNCTIONS
#-----------------------------------------------------------------------------------------
# Delete the HDFS after testing if it exists

function delete_hdfs_dir {
    hdfs_dir=$1
    hadoop fs -test -d ${hdfs_dir}
    if [ $? -eq 0 ]; then
        echo "Removing HDFS dir : ${hdfs_dir}"
        hadoop fs -rm -r -skipTrash ${hdfs_dir}
        if [ $? -ne 0 ]; then
            echo "Failed to remove HDFS dir : ${hdfs_dir}"
            exit 1
        fi
    fi
}
#-----------------------------------------------------------------------------------------

env=$1
audit=$2
appName=$3
artifactId=$4
version=$5
dirSuffix=$6

baseDir=/${env}/${audit}
appDir=${baseDir}/apps

echo "****************************************"
echo "Starting App Deploy"
echo "****************************************"
echo "Environment  : $env"
echo "Audit        : $audit"
echo "App          : $appName"
echo "Artifact     : $artifactId"
echo "Version      : $version"
echo "DirSuffix    : $dirSuffix"
echo "****************************************"
echo "Capturing Start Time for process."
start=`date +%s`

#-----------------------------------------------------------------------------------------
# BEGIN Core Logic for App Deploy.sh
# Application developer will provide deployment steps
# in the core sections below. Setup should include
# setups for Edge node as well as HDFS
#
# For the structure of application deployment, please refer
#
# https://jiraims.rm.imshealth.com/wiki/display/BDL/Big+Data+Lake
#
#-----------------------------------------------------------------------------------------

echo "****************************************"
echo "Doing Edge Node setup for ${appName}"
echo "****************************************"
echo "Extracting archive ${appDir}/${appName}/${version}${dirSuffix}/tmp/${artifactId}.jar"
cd "${appDir}/${appName}/${version}${dirSuffix}"
cp ${appDir}/${appName}/${version}${dirSuffix}/tmp/${artifactId}.jar ${appDir}/${appName}/${version}${dirSuffix}/


echo "Making all the scripts as executable and QC scripts executable for 'other'"
if [ -d scripts ]; then
   find scripts -type f|grep -e "\.sh$" -e "\.ksh$" |xargs -n 1 chmod u+x
   if [ -d scripts/qc ]; then
      find scripts/qc -type f|grep -e "\.sh$" -e "\.ksh$" |xargs -n 1 chmod o+x
   fi
fi

echo "Clean up archive file"
rm -rf tmp

echo "Injecting US9_VERSION property for application shell properties"
for file in scripts/*.conf
do
  echo "shell.default.US9_VERSION = ${version}${dirSuffix}" >> "${file}"
done

echo "Generating properties for application shell properties"
/${env}/cmn/apps/devops-deploy/current/scripts/buildShellProperties.sh
if [ $? -ne 0 ]; then
    echo "Command /${env}/cmn/apps/devops-deploy/current/scripts/buildShellProperties.sh"
    echo "Failed to generate application properties for shell"
    exit 1
fi

cd "${appDir}/${appName}/${version}${dirSuffix}"

#-----------------------------------------------------------------------------------------

echo "****************************************"
echo "Doing HDFS Setup for ${appName}"
echo "****************************************"
cd ..
user=`whoami`

echo "Getting kerberos ticket for for ${user}"
kinit -kt /home/${user}/${user}.keytab ${user}@INTERNAL.IMSGLOBAL.COM
if [ $? -ne 0 ]; then
   echo "Could not initialize the keytab: /home/${user}/${user}.keytab ${user}@INTERNAL.IMSGLOBAL.COM"
   exit 1
fi

echo "Creating HDFS directories for ${appName}"
hadoop fs -mkdir -p "${appDir}/${appName}"

echo "Clean up the HDFS this version directory if the application was deployed earlier"
delete_hdfs_dir "${appDir}/${appName}/${version}${dirSuffix}"

echo "Chmod 777 -R to ${appDir}/${appName}/${version}${dirSuffix} folder"

chmod 755 -R ${appDir}/${appName}/${version}${dirSuffix}/*

echo "setting job and spark properties is started!"
${appDir}/${appName}/${version}${dirSuffix}/set_run_time_props.ksh "${appDir}/${appName}/${version}${dirSuffix}"
echo "setting job and spark properties is done!"


echo "Deploying the code to ${appDir}/${appName}/${version}${dirSuffix} folder"
hadoop fs -put "${appDir}/${appName}/${version}${dirSuffix}" "${appDir}/${appName}"

#-----------------------------------------------------------------------------------------

echo "Capturing End Time for process."
end=`date +%s`
runtime=$((end-start))
echo "****************************************"
echo "App Deployed in  ${runtime} secs"
echo "****************************************"
exit 0