package com.rxcorp.bdf.sparxta

case class CmdSparkArguments (confFilePath:String="",runType:String="",srcJdbc:String="",tgtJdbc:String="",sftpUser:String="",sftpPass:String="",ftpUser:String="",ftpPass:String="",smbUser:String="",smbPass:String="",environment: String = "",
                              asset: String = "", countryName: String = "",tenant:String="")


