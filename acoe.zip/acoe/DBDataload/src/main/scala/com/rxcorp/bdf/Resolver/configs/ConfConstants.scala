package com.rxcorp.bdf.Resolver.configs

/** The `ConfConstants` trait offers constants for different keys expected in .conf file related to [[ConfFile]].
  * Created by Apoorv */


trait ConfConstants {

  /** The [[tableListFilePath]] constant value equals `tableListFilePath` */
  final val tableListFilePath: String = "tableListFilePath"

  /** The [[fixedHdfsPath]] constant value equals `fixedHdfsPath` */
  final val fixedHdfsPath: String = "fixedHdfsPath"

  /** The [[mailIds]] constant value equals `mailIds` */
  final val mailIds: String = "mailIds"

  /** The [[columnCountTest]] constant value equals `columnCountTest` */
  final val columnCountTest: String = "columnCountTest"

  /** The [[fieldNameTest]] constant value equals `fieldNameTest` */
  final val fieldNameTest: String = "fieldNameTest"

  /** The [[recordCountTest]] constant value equals `recordCountTest` */
  final val recordCountTest: String = "recordCountTest"

  /** The [[schemaTest]] constant value equals `schemaTest` */
  final val schemaTest: String = "schemaTest"

  /** The [[nullValue]] constant value equals `nullValue` */
  final val nullValue: String = "nullValue"

  /** The [[duplicateTest]] constant value equals `duplicateTest` */
  final val duplicateTest: String = "duplicateTest"

  /** The [[dataValidationTest]] constant value equals `dataValidationTest` */
  final val dataValidationTest: String = "dataValidationTest"

  /** The [[nullCheckTest]] constant value equals `nullCheckTest` */
  final val nullCheckTest: String = "nullCheckTest"

  /** The [[sumCheckTest]] constant value equals `sumCheckTest` */
  final val sumCheckTest: String = "sumCheckTest"

  /** The [[emptyValue]] constant value equals `emptyValue` */
  final val emptyValue: String = "emptyValue"

  /** The [[sortSource]] constant value equals `sortSource` */
  final val sortSource: String = "sortSource"

  /** The [[dataMismatchTest]] constant value equals `dataMismatchTest` */
  final val dataMismatchTest: String = "dataMismatchTest"


}
