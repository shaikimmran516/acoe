package com.rxcorp.bdf

import com.rxcorp.bdf.sparxta.CmdSparkArguments

/** The `Driver` object holds the mainClass for the spark-Submit
  * It offers parser to parse and validate the received commands line arguments
  * and performs the Spark related tasks for the received job information.
  */

object SparxtaDriver extends App {

  val parser = new scopt.OptionParser[CmdSparkArguments]("com.rxcorp.bdf.SparxtaDriver") {
    head("Module:", "sparxta-Driver")

    opt[String]("configFile").required.action( (x, c) =>
      c.copy(confFilePath = x)
    ).text("configFile is required!")

    opt[String]("runType").required.action( (x, c) =>
      c.copy(runType = x)
    ).text("runType is required!")

    opt[String]("environment").required.action( (x, c) =>
      c.copy(environment = x)
    ).text("environment is required!")

    opt[String]("asset").required.action( (x, c) =>
      c.copy(asset = x)
    ).text("asset is required!")

    opt[String]("country").required.action( (x, c) =>
      c.copy(countryName = x)
    ).text("country is required!")

    opt[String]("tenant").required.action( (x, c) =>
      c.copy(tenant = x)
    ).text("tenant is required!")

    opt[String]("jdbcUrl").action( (x, c) =>
      c.copy(srcJdbc = x)
    ).text("jdbcUrl is optional!")

    opt[String]("jdbcTgt").action( (x, c) =>
      c.copy(tgtJdbc = x)
    ).text("jdbcTgt is optional!")

    opt[String]("sftpUser").action( (x, c) =>
      c.copy(sftpUser = x)
    ).text("sftpUser is optional!")

    opt[String]("sftpPass").action( (x, c) =>
      c.copy(sftpPass = x)
    ).text("sftpPass is optional!")

    opt[String]("ftpUser").action( (x, c) =>
      c.copy(ftpUser = x)
    ).text("ftpUser is optional!")

    opt[String]("ftpPass").action( (x, c) =>
      c.copy(ftpPass = x)
    ).text("ftpPass is optional!")

    opt[String]("smbUser").action( (x, c) =>
      c.copy(smbUser = x)
    ).text("smbUser is optional!")

    opt[String]("smbPass").action( (x, c) =>
      c.copy(smbPass = x)
    ).text("smbPass is optional!")
  }



  parser.parse(args, CmdSparkArguments()) match {
    case Some(cmdLineArgs) =>
      com.rxcorp.bdf.Utilities.spark.SparkEnvironment.sparkSession
      val connectDetails= com.rxcorp.bdf.Resolver.configs.ConnectDetails.getConn(cmdLineArgs)
      cmdLineArgs.runType.toInt match{
        case 1 | 2 | 3 => com.rxcorp.bdf.SparxtaAuto.DbDataLoadRoot(cmdLineArgs.confFilePath,connectDetails,cmdLineArgs.environment,cmdLineArgs.asset,cmdLineArgs.countryName,cmdLineArgs.tenant,cmdLineArgs.runType.toInt)
        case 4 => com.rxcorp.bdf.SparxtaMini.SparxtaMini(cmdLineArgs.confFilePath,connectDetails,cmdLineArgs.environment,cmdLineArgs.asset,cmdLineArgs.countryName,cmdLineArgs.tenant)
        case 5 => com.rxcorp.bdf.SparxtaMiniBitemp.SparxtaBitempMini(cmdLineArgs.confFilePath,connectDetails,cmdLineArgs.environment,cmdLineArgs.asset,cmdLineArgs.countryName,cmdLineArgs.tenant)
      }

  }
  }
