package com.rxcorp.bdf.Resolver.configs

import com.typesafe.config.Config
import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}

import scala.util.Try

/** The `DatabaseConfig` object extends [[DatabaseConstants]] trait.
  *
  * This object offers methods to resolve files config from user's .job file.
  * Created By Apoorv
  */


object DatabaseConfig extends DatabaseConstants {

  /** The `getDBConfig` method returns [[DBConf]] case class instance by resolving the database configurations from user's .conf file.
    * @param config The config object from .conf file
    * @return [[DBConf]]
    */
  def getDBConfig(config: Config):DBConf = {
    val jdbcURL: Option[String] = Try(Some(config.getString("jdbc_url"))).getOrElse(None)
    val jdbcTgt: Option[String] = Try(Some(config.getString("jdbc_tgt"))).getOrElse(None)
    DBConf(jdbcURL,jdbcTgt)
  }

  /** The `DBConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param jdbcURL   jdbc_url for source database connection.
    * @param jdbcTgt   jdbc_tgt for target database connection.
    */

  case class DBConf(jdbcURL:Option[String],jdbcTgt:Option[String]) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("jdbcURL", jdbcURL)
        .append("jdbcTgt", jdbcTgt)
        .toString
    }
  }

}
