package com.rxcorp.bdf.Resolver.table

import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}
import org.apache.spark.sql.Row

import scala.util.Try
/** Created By Apoorv*/
object TableDetails extends TableConstants {

  /** The `getTableDetails` method returns [[TableConf]] case class instance by resolving the tables/delmited files from .csv file
    * @param inputString Row contains values from .csv file
    * @return [[TableConf]]
    */

  def getTableDetails(inputString: Row):TableConf = {
    val srcConType: String = Try(inputString.getString(0).trim).getOrElse(throw new Exception("Connection Type Missing"))
    val srcTableNm: String = Try(inputString.getString(1).trim).getOrElse(throw new Exception("Source Table Missing"))
    val alias: String =Try(inputString.getString(2).trim).getOrElse(throw new Exception("Alias is Missing"))
    val srcPrsnlQuery: Option[String] =Try(Some(inputString.getString(3).trim)).getOrElse(None)
    val header: String =Try(inputString.getString(4).trim.toLowerCase).getOrElse("yes")
    val schemaFile=Try(Some(inputString.getString(5).trim)).getOrElse(None)
    val tgtTableNm=Try(inputString.getString(6).trim).getOrElse(throw new Exception("Target Table is Missing"))
    val tgtPrsnlQuery=Try(Some(inputString.getString(7).trim)).getOrElse(None)
    val bitemp=Try(inputString.getString(8)).getOrElse("yes")
    val splitColumn=Try(Some(inputString.getString(9).trim)).getOrElse(None)
    val aggColumn=Try(Some(inputString.getString(10).trim)).getOrElse(None)
    val useTargetSchema=Try(inputString.getString(11).trim.toLowerCase).getOrElse("no")
    val zipFile=Try(inputString.getString(12).trim.toLowerCase).getOrElse("no")
    val excludeColumn=Try(Some(inputString.getString(13).trim)).getOrElse(None)
    val excludeRow=Try(Some(inputString.getString(14).trim)).getOrElse(None)
    TableConf(srcConType,srcTableNm,alias,srcPrsnlQuery,header,schemaFile,tgtTableNm,
      tgtPrsnlQuery,bitemp,splitColumn,aggColumn,useTargetSchema,zipFile,excludeColumn,excludeRow)
  }


  /** The `TableConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param srcConType   source Connection Type.
    * @param srcTableNm   source Table Name .
    * @param alias         Alias.
    * @param srcPrsnlQuery   source Personal SQL Query .
    * @param header      whether header is present or not .
    * @param schemaFile    schema file hdfs path for files  .
    * @param tgtTableNm       target Table Name  .
    * @param tgtPrsnlQuery      target Personal SQL Query .
    * @param bitemp        By default "yes" , can be made "no" by user to remove bitemporal columns .
    * @param splitColumn  Partion column for parallel loading of table.
    * @param useTargetSchema defaultt"no" can be made "yes" by user if source table has differnt schema than target.
    * @param aggColumn      comma seperated  list of columns for sum check.
    * @param zipFile     By default "no" , can be made "yes" by user if source is zipped file .
    * @param excludeColumn comma delimited columns to be excluded
    */
  case class TableConf(srcConType:String,srcTableNm:String,alias:String,srcPrsnlQuery:Option[String],header:String,schemaFile:Option[String],tgtTableNm:String,
                     tgtPrsnlQuery:Option[String],bitemp:String,splitColumn:Option[String],aggColumn:Option[String],useTargetSchema:String,zipFile:String,excludeColumn:Option[String],excludeRow:Option[String]) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("srcConType", srcConType)
        .append("srcTableNm", srcTableNm)
        .append("alias", alias)
        .append("srcPrsnlQuery", srcPrsnlQuery)
        .append("header", header)
        .append("schemaFile", schemaFile)
        .append("tgtTableNm", tgtTableNm)
        .append("tgtPrsnlQuery", tgtPrsnlQuery)
        .append("bitemp", bitemp)
        .append("splitColumn", splitColumn)
        .append("aggColumn", aggColumn)
        .append("useTargetSchema", useTargetSchema)
        .append("zipFile", zipFile)
        .append("excludeColumn",excludeColumn)
        .append("excludeRow",excludeRow)
        .toString
    }
  }



}
