package com.rxcorp.bdf.Utilities.utils

import java.nio.file.Files
import java.nio.file.Paths
import scala.sys.process._
import java.awt.Color

import net.ruippeixotog.scalascraper.browser.JsoupBrowser
import net.ruippeixotog.scalascraper.dsl.DSL._
import net.ruippeixotog.scalascraper.dsl.DSL.Extract._
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.select.Elements

import scala.collection.JavaConversions._
import scalax.chart.api._
import scalax.chart.RingChart
import java.awt.Font

import org.jfree.chart.labels.StandardPieSectionLabelGenerator
import java.text.DecimalFormat

import com.rxcorp.bdf.Resolver.configs.Resolver
import com.rxcorp.bdf.Utilities.files.Constants
import com.sksamuel.scrimage.Image

import scala.collection.mutable
import com.rxcorp.bdf.utiljava.mail.Email.send

/** Created By Apoorv*/


object Extras extends Constants {

  /** The `appendHeader` method creates header for table to be sent in mail.
    * @param tables all table details to be attached in mail
    * @param headerType type of headet
    * @return StringBuilder building string for table details.
    */
  def appendHeader(tables:StringBuilder,headerType: Int): StringBuilder ={
    if(headerType==1){
      tables.append("<table border=\"1\"><tr><th style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;font-weight:700;border:2.0pt double #4472C4;'>Source System</th><th style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;font-weight:700;border:2.0pt double #4472C4;'>Alias</th><th style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;font-weight:700;border:2.0pt double #4472C4;'>Source</th><th style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;font-weight:700;border:2.0pt double #4472C4;'>Target</th><th style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;font-weight:700;border:2.0pt double #4472C4;'>Execution Status</th><th style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;font-weight:700;border:2.0pt double #4472C4;'>Loading Time</th><th style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;font-weight:700;border:2.0pt double #4472C4;'>Testing Time</th></tr>")
    }
    tables
  }

  /** The `appendRow` method add execution status details in mail for completed scenarios
    * @param resolver resolver containing all properties of an instance
    * @param tableNM target table name
    * @param rowType 1 is for pass, 2 for zero incremental records, 3 for source/target empty
    * @param loadTime total loading Time of data
    * @param testTimeEnd total testing Time
    * @return StringBuilder building string for table details.
    */

  def appendRow(tables:StringBuilder,resolver: Resolver.resolveConf,rowType: Int,loadTime:String,testTimeEnd:String,tableNM:String): StringBuilder ={
    if(rowType==1){
        tables.append("<tr><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + resolver.srcConType + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + resolver.alias + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + resolver.srcTableNm + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + tableNM + "</td><td style='color:#70AD47;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>Completed"+ "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + loadTime +  "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + testTimeEnd +"</td></tr>")
    }
    if(rowType==2){
      tables.append("<tr><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + resolver.srcConType + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + resolver.alias + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + resolver.srcTableNm + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + tableNM + "</td><td style='color:#70AD47;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>"+"Zero Incremental Records"+ "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + loadTime +  "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + testTimeEnd + "</td></tr>")
    }
    if(rowType==3){
      tables.append("<tr><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + resolver.srcConType + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + resolver.alias + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + resolver.srcTableNm+ "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + tableNM + "</td><td style='color:red;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>"+"Count zero for either source or target"+ "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + loadTime +  "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + testTimeEnd + "</td></tr>")

    }
    tables
  }

  /** The `appendException` method add execution status details in mail for exceptions
    * @param resolver resolver containing all properties of an instance
    * @param tableNM target table name
    * @param rowType 1 is for pass, 2 for zero incremental records, 3 for source/target empty
    * @param loadTime total loading Time of data
    * @param testTimeEnd total testing Time
    * @param except caught exception
    * @return StringBuilder building string for table details.
    */
  def appendException(tables:StringBuilder,resolver: Resolver.resolveConf,rowType: Int,loadTime:String,testTimeEnd:String,except:Exception,tableNM:String): StringBuilder = {
    if(rowType==1){
      tables.append("<tr><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + resolver.srcConType + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + resolver.alias + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + resolver.srcTableNm + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + tableNM + "</td><td style='color:red;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + except + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + loadTime + "</td><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + testTimeEnd + "</td></tr>")
    }
    tables
  }

  /** The `cleanUpHDFS` method cleans temp files created in hdfs
    * @param path hdfs path
    * @param alias alias name
    * @param deleteType 1 is for normal data load, 2 with bitemporality
    * @param runType total loading Time of data
    */
  def cleanUpHDFS(path:String,alias:String,deleteType:String,runType:Int): Unit ={
    if(runType==1 ){
      deleteType match {
        case `oracleType` | `db2Type` | `impalaType` | `exasolType` | `netezzaType` | `sqlserverType` | `teiidType` | `hiveType`  | `flatPipeType` | `flatCommaType` | `flatTildeType` | `flatTabType` | `flatSemiColonType` | `flatSFTPType` | `flatFTPType` | `flatSMBType` =>

          s"hadoop fs -rm -r $path/$alias/tgt/" !

          s"hadoop fs -rm -r $path/$alias/src/" !

          s"hadoop fs -rm -r $path/$alias/Ftp/" !

          s"hadoop fs -rm -r $path/$alias/Sftp/" !

          s"hadoop fs -rm -r $path/$alias/smb/" !

        case `fixedType` | `fixedSFTPType` | `fixedFTPType` | `fixedSMBType`=>

          s"hadoop fs -rm -r $path/$alias/tgt/" !

          s"hadoop fs -rm -r $path/$alias/src/" !

          s"hadoop fs -rm -r $path/$alias/Ftp/" !

          s"hadoop fs -rm -r $path/$alias/Sftp/" !

          s"hadoop fs -rm -r $path/$alias/smb/" !

          s"hadoop fs -rm -r $path/$alias/fixed/" !

      }}
    if(runType==3 ){
      deleteType match {
        case `oracleType` | `db2Type` | `impalaType` | `exasolType` | `netezzaType` | `sqlserverType` | `teiidType` | `hiveType` | `flatPipeType` | `flatCommaType` | `flatTildeType` | `flatTabType` | `flatSemiColonType` | `flatSFTPType` | `flatFTPType` | `flatSMBType`  =>

          s"hadoop fs -rm -r $path/$alias/prev_tgt/" !

          s"hadoop fs -rm -r $path/$alias/curr_tgt/" !

          s"hadoop fs -rm -r $path/$alias/src/" !

          s"hadoop fs -rm -r $path/$alias/Ftp/" !

          s"hadoop fs -rm -r $path/$alias/Sftp/" !

          s"hadoop fs -rm -r $path/$alias/smb/" !

         case `fixedType` | `fixedSFTPType` | `fixedFTPType` | `fixedSMBType` =>

          s"hadoop fs -rm -r $path/$alias/prev_tgt/" !

          s"hadoop fs -rm -r $path/$alias/curr_tgt/" !

          s"hadoop fs -rm -r $path/$alias/src/" !

          s"hadoop fs -rm -r $path/$alias/fixed/" !

          s"hadoop fs -rm -r $path/$alias/Ftp/" !

          s"hadoop fs -rm -r $path/$alias/Sftp/" !

           s"hadoop fs -rm -r $path/$alias/smb/" !


      }}
    if(runType==4 ){
      s"hadoop fs -rm -r $path/$alias/Ftp/" !
    }

  }

  /** The `createChart` method creates chart to be added in mail
    * @param input input data extracted from html scrapper
    * @param chartName name of chart
    * @param pngfileName png file name to be saved
    */
  def createChart(input:Seq[(String, Int)],chartName:String,pngfileName:String): Unit ={
    var chart = RingChart(input)
    chart.plot.setBackgroundPaint(Color.WHITE)
    chart.plot.setIgnoreZeroValues(true)
    chart.plot.setLabelLinksVisible(false)
    chart.plot.setLabelOutlinePaint(Color.WHITE)
    chart.plot.setLabelBackgroundPaint(Color.WHITE)
    chart.plot.setLabelShadowPaint(Color.WHITE)
    chart.plot.setExplodePercent("Error", 0.10)
    chart.plot.setExplodePercent("Fail", 0.10)
    chart.plot.setExplodePercent("Warning", 0.10)
    val gen = new StandardPieSectionLabelGenerator("{0}: {1} ({2})", new DecimalFormat("0"), new DecimalFormat("0%"))
    chart.plot.setLabelGenerator(gen)
    chart.plot.setOutlinePaint(Color.WHITE)
    chart.plot.setShadowPaint(Color.WHITE)
    chart.plot.setOutlineVisible(false)
    chart.plot.setSeparatorsVisible(false)
    chart.title_=(chartName)
    chart.plot.setSectionPaint("Pass", Color.GREEN)
    chart.plot.setSectionPaint("Fail", Color.RED)
    chart.plot.setSectionPaint("Warning", Color.ORANGE)
    chart.plot.setSectionPaint("Error", Color.BLUE)
    val font3 = new Font("SanSerif", Font.TRUETYPE_FONT, 20)
    chart.plot.setLabelFont(font3)
    chart.plot.setLabelPaint(Color.BLUE)
    chart.plot.setSectionDepth(.5)
    chart.plot.setBaseSectionOutlinePaint(Color.WHITE)
    chart.saveAsPNG(pngfileName)
    val byteArray1 = Files.newInputStream(Paths.get(pngfileName))
    import java.io.File
    Image.fromStream(byteArray1).scaleTo(420, 240).output(new File(pngfileName))
  }

  /** The `HTMLScrapper` method scraps html file to create info for mail.
    * @param confFilePath conf file path
    */

  def HTMLScrapper(confFilePath:String):(Seq[(String, Int)],Int,mutable.Map[String, String]) ={
    val tableStatus = mutable.HashMap[String, String]()
    val browser = JsoupBrowser()
    val doc = browser.parseFile(confFilePath)
    val items = doc >> elementList("script")
    val liDiv = doc >> elementList("li div")
    for (x <- liDiv) {
      val parse = Jsoup.parse(x.toString)
      val testHead = parse.getElementsByClass("test-heading")
      for (y <- testHead) {
        val testName = y.getElementsByClass("test-name").text().replaceAll("- Validation", "").trim()
        val testSta = y.getElementsByClass("test-status").text()
        tableStatus.put(testName, testSta)
      }
    }
    val tableTestCount: Int = tableStatus.size
    val a = Jsoup.parse(items(0).toString)
    val b: Elements = a.getElementsByTag("script")
    val c: Element = b(0)
    val d: String = c.data()
    val e = d.replaceAll("var statusGroup = \\{", "").replaceAll("};", "")
    val f = e.split(",")
    val k: Array[String] = f.map(x => x.trim).filterNot(_.isEmpty)
    val result = k.map(_.split(":")).map(arr => (arr(0).trim, arr(1).trim.toInt))
    val x = result.filter(_._1.contains("Parent")).filterNot(_._1.contains("exception"))
    val m = x.map { x => if (x._1.contains("Parent")) x._1.replaceAll("Parent", "").toLowerCase.capitalize -> x._2 else x }
    m.foreach(println)
    val scrappedData: Seq[(String, Int)] = m.toSeq
    (scrappedData,tableTestCount,tableStatus)
  }

  /** The `createResultTable` method creates reported details from scrapping html file.
    * @param tableStatus scrapped table details
    * @return String Table contating report status for all tables to be attached in mail
    */
  def createResultTable(tableStatus:mutable.Map[String, String]):String = {
    val tableStat = new StringBuilder()
    tableStat.append("<table border=\"1\"><tr><th style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;font-weight:700;border:2.0pt double #4472C4;'>Alias</th><th style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;font-weight:700;border:2.0pt double #4472C4;'>Report</th></tr>")
    for ((name, status) <- tableStatus) {
      status match {
        case "pass" => tableStat.append("<tr><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + name + "</td><td style='color:#70AD47;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + status.toLowerCase.capitalize + "</td></tr>")
        case "fail" => tableStat.append("<tr><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + name + "</td><td style='color:red;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + status.toLowerCase.capitalize + "</td></tr>")
        case "warning" => tableStat.append("<tr><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + name + "</td><td style='color:orange;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + status.toLowerCase.capitalize + "</td></tr>")
        case "error" => tableStat.append("<tr><td style='color:#305496;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + name + "</td><td style='color:red;padding-bottom:.75pt;padding-top:.75pt;border:2.0pt double #4472C4;'>" + status.toLowerCase.capitalize + "</td></tr>")
      }
    }
    tableStat.toString()
  }

  /** The `emailBuilder` method builds email template
    * @param runType runType
    * @param confFileName path to conf file
    * @param emailIds list of email ids(; delimited)
    * @param jobEnd total execution Time  of job
    * @param tables string containg table execution status
    * @param tableStat string contating results of validation
    * @param tableTestCount succesful execution test  counts
    * @param totalInputs total tables/files for validation count
    * @param environment env
    * @param asset asset
    * @param country country
    * @param tenant tenant
    */

  def emailBuilder(runType:Int,confFileName:String,emailIds:String,jobEnd:String,tables:String,tableStat:String,tableTestCount:String,totalInputs:String,environment:String,asset:String,country:String,tenant:String) ={
     if(runType==1){
     send("AutomationTestReport@in.imshealth", emailIds, s"$environment|$asset|$country|$tenant", s"<h2>Automation Result for $country|$asset</h2>" +
        "<br><p>Please find the comparison result of the following tables attached herewith.</p><br>" +
       s"<p>Total Tables/Files For Validation: $totalInputs </p>"+
       s"<p>No. of Tables/Files Validated: $tableTestCount </p>"+
       s"<p>Total Job Execution Time: $jobEnd </p>" +
       s"<p>Validation Results: </p>"+
       tableStat+"</table>"+
       s"<p>Validation List: </p>"+
       tables +"</table>"+
        "<p>QA Team</p>" +
        "<p>Sparxta version:2.0.1-SNAPSHOT</p>",s"${confFileName}_comparison.html")
    } else if (runType==2) {
      send("AutomationTestReport@in.imshealth", emailIds, s"$environment|$asset|$country|$tenant", s"<h2>Automation Result for  $country|$asset</h2>" +
        "<br><p>Please find the comparison result of the following tables attached herewith.</p><br>"+
       s"<p>Total Tables/Files For Validation: $totalInputs </p>"+
         s"<p>No. of Tables/Files Validated: 0 </p>"+
        s"<p>Validation List: </p>"+
        tables.toString() +
        "</table><br><p>QA Team</p>"
      +"<p>Sparxta version:2.0.1-SNAPSHOT</p>")
    } else if (runType==3) {
      send("AutomationTestReport@in.imshealth", emailIds, s"$environment|$asset|$country|$tenant", s"<h2>Automation Result for $country|$asset</h2>" +
        "<br><p>Please find the comparison result of the following tables attached herewith.</p><br>" +
        s"<p>Total Tables/Files For Validation: $totalInputs </p>"+
        s"<p>No. of Tables/Files Validated: $tableTestCount </p>"+
        s"<p>Total Job Execution Time: $jobEnd </p>"+
       s"<p>Validation Results: </p>"+
         tableStat + "</table>" +
        s"<p>Validation List: </p>"+
        tables + "</table>" +
        "<img src=\"cid:image1\"><img src=\"cid:image\">" +
        "<p>QA Team</p>"+
        "<p>Sparxta version:2.0.1-SNAPSHOT</p>", s"${confFileName}_comparison.html", s"${confFileName}_chart.png", s"${confFileName}_chart1.png")
    }
     else if (runType==4) {
       send("AutomationTestReport@in.imshealth", emailIds, s"$environment|$asset|$country|$tenant", s"<h2>Automation Result for $country|$asset</h2>" +
         "<br><p>Please find the comparison result of the following tables attached herewith.</p><br>" +
         s"<p>Total Tables/Files For Validation: $totalInputs </p>"+
         s"<p>No. of Tables/Files Validated: $tableTestCount </p>"+
         s"<p>Total Job Execution Time: $jobEnd </p>"+
         s"<p>Validation Results: </p>"+
         tableStat + "</table>" +
         s"<p>Validation List: </p>"+
         tables + "</table>" +
         "<img src=\"cid:image1\"><img src=\"cid:image\">" +
         "<p>QA Team</p>"+
         "<p>Sparxta version:2.0.1-SNAPSHOT</p>", s"${confFileName}_comparison.html", s"${confFileName}_chart.png", s"${confFileName}_chart1.png",s"${System.getProperty("java.io.tmpdir")}/${environment}${asset}${tenant}${country}.csv")
     }

  }

  }
