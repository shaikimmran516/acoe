package com.rxcorp.bdf.Utilities.logger


import com.rxcorp.bdf.logging.internal.{LoggingConf, Settings, StandardImsLogger}
import com.typesafe.config.Config

object QIMSLoggerFactory {
  private var imsLogger: StandardImsLogger = _

  def getLogger:Some[QIMSLogger] = synchronized{
    if (imsLogger != null)
      Some(new QIMSLogger(imsLogger))
    else
      Some(new QIMSLogger(StandardImsLogger.logger))
  }

  def apply(loggerConfig: Config): QIMSLogger = synchronized {
    if (imsLogger == null) {
      val logger: StandardImsLogger = StandardImsLogger.logger
      logger.setConfig(LoggingConf(loggerConfig))
      logger.setEventAttributes(Settings(loggerConfig))
      imsLogger = logger
    }
    new QIMSLogger(imsLogger)
  }
}


