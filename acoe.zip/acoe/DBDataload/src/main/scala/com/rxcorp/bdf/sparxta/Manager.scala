package com.rxcorp.bdf.sparxta

import scala.io.{BufferedSource, Source}
import java.util.Properties

import scala.sys.process._
import com.rxcorp.bdf.Utilities.logger.{QIMSLogger, QIMSLoggerFactory}
import com.rxcorp.bdf.Utilities.spark.AppResolver
import com.rxcorp.bdf.logging.log._
import org.apache.commons.io.FileUtils
import java.io.File

import scopt.OptionParser

/** The `Manager` object holds the mainClass for the jar
* It offers parser to parse and validate the received commands line arguments
* and invokes Spark job
*/
import scala.collection.mutable
object Manager  extends App {

    val parser: OptionParser[CmdManagerArguments] = new scopt.OptionParser[CmdManagerArguments]("com.rxcorp.bdf.Utilities.sparxta.Manager"){
      head("Module:", "sparxta")

      opt[String]("sparkProps").required.action( (x, c) =>
        c.copy(sparkProps = x)
      ).text("sparkProps  is required!")

      opt[String]("runType").required.action( (x, c) =>
        c.copy(runType = x)
      ).text("runType  is required!")

      opt[String]("environment").required.action( (x, c) =>
        c.copy(environment = x)
      ).text("environment  is required!")

      opt[String]("jdbcUrl").action( (x, c) =>
        c.copy(jdbcUrl = x)
      ).text("jdbcUrl is optional!")

      opt[String]("jdbcTgt").action( (x, c) =>
        c.copy(jdbcTgt = x)
      ).text("jdbcTgt is optional!")

      opt[String]("sftpUser").action( (x, c) =>
        c.copy(sftpUser = x)
      ).text("sftpUser is optional!")

      opt[String]("sftpPass").action( (x, c) =>
        c.copy(sftpPass = x)
      ).text("sftpPass is optional!")

      opt[String]("ftpUser").action( (x, c) =>
        c.copy(ftpUser = x)
      ).text("ftpUser is optional!")

      opt[String]("ftpPass").action( (x, c) =>
        c.copy(ftpPass = x)
      ).text("ftpPass is optional!")

      opt[String]("smbUser").action( (x, c) =>
        c.copy(smbUser = x)
      ).text("smbUser is optional!")

      opt[String]("smbPass").action( (x, c) =>
        c.copy(smbPass = x)
      ).text("smbPass is optional!")

      note(
        s"""
           |Sample Args: --sparkProps <path-to-spark.properties-file>
           |--runType <run Type>
           |--jdbcUrl <jdbcUrl>
           |--jdbcTgt <jdbcTgt>
           |--sftpUser <Sftp User name>
           |--sftpPass <Sftp Pass name>
           |--ftpUser <Ftp User name>
           |--ftpPass <Ftp Pass name>
           |--smbUser <smb User name>
           |--smbPass <smb Pass name>
           |--environment <environment>
       """.stripMargin
      )
    }
  /** The `Manager` object holds the main class of the job.
    * It validates the commandline arguments starts and triggers the spark job.
    */



    var propsFile=""

    parser.parse(args, CmdManagerArguments()) match {
      case Some(cmdLineArgs) =>
        require(cmdLineArgs.sparkProps.nonEmpty, s"Spark Property File: ${cmdLineArgs.sparkProps} is required!")
        propsFile = cmdLineArgs.sparkProps
        require(Range(1,6).contains(cmdLineArgs.runType.toInt), "Run Type ranges from 1 to 5 only!")
        val source: BufferedSource = Source.fromFile(propsFile)
        val sparkMandatoryProp: Properties = new Properties
        sparkMandatoryProp.load(source.bufferedReader())
        val loggerOpts: mutable.Map[EventAttribute, String] = mutable.Map(jobType -> "Scala", module -> "DBDataload")
        loggerOpts += (componentLifecycle -> cmdLineArgs.environment)
        val sparkResolve: SparkResolver.sparkConf =com.rxcorp.bdf.sparxta.SparkResolver.getSparkConfig(sparkMandatoryProp,cmdLineArgs)
        if(sparkResolve.asset.trim.nonEmpty) loggerOpts += (asset -> sparkResolve.asset)
        if(sparkResolve.countryName.trim.nonEmpty) loggerOpts += (countryScope -> sparkResolve.countryName)
        val sparkOptionalProp= com.rxcorp.bdf.Utilities.spark.AppResolver.readSparkProps(propsFile)
        val logger: QIMSLogger = QIMSLoggerFactory.apply(AppResolver.readFromConfigFile.loggerConfig)
        if(loggerOpts.nonEmpty) logger.addOptions(loggerOpts)
        logger.info(this.getClass, s"Job Started")
        com.rxcorp.bdf.Utilities.spark.SparkLaunch.invokeSparkJob(sparkResolve,sparkOptionalProp)
        val localTmpDir: String = System.getProperty("java.io.tmpdir")
         s"hadoop fs -get ${localTmpDir}/${sparkResolve.environment}_${sparkResolve.tenant}_${sparkResolve.asset}_${sparkResolve.countryName}.txt/part* ${localTmpDir}/${sparkResolve.environment}_${sparkResolve.tenant}_${sparkResolve.asset}_${sparkResolve.countryName}.txt" !

        val lines: String = scala.io.Source.fromFile(s"${localTmpDir}/${sparkResolve.environment}_${sparkResolve.tenant}_${sparkResolve.asset}_${sparkResolve.countryName}.txt/").mkString.trim
        val exit_code : String = lines.takeWhile(_ != null).mkString("\n")
        FileUtils.deleteQuietly(new File(s"${localTmpDir}/${sparkResolve.environment}_${sparkResolve.tenant}_${sparkResolve.asset}_${sparkResolve.countryName}.txt"))
        sys.exit(exit_code.trim().toInt)
      case None =>
        Console.err.println("Missing Arguments!")
    }


}
