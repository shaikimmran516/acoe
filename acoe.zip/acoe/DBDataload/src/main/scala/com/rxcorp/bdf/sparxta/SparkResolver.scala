package com.rxcorp.bdf.sparxta

import java.util.Properties

import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}

import scala.util.Try

object SparkResolver extends SparkConstants {


  def getSparkConfig(sparkProp: Properties,cmdArgs:CmdManagerArguments):sparkConf = {
    val keytab= Try(sparkProp.getProperty("keytab").trim).getOrElse(throw new Exception("keytab is missing"))
    val principal = Try(sparkProp.getProperty("principal").trim).getOrElse(throw new Exception("principal is missing"))
    val queue= Try(sparkProp.getProperty("queue").trim).getOrElse(throw new Exception("queue is missing"))
    val configFile=Try(sparkProp.getProperty("configFile").trim).getOrElse(throw new Exception("configFile is missing"))
    val path=Try(sparkProp.getProperty("path").trim).getOrElse(throw new Exception("jar path is missing"))
    val className=Try(sparkProp.getProperty("class").trim).getOrElse(throw new Exception("class name is missing"))
    val asset=Try(sparkProp.getProperty("asset").trim).getOrElse(throw new Exception("asset is missing"))
    val deployMode=Try(sparkProp.getProperty("deploy-mode").trim).getOrElse(throw new Exception("depoly-mode is missing"))
    val countryName=Try(sparkProp.getProperty("country").trim).getOrElse(throw new Exception("country is missing"))
    val environment=Try(cmdArgs.environment).getOrElse(throw new Exception("environment is missing"))
    val tenant=Try(sparkProp.getProperty("tenant").trim).getOrElse(throw new Exception("tenant is missing"))
    val runType=Try(cmdArgs.runType).getOrElse(throw new Exception("runType is missing"))
    val jdbcUrl=Try(Some(cmdArgs.jdbcUrl)).getOrElse(None)
    val jdbcTgt=Try(Some(cmdArgs.jdbcTgt)).getOrElse(None)
    val sftpUser=Try(Some(cmdArgs.sftpUser)).getOrElse(None)
    val sftpPass=Try(Some(cmdArgs.sftpPass)).getOrElse(None)
    val ftpUser=Try(Some(cmdArgs.ftpUser)).getOrElse(None)
    val ftpPass=Try(Some(cmdArgs.ftpPass)).getOrElse(None)
    val smbUser=Try(Some(cmdArgs.smbUser)).getOrElse(None)
    val smbPass=Try(Some(cmdArgs.smbPass)).getOrElse(None)
    sparkConf(keytab,principal,queue,configFile,path,className,asset,deployMode,countryName,environment,runType,jdbcUrl,jdbcTgt,sftpUser,sftpPass,ftpUser,ftpPass,tenant,smbUser,smbPass)
  }

  /** The `sparkConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param keytab   keytab path .
    * @param principal   principal name .
    * @param queue         queue name.
    * @param configFile    conf File Path .
    * @param path      path to spark jar.
    * @param className    class name .
    * @param asset         asset .
    * @param deployMode      deploy mode.
    * @param countryName country name .
    * @param environment      environment .
    * @param runType     runType .
    * @param jdbcUrl        jdbcUrl for source database.
    * @param sftpUser      Sftp user name.
    * @param sftpPass       Sftp password.
    * @param jdbcTgt        jdbc target database.
    * @param ftpUser      Ftp user name.
    * @param ftpPass       Ftp password.
    * @param tenant         tenant name.
    */
  case class sparkConf(keytab:String,principal:String,queue:String,configFile:String,path:String,className:String,asset:String,
                       deployMode:String,countryName:String,environment:String,runType:String,jdbcUrl:Option[String],jdbcTgt:Option[String],sftpUser:Option[String],sftpPass:Option[String],ftpUser:Option[String],ftpPass:Option[String],tenant:String,smbUser:Option[String],smbPass:Option[String]) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("keytab", keytab)
        .append("principal", principal)
        .append("queue",queue)
        .append("configFile", configFile)
        .append("path", path)
        .append("className", className)
        .append("asset", asset)
        .append("deployMode", deployMode)
        .append("countryName", countryName)
        .append("environment", environment)
        .append("runType", runType)
        .append("jdbcUrl", jdbcUrl)
        .append("jdbcTgt", jdbcTgt)
        .append("sftpUser", sftpUser)
        .append("sftpPass",sftpPass)
        .append("ftpUser", ftpUser)
        .append("ftpPass",ftpPass)
        .append("tenant",tenant)
        .append("smbUser",smbUser)
        .append("smbPass",smbPass)
        .toString
    }
  }

}
