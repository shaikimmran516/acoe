package com.rxcorp.bdf.Resolver.table

import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}
import org.apache.spark.sql.Row

import scala.util.Try
/** Created By Apoorv*/
object MiniBiFilesDetails {

  /** The `getBiMiniFileDetails` method returns [[miniBiFilesConf]] case class instance by resolving the  files  with bitemporality from .csv file for mini version
    * @param inputString Row contains values from .csv file
    * @return [[miniBiFilesConf]]
    */

  def getBiMiniFileDetails(inputString: Row):miniBiFilesConf = {
    val srcConType= Try(inputString.getString(0).trim).getOrElse(throw new Exception("Connection Type Missing"))
    val srcTableNm= Try(inputString.getString(1).trim).getOrElse(throw new Exception("Source File name Missing"))
    val schemaFile: Option[String] =Try(Some(inputString.getString(2).trim)).getOrElse(throw new Exception("Schema File name Missing"))
    val post=Try(Some(inputString.getString(3))).getOrElse(None)
    val header=Try(inputString.getString(4).trim.toLowerCase).getOrElse("no")
    val footer=Try(inputString.getString(5).trim.toLowerCase).getOrElse("no")
    val alias=Try(inputString.getString(6).trim).getOrElse(throw new Exception("Alias is Missing"))
    val srcWhere=Try(Some(inputString.getString(7).trim)).getOrElse(None)
    val prevHistory= Try(inputString.getString(8).trim).getOrElse(throw new Exception("Previous History Target Table is Missing"))
    val currHistory=Try(inputString.getString(9).trim).getOrElse(throw new Exception("Current History Target Table is Missing"))
    val tgtWhere=Try(Some(inputString.getString(10).trim)).getOrElse(None)
    val primaryKey=Try(inputString.getString(11).trim).getOrElse(throw new Exception("Primary Key is Missing"))
    val runOption=Try(inputString.getString(12).toLowerCase.trim).getOrElse(throw new Exception("Run Option is Missing"))
    val bussEffMapping=Try(Some(inputString.getString(13).trim)).getOrElse(None)
    val zipFile=Try(inputString.getString(14)).getOrElse("no")
    val mode =Try(inputString.getString(12)).getOrElse("overwrite")

    miniBiFilesConf(srcConType,srcTableNm,schemaFile,alias,post,header,footer,srcWhere,
      tgtWhere,prevHistory,currHistory,primaryKey,runOption,bussEffMapping,zipFile,mode)
  }

  /** The `miniBiFilesConf` case class offers access to the values held in the parameters for an instance.
    * @param srcConType   source Connection Type.
    * @param srcTableNm   source Table Name
    * @param post        Record identifier , if value is specified, then only those records from fixed length file will be extracted.
    * @param alias         Alias.
    * @param header      whether header is present or not .
    * @param footer      whether footer is present or not.
    * @param schemaFile    schema file hdfs path for files  .
    * @param tgtWhere   target where Query .
    * @param prevHistory   previous history table.
    * @param currHistory      current history table.
    * @param primaryKey    comma seperated primary keys  .
    * @param runOption      run option .
    * @param bussEffMapping     column mapped to business effective date.
    * @param zipFile     By default "no" , can be made "yes" by user if source is zipped file .
    * @param mode By default "overwrite" , can be changed by user to append for incremental load.
    */
  case class miniBiFilesConf(srcConType:String,srcTableNm:String,schemaFile:Option[String],alias:String,post:Option[String],header:String,footer:String,srcWhere:Option[String],
                           tgtWhere:Option[String],prevHistory:String,currHistory:String,primaryKey:String,runOption:String,bussEffMapping:Option[String],zipFile:String,mode:String) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("srcConType", srcConType)
        .append("srcTableNm", srcTableNm)
        .append("schemaFile", schemaFile)
        .append("post", post)
        .append("header", header)
        .append("footer", footer)
        .append("alias", alias)
        .append("srcWhere", srcWhere)
        .append("tgtWhere", tgtWhere)
        .append("prevHistory", prevHistory)
        .append("currHistory", currHistory)
        .append("primaryKey", primaryKey)
        .append("runOption", runOption)
        .append("bussEffMapping", bussEffMapping)
        .append("zipFile", zipFile)
        .append("mode",mode)
        .toString
    }
  }

}
