package com.rxcorp.bdf.Utilities.Db

import scala.util.matching.Regex

/** The `DBRegexPatterns` trait offers constants for RDBMS datatype regex patterns. */
trait DBRegexPatterns {

  /** The [[BIGDECIMALPattern]] variable holds the `(BIGDECIMAL)(\(\d+\))?` regex pattern. */
  val BIGDECIMALPattern :Regex = "(BIGDECIMAL)(\\(\\d+\\))?".r

  /** The [[BIGINTPattern]] variable holds the `(BIGINT)(\(\d+\))?` regex pattern. */
  val BIGINTPattern :Regex = "(BIGINT)(\\(\\d+\\))?".r

  /** The [[BIGINTIDENTITYPattern]] variable holds the `(INT)(\(\d+\))?` regex pattern. */
  val BIGINTIDENTITYPattern: Regex = "(BIGINT\\s+IDENTITY)(\\(\\d+\\))?".r

  /** The [[BIGINTEGERPattern]] variable holds the `(BIGINTEGER)(\(\d+\))?` regex pattern. */
  val BIGINTEGERPattern :Regex = "(BIGINTEGER)(\\(\\d+\\))?".r

  /** The [[BINARYPattern]] variable holds the `(BINARY)(\(\d+\))?` regex pattern. */
  val BINARYPattern: Regex = "(BINARY)(\\(\\d+\\))?".r

  /** The [[BINARYDOUBLEPattern]] variable holds the `(BINARY_DOUBLE)(\(\d+\))?` regex pattern. */
  val BINARYDOUBLEPattern: Regex = "(BINARY_DOUBLE)(\\(\\d+\\))?".r

  /** The [[BINARYFLOATPattern]] variable holds the `(BINARY_FLOAT)(\(\d+\))?` regex pattern. */
  val BINARYFLOATPattern: Regex = "(BINARY_FLOAT)(\\(\\d+\\))?".r

  /** The [[BITPattern]] variable holds the `(BIT)(\(\d+\))?` regex pattern. */
  val BITPattern: Regex = "(BIT)(\\(\\d+\\))?".r

  /** The [[BLOBPattern]] variable holds the `(BLOB)(\(\d+\))?` regex pattern. */
  val BLOBPattern: Regex = "(BLOB)(\\(\\d+\\))?".r

  /** The [[BOOLPattern]] variable holds the `(BOOL)(\(\d+\))?` regex pattern. */
  val BOOLPattern: Regex = "(BOOL)(\\(\\d+\\))?".r

  /** The [[BOOLEANPattern]] variable holds the `(BOOLEAN)(\(\d+\))?` regex pattern. */
  val BOOLEANPattern: Regex = "(BOOLEAN)(\\(\\d+\\))?".r

  /** The [[BYTEPattern]] variable holds the `(BYTE)(\(\d+\))?` regex pattern. */
  val BYTEPattern: Regex  = "(BYTE)(\\(\\d+\\))?".r

  /** The [[BYTEINTPattern]] variable holds the `(BYTEINT)(\(\d+\))?` regex pattern. */
  val BYTEINTPattern: Regex  = "(BYTEINT)(\\(\\d+\\))?".r

  /** The [[CLOBPattern]] variable holds the `(CLOB)(\(\d+\))?` regex pattern. */
  val CLOBPattern: Regex = "(CLOB)(\\(\\d+\\))?".r

  /** The [[CHARPattern]] variable holds the `(CHAR)(\(\d+\))?` regex pattern. */
  val CHARPattern: Regex = "(CHAR)(\\(\\d+\\))?".r

  /** The [[DATEPattern]] variable holds the `(DATE)(\(\d+\))?` regex pattern. */
  val DATEPattern: Regex = "(DATE)(\\(\\d+\\))?".r

  /** The [[DATETIMEPattern]] variable holds the `(DATETIME)(\(\d+\))?` regex pattern. */
  val DATETIMEPattern: Regex = "(DATETIME)(\\(\\d+\\))?".r

  /** The [[DATETIME2Pattern]] variable holds the `(DATETIME2)(\(\d+\))?` regex pattern. */
  val DATETIME2Pattern: Regex = "(DATETIME2)(\\(\\d+\\))?".r

  /** The [[DATETIMEOFFSETPattern]] variable holds the `(DATETIMEOFFSET([0-9]))(\(\d+\))?` regex pattern. */
  val DATETIMEOFFSETPattern: Regex = "(DATETIMEOFFSET([0-9]))(\\(\\d+\\))?".r

  /** The [[DBCLOBPattern]] variable holds the `(DBCLOBPattern)(\(\d+\))?` regex pattern. */
  val DBCLOBPattern: Regex = "(DBCLOBPattern)(\\(\\d+\\))?".r

  /** The [[DECIMALPattern]] variable holds the `(DECIMAL)(\(\d+\))?` regex pattern. */
  val DECIMALPattern: Regex = "(DECIMAL)(\\(\\d+\\))?".r

  /** The [[DOUBLEPattern]] variable holds the `(DOUBLE)(\(\d+\))?` regex pattern. */
  val DOUBLEPattern: Regex = "(DOUBLE)(\\(\\d+\\))?".r

  /** The [[DOUBLEPRECISIONPattern]] variable holds the `(DOUBLE PRECISION)(\(\d+\))?` regex pattern. */
  val DOUBLEPRECISIONPattern: Regex = "(DOUBLE PRECISION)(\\(\\d+\\))?".r

  /** The [[FLOATPattern]] variable holds the `(FLOAT)(\(\d+\))?` regex pattern. */
  val FLOATPattern: Regex = "(FLOAT)(\\(\\d+\\))?".r

  /** The [[GRAPHICPattern]] variable holds the `(GRAPHIC)(\(\d+\))?` regex pattern. */
  val GRAPHICPattern: Regex = "(GRAPHIC)(\\(\\d+\\))?".r

  /** The [[IMAGEPattern]] variable holds the `(IMAGE)(\(\d+\))?` regex pattern. */
  val IMAGEPattern: Regex = "(IMAGE)(\\(\\d+\\))?".r

  /** The [[INTPattern]] variable holds the `(INT)(\(\d+\))?` regex pattern. */
  val INTPattern: Regex = "(INT)(\\(\\d+\\))?".r

  /** The [[INTIDENTITYPattern]] variable holds the `(INT)(\(\d+\))?` regex pattern. */
  val INTIDENTITYPattern: Regex = "(INT\\s+IDENTITY)(\\(\\d+\\))?".r

  /** The [[INTEGERPattern]] variable holds the `(INTEGER)(\(\d+\))?` regex pattern. */
  val INTEGERPattern: Regex = "(INTEGER)(\\(\\d+\\))?".r

  /** The [[INTERVALPattern]] variable holds the `(INTERVAL)(\(\d+\))?` regex pattern. */
  val INTERVALPattern: Regex = "(INTERVAL)(\\(\\d+\\))?".r

  /** The [[LONGPattern]] variable holds the `(LONG)(\(\d+\))?` regex pattern. */
  val LONGPattern: Regex = "(LONG)(\\(\\d+\\))?".r

  /** The [[MONEYPattern]] variable holds the `(MONEY)(\(\d+\))?` regex pattern. */
  val MONEYPattern: Regex = "(MONEY)(\\(\\d+\\))?".r

  /** The [[NCHARPattern]] variable holds the `(NCHAR)(\(\d+\))?` regex pattern. */
  val NCHARPattern: Regex = "(NCHAR)(\\(\\d+\\))?".r

  /** The [[NCLOBPattern]] variable holds the `(NCLOB)(\(\d+\))?` regex pattern. */
  val NCLOBPattern: Regex = "(NCLOB)(\\(\\d+\\))?".r

  /** The [[NTEXTPattern]] variable holds the `(NTEXT)(\(\d+\))?` regex pattern. */
  val NTEXTPattern: Regex = "(NTEXT)(\\(\\d+\\))?".r

  /** The [[NUMBERPattern]] variable holds the `(NUMBER)(\(\d+\))?` regex pattern. */
  val NUMBERPattern: Regex = "(NUMBER)(\\(\\d+\\))?".r

  /** The [[NUMERICPattern]] variable holds the `(NUMERIC)(\(\d+\))?` regex pattern. */
  val NUMERICPattern: Regex = "(NUMERIC)(\\(\\d+\\))?".r

  /** The [[NVARCHARPattern]] variable holds the `(NVARCHAR)(\(\d+\))?` regex pattern. */
  val NVARCHARPattern: Regex = "(NVARCHAR)(\\(\\d+\\))?".r

  /** The [[NVARCHAR2Pattern]] variable holds the `(NVARCHAR2)(\(\d+\))?` regex pattern. */
  val NVARCHAR2Pattern: Regex = "(NVARCHAR2)(\\(\\d+\\))?".r

  /** The [[NzINT124Pattern]] variable holds the `(INT[1-4])(\(\d+\))?` regex pattern.
    * This pattern applies for INT1, INT2 and INT4 of Netezza.
    */
  val NzINT124Pattern: Regex = "(INT[1-4])(\\(\\d+\\))?".r

  /** The [[NzINT8Pattern]] variable holds the `(INT8)(\(\d+\))?` regex pattern. */
  val NzINT8Pattern: Regex = "(INT8)(\\(\\d+\\))?".r

  /** The [[RAWPattern]] variable holds the `(RAW)(\(\d+\))?` regex pattern. */
  val RAWPattern: Regex = "(RAW)(\\(\\d+\\))?".r

  /** The [[REALPattern]] variable holds the `(REAL)(\(\d+\))?` regex pattern. */
  val REALPattern: Regex = "(REAL)(\\(\\d+\\))?".r

  /** The [[ROWIDPattern]] variable holds the `(ROWID)(\(\d+\))?` regex pattern. */
  val ROWIDPattern: Regex = "(ROWID)(\\(\\d+\\))?".r

  /** The [[SERIALPattern]] variable holds the `(SERIAL)(\(\d+\))?` regex pattern. */
  val SERIALPattern: Regex = "(SERIAL)(\\(\\d+\\))?".r

  /** The [[SHORTPattern]] variable holds the `(SHORT)(\(\d+\))?` regex pattern. */
  val SHORTPattern: Regex = "(SHORT)(\\(\\d+\\))?".r

  /** The [[SMALLINTPattern]] variable holds the `(SMALLINT)(\(\d+\))?` regex pattern. */
  val SMALLINTPattern: Regex = "(SMALLINT)(\\(\\d+\\))?".r

  /** The [[SMALLDATETIMEPattern]] variable holds the `(SMALLDATETIME)(\(\d+\))?` regex pattern. */
  val SMALLDATETIMEPattern: Regex = "(SMALLDATETIME)(\\(\\d+\\))?".r

  /** The [[SMALLMONEYPattern]] variable holds the `(SMALLMONEY)(\(\d+\))?` regex pattern. */
  val SMALLMONEYPattern: Regex = "(SMALLMONEY)(\\(\\d+\\))?".r

  /** The [[STRINGPattern]] variable holds the `(STRING)(\(\d+\))?` regex pattern. */
  val STRINGPattern: Regex = "(STRING)(\\(\\d+\\))?".r

  /** The [[TEXTPattern]] variable holds the `(TEXT)(\(\d+\))?` regex pattern. */
  val TEXTPattern: Regex = "(TEXT)(\\(\\d+\\))?".r

  /** The [[TINYINTPattern]] variable holds the `(TINYINT)(\(\d+\))?` regex pattern. */
  val TINYINTPattern: Regex = "(TINYINT)(\\(\\d+\\))?".r

  /** The [[TIMEPattern]] variable holds the `(TIME)(\(\d+\))?` regex pattern. */
  val TIMEPattern: Regex = "(TIME)(\\(\\d+\\))?".r

  /** The [[TIMETZPattern]] variable holds the `(TIMETZ)(\(\d+\))?` regex pattern. */
  val TIMETZPattern: Regex = "(TIMETZ)(\\(\\d+\\))?".r

  /** The [[TIMEWTZPattern]] variable holds the `(TIME_WITH_TIME_ZONE)(\(\d+\))?` regex pattern. */
  val TIMEWTZPattern: Regex = "(TIME_WITH_TIME_ZONE)(\\(\\d+\\))?".r

  /** The [[TSPattern]] variable holds the `(TIMESTAMP)(\(\d+\))?` regex pattern. */
  val TSPattern: Regex = "(TIMESTAMP)(\\(\\d+\\))?".r

  /** The [[UDTPattern]] variable holds the `(UDT)(\(\d+\))?` regex pattern. */
  val UDTPattern: Regex = "(UDT)(\\(\\d+\\))?".r

  /** The [[UNIQUEIDENTIFIERPattern]] variable holds the `(UNIQUEIDENTIFIER)(\(\d+\))?` regex pattern. */
  val UNIQUEIDENTIFIERPattern: Regex = "(UNIQUEIDENTIFIER)(\\(\\d+\\))?".r

  /** The [[UROWIDPattern]] variable holds the `(UROWID)(\(\d+\))?` regex pattern. */
  val UROWIDPattern: Regex = "(UROWID)(\\(\\d+\\))?".r

  /** The [[VARBINARYPattern]] variable holds the `(VARBINARY)(\(\d+\))?` regex pattern. */
  val VARBINARYPattern: Regex = "(VARBINARY)(\\(\\d+\\))?".r

  /** The [[VARCHARPattern]] variable holds the `(VARCHAR)(\(\d+\))?` regex pattern. */
  val VARCHARPattern: Regex = "(VARCHAR)(\\(\\d+\\))?".r

  /** The [[VARCHAR2Pattern]] variable holds the `(VARCHAR2)(\(\d+\))?` regex pattern. */
  val VARCHAR2Pattern: Regex = "(VARCHAR2)(\\(\\d+\\))?".r

  /** The [[VARGRAPHICPattern]] variable holds the `(VARGRAPHIC)(\(\d+\))?` regex pattern. */
  val VARGRAPHICPattern: Regex = "(VARGRAPHIC)(\\(\\d+\\))?".r

  /** The [[XMLPattern]] variable holds the `(XML)(\(\d+\))?` regex pattern. */
  val XMLPattern: Regex = "(XML)(\\(\\d+\\))?".r
}
