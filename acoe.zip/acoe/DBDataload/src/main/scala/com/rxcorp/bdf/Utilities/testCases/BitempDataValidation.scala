package com.rxcorp.bdf.Utilities.testCases

import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{Column, DataFrame, Dataset, Row}

/** Created By Apoorv*/
object BitempDataValidation {

  /** The `assertDataFrameEqualsB` method compares 2 dataframes and return the counts of unmatched rows
    * @param srcData Workflow ID assigned to the job to be launched
    * @param tgtData Execution details
    * @param isRelaxed Index of the execution for the current job to process
    * @return True or false with counts from both source and target of unmatched rows.
    */


  def assertDataFrameEqualsB(srcData: Dataset[Row], tgtData: Dataset[Row], isRelaxed: Boolean): (Boolean,Long,Long)= {

    var counts1:Long=0
    var counts2:Long=0

    try {
      srcData.rdd.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      tgtData.rdd.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      val srcColumns: Array[String] = srcData.columns
      val tgtColumns: Array[String] = tgtData.columns
      scala.util.Sorting.quickSort(srcColumns)
      scala.util.Sorting.quickSort(tgtColumns)
      val srcSeq: Seq[Column] = srcColumns.map(col(_))
      val tgtSeq: Seq[Column] = tgtColumns.map(col(_))
      val srcPrime=  if (isRelaxed){srcData} else {srcData.sort(srcSeq: _*)}
      val tgtPrime=  if (isRelaxed){tgtData} else {tgtData.sort(tgtSeq: _*)}
      val srcCompareTgt = srcPrime.except(tgtPrime)
      counts1 = srcCompareTgt.count()
      val tgtComapreSrc = tgtPrime.except(srcPrime)
      counts2 = tgtComapreSrc.count()
      if (counts1 != counts2 || counts1 != 0 || counts2 != 0) {
        return (false,counts1,counts2)
      }
    } finally {
      srcData.rdd.unpersist()
      tgtData.rdd.unpersist()
    }

    (true,counts1,counts2)
  }
}

