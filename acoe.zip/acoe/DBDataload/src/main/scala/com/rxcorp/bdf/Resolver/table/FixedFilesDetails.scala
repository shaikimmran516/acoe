package com.rxcorp.bdf.Resolver.table

import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}
import org.apache.spark.sql.Row

import scala.util.Try
/** Created By Apoorv*/
object FixedFilesDetails extends FixedFileConstants {

  /** The `getFixedFileDetails` method returns [[FixedConf]] case class instance by resolving the fixed length files from .csv file
    * @param inputString Row contains values from .csv file
    * @return [[FixedConf]]
    */

  def getFixedFileDetails(inputString: Row):FixedConf = {
    val srcConType= Try(inputString.getString(0).trim).getOrElse(throw new Exception("Connection Type Missing"))
    val srcTableNm= Try(inputString.getString(1).trim).getOrElse(throw new Exception("Source File name Missing"))
    val schemaFile: Option[String] =Try(Some(inputString.getString(2).trim)).getOrElse(throw new Exception("Schema File name Missing"))
    val post=Try(Some(inputString.getString(3))).getOrElse(None)
    val header=Try(inputString.getString(4).trim.toLowerCase).getOrElse("no")
    val footer=Try(inputString.getString(5).trim.toLowerCase).getOrElse("no")
    val alias=Try(inputString.getString(6).trim).getOrElse(throw new Exception("Alias is Missing"))
    val srcPrsnlQuery=Try(Some(inputString.getString(7).trim)).getOrElse(None)
    val tgtTableNm=Try(inputString.getString(8).trim).getOrElse(throw new Exception("Target Table is Missing"))
    val tgtPrsnlQuery=Try(Some(inputString.getString(9).trim)).getOrElse(None)
    val bitemp=Try(inputString.getString(10)).getOrElse("yes")
    val aggColumn=Try(Some(inputString.getString(11).trim)).getOrElse(None)
    val zipFile=Try(inputString.getString(12)).getOrElse("no")
    val excludeColumn=Try(Some(inputString.getString(13).trim)).getOrElse(None)

    FixedConf(srcConType,srcTableNm,schemaFile,alias,post,header,footer,srcPrsnlQuery,tgtTableNm,
      tgtPrsnlQuery,bitemp,aggColumn,zipFile,excludeColumn)
  }

  /** The `FixedConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param srcConType   source Connection Type.
    * @param srcTableNm   source Table Name
    * @param post        Record identifier , if value is specified, then only those records from fixed length file will be extracted.
    * @param alias         Alias.
    * @param srcPrsnlQuery   source Personal SQL Query .
    * @param header      whether header is present or not .
    * @param footer      whether footer is present or not.
    * @param schemaFile    schema file hdfs path for files  .
    * @param tgtTableNm       target Table Name  .
    * @param tgtPrsnlQuery      target Personal SQL Query .
    * @param bitemp        By default "yes" , can be made "no" by user to remove bitemporal columns .
    * @param aggColumn      comma seperated  list of columns for sum check.
    * @param zipFile     By default "no" , can be made "yes" by user if source is zipped file .
    * @param excludeColumn comma delimited columns to be excluded
    */
  case class FixedConf(srcConType:String,srcTableNm:String,schemaFile:Option[String],alias:String,post:Option[String],header:String,footer:String,srcPrsnlQuery:Option[String],tgtTableNm:String,
                       tgtPrsnlQuery:Option[String],bitemp:String,aggColumn:Option[String],zipFile:String,excludeColumn:Option[String]) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("srcConType", srcConType)
        .append("srcTableNm", srcTableNm)
        .append("schemaFile", schemaFile)
        .append("post", post)
        .append("header", header)
        .append("footer", footer)
        .append("alias", alias)
        .append("srcPrsnlQuery", srcPrsnlQuery)
        .append("tgtTableNm", tgtTableNm)
        .append("tgtPrsnlQuery", tgtPrsnlQuery)
        .append("bitemp", bitemp)
        .append("aggColumn", aggColumn)
        .append("zipFile", zipFile)
        .append("excludeColumn",excludeColumn)
        .toString
    }
  }

}
