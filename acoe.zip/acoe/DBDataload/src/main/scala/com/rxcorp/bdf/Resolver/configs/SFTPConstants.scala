package com.rxcorp.bdf.Resolver.configs

/** The `STPConstants` trait offers constants for different keys expected in .conf file related to [[SFTPConfig]].
  * Created By Apoorv */

trait SFTPConstants {

  /** The [[sftpHost]] constant value equals `sftpHost` */
  final val sftpHost: String = "sftpHost"
  /** The [[sftpUser]] constant value equals `sftpUser` */
  final val sftpUser: String = "sftpUser"
  /** The [[sftpPassword]] constant value equals `sftpPassword` */
  final val sftpPassword: String = "sftpPassword"
  /** The [[sftpDelimiter]] constant value equals `sftpDelimiter` */
  final val sftpDelimiter: String = "sftpDelimiter"
  /** The [[sftpHeader]] constant value equals `sftpHeader` */
  final val sftpHeader: String = "sftpHeader"
  /** The [[sftpFileType]] constant value equals `sftpFileType` */
  final val sftpFileType: String = "sftpFileType"
  /** The [[sftpFilePath]] constant value equals `sftpFilePath` */
  final val sftpFilePath: String = "sftpFilePath"


}
