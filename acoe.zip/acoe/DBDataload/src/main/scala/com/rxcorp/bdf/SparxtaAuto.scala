package com.rxcorp.bdf

import better.files.File
import com.rxcorp.bdf.Resolver.configs.ConfFile
import com.rxcorp.bdf.Resolver.configs.ConnectDetails.connConf
import com.rxcorp.bdf.Resolver.configs.Resolver.resolve
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.sparkSession
import com.rxcorp.bdf.Utilities.testCases.{TestCurrBitemp, TestDeltaBitemp, TestMain, TestSnapBitemp}
import com.rxcorp.bdf.Utilities.time.Time.convertTime
import com.rxcorp.bdf.Utilities.utils.Extras._
import com.rxcorp.bdf.Utilities.utils.SparxtaUtils.getSourceDataframe
import com.rxcorp.bdf.Utilities.utils.Utils._
import com.typesafe.config.Config
import com.rxcorp.bdf.Utilities.utils.SparxtaUtils.resolveTargetDb
import com.rxcorp.bdf.Utilities.utils.SparxtaUtils.removeRows
import org.apache.spark.sql.{DataFrame, Row}

import scala.collection.mutable
import scala.util.Try

object SparxtaAuto  {

  /** The `SparxtaAuto` method runs method for runType=1, i.e For any soucre to Hive as target. This creates HTML report and sends in mail.
    * @param configFile path to .conf file
    * @param connectDetails connection details
    * @param environment enviorment name
    * @param asset asset name
    * @param country country name
    * @param tenant tenant name
    */

  def DbDataLoadRoot(configFile:String,connectDetails:connConf,environment:String,asset:String,country:String,tenant:String,runType:Int): Unit = {
    val jobStart: Long = System.nanoTime
    val confFilePath: String = configFile
    val config: Config = readConfFile(confFilePath)
    val tables = new StringBuilder
    val tableException: mutable.HashMap[String, Exception] = mutable.HashMap[String,Exception]()
    val tableLoadingTime: mutable.HashMap[String, String] = mutable.HashMap[String,String]()
    val confFileName: String = confFilePath.split("\\/").toList.takeRight(1).head.split("\\.").toList.take(1).head
    val confF: ConfFile.mainConf = ConfFile.getConfig(config)
    val tableListArray: Array[Row] = getTableListArray(sparkSession,confF.tableListPath)
    val totalInputs: Int =tableListArray.length
    appendHeader(tables,1)
    tableListArray.foreach{ eachRow =>

      val tableStart: Long = System.nanoTime
      try {
        val csvArray: Product = getCsvArray(eachRow,runType)
        val resolver = resolve(csvArray)
        val tableDF: DataFrame = getSourceDataframe(resolver, config,connectDetails)
        tableDF.createOrReplaceTempView(s"${resolver.alias}")
        var finalSrcDF = getDataframeQuery(sparkSession, resolver.srcPrsnlQuery.get, resolver.alias)
        if (finalSrcDF.take(1).isEmpty){throw new Exception("Source count is zero please check")}
        if (runType==3){
        val prevFinalTgtDF: DataFrame = resolveDf(resolver, config,1,resolver.prevHistory.get,connectDetails)
        val currFinalTgtDF: DataFrame = resolveDf(resolver, config,1,resolver.currHistory.get,connectDetails)
        finalSrcDF=useTargetSchema(resolver,finalSrcDF,removeBitempCols(sparkSession,currFinalTgtDF))
        writeDataframe(sparkSession, prevFinalTgtDF, s"${confF.fixedHDFSpath}/${resolver.alias}/prev_tgt/")
        writeDataframe(sparkSession, currFinalTgtDF, s"${confF.fixedHDFSpath}/${resolver.alias}/curr_tgt/")
        }else{
          if (!(resolver.excludeColumn.isEmpty)) finalSrcDF=excludeColumns(sparkSession,resolver.excludeColumn.get,finalSrcDF)
          var finalTgtDF = resolveTargetDb(resolver, config,connectDetails,runType)
          if (finalTgtDF.take(1).isEmpty){throw new Exception("Target count is zero please check")}
          if (!(resolver.excludeColumn.isEmpty)) finalTgtDF=excludeColumns(sparkSession,resolver.excludeColumn.get,finalTgtDF)
          finalSrcDF=useTargetSchema(resolver,finalSrcDF,finalTgtDF)
          if (!(resolver.excludeRow.isEmpty)) finalSrcDF=removeRows(resolver,finalSrcDF)
          writeDataframe(sparkSession, finalTgtDF, s"${confF.fixedHDFSpath}/${resolver.alias}/tgt/")
          }
        writeDataframe(sparkSession, finalSrcDF, s"${confF.fixedHDFSpath}/${resolver.alias}/src/")
        val tableEnd: String = convertTime(System.nanoTime - tableStart)
        tableLoadingTime.put(resolver.alias, tableEnd)
        print("a")
      }
      catch{
        case e : Exception => val csvArray: Product = getCsvArray(eachRow,runType)
          val resolver = resolve(csvArray); tableException.put(resolver.alias,e)
          val tableEnd: String = convertTime(System.nanoTime - tableStart)
          tableLoadingTime.put(resolver.alias,tableEnd)
      }

    }

    val reportHTML: File = File(s"${confFileName}_comparison.html")
    if (reportHTML.exists) reportHTML.delete()
    val testArray: mutable.HashMap[String, String] =mutable.HashMap[String,String]()

    tableListArray.foreach { eachRow =>
      val testTimeStart: Long = System.nanoTime
      try{
        val csvArray: Product = getCsvArray(eachRow, runType)
        val resolver: Resolver.configs.Resolver.resolveConf = resolve(csvArray)
        if(tableException contains resolver.alias){
          throw new Exception(tableException(resolver.alias))
        }
        val aggColumns: List[String] = if (!(resolver.aggColumn.isEmpty)) {
          resolver.aggColumn.get.trim.split(",").toList
        } else List[String]()
        if (runType==3){
          val primaryKey: List[String] =resolver.primaryKey.get.trim.split(",").toList
          val nonCompare:List[String]=Try(resolver.nonComapre.get.trim.split(",").toList).getOrElse(List[String]())
          val busEffMap: List[String] =Try(resolver.bussEffMapping.get.trim.split(",").toList).getOrElse(List[String]())
          val busExpMap: List[String] =Try(resolver.bussExpMapping.get.trim.split(",").toList).getOrElse(List[String]())
          val deltaCol: List[String] =Try(resolver.deltaColumn.get.trim.split(",").toList).getOrElse(List[String]())
          if (resolver.runOption.get.toLowerCase=="snapshot") {
            val test: TestSnapBitemp = new TestSnapBitemp()
            test.param(confFilePath, resolver.alias, resolver.srcTableNm, resolver.prevHistory.get, resolver.currHistory.get, primaryKey, resolver.runOption.get, resolver.loadDate.get, nonCompare, busEffMap, deltaCol, resolver.srcConType, aggColumns)
            test.execute()
          }
          if (resolver.runOption.get.toLowerCase=="delta") {
            val test: TestDeltaBitemp = new TestDeltaBitemp()
            test.param(confFilePath, resolver.alias, resolver.srcTableNm, resolver.prevHistory.get, resolver.currHistory.get, primaryKey, resolver.runOption.get, resolver.loadDate.get, nonCompare, busEffMap, deltaCol, resolver.srcConType, aggColumns)
            test.execute()
          }
          if (resolver.runOption.get.toLowerCase=="current") {
            val test: TestCurrBitemp = new TestCurrBitemp()
            test.param(confFilePath, resolver.alias, resolver.srcTableNm, resolver.prevHistory.get, resolver.currHistory.get, primaryKey, resolver.runOption.get, resolver.loadDate.get, nonCompare, busEffMap,busExpMap, deltaCol, resolver.srcConType, aggColumns)
            test.execute()
          }
          cleanUpHDFS(confF.fixedHDFSpath,resolver.alias,resolver.srcConType,3)
        } else{
          val test: TestMain = new TestMain()
          test.param(confFilePath, eachRow, aggColumns, runType,environment,asset,country,tenant)
          test.execute()
          cleanUpHDFS(confF.fixedHDFSpath,resolver.alias,resolver.srcConType,1)
        }
        val testTimeEnd: String = convertTime(System.nanoTime - testTimeStart)
        testArray.put(resolver.alias,testTimeEnd)
        if(runType==3){
          appendRow(tables,resolver,1,tableLoadingTime(resolver.alias),testTimeEnd,resolver.currHistory.get)
        }else{
          appendRow(tables,resolver,1,tableLoadingTime(resolver.alias),testTimeEnd,resolver.tgtTableNm.get)
        }
      }catch{
        case e : Exception => val csvArray = getCsvArray(eachRow,runType)
          val resolver = resolve(csvArray)
          tableException.put(resolver.alias,e)
          val testTimeEnd = convertTime(System.nanoTime - testTimeStart)
          testArray.put(resolver.alias,testTimeEnd)
          if(runType==3){appendException(tables,resolver,1,tableLoadingTime(resolver.alias),testTimeEnd,tableException(resolver.alias),resolver.currHistory.get)
      }
          else{appendException(tables,resolver,1,tableLoadingTime(resolver.alias),testTimeEnd,tableException(resolver.alias),resolver.tgtTableNm.get)
          }

      }

    }
    if (reportHTML.exists) {
      val tableTestCount: Int = HTMLScrapper(s"${confFileName}_comparison.html")._2
      val tableStatus: mutable.Map[String, String] = HTMLScrapper(s"${confFileName}_comparison.html")._3
      val scrappedData: Seq[(String, Int)] = HTMLScrapper(s"${confFileName}_comparison.html")._1
      createChart(scrappedData,"Tests",s"${confFileName}_chart.png")
      val tableStat: String =createResultTable(tableStatus)
      val report: Seq[(String, Int)] = tableStatus.groupBy { case(id, value) => value.toLowerCase.capitalize }.mapValues(_.size).toSeq
      createChart(report,"Tables",s"${confFileName}_chart1.png")
      val jobEnd: String = convertTime(System.nanoTime - jobStart)

      //sparkSession.read.option("header","true").csv(s"${confF.fixedHDFSpath}/${environment}${asset}${tenant}${country}/info/").coalesce(1).write.mode("overwrite").option("delimiter", ",").option("header","true").csv(s"${confF.fixedHDFSpath}/${environment}${asset}${tenant}${country}/info1/")

      // s"hadoop fs -copyToLocal ${confF.fixedHDFSpath}/${environment}${asset}${tenant}${country}/info1/*.csv ${System.getProperty("java.io.tmpdir")}/${environment}${asset}${tenant}${country}.csv" !

      emailBuilder(3,confFileName,confF.mailIds,jobEnd,tables.toString(),tableStat,tableTestCount.toString,totalInputs.toString,environment,asset,country,tenant)

      //s"hadoop fs -rm -r ${confF.fixedHDFSpath}/${environment}${asset}${tenant}${country}/" !

      // s"hadoop fs -rm ${System.getProperty("java.io.tmpdir")}/${environment}${asset}${tenant}${country}.csv" !

      val exitcode = if (totalInputs==tableTestCount){
        if (tableStatus.values.exists(_ == "fail")){ 3}
        else if (tableStatus.values.exists(_ == "warning")){ 2}
        else if (tableStatus.values.exists(_ == "error")){4}
        else  0
      }else{
        1
      }
      val localTmpDir: String = System.getProperty("java.io.tmpdir")
      sparkSession.sparkContext.parallelize(exitcode.toString.trim).repartition(1).saveAsTextFile(s"$localTmpDir/${environment}_${tenant}_${asset}_${country}.txt")
    }else {
      emailBuilder(2,confFileName,confF.mailIds,null,tables.toString(),null,null,totalInputs.toString,environment,asset,country,tenant)
      val localTmpDir: String = System.getProperty("java.io.tmpdir")
      sparkSession.sparkContext.parallelize(1.toString).saveAsTextFile(s"/$localTmpDir/${environment}_${tenant}_${asset}_${country}.txt")
    }



  }

}
