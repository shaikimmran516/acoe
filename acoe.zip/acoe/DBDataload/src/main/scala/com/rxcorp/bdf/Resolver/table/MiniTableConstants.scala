package com.rxcorp.bdf.Resolver.table

/** The `MiniTableConstants` trait offers constants for different keys expected in .csv file related to [[MiniTableDetails]]. */
/** Created By Apoorv*/
trait MiniTableConstants {
  /** The [[srcConType]] constant value equals `srcConType` */
  final val srcConType: String = "srcConType"
  /** The [[srcTableNm]] constant value equals `srcTableNm` */
  final val srcTableNm: String = "srcTableNm"
  /** The [[alias]] constant value equals `alias` */
  final val alias: String = "alias"
  /** The [[srcWhere]] constant value equals `srcWhere` */
  final val srcWhere: String = "srcWhere"
  /** The [[tgtTableNm]] constant value equals `tgtTableNm` */
  final val tgtTableNm: String = "tgtTableNm"
  /** The [[tgtWhere]] constant value equals `tgtWhere` */
  final val tgtWhere: String = "tgtWhere"
  /** The [[bitemp]] constant value equals `bitemp` */
  final val bitemp: String = "bitemp"
  /** The [[useTargetSchema]] constant value equals `useTargetSchema` */
  final val useTargetSchema: String = "useTargetSchema"
  /** The [[mode]] constant value equals `mode` */
  final val mode: String = "mode"
}
