package com.rxcorp.bdf

import com.rxcorp.bdf.Utilities.time.Time.convertTime
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.sparkSession
import better.files._
import com.rxcorp.bdf.Resolver.configs.ConfFile
import com.rxcorp.bdf.Resolver.configs.ConnectDetails.connConf
import com.typesafe.config.Config
import org.apache.spark.sql._
import com.rxcorp.bdf.Resolver.configs.Resolver.resolve
import com.rxcorp.bdf.Utilities.testCases.TestMini
import com.rxcorp.bdf.Utilities.utils.Extras._
import com.rxcorp.bdf.Utilities.utils.SparxtaMiniUtils.getSourceCount
import com.rxcorp.bdf.Utilities.utils.Utils._

import scala.collection.mutable
import scala.util.control.Breaks._
import com.rxcorp.bdf.Utilities.utils.SparxtaMiniUtils.getCountsDF

object SparxtaMini {


  /** The `SparxtaMini` method runs method for runType=4, i.e For any soucre to any hive as target for Production QC version. This creates HTML report and sends in mail.
    * @param configFile path to .conf file
    * @param environment enviorment name
    * @param asset asset name
    * @param country country name
    * @param tenant tenant name
    */

  def SparxtaMini(configFile:String,connectDetails:connConf,environment:String,asset:String,country:String,tenant:String): Unit = {
    val jobStart = System.nanoTime
    val confFilePath = configFile
    val config: Config = readConfFile(confFilePath)
    val tables = new StringBuilder
    val tableException= mutable.HashMap[String,Exception]()
    val tableLoadingTime= mutable.HashMap[String,String]()
    val confFileName: String = confFilePath.split("\\/").toList.takeRight(1).head.split("\\.").toList.take(1).head
    val confF = ConfFile.getConfig(config)
    val reportHTML = File(s"${confFileName}_comparison.html")
    if (reportHTML.exists) reportHTML.delete()
    val testArray=mutable.HashMap[String,String]()
    val tableListArray= getTableListArray(sparkSession,confF.tableListPath)
    val totalInputs=tableListArray.length

    appendHeader(tables,1)
    tableListArray.foreach{ eachRow =>
        breakable {
        val tableStart = System.nanoTime
          val (srcCount:Int,finalSrcDF:Dataset[Row],tgtCount:Int,finalTgtDF:Dataset[Row])= try {
          val csvArray = getCsvArray(eachRow,4)
          val resolver = resolve(csvArray)
          var (srcCnt,srcDF)=getSourceCount(resolver,config,connectDetails)
          srcDF.limit(200).cache()
          srcDF = if (!(confF.nullValue.isEmpty)) {replaceNulls(srcDF,confF.nullValue.get)} else srcDF
          srcDF =  if(!(confF.emptyValue.isEmpty)){nullifyEmptyStrings(srcDF)}else srcDF
          var (tgtCnt,targetDF) = getCountsDF(resolver,config,resolver.tgtTableNm.get,resolver.tgtWhere.get,resolver.primaryKey.get)
          if (resolver.bitemp == "no") {targetDF = removeBitempCols(sparkSession,targetDF)}
          srcDF=useTargetSchema(resolver,srcDF,targetDF)
          val tgtDF= targetDF.intersect(srcDF)
          tgtDF.cache
          val tableEnd = convertTime(System.nanoTime - tableStart)
          tableLoadingTime.put(resolver.alias, tableEnd)
          (srcCnt,srcDF,tgtCnt,tgtDF)
         }catch{
          case e : Exception => val csvArray = getCsvArray(eachRow,4);val resolver = resolve(csvArray); tableException.put(resolver.alias,e);val tableEnd = convertTime(System.nanoTime - tableStart); tableLoadingTime.put(resolver.alias,tableEnd);
        }

        val testTimeStart = System.nanoTime
        val csvArray = getCsvArray(eachRow,4)
        val resolver: Resolver.configs.Resolver.resolveConf = resolve(csvArray)
        if(tableException contains resolver.alias){
          val testTimeEnd: String = convertTime(System.nanoTime - testTimeStart)
          appendException(tables,resolver,1,tableLoadingTime(resolver.alias),testTimeEnd,tableException(resolver.alias),resolver.tgtTableNm.get)
          break()
        }
        val test = new TestMini()
        if (srcCount!=0 || tgtCount !=0) {
          test.param(confFilePath, eachRow, finalSrcDF, finalTgtDF, srcCount, tgtCount)
          test.execute()
        } else
        {
          if (tgtCount==0 || srcCount==0 || resolver.mode=="append"){
            val testTimeEnd: String = convertTime(System.nanoTime - testTimeStart)
            appendRow(tables,resolver,2,tableLoadingTime(resolver.alias),testTimeEnd,resolver.tgtTableNm.get)
            break()
          }
          else{
            val testTimeEnd: String = convertTime(System.nanoTime - testTimeStart)
            appendRow(tables,resolver,3,tableLoadingTime(resolver.alias),testTimeEnd,resolver.tgtTableNm.get)
            break()}
        }
        cleanUpHDFS(confF.fixedHDFSpath,resolver.alias,resolver.srcConType,1)
        val testTimeEnd = convertTime(System.nanoTime - testTimeStart)
        testArray.put(resolver.alias,testTimeEnd)
          finalSrcDF.unpersist()
          finalTgtDF.unpersist()
        appendRow(tables,resolver,1,tableLoadingTime(resolver.alias),testTimeEnd,resolver.tgtTableNm.get)
      }
      }

    if (reportHTML.exists) {
      val tableTestCount = HTMLScrapper(s"${confFileName}_comparison.html")._2
      val tableStatus= HTMLScrapper(s"${confFileName}_comparison.html")._3
      val tableStat=createResultTable(tableStatus)
      val jobEnd = convertTime(System.nanoTime - jobStart)
      emailBuilder(1,confFileName,confF.mailIds,jobEnd,tables.toString(),tableStat,tableTestCount.toString,totalInputs.toString,environment,asset,country,tenant)
    }else {
      emailBuilder(2,confFileName,confF.mailIds,null,tables.toString(),null,null,totalInputs.toString,environment,asset,country,tenant)
    }

    }
}
