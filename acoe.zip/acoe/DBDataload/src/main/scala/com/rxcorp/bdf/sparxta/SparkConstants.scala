package com.rxcorp.bdf.sparxta

/** The `SparkConstants` trait offers constants for different keys expected in .csv file related to [[SparkResolver]]. */
/** Created By Apoorv*/

trait SparkConstants {

    /** The [[keytab]] constant value equals `keytab` */
    final val keytab: String = "keytab"
    /** The [[principal]] constant value equals `principal` */
    final val principal: String = "principal"
    /** The [[queue]] constant value equals `queue` */
    final val queue: String = "queue"
    /** The [[configFile]] constant value equals `configFile` */
    final val configFile: String = "configFile"
    /** The [[path]] constant value equals `path` */
    final val path: String = "path"
    /** The [[className]] constant value equals `className` */
    final val className: String = "className"
    /** The [[asset]] constant value equals `asset` */
    final val asset: String = "asset"
    /** The [[deployMode]] constant value equals `deployMode` */
    final val deployMode: String = "deployMode"
    /** The [[countryName]] constant value equals `countryName` */
    final val countryName: String = "countryName"
    /** The [[environment]] constant value equals `environment` */
    final val environment: String = "environment"
    /** The [[runType]] constant value equals `runType` */
    final val runType: String = "runType"
    /** The [[jdbcUrl]] constant value equals `jdbcUrl` */
    final val jdbcUrl: String = "jdbcUrl"
    /** The [[sftpUser]] constant value equals `sftpUser` */
    final val sftpUser: String = "sftpUser"
  /** The [[sftpPass]] constant value equals `sftpPass` */
  final val sftpPass: String = "sftpPass"
  /** The [[jdbcTgt]] constant value equals `jdbcTgt` */
  final val jdbcTgt: String = "jdbcTgt"
  /** The [[ftpUser]] constant value equals `ftpUser` */
  final val ftpUser: String = "ftpUser"
  /** The [[ftpPass]] constant value equals `ftpPass` */
  final val ftpPass: String = "ftpPass"
  /** The [[smbUser]] constant value equals `smbUser` */
  final val smbUser: String = "smbUser"
  /** The [[smbPass]] constant value equals `smbPass` */
  final val smbPass: String = "smbPass"
  /** The [[tenant]] constant value equals `tenant` */
  final val tenant: String = "tenant"

}
