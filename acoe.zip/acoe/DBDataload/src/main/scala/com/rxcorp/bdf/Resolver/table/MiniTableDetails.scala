package com.rxcorp.bdf.Resolver.table

import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}
import org.apache.spark.sql.Row

import scala.util.Try

/** Created By Apoorv*/
object MiniTableDetails extends MiniTableConstants {

  /** The `getMiniTableDetails` method returns [[miniTableConf]] case class instance by resolving the tables files from .csv file for mini version
    * @param inputString Row contains values from .csv file
    * @return [[miniTableConf]]
    */

  def getMiniTableDetails(inputString: Row):miniTableConf = {
    val srcConType= Try(inputString.getString(0).trim).getOrElse(throw new Exception("Connection Type Missing"))
    val srcTableNm= Try(inputString.getString(1).trim).getOrElse(throw new Exception("Source Table Missing"))
    val alias=Try(inputString.getString(2).trim).getOrElse(throw new Exception("Alias is Missing"))
    val srcWhere=Try(Some(inputString.getString(3).trim)).getOrElse(None)
    val tgtTableNm=Try(inputString.getString(4).trim).getOrElse(throw new Exception("Target Table is Missing"))
    val tgtWhere=Try(Some(inputString.getString(5).trim)).getOrElse(None)
    val bitemp=Try(inputString.getString(6)).getOrElse("yes")
    val useTargetSchema=Try(inputString.getString(7)).getOrElse("no")
    val mode =Try(inputString.getString(8)).getOrElse("overwrite")
    miniTableConf(srcConType,srcTableNm,alias,srcWhere,tgtTableNm,
      tgtWhere,bitemp,useTargetSchema,mode)
  }

  /** The `miniTableConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param srcConType   source Connection Type.
    * @param srcTableNm   source Table Name .
    * @param alias         Alias.
    * @param srcWhere   source where Query .
    * @param tgtTableNm       target Table Name  .
    * @param tgtWhere      target where Query .
    * @param bitemp        By default "yes" , can be made "no" by user to remove bitemporal columns .
    * @param useTargetSchema defaultt"no" can be made "yes" by user if source table has differnt schema than target.
    * @param mode By default "overwrite" , can be changed by user to append for incremental load.
    */
  case class miniTableConf(srcConType:String,srcTableNm:String,alias:String,srcWhere:Option[String],tgtTableNm:String,
                           tgtWhere:Option[String],bitemp:String,useTargetSchema:String,mode:String) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("srcConType", srcConType)
        .append("srcTableNm", srcTableNm)
        .append("alias", alias)
        .append("srcWhere", srcWhere)
        .append("tgtTableNm", tgtTableNm)
        .append("tgtWhere", tgtWhere)
        .append("bitemp", bitemp)
        .append("useTargetSchema", useTargetSchema)
        .append("mode",mode)
        .toString
    }
  }

}
