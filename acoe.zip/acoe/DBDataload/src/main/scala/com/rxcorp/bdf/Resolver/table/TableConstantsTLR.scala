package com.rxcorp.bdf.Resolver.table

/** The `TableConstantsTLR` trait offers constants for different keys expected in .csv file related to [[TableDetailsTLR]]. */
/** Created By Apoorv*/
trait TableConstantsTLR {
  /** The [[srcConType]] constant value equals `srcConType` */
  final val srcConType: String = "srcConType"
  /** The [[srcTableNm]] constant value equals `srcTableNm` */
  final val srcTableNm: String = "srcTableNm"
  /** The [[alias]] constant value equals `alias` */
  final val alias: String = "alias"
  /** The [[srcPrsnlQuery]] constant value equals `srcPrsnlQuery` */
  final val srcPrsnlQuery: String = "srcPrsnlQuery"
  /** The [[header]] constant value equals `header` */
  final val header: String = "header"
  /** The [[schemaFile]] constant value equals `schemaFile` */
  final val schemaFile: String = "schemaFile"
  /** The [[tgtConType]] constant value equals `tgtConType` */
  final val tgtConType: String = "tgtConType"
  /** The [[tgtTableNm]] constant value equals `tgtTableNm` */
  final val tgtTableNm: String = "tgtTableNm"
  /** The [[tgtAlias]] constant value equals `tgtAlias` */
  final val tgtAlias: String = "tgtAlias"
  /** The [[tgtPrsnlQuery]] constant value equals `tgtPrsnlQuery` */
  final val tgtPrsnlQuery: String = "tgtPrsnlQuery"
  /** The [[splitColumn]] constant value equals `splitColumn` */
  final val splitColumn: String = "splitColumn"
  /** The [[splitTgtColumn]] constant value equals `splitTgtColumn` */
  final val splitTgtColumn: String = "splitTgtColumn"
  /** The [[aggColumn]] constant value equals `aggColumn` */
  final val aggColumn: String = "aggColumn"
  /** The [[useTargetSchema]] constant value equals `useTargetSchema` */
  final val useTargetSchema: String = "useTargetSchema"
  /** The [[zipFile]] constant value equals `zipFile` */
  final val zipFile: String = "zipFile"
  /** The [[excludeColumn]] constant value equals `excludeColumn` */
  final val excludeColumn: String = "excludeColumn"

}
