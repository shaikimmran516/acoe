package com.rxcorp.bdf.Utilities.files

import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}

/** The `Schema` case class offers access to the values held in the parameters for an instance.
  * Taken From Mansoor.(SLP)
  * @param metaType The meta annotation for the defined datatype
  * @param ordinal The column position
  * @param columnName The column name
  * @param dataType The column datatype
  * @param precision The datatype precision
  * @param scale The datatype scale
  * @param posStart The start position of column for fixed length file
  * @param posEnd The end position of column for fixed length file
  */
case class Schema(metaType: String,
                  ordinal: Int,
                  columnName: String,
                  dataType: String,
                  precision: Int,
                  scale: Int,
                  posStart: Option[Int] = None,
                  posEnd: Option[Int] = None) {
  override def toString: String = {
    new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
      .append("metaType", metaType)
      .append("ordinal", ordinal)
      .append("columnName", columnName)
      .append("dataType", dataType)
      .append("precision", precision)
      .append("scale", scale)
      .append("posStart", posStart)
      .append("posEnd", posEnd)
      .toString
  }
}



