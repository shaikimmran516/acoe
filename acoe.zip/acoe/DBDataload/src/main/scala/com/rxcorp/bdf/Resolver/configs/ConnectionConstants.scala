package com.rxcorp.bdf.Resolver.configs

/** The `ConnectionConstants` trait offers constants for different keys expected in command line arguments  related to [[ConnectDetails]].
  * Created by Apoorv */

trait ConnectionConstants {

  /** The [[jdbcURL]] constant value equals `jdbcURL` */
  final val jdbcURL: String = "jdbcURL"

  /** The [[jdbcTgt]] constant value equals `jdbcTgt` */
  final val jdbcTgt: String = "jdbcTgt"

  /** The [[sftpUser]] constant value equals `sftpUser` */
  final val sftpUser: String = "sftpUser"

  /** The [[sftpPass]] constant value equals `sftpPass` */
  final val sftpPass: String = "sftpPass"

  /** The [[ftpUser]] constant value equals `ftpUser` */
  final val ftpUser: String = "ftpUser"

  /** The [[ftpPass]] constant value equals `ftpPass` */
  final val ftpPass: String = "ftpPass"

}
