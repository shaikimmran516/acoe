package com.rxcorp.bdf.Resolver.configs

import com.rxcorp.bdf.sparxta.CmdSparkArguments
import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}

import scala.util.Try


object ConnectDetails extends ConnectionConstants {

  /** The `getConn` method returns [[connConf]] case class instance by resolving the cpnnection configurations from command line arguments
    * @param cmdArgs command Line arguments
    * @return [[connConf]]
    */
  def getConn(cmdArgs: CmdSparkArguments):connConf = {
    val jdbcURL: Option[String] = Try(Some(cmdArgs.srcJdbc)).getOrElse(None)
    val jdbcTgt: Option[String] = Try(Some(cmdArgs.tgtJdbc)).getOrElse(None)
    val sftpUser: Option[String] = Try(Some(cmdArgs.sftpUser)).getOrElse(None)
    val sftpPass: Option[String] = Try(Some(cmdArgs.sftpPass)).getOrElse(None)
    val ftpUser: Option[String] = Try(Some(cmdArgs.ftpUser)).getOrElse(None)
    val ftpPass: Option[String] = Try(Some(cmdArgs.ftpPass)).getOrElse(None)
    val smbUser: Option[String] = Try(Some(cmdArgs.smbUser)).getOrElse(None)
    val smbPass: Option[String] = Try(Some(cmdArgs.smbPass)).getOrElse(None)
    connConf(jdbcURL, jdbcTgt, sftpUser, sftpPass, ftpUser, ftpPass,smbUser,smbPass)
  }
  /** The `connConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param jdbcURL   source jdbc .
    * @param jdbcTgt   target jdbc .
    * @param sftpUser  Sftp username.
    * @param sftpPass  Sftp password.
    * @param ftpUser   Ftp username.
    * @param ftpPass   Ftp password.
    */
  case class connConf(jdbcURL:Option[String],jdbcTgt:Option[String],sftpUser:Option[String],sftpPass:Option[String],ftpUser:Option[String],ftpPass:Option[String],smbUser:Option[String],smbPass:Option[String]) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("jdbcURL", jdbcURL)
        .append("jdbcTgt", jdbcTgt)
        .append("sftpUser",sftpUser)
        .append("sftpPass", sftpPass)
        .append("ftpUser", ftpUser)
        .append("ftpPass", ftpPass)
        .append("smbUser", smbUser)
        .append("smbPass", smbPass)
        .toString
    }
  }

}
