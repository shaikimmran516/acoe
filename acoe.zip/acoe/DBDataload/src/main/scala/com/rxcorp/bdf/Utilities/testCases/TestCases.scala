package com.rxcorp.bdf.Utilities.testCases

import com.aventstack.extentreports.ExtentTest
import com.aventstack.extentreports.markuputils.MarkupHelper
import com.rxcorp.bdf.Resolver.configs.{ConfFile, Resolver}
import DataValidation.assertDataFrameEqualsK
import org.apache.spark.sql.functions.sum
import org.apache.spark.sql.{Column, Dataset, Row}
import org.apache.spark.sql.types.{DataType, LongType, StructField, StructType}
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext.implicits._
import BitempDataValidation.assertDataFrameEqualsB
import org.apache.spark.sql
import org.apache.spark.sql.functions.lit
import org.eclipse.jetty.websocket.common.frames.DataFrame
import org.apache.spark.sql.functions.{broadcast, col}
import org.scalatest.FunSuite
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types._

object TestCases extends FunSuite {


  def columnCountTest(parentTest: ExtentTest, srcColCount: Int, tgtColCount: Int, resolver: Resolver.resolveConf , infoDF :Dataset[Row]):Dataset[Row]= {

    val columnCount = parentTest.createNode("Column Count Validation", "Checking Numbers of Columns")
    val updateInfoDF = try {
      val colException = intercept[org.scalatest.exceptions.TestFailedException] {
        assert(srcColCount === tgtColCount)
      }
      if (!colException.getMessage().isEmpty()){
      columnCount.fail(s"${resolver.alias} - Count exception is given below: <br>" + colException)
      infoDF.withColumn("Column Count Validation", lit("Fail"))}
      else {
        columnCount.pass(s"${resolver.alias} - Validating column counts <br> ${resolver.srcTableNm} Table - Source table count : "
          + srcColCount + s"<br> ${resolver.tgtTableNm} Table - Target table count : " + tgtColCount)
        infoDF.withColumn("Column Count Validation", lit("Pass"))
      }
    } catch {
      case e: org.scalatest.exceptions.TestFailedException => columnCount.pass(s"${resolver.alias} - Validating column counts <br> " +
        s"${resolver.srcTableNm} Table - Source table count : " + srcColCount + s"<br> ${resolver.tgtTableNm} Table - Target table count : "
        + tgtColCount)
        infoDF.withColumn("Column Count Validation", lit("Pass"))
      case unknown: Exception => columnCount.error(s"${resolver.alias} - Count exception. Validation could not be completed for some other reason. " + unknown)
        infoDF.withColumn("Column Count Validation", lit("Error"))
    }
    updateInfoDF
  }


  def fieldNameTest(parentTest: ExtentTest, srcCols: IndexedSeq[Any], tgtCols: IndexedSeq[Any], resolver: Resolver.resolveConf,infoDF:Dataset[Row]):Dataset[Row]= {
    val fieldsTest = parentTest.createNode(s"Field Name Validation", "Validating Field Names")
    val updateInfoDF =try {
      val fieldException = intercept[org.scalatest.exceptions.TestFailedException] {
        assertResult(srcCols) {
          tgtCols
        }
      }

      if (!fieldException.getMessage().isEmpty()){
        fieldsTest.fail(s"${resolver.alias} - Field Name exception is given below: <br>" + fieldException)
       infoDF.withColumn("Field Name Validation", lit("Fail"))}
      else {
        fieldsTest.pass(s"${resolver.alias} - Validation of Field names is Successful. <br> ${resolver.srcTableNm} Table - Source Field Names " +
          s"are given below:  <br> " + srcCols.mkString("\n") + s" <br> ${resolver.tgtTableNm} Table - Target Field Names " +
          s"are given below: <br>" + tgtCols.mkString("\n"))
        infoDF.withColumn("Field Name Validation", lit("Pass"))
      }
    } catch {
      case e: org.scalatest.exceptions.TestFailedException => fieldsTest.pass(s"${resolver.alias} - Validation of Field names is " +
        s"Successful. <br> ${resolver.srcTableNm} Table - Source Field Names are given below:  <br> " + srcCols.mkString("\n")
        + s" <br> ${resolver.tgtTableNm} Table - Target Field Names are given below:  <br>" + tgtCols.mkString("\n"))
        infoDF.withColumn("Field Name Validation", lit("Pass"))
      case unknown: Exception => fieldsTest.error(s"${resolver.alias} - Validation of Field Name got exception. Validation could not be " +
        s"completed for some other reason." + unknown)
        infoDF.withColumn("Field Name Validation", lit("Error"))
    }
    updateInfoDF
  }

  def recordCountTest(parentTest: ExtentTest, srcCount: Long, tgtCount: Long, resolver: Resolver.resolveConf,infoDF:Dataset[Row]):Dataset[Row]=  {
    val test_count = parentTest.createNode(s"Record Count Checking", "Validating Counts")
    val updateInfoDF = try {
      val countException = intercept[org.scalatest.exceptions.TestFailedException] {
        assert(srcCount === tgtCount)
      }
      println(countException.getMessage())

      if (!countException.getMessage().isEmpty()) {
        test_count.fail(s"${resolver.alias} - Count exception is given below: <br>" + countException)
        infoDF.withColumn("Record Count Checking", lit("Fail"))

      }
      else {
        test_count.pass(s"${resolver.alias} - Validating table counts <br> ${resolver.srcTableNm} Table - Source table count : "
          + srcCount + s"<br> ${resolver.tgtTableNm} Table - Target table count : " + tgtCount)
        infoDF.withColumn("Record Count Checking", lit("Pass"))
      }

    } catch {
      case e: org.scalatest.exceptions.TestFailedException => test_count.pass(s"${resolver.alias} - Validating table counts <br> " +
        s"${resolver.srcTableNm} Table - Source table count : " + srcCount + s"<br> ${resolver.tgtTableNm} Table - Target table count : "
        + tgtCount)
        infoDF.withColumn("Record Count Checking", lit("Pass"))
      case unknown: Exception => test_count.error(s"${resolver.alias} - Count exception. Validation could not be completed for some other reason. " + unknown)
        infoDF.withColumn("Record Count Checking", lit("Error"))

    }
    updateInfoDF
  }


  def schemaTest(parentTest: ExtentTest, src: Dataset[Row], tgt: Dataset[Row], resolver: Resolver.resolveConf,infoDF:Dataset[Row]):Dataset[Row]= {
    var updateInfoDF = if (resolver.srcConType == "netezza" || resolver.srcConType == "oracle" || resolver.srcConType == "sqlserver" || resolver.srcConType == "teiid" || resolver.srcConType == "exasol" || resolver.srcConType == "impala" || resolver.srcConType == "db2") {
      val dataSchemaTest = parentTest.createNode(s"Schema Check", "Comparing the Schemas")

      try {
        val schm = DataType.fromJson(src.schema.json.replaceAll("\"nullable\":false", "\"nullable\":true")).asInstanceOf[StructType]

        var dataSchemCheck = false
        if (schm.toString().equalsIgnoreCase(tgt.schema.toString)) {
          dataSchemCheck = true
        }
        if (dataSchemCheck == true) {
          dataSchemaTest.pass(s"${resolver.alias} - Validation of Schema is successful- " + s"<br> ${resolver.srcTableNm} Table - Source table Schema : "
            + schm.toString()
            + s"<br> ${resolver.tgtTableNm} Table - Target table Schema : " + tgt.schema.toString
          )
          infoDF.withColumn("Schema Check", lit("Pass"))
        }
        else {
          dataSchemaTest.warning(s"${resolver.alias} - Validation of Schema failed" + s"<br> ${resolver.srcTableNm} Table - Source table Schema : "
            + schm.toString()
            + s"<br> ${resolver.tgtTableNm} Table - Target table Schema : " + tgt.schema.toString)
          infoDF.withColumn("Schema Check", lit("Warning"))
        }
      } catch {
        case unknown => dataSchemaTest.error(s"${resolver.alias} - Schema validation exception. Validation could not be " +
          s"completed." + unknown)
          infoDF.withColumn("Schema Check", lit("Error"))
      }
    } else {
      val dataSchemaTest = parentTest.createNode(s"Schema Check", "Comparing the Schemas")

       try {
        val schm = DataType.fromJson(src.schema.json.replaceAll("\"nullable\":false", "\"nullable\":true")).asInstanceOf[StructType]

        var dataSchemCheck = false
        if (schm.toString().equalsIgnoreCase(tgt.schema.toString)) {
          dataSchemCheck = true
        }
        if (dataSchemCheck == true) {
          dataSchemaTest.pass(s"${resolver.alias} - Validation of Schema is successful- " + s"<br> ${resolver.srcTableNm} Table - Source table Schema : "
            + schm.toString()
            + s"<br> ${resolver.tgtTableNm} Table - Target table Schema : " + tgt.schema.toString
          )
          infoDF.withColumn("Schema Check", lit("Pass"))

        }
        else {
          dataSchemaTest.fail(s"${resolver.alias} - Validation of Schema failed" + s"<br> ${resolver.srcTableNm} Table - Source table Schema : "
            + schm.toString()
            + s"<br> ${resolver.tgtTableNm} Table - Target table Schema : " + tgt.schema.toString)
          infoDF.withColumn("Schema Check", lit("Fail"))

        }
      } catch {
        case unknown => dataSchemaTest.error(s"${resolver.alias} - Schema validation exception. Validation could not be " +
          s"completed. " + unknown)
          infoDF.withColumn("Schema Check", lit("Error"))

      }

    }
    updateInfoDF
  }

  def duplicateTest(parentTest: ExtentTest, src: Dataset[Row], tgt: Dataset[Row], dupSrcCount: Long, duptgtCount: Long, srcCount: Long, tgtCount: Long, resolver: Resolver.resolveConf,infoDF:Dataset[Row]):Dataset[Row]= {

    val duplicateCountTest = parentTest.createNode(s"Duplicate Checking", "Validating Duplicates")
    val updateInfoDF = try {

      var dupSrcTest: Boolean = false
      if (dupSrcCount === srcCount) {
        dupSrcTest = true
      }
      var dupTgtTest: Boolean = false
      if (duptgtCount === tgtCount) {
        dupTgtTest = true
      }
      var dupMatchTest: Boolean = false
      if (duptgtCount === dupSrcCount) {
        dupMatchTest = true
      }


      if (dupSrcTest === false && dupTgtTest === false && dupMatchTest == true) {
        duplicateCountTest.pass(s"${resolver.alias} - Number of Duplicates found in source and target matches. <br> ${resolver.srcTableNm} Table - Source table count : "
          + srcCount + " Distinct count: " + dupSrcCount
          + s"<br> ${resolver.tgtTableNm} Table - Target table count : " + tgtCount
          + " Distinct count: " + duptgtCount)
        infoDF.withColumn("Duplicate Checking", lit("Pass"))

      }
      else if (dupSrcTest === false && dupTgtTest === false && dupMatchTest == false) {
        duplicateCountTest.warning(s"${resolver.alias} - Duplicates found <br> ${resolver.srcTableNm} Table - Source table count : "
          + srcCount + " Distinct count: " + dupSrcCount
          + s"<br> ${resolver.tgtTableNm} Table - Target table count : " + tgtCount
          + " Distinct count: " + duptgtCount)
        infoDF.withColumn("Duplicate Checking", lit("Warning"))

      }


      else if (dupSrcTest === false && dupTgtTest === true) {
        val dedupSrc = src.dropDuplicates()
        duplicateCountTest.fail(s"${resolver.alias} - Duplicate exception in Source : <br>"
          + " We have " + (srcCount - dedupSrc.count()) + " duplicates in Source data.\n"
          + s"${resolver.alias} -  <br> ${resolver.srcTableNm} Table - Source table count : "
          + srcCount + " Distinct count: " + dupSrcCount
          + s"<br> ${resolver.tgtTableNm} Table - Target table count : " + tgtCount
          + " Distinct count: " + duptgtCount)
        infoDF.withColumn("Duplicate Checking", lit("Fail"))



      }
      else if (dupSrcTest === true && dupTgtTest === false) {
        val dedupTgt = tgt.dropDuplicates()
        duplicateCountTest.fail(s"${resolver.alias} - Duplicate exception in Target : <br>"
          + " We have " + (tgtCount - dedupTgt.count()) + " duplicates in Target data.\n"
          + s"${resolver.alias} -  Duplicates found <br> ${resolver.srcTableNm} Table - Source table count : "
          + srcCount + " Distinct count: " + dupSrcCount
          + s"<br> ${resolver.tgtTableNm} Table - Target table count : " + tgt.count()
          + " Distinct count: " + duptgtCount)
        infoDF.withColumn("Duplicate Checking", lit("Fail"))


      }
      else if (dupSrcTest === true && dupTgtTest === true && dupMatchTest == false) {
        duplicateCountTest.fail(s"${resolver.alias} - Distincts of Both table not matching <br> ${resolver.srcTableNm} Table - Source table count : "
          + srcCount + " Distinct count: " + dupSrcCount
          + s"<br> ${resolver.tgtTableNm} Table - Target table count : " + tgtCount
          + " Distinct count: " + duptgtCount)
        infoDF.withColumn("Duplicate Checking", lit("Fail"))

      }

      else {
        duplicateCountTest.pass(s"${resolver.alias} - No Duplicates found <br> ${resolver.srcTableNm} Table - Source table count : "
          + srcCount + " Distinct count: " + dupSrcCount
          + s"<br> ${resolver.tgtTableNm} Table - Target table count : " + tgtCount
          + " Distinct count: " + duptgtCount)
        infoDF.withColumn("Duplicate Checking", lit("Pass"))

      }
    } catch {
      case unknown: Exception => duplicateCountTest.error(s"${resolver.alias} - Duplicate count exception. Validation could not be " +
        s"completed for some other reason." + unknown)
        infoDF.withColumn("Duplicate Checking", lit("Error"))

    }
    updateInfoDF
  }


  def dataValidationTest(parentTest: ExtentTest, src: Dataset[Row], tgt: Dataset[Row], resolver: Resolver.resolveConf, conf: ConfFile.mainConf,infoDF:Dataset[Row]):Dataset[Row]= {

    val updateInfoDF = if (!(conf.nullValue.isEmpty) && !(conf.emptyValue.isEmpty)) {
      val testDataValidation = parentTest.createNode(s"Data Validation(Replacing null values with the nullValue parameter and Empty Values with null)", "Validating Data")
      try {

        val (k,counts1,counts2) = assertDataFrameEqualsK(src, tgt, resolver.alias, conf.fixedHDFSpath, false)
        if (k == true) {
          testDataValidation.pass(s"${resolver.alias} - Validation of Data is successful")
          testDataValidation.pass(s"Samples of data Match from both tables:\n" +
            s"Path: " + conf.fixedHDFSpath + s"/${resolver.alias}/csv_match/")
          infoDF.withColumn("Data Validation", lit("Pass"))

        }
        else {
          testDataValidation.fail(s"${resolver.alias} - Validation of Data failed: Mismatched rows from source : "+counts1+ " Mismatched rows from target : "+ counts2 )
          testDataValidation.fail(s"Samples of data Mismatch:\n" +
            s"Path: " + conf.fixedHDFSpath + s"/${resolver.alias}/csv_mismatch/")
          infoDF.withColumn("Data Validation", lit("Fail"))

        }
      } catch {
        case unknown: Exception => testDataValidation.error(s"${resolver.alias} - Dataframe validtaion exception. Validation could not be " +
          s"completed." + unknown)
          infoDF.withColumn("Data Validation", lit("Error"))

      }
    } else if (!(conf.nullValue.isEmpty) && (conf.emptyValue.isEmpty)) {
      val test_data_validation = parentTest.createNode(s"Data Validation(Replacing null values with the nullValue parameter", "Validating Data")
      try {

        val (k,counts1,counts2) = assertDataFrameEqualsK(src, tgt, resolver.alias, conf.fixedHDFSpath, false)
        if (k == true) {
          test_data_validation.pass(s"${resolver.alias} - Validation of Data is successful")
          test_data_validation.pass(s"Samples of data Match from both tables:\n" +
            s"Path: " + conf.fixedHDFSpath + s"/${resolver.alias}/csv_match/")
          infoDF.withColumn("Data Validation", lit("Pass"))

        }
        else {
          test_data_validation.fail(s"${resolver.alias} - Validation of Data failed: Mismatched rows from source : "+counts1+ " Mismatched rows from target : "+ counts2 )
          test_data_validation.fail(s"Samples of data Mismatch:\n" +
            s"Path: " + conf.fixedHDFSpath + s"/${resolver.alias}/csv_mismatch/")
          infoDF.withColumn("Data Validation", lit("Fail"))

        }
      } catch {
        case unknown: Exception => test_data_validation.error(s"${resolver.alias} - Dataframe validtaion exception. Validation could not be " +
          s"completed." + unknown)
          infoDF.withColumn("Data Validation", lit("Error"))

      }
    } else if ((conf.nullValue.isEmpty) && !(conf.emptyValue.isEmpty)) {
      val testDataValidation = parentTest.createNode(s"Data Validation(Replacing empty values with the null}", "Validating Data")
      try {
        val (k,counts1,counts2) = assertDataFrameEqualsK(src, tgt, resolver.alias, conf.fixedHDFSpath, false)
        if (k == true) {
          testDataValidation.pass(s"${resolver.alias} - Validation of Data is successful")
          testDataValidation.pass(s"Samples of data Match from both tables:\n" +
            s"Path: " + conf.fixedHDFSpath + s"/${resolver.alias}/csv_match/")
          infoDF.withColumn("Data Validation", lit("Pass"))
        }
        else {
          testDataValidation.fail(s"${resolver.alias} - Validation of Data failed: Mismatched rows from source : "+counts1+ " Mismatched rows from target : "+ counts2 )
          testDataValidation.fail(s"Samples of data Mismatch:\n" +
            s"Path: " + conf.fixedHDFSpath + s"/${resolver.alias}/csv_mismatch/")
          infoDF.withColumn("Data Validation", lit("Fail"))
        }
      } catch {
        case unknown: Exception => testDataValidation.error(s"${resolver.alias} - Dataframe validtaion exception. Validation could not be " +
          s"completed." + unknown)
          infoDF.withColumn("Data Validation", lit("Error"))

      }
    } else {
      val testDataValidation = parentTest.createNode(s"Data Validation", "Validating Data")
      try {
        val (k,counts1,counts2) = assertDataFrameEqualsK(src, tgt, resolver.alias, conf.fixedHDFSpath, false)
        if (k == true) {
          testDataValidation.pass(s"${resolver.alias} - Validation of Data is successful")
          testDataValidation.pass(s"Samples of data Match from both tables:\n" +
            s"Path: " + conf.fixedHDFSpath + s"/${resolver.alias}/csv_match/")
          infoDF.withColumn("Data Validation", lit("Pass"))
        }
        else {
          testDataValidation.fail(s"${resolver.alias} - Validation of Data failed: Mismatched rows from source : "+counts1+ " Mismatched rows from target : "+ counts2 )
          testDataValidation.fail(s"Samples of data Mismatch:\n" +
            s"Path: " + conf.fixedHDFSpath + s"/${resolver.alias}/csv_mismatch/")
          infoDF.withColumn("Data Validation", lit("Fail"))

        }
      } catch {
        case unknown: Exception => testDataValidation.error(s"${resolver.alias} - Dataframe validtaion exception. Validation could not be " +
          s"completed." + unknown)
          infoDF.withColumn("Data Validation", lit("Error"))

      }
    }
    updateInfoDF
  }


  def sumCheckTest(parentTest: ExtentTest, src: Dataset[Row], tgt: Dataset[Row], resolver: Resolver.resolveConf, aggCols:Seq[String],infoDF:Dataset[Row]):Dataset[Row]= {

    val sumCheck = parentTest.createNode(s"Sum Check", "Checking for Aggregation for Specified columns in Data")
    val updateInfoDF=try {
      val columnNames = aggCols
      val sums = columnNames.map(colName => sum(colName).cast("Decimal(38, 16)").as("sum_" + colName))
      val sumSrc = src.groupBy().agg(sums.head, sums.tail: _*).first
      val sumTgt = tgt.groupBy().agg(sums.head, sums.tail: _*).first
      val sumChecks = sumSrc.equals(sumTgt)

      if (sumChecks == true) {
        sumCheck.pass(s"${resolver.alias} - Validation of Sums for " + columnNames.mkString(",") + " is successful: \n" +
          "Source: " + sumSrc.mkString(",") + " is equal to Target: " + sumTgt.mkString(","))
        infoDF.withColumn("Sum Check", lit("Pass"))
      }
      else {
        sumCheck.fail(s"${resolver.alias} - Validation of Sums for " + columnNames.mkString(",") + " failed: \n" +
          "Source: " + sumSrc.mkString(",") + " is  not equal to Target: " + sumTgt.mkString(","))
        infoDF.withColumn("Sum Check", lit("Fail"))
      }

    } catch {
      case unknown: Exception => sumCheck.error(s"${resolver.alias} - Dataframe Sum check could not be " +
        s"completed." + unknown)
        infoDF.withColumn("Sum Check", lit("Error"))

    }
    updateInfoDF
  }

  def nullCheckTest(parentTest: ExtentTest, src: Dataset[Row], tgt: Dataset[Row],srcCount: Long, tgtCount: Long, resolver: Resolver.resolveConf,infoDF:Dataset[Row]):Dataset[Row]= {
    val test_null_row_check = parentTest.createNode(s"Null Rows Check", "Checking for null rows in Data")
    val updateInfoDF=try {
      val srcNullCheck = srcCount - src.na.drop(1, src.columns).count()
      val tgtNullCheck = tgtCount - tgt.na.drop(1, tgt.columns).count()
      if (srcNullCheck == 0 && tgtNullCheck == 0) {
        test_null_row_check.pass(s"${resolver.alias} - No null rows found")
        infoDF.withColumn("Null Rows Check", lit("Pass"))

      }
      else {
        test_null_row_check.fail(s"${resolver.alias} - Null rows found:\n" + "Source table:" + srcNullCheck + "Target table:" +
          tgtNullCheck)
        infoDF.withColumn("Null Rows Check", lit("Fail"))
      }

    } catch {
      case unknown: Exception => test_null_row_check.error(s"${resolver.alias} - Dataframe null check could not be " +
        s"completed." + unknown)
        infoDF.withColumn("Null Rows Check", lit("Error"))
    }
    updateInfoDF
  }

  def getSampleData(parentTest: ExtentTest,srcTable:Dataset[Row],tgtTable:Dataset[Row]): Unit ={
    import com.aventstack.extentreports.markuputils.MarkupHelper
    val srcHead= srcTable.schema.fieldNames.map(_.toLowerCase)
    val tgtHead= tgtTable.schema.fieldNames.map(_.toLowerCase)
    val srcDf=srcTable.limit(1).cache()
    val tgtDf=tgtTable.intersect(srcDf)
    val sourcePrintDf =srcDf.take(1).map{ r =>val array = r.toSeq.toArray; array.map(y=> if(y != null){y.toString} else null)}.flatten
    val targetPrintDf=tgtDf.take(1).map{ r =>val array = r.toSeq.toArray; array.map(y=> if(y != null){y.toString} else null)}.flatten
    val srcPrintDf = srcHead.zip(sourcePrintDf).toSeq.toDF.collect().map{ r =>val array = r.toSeq.toArray; array.map(y=> if(y != null){y.toString} else null)}
    val tgtPrintDf = tgtHead.zip(targetPrintDf).toSeq.toDF.collect().map{ r =>val array = r.toSeq.toArray; array.map(y=> if(y != null){y.toString} else null)}
    val srcPrint = MarkupHelper.createTable(srcPrintDf)
    val tgtPrint = MarkupHelper.createTable(tgtPrintDf)
    val printTest = parentTest.createNode(s"Sample Datas", "Print Sample Data")
    printTest.info(srcPrint)
    printTest.info(tgtPrint)
    srcDf.unpersist()
  }

  def dataMiniValidation(parentTest: ExtentTest, src: Dataset[Row], tgt: Dataset[Row], resolver: Resolver.resolveConf,conf: ConfFile.mainConf): Unit = {
    if (resolver.srcConType == "netezza" || resolver.srcConType == "oracle" || resolver.srcConType == "sqlserver" || resolver.srcConType == "teiid" || resolver.srcConType == "exasol" || resolver.srcConType == "impala" || resolver.srcConType == "db2") {
      val testDataValidation = parentTest.createNode(s"Data Validation(Random 200 records)", "Validating Data")
      try {
        var (dCompare,dataS,dataT)= assertDataFrameEqualsB(src, tgt,false)
        var sData = false
        if (dCompare == true) {
          sData= true
        }
        if (sData == true) {
          testDataValidation.pass(s"${resolver.alias} -  Data validation for 200 sample records with Source table to target. \n Unmatched Rows:  \n From Source :" + dataS + "\n From Target :" + dataT)
          src.coalesce(1).write.mode(saveMode = "overwrite").option("delimiter", ",").option("header","true").csv(s"${conf.fixedHDFSpath}/csv/${resolver.alias}/src.csv")
          tgt.coalesce(1).write.mode(saveMode = "overwrite").option("delimiter", ",").option("header","true").csv(s"${conf.fixedHDFSpath}/csv/${resolver.alias}/tgt.csv")
          testDataValidation.pass(s"Samples of data Match from table:\n" + s"Path: " + s"${conf.fixedHDFSpath}/csv/${resolver.alias}")
        }
        else {
          testDataValidation.fail(s"${resolver.alias} - Validation of Data failed \n Unmatched Rows:  \n From Source :" + dataS + "\n From Target :" + dataT)
          src.coalesce(1).write.mode(saveMode = "overwrite").option("delimiter", ",").option("header","true").csv(s"${conf.fixedHDFSpath}/csv/${resolver.alias}/src.csv")
          tgt.coalesce(1).write.mode(saveMode = "overwrite").option("delimiter", ",").option("header","true").csv(s"${conf.fixedHDFSpath}/csv/${resolver.alias}/tgt.csv")
          testDataValidation.fail(s"Samples of data Mismatch from table:\n" + s"Path: " + s"${conf.fixedHDFSpath}/csv/${resolver.alias}")
        }
      } catch {
        case unknown: Exception => testDataValidation.error(s"${resolver.alias} - Data validation exception. Validation could not be completed for some other reason. " + unknown)
      }
    }
  }

  def dataDebugTest(parentTest: ExtentTest, src: Dataset[Row], tgt: Dataset[Row], resolver: Resolver.resolveConf, conf: ConfFile.mainConf): Unit = {
    import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.sparkSession
    val testDebugValidation = parentTest.createNode(s"Data Validation to find exact mismatch", "Validating Data")
    val columns = src.schema.fields.map(_.name)
    val selectiveDifferences = columns.map(col => src.select(col).except(tgt.select(col)))
    val selectiveDifferencesTgt = columns.map(col => tgt.select(col).except(src.select(col)))
    def addColumnIndex(df: Dataset[Row]) = sparkSession.createDataFrame(
      df.rdd.zipWithIndex.map{case (row, columnindex) => Row.fromSeq(row.toSeq :+ columnindex)}, StructType(df.schema.fields :+ StructField("columnindex", LongType, false))
    )
    val mismatchArray: Array[Dataset[Row]] = selectiveDifferences.filter(diff => diff.count>0)
    val ArrayDF: Array[sql.DataFrame] = mismatchArray.map(diff => addColumnIndex(diff.limit(5)))
    val dfSrc = ArrayDF.tail.foldLeft(ArrayDF.head){(df1, df2) => df1.join(df2, Seq("columnindex"))}.drop("columnindex")
    val mismatchArrayTgt = selectiveDifferencesTgt.filter(diff => diff.count>0)
    val ArrayDF1: Array[sql.DataFrame] = mismatchArrayTgt.map(diff => addColumnIndex(diff.limit(5)))
    val dftgt = ArrayDF1.tail.foldLeft(ArrayDF1.head){(df1, df2) => df1.join(df2, Seq("columnindex"))}.drop("columnindex")
if (!(dfSrc.count == 0 || dftgt.count == 0)){
  dfSrc.repartition(1).write.mode(saveMode = "overwrite").option("delimiter", ",").option("header","true").csv(s"${conf.fixedHDFSpath}/${resolver.alias}/csv_analyze/src")
  dftgt.repartition(1).write.mode(saveMode = "overwrite").option("delimiter", ",").option("header","true").csv(s"${conf.fixedHDFSpath}/${resolver.alias}/csv_analyze/tgt")
  testDebugValidation.fail(s"${resolver.alias} - Validation of Data failed : Refer Path :" + s"${conf.fixedHDFSpath}/${resolver.alias}/csv_analyze/")
}else{testDebugValidation.pass(s"${resolver.alias} - Validation of Data passed : No Differences found")}
  }

  def getInfo(parentTest: ExtentTest,resolver: Resolver.resolveConf, conf: ConfFile.mainConf,environment:String,asst:String,con:String,ten:String) ={
    import com.aventstack.extentreports.markuputils.MarkupHelper
    val infoDF: sql.DataFrame = Seq(
      (environment,asst,con,ten,resolver.srcConType, resolver.srcTableNm,resolver.tgtTableNm)
    ).toDF("Enviornment","Asset","Country","Tenant","Source Type", "Source Table Name","Target Table Name")
    val srcHead= infoDF.schema.fieldNames
    val sourcePrintDf =infoDF.take(1).map{ r =>val array = r.toSeq.toArray; array.map(y=> if(y != null){y.toString} else null)}.flatten
    val srcPrintDf = srcHead.zip(sourcePrintDf).toSeq.toDF.collect().map{ r =>val array = r.toSeq.toArray; array.map(y=> if(y != null){y.toString} else null)}
    val srcPrint = MarkupHelper.createTable(srcPrintDf)
    val printTest = parentTest.createNode(s"Source/Target Information", "Source and target information")
    printTest.info(srcPrint)
    infoDF
  }

}