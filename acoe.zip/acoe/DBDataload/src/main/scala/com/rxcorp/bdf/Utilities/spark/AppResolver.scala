package com.rxcorp.bdf.Utilities.spark


import com.typesafe.config.{Config, ConfigFactory}
import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}

import scala.io.Source
import scala.util.Try

object AppResolver {

/** The `readFromConfigFile` method returns [[AppConfig]] case class instance by resolving the reference.conf.
  * @return [[AppConfig]]
  *        */

  def readFromConfigFile: AppConfig = {
    ConfigFactory.invalidateCaches()
    val appConfig: Config = ConfigFactory.load().resolve().getConfig("app")

    def createHadoopConfig: HadoopConfig = {
      val hadoopConfig: Config = appConfig.getConfig("hadoop")
      val hiveSiteXML: String = hadoopConfig.getString("hive-site-xml")
      val yarnSiteXML: String = hadoopConfig.getString("yarn-site-xml")
      val sparkHome: String = hadoopConfig.getString("sparkHome")
      val sparkMaster: String = hadoopConfig.getString("sparkMaster")
      val sparkDeployMode: String = hadoopConfig.getString("sparkDeployMode")
      HadoopConfig(hiveSiteXML, yarnSiteXML, sparkHome, sparkMaster, sparkDeployMode)
    }
    val loggerConfig: Config = appConfig.getConfig("qimsLogger")
    AppConfig(createHadoopConfig, loggerConfig)
  }

  /** The `getEnv` method returns the client environment name based on the DIUP.
    * @return Environment name development | integration | acceptance | production
    */
  def getEnv: String = {
    val envCode: String  = Try(System.getenv("LOGNAME").split("")(3)).getOrElse("d")
    val env: String = envCode match {
      case "d" => "development"
      case "i" => "integration"
      case "u" => "acceptance"
      case "p" => "production"
    }
    env
  }

  /**
    *The `readSparkProps` method returns a list of user submitted Spark properties from .properties file
    * @param propsFile The absolute path to the Spark Properties file on the edgenode
    * @return List of user submitted Spark properties
    */
  def readSparkProps(propsFile: String): List[String] = {
    import scala.collection.JavaConversions._
    ConfigFactory.invalidateCaches()
    val br= Source.fromFile(propsFile).getLines.filter(x=>x.startsWith("--")).map(l=>l.replace("--","")).map(l => l.replace("@", "\"@\"")).mkString("\n")
    val config: Config = ConfigFactory.parseString(br).resolveWith(ConfigFactory.systemProperties())
    val confList = config.entrySet().map({ entry => s"${entry.getKey}=${entry.getValue.unwrapped}"}).toList
    confList
  }

  /** The `HadoopConfig` case class offers access to the values held in the parameters for an instance.
    * @param hiveSiteXML The absolute path for hive-site.xml file on the edgenode.
    * @param yarnSiteXML The absolute path for yarn-site.xml file on the edgenode.
    * @param sparkHome The absolute path for spark home directory on the edgenode.
    * @param sparkMaster The cluster manager to connect to.
    * @param sparkDeployMode The spark application deploy mode (cluster / client).
    */
  case class HadoopConfig(hiveSiteXML: String, yarnSiteXML: String,
                          sparkHome: String, sparkMaster: String,
                          sparkDeployMode: String) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("hiveSiteXML", hiveSiteXML)
        .append("yarnSiteXML", yarnSiteXML)
        .append("sparkHome", sparkHome)
        .append("sparkMaster", sparkMaster)
        .append("sparkDeployMode", sparkDeployMode)
        .toString
    }
  }

  /** The `AppConfig` case class offers access to the values held in the parameters for an instance.
    *  @param hadoopConfig The [[HadoopConfig]] case class instance.
    *  @param loggerConfig The config used by BDF logging framework.
    */
  case class AppConfig( hadoopConfig: HadoopConfig, loggerConfig: Config) {
    // Override case class default toString to exclude sensitive Strings.
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("hadoopConfig", hadoopConfig)
        .append("loggerConfig", loggerConfig)
        .toString
    }
  }
}
