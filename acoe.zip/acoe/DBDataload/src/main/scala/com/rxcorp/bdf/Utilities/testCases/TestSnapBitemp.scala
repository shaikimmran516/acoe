package com.rxcorp.bdf.Utilities.testCases

import java.io.{ InputStreamReader}
import BitempDataValidation.assertDataFrameEqualsB
import com.aventstack.extentreports.ExtentReports
import com.aventstack.extentreports.reporter.ExtentHtmlReporter
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.sparkSession
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext
import com.typesafe.config.{Config, ConfigFactory}
import org.scalatest.FunSuite
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext.implicits._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataType, StructType}
import org.apache.spark.sql.{Column, Dataset, Row}
import scala.util.Try

//TODO :Clean up of this class is needed to be in precise code format and standards
class TestSnapBitemp extends FunSuite {
  var config1 = ""
  var table1 = ""
  var src_table = ""
  var pre_tgt_table = ""
  var new_tgt_table=""
  var source_col = Array[String]()
  var target_col = Array[String]()
  var p_key =  List[String]()
  var source_sys = ""
  var run_op=""
  var Load_dt=""
  var agg_cols=List[String]()
  var nonCompare=List[String]()
  var bussEffMap=List[String]()
  var deltaMap=List[String]()

  def param(conf: String, table: String, src_tbl: String, pre_tgt_tbl: String, new_tgt_tbl:String,primary_key:List[String],run_opt:String,Load_Dt:String,non_compare:List[String] ,business_eff_map:List[String],delta_map:List[String],sys: String,agg_columns:List[String]): Unit = {
    config1 = conf
    table1 = table
    src_table = src_tbl
    pre_tgt_table = pre_tgt_tbl
    new_tgt_table = new_tgt_tbl
    p_key = primary_key
    Load_dt = Load_Dt
    run_op = run_opt
    //source_col = src_col.map(x => x.toLowerCase)
    //target_col = tgt_col.map(x => x.toLowerCase)
    source_sys = sys
    agg_cols = agg_columns
    nonCompare=non_compare
    bussEffMap=business_eff_map
    deltaMap=delta_map
  }

  test("Bitemp comparison") {
    val  fileSystem = FileSystem.get(new Configuration())
    println(fileSystem)
    val jobFile: Path = new Path(config1)
    println(jobFile)
    //val confFFF= Source.fromFile(jobFilePath1).bufferedReader()
    //println(confFFF)
    val reader = new InputStreamReader(fileSystem.open(jobFile))

    // val confFFF =new BufferedReader(new InputStreamReader(fileSystem.open(jobFile)))
    val config: Config = ConfigFactory.parseReader(reader).withFallback(ConfigFactory.systemProperties()).resolve()





    //val confFile = Paths.get(config1).toFile
    //val config = ConfigFactory.parseFile(confFile)
    //val config = ConfigFactory.load(jobFileConfig)
    val table = table1
    val fixed_path = config.getString("home_hdfs_dir")
    var C_test=Try(config.getString("column_count").trim).getOrElse("yes")
    var F_test=Try(config.getString("field_name").trim).getOrElse("yes")
    var Rc_test=Try(config.getString("record_count").trim).getOrElse("yes")
    var S_test=Try(config.getString("schema_check").trim).getOrElse("yes")
    var Du_test=Try(config.getString("duplicate").trim).getOrElse("yes")
    var Data_test=Try(config.getString("data_validation").trim).getOrElse("yes")
    var n_test=Try(config.getString("null_check").trim).getOrElse("yes")
    var su_test=Try(config.getString("sum_check").trim).getOrElse("yes")
    var null_rep=Try(config.getString("nullValue")).getOrElse(null)
    var empty_rep=Try(config.getString("emptyValue")).getOrElse(null)



    val confFileName = config1.split("\\/").toList.takeRight(1).head.toString.split("\\.").toList.take(1).head.toString

    val htmlReporter = new ExtentHtmlReporter( s"${confFileName}_comparison.html") //config.getString("home_hdfs_dir") +
    // create ExtentReports and attach reporter(s)
    val extent = new ExtentReports
    htmlReporter.setAppendExisting(true)
    extent.attachReporter(htmlReporter)
    var source_header: String = "true"
    //    if (conf.getInt("source_header") != 1)
    //      source_header = "false"

    def nullifyEmptyStrings(df:Dataset[Row]): Dataset[Row] = {
      var in = df
      for (e <- df.columns) {
        in = in.withColumn(e, when(length(col(e))===0, lit(null)).otherwise(col(e)))
      }
      in
    }
    var source_dataframe = hiveContext.emptyDataFrame
    var source_dataframe2 = hiveContext.emptyDataFrame
    var source_dataframe3 = hiveContext.emptyDataFrame
    try {
      if (!(null_rep == null)) {
        source_dataframe2 = sparkSession.read.option("ignoreLeadingWhiteSpace", false).option("ignoreTrailingWhiteSpace", false).parquet(config.getString("home_hdfs_dir") + s"/${table}/src/*")
        if(!(empty_rep==null)){
          source_dataframe3 = source_dataframe2.na.fill(null_rep)
          source_dataframe = nullifyEmptyStrings(source_dataframe3)
        }
        else {
          source_dataframe = source_dataframe2.na.fill(null_rep)
        }

      } else
      {

        if(!(empty_rep==null)){
          source_dataframe3 = sparkSession.read.option("ignoreLeadingWhiteSpace", false).option("ignoreTrailingWhiteSpace", false).parquet(config.getString("home_hdfs_dir") + s"/${table}/src/*")

          source_dataframe = nullifyEmptyStrings(source_dataframe3)
        }
        else {
          source_dataframe = sparkSession.read.option("ignoreLeadingWhiteSpace", false).option("ignoreTrailingWhiteSpace", false).parquet(config.getString("home_hdfs_dir") + s"/${table}/src/*")
        }

      }
      println(s"${table} -Source schema structure")
      source_dataframe.printSchema()
      println(s"${table} - Source data loading validation successful.")
    } catch {
      case unknown: Exception => println(s"${table} - Source data loading failed." + unknown)
    }

    var prev_target_dataframe = hiveContext.emptyDataFrame
    var prev_target_dataframe2 = hiveContext.emptyDataFrame

    //    val target_dataframe = spark.read.option("header", header1)
    //    .option("delimiter", conf.getString("target_delimiter")).option("inferSchema", "true").csv(conf.getString("target_hdfs_file"))
    try {
      prev_target_dataframe = sparkSession.read.option("ignoreLeadingWhiteSpace", false).option("ignoreTrailingWhiteSpace", false).parquet(config.getString("home_hdfs_dir") + s"/${table}/prev_tgt/*")
      println(s"${table} -Target schema structure")
      prev_target_dataframe.printSchema()
      //target_col=target_dataframe.schema.fieldNames

      // val header22 = target_dataframe.first()
      //target_dataframe2 = target_dataframe.filter(row => row.toSeq.toArray.deep != header22.toSeq.toArray.deep)
      println(s"${table} - Target data loading validation successful.")
    } catch {
      case unknown: Exception => println(s"${table} - Target data loading failed." + unknown)
    }

    var new_target_dataframe=hiveContext.emptyDataFrame
    var new_target_dataframe2=hiveContext.emptyDataFrame

    //    val target_dataframe = spark.read.option("header", header1)
    //    .option("delimiter", conf.getString("target_delimiter")).option("inferSchema", "true").csv(conf.getString("target_hdfs_file"))
    try {
      new_target_dataframe = sparkSession.read.option("ignoreLeadingWhiteSpace", false).option("ignoreTrailingWhiteSpace", false).parquet(config.getString("home_hdfs_dir") + s"/${table}/curr_tgt/*")
      println(s"${table} -Target schema structure")
      new_target_dataframe.printSchema()
      //target_col=target_dataframe.schema.fieldNames

      // val header22 = target_dataframe.first()
      //target_dataframe2 = target_dataframe.filter(row => row.toSeq.toArray.deep != header22.toSeq.toArray.deep)
      println(s"${table} - Target data loading validation successful.")
    } catch {
      case unknown: Exception => println(s"${table} - Target data loading failed." + unknown)
    }




    var colsDrop = bussEffMap ++ nonCompare


    var dataCompare1 = new_target_dataframe.except(prev_target_dataframe).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    var window = Window.partitionBy(p_key.map(col): _*).orderBy(p_key.map(col): _*)
    var tgtChanges= dataCompare1.withColumn("count",count(concat(p_key.map(col): _*)).over(window)).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)


    // I/U/D from targets in seprate dataframes // delete also contains delete reaapearing records

    var tgtInsert = tgtChanges.filter("count==1").drop("count")
    var tgtInsertDrop= tgtInsert.select(tgtInsert.columns.filter(colName => !colsDrop.contains(colName)).map(colName => new Column(colName)): _*).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    var tgtUpdate = dataCompare1.filter("row_not_recv_ind<>1").withColumn("count",count(concat(p_key.map(col): _*)).over(window)).filter("count==3").drop("count")
    var tgtUpdateDrop= tgtUpdate.select(tgtUpdate.columns.filter(colName => !colsDrop.contains(colName)).map(colName => new Column(colName)): _*).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    var tgtReappear= tgtChanges.filter("count==3").drop("count").except(tgtUpdate)
    var tgtReappearDrop= tgtReappear.select(tgtReappear.columns.filter(colName => !colsDrop.contains(colName)).map(colName => new Column(colName)): _*).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    var tgtDelete = tgtChanges.filter("count==2").drop("count")
    var tgtDeleteDrop= tgtDelete.select(tgtDelete.columns.filter(colName => !colsDrop.contains(colName)).map(colName => new Column(colName)): _*).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)

    dataCompare1.unpersist()
    tgtChanges.unpersist()




    var window1 = Window.partitionBy(p_key.map(col): _*).orderBy(col("bus_eff_dt").desc,col("proc_eff_ts").desc)
    var snapD=prev_target_dataframe.withColumn("rank",rank().over(window1)).filter("rank==1").drop("rank").persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    var snap= snapD.filter("row_not_recv_ind<>1").persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    var colsToRemov = Seq("bus_eff_dt", "bus_expry_dt", "proc_eff_ts", "proc_expry_ts", "row_not_recv_ind", "oprtnl_stat_cd")
    var snap_no_bitemp= snap.select(snap.columns.filter(colName => !colsToRemov.contains(colName)).map(colName => new Column(colName)): _*)
    val deleted_snap = snapD.filter("row_not_recv_ind=1").select(p_key.map(col): _*).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)


    snap.unpersist()
    snapD.unpersist()

    var src_drop=source_dataframe.select(source_dataframe.columns.filter(colName => !colsDrop.contains(colName)).map(colName => new Column(colName)): _*).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    var snap_no_bitemp_drop=snap_no_bitemp.select(snap_no_bitemp.columns.filter(colName => !colsDrop.contains(colName)).map(colName => new Column(colName)): _*).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)


    snap_no_bitemp.unpersist()


    var dataCompare2 = src_drop.except(snap_no_bitemp_drop).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    var dataCompare3= snap_no_bitemp_drop.except(src_drop).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)

    snap_no_bitemp_drop.unpersist()

    var commonKeys= dataCompare2.select(p_key.map(col): _*).intersect(dataCompare3.select(p_key.map(col): _*)).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    //var commonWDeletedKeys=commonKeys.except(deleted_snap).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)


    var srcUpdateNew = dataCompare2.join(commonKeys, p_key).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    var srcUpdateOld = dataCompare3.join(commonKeys, p_key).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)

    commonKeys.unpersist()
    //commonWDeletedKeys.unpersist()
    var srcReappear =dataCompare2.join(deleted_snap, p_key).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    //var srcReappearOld= dataCompare3.join(deleted_snap, p_key).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)

    var srcInsert=dataCompare2.except(srcUpdateNew).except(srcReappear).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    var srcDelete=dataCompare3.except(srcUpdateOld).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)


    deleted_snap.unpersist()
    dataCompare2.unpersist()
    dataCompare3.unpersist()

    var current_snap= new_target_dataframe.withColumn("rank",rank().over(window1)).filter("rank==1").drop("rank").persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    var current_snap_no_bitem= current_snap.select(current_snap.columns.filter(colName => !colsToRemov.contains(colName)).map(colName => new Column(colName)): _*).filter("row_not_recv_ind<>1").persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    var current_snap_no_bitem_drop=current_snap_no_bitem.select(current_snap_no_bitem.columns.filter(colName => !colsDrop.contains(colName)).map(colName => new Column(colName)): _*).filter("row_not_recv_ind<>1").persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
    current_snap.unpersist()
    current_snap_no_bitem.unpersist()





    val col_test = extent.createTest(s"${table} - Validation", "Validating Source and Target Table")
    println("validating table fields")

    var src_col_count = source_dataframe.columns.length
    var tgt_col_count = new_target_dataframe.columns.length

    if(C_test=="yes" || C_test == "" || C_test == null){
      val col_count = col_test.createNode("Column Count Validation", "Checking Numbers of Columns")
      try {
        val colException = intercept[org.scalatest.exceptions.TestFailedException] {
          assert( src_col_count === (tgt_col_count-6) )
        }
        if (!colException.getMessage().isEmpty())
          col_count.fail(s"${table} - Count exception is given below: <br>" + colException)
        else
          col_count.pass(s"${table} - Validating column counts <br> ${src_table} Table - Source table count : "
            + src_col_count + s"<br> ${new_tgt_table} Table - Target table count including 6 extra Bitemp columns : " + tgt_col_count)

      } catch {
        case e: org.scalatest.exceptions.TestFailedException => col_count.pass(s"${table} - Validating column counts <br> " +
          s"${src_table} Table - Source table count : " + src_col_count + s"<br> ${new_tgt_table} Table - Target table count including 6 extra Bitemp columns : "
          + tgt_col_count)
        case unknown: Exception => col_count.error(s"${table} - Count exception. Validation could not be completed for some other reason. " + unknown)
      }
    }

    if(F_test=="yes" || F_test == "" || F_test == null) {
      val test_fields = col_test.createNode(s"Field Name Validation", "Validating Field Names")

      var src_field_names=source_dataframe.schema.fieldNames.map(_.toLowerCase)
      var tgt_field_names= new_target_dataframe.schema.fieldNames.map(_.toLowerCase)
      var bitempCols = Array("bus_eff_dt", "bus_expry_dt", "proc_eff_ts", "proc_expry_ts", "row_not_recv_ind", "oprtnl_stat_cd").map(_.toLowerCase)
      var tgt_fields_noBitemp= tgt_field_names.diff(bitempCols)



      try {
        val fieldException = intercept[org.scalatest.exceptions.TestFailedException] {
          assertResult(src_field_names.deep) {
            tgt_fields_noBitemp.deep
          }
        }

        if (!fieldException.getMessage().isEmpty())
          test_fields.fail(s"${table} - Field Name exception is given below: <br>" + fieldException)
        else
          test_fields.pass(s"${table} - Validation of Field names is Successful. <br> ${src_table} Table - Source Field Names " +
            s"are given below:  <br> " + src_field_names.mkString("\n") + s" <br> ${new_tgt_table} Table - Target Field Names including Bitemp Columns " +
            s"are given below: <br>" + tgt_field_names.mkString("\n"))
      } catch {
        case e: org.scalatest.exceptions.TestFailedException => test_fields.pass(s"${table} - Validation of Field names is " +
          s"Successful. <br> ${src_table} Table - Source Field Names are given below:  <br> " + src_field_names.mkString("\n")
          + s" <br> ${new_tgt_table} Table - Target Field Names  including Bitemp columns are given below:  <br>" + tgt_field_names.mkString("\n"))
        case unknown: Exception => test_fields.error(s"${table} - Validation of Field Name got exception. Validation could not be " +
          s"completed for some other reason." + unknown)
      }
    }



    var tUpdateCounts = tgtUpdateDrop.count
    var sUpdateNewCounts = srcUpdateNew.count
    var sUpdateOldCounts = srcUpdateOld.count
    var tInputCounts = tgtInsertDrop.count
    var sInputCounts = srcInsert.count
    var tSnapCounts = current_snap_no_bitem_drop.count
    var sSnapCounts = source_dataframe.count
    var tDeleteCounts = tgtDeleteDrop.count
    var sDeleteCounts = srcDelete.count
    var tReappearCounts = tgtReappearDrop.count
    var sReappearCounts = srcReappear.count

    if(Rc_test=="yes" || Rc_test == "" || Rc_test == null) {


      val test_count = col_test.createNode(s"Record Count Checking", "Validating Counts")

      val snap_count = test_count.createNode(" Current Snapshot", "Validating Counts of Source with Current Snapshot from target ")


      var snapCounts: Boolean = false
      try {

        if (tSnapCounts == sSnapCounts) {
          snapCounts = true
        }


        if (snapCounts == false)
          snap_count.fail(s"${table} - Validating Count with Current Snapshot from target <br> ${src_table} Table - Source table count : "
            + sSnapCounts + s"<br> ${new_tgt_table} Table - Target table count : " + tSnapCounts)
        else
          snap_count.pass(s"${table} - Validating Count with Current Snapshot from target <br> ${src_table} Table - Source table count : "
            + sSnapCounts + s"<br> ${new_tgt_table} Table - Target table count : " + tSnapCounts)

      } catch {
        case unknown: Exception => snap_count.error(s"${table} - Count exception. Validation could not be completed for some other reason. " + unknown)
      }

      val test_input_count = test_count.createNode(" New Input Records", "Validating Counts of New Input Records")


      var inputCounts: Boolean = false
      try {

        if (tInputCounts == sInputCounts) {
          inputCounts = true
        }


        if (inputCounts == false)
          test_input_count.fail(s"${table} - Validating Count of new Input records <br> ${src_table} Table - Source table count : "
            + sInputCounts + s"<br> ${new_tgt_table} Table - Target table count : " + tInputCounts)
        else
          test_input_count.pass(s"${table} - Validating Count of new Input records <br> ${src_table} Table - Source table count : "
            + sInputCounts + s"<br> ${new_tgt_table} Table - Target table count : " + tInputCounts)

      } catch {
        case unknown: Exception => test_input_count.error(s"${table} - Count exception. Validation could not be completed for some other reason. " + unknown)
      }


      val test_delete_count = test_count.createNode(" Deleted Records", "Validating Counts of Deleted Records")


      var deleteCounts: Boolean = false
      try {

        if ((sDeleteCounts + sDeleteCounts) == tDeleteCounts) {
          deleteCounts = true
        }

        if (deleteCounts == false)
          test_delete_count.fail(s"${table} - Validating Count of Deleted records <br> ${src_table} Table - Source table count : "
            + sDeleteCounts + s"<br> ${new_tgt_table} Table - Target table count : " + tDeleteCounts)
        else
          test_delete_count.pass(s"${table} - Validating Count of Deleted records <br> ${src_table} Table - Source table count : "
            + sDeleteCounts + s"<br> ${new_tgt_table} Table - Target table count : " + tDeleteCounts)

      } catch {
        case unknown: Exception => test_delete_count.error(s"${table} - Count exception. Validation could not be completed for some other reason. " + unknown)
      }

      val test_update_count = test_count.createNode(" Updated Records", "Validating Counts of Updated Records")


      var updateCounts: Boolean = false
      try {

        if ((sUpdateNewCounts + sUpdateOldCounts + sUpdateOldCounts) == tUpdateCounts) {
          updateCounts = true
        }

        if (updateCounts == false)
          test_update_count.fail(s"${table} - Validating Count Updated records <br> ${src_table} Table - Source table count : "
            + sUpdateNewCounts + s"<br> ${new_tgt_table} Table - Target table count : " + tUpdateCounts)
        else
          test_update_count.pass(s"${table} - Validating Count Updated records <br> ${src_table} Table - Source table count : "
            + sUpdateNewCounts + s"<br> ${new_tgt_table} Table - Target table count : " + tUpdateCounts)

      } catch {
        case unknown: Exception => test_update_count.error(s"${table} - Count exception. Validation could not be completed for some other reason. " + unknown)
      }

      val test_reappear_count = test_count.createNode(" Reappeared Records", "Validating Counts of Reappeared Records")


      var ReappearCounts: Boolean = false
      try {

        if ((3*sReappearCounts) == tReappearCounts) {
          ReappearCounts = true
        }

        if (ReappearCounts == false)
          test_reappear_count.fail(s"${table} - Validating Count Reappeared records <br> ${src_table} Table - Source table count : "
            + sReappearCounts + s"<br> ${new_tgt_table} Table - Target table count : " + tReappearCounts)
        else
          test_reappear_count.pass(s"${table} - Validating Count Reappeared records <br> ${src_table} Table - Source table count : "
            + sReappearCounts + s"<br> ${new_tgt_table} Table - Target table count : " + tReappearCounts)

      } catch {
        case unknown: Exception => test_reappear_count.error(s"${table} - Count exception. Validation could not be completed for some other reason. " + unknown)
      }
    }

    if(S_test=="yes" || S_test == "" || S_test == null){
      if (source_sys=="netezza"|| source_sys=="oracle"||source_sys=="sqlserver" || source_sys=="teiid" || source_sys=="exasol"){
        val test_data_schema = col_test.createNode(s"Schema Check", "Comparing the Schemas")


        try {
          val schm = DataType.fromJson(source_dataframe.schema.json.replaceAll("\"nullable\":false", "\"nullable\":true")).asInstanceOf[StructType]

          var tgt_schema = new_target_dataframe.schema.toString.replace(", StructField(bus_eff_dt,StringType,true), StructField(bus_expry_dt,StringType,true), StructField(proc_eff_ts,StringType,true), StructField(proc_expry_ts,StringType,true), StructField(row_not_recv_ind,StringType,true), StructField(oprtnl_stat_cd,StringType,true)","")



          var d_schem_check = false
          if (schm.toString().equalsIgnoreCase(tgt_schema)) {
            d_schem_check = true
          }
          if (d_schem_check == true) {
            test_data_schema.pass(s"${table} - Validation of Schema is successful- " + s"<br> ${src_table} Table - Source table Schema : "
              + schm.toString()
              + s"<br> ${new_tgt_table} Table - Target table Schema : " + tgt_schema
            )
          }
          else {
            test_data_schema.warning(s"${table} - Validation of Schema failed" + s"<br> ${src_table} Table - Source table Schema : "
              + schm.toString()
              + s"<br> ${new_tgt_table} Table - Target table Schema : " + tgt_schema)
          }
        } catch {
          case unknown => test_data_schema.error(s"${table} - Schema validtaion exception. Validation could not be " +
            s"completed." + unknown)
        }
      }else{ val test_data_schema = col_test.createNode(s"Schema Check", "Comparing the Schemas")

        try {
          val schm = DataType.fromJson(source_dataframe.schema.json.replaceAll("\"nullable\":false", "\"nullable\":true")).asInstanceOf[StructType]
          var tgt_schema = new_target_dataframe.schema.toString.replace(", StructField(bus_eff_dt,StringType,true), StructField(bus_expry_dt,StringType,true), StructField(proc_eff_ts,StringType,true), StructField(proc_expry_ts,StringType,true), StructField(row_not_recv_ind,StringType,true), StructField(oprtnl_stat_cd,StringType,true)","")

          var d_schem_check = false
          if (schm.toString().equalsIgnoreCase(tgt_schema)) {
            d_schem_check = true
          }
          if (d_schem_check == true) {
            test_data_schema.pass(s"${table} - Validation of Schema is successful- " + s"<br> ${src_table} Table - Source table Schema : "
              + schm.toString()
              + s"<br> ${new_tgt_table} Table - Target table Schema : " + tgt_schema
            )
          }
          else {
            test_data_schema.warning(s"${table} - Validation of Schema failed" + s"<br> ${src_table} Table - Source table Schema : "
              + schm.toString()
              + s"<br> ${new_tgt_table} Table - Target table Schema : " + tgt_schema)
          }
        } catch {
          case unknown => test_data_schema.error(s"${table} - Schema validtaion exception. Validation could not be " +
            s"completed. " + unknown)
        }

      }
    }

    var colsToRemove = Seq("bus_eff_dt", "bus_expry_dt", "proc_eff_ts", "proc_expry_ts", "row_not_recv_ind", "oprtnl_stat_cd")

    if(Data_test=="yes" || Data_test == "" || Data_test == null) {

      var test_data_validation = col_test.createNode(s"Data Validation", "Validating Data")
      if (!(null_rep == null) && !(empty_rep == null)) {
        var test_data_validation = col_test.createNode(s"Data Validation(Replacing null values with the nullValue parameter and Empty Values with null)", "Validating Data")
      }else if(!(null_rep == null) && (empty_rep == null)) {var test_data_validation = col_test.createNode(s"Data Validation(Replacing null values with the nullValue parameter)", "Validating Data")}
      else if((null_rep == null) && !(empty_rep == null)) {var test_data_validation = col_test.createNode(s"Data Validation(Replacing empty values with the null)", "Validating Data")}


      val test_snap_data = test_data_validation.createNode(" Current Snapshot Data validation", "Validating Source Data with Current Snapshot of History")

      try{
        val (snapCompare,snapS,snapT)= assertDataFrameEqualsB(source_dataframe.select(source_dataframe.columns.filter(colName => !colsDrop.contains(colName)).map(colName => new Column(colName)): _*), current_snap_no_bitem_drop, false)
        var snapData = false
        if (snapCompare == true) {
          snapData= true
        }


        if (snapData == true)
          test_snap_data.pass(s"${table} - Validation of Snapshots is successful: Data vaidation with Source table to Current Snapshot from target. \n Unmatched Rows:  \n From Source :" + snapS + "\n From Target :" +snapT)

        else
          test_snap_data.fail(s"${table} - Validation of Snapshots Data failed \n Unmatched Rows:  \n From Source :" + snapS + "\n From Target :" +snapT)

      } catch {
        case unknown: Exception => test_snap_data.error(s"${table} - Data validation exception. Validation could not be completed for some other reason. " + unknown)
      }


      val test_input_data = test_data_validation.createNode(" New Input Records", "Validating Data of Input Records")

      try{
        val (inputCompare,inputS,inputT)= assertDataFrameEqualsB(srcInsert, tgtInsertDrop.select(tgtInsertDrop.columns.filter(colName => !colsToRemove.contains(colName)).map(colName => new Column(colName)): _*),  false)
        var inputData: Boolean = false
        if (inputCompare == true) {
          inputData= true
        }


        if (inputData == true)
          test_input_data.pass(s"${table} - Validation of Input Data is successful: For each input in source there exist a new record with same data. \n Unmatched Rows:  \n From Source :" + inputS + "\n From Target :" +inputT)

        else
          test_input_data.fail(s"${table} - Validation of Input Data failed.  \n Unmatched Rows:  \n From Source :" + inputS + "\n From Target :" +inputT)

      } catch {
        case unknown: Exception => test_input_data.error(s"${table} - Data validation exception. Validation could not be completed for some other reason. " + unknown)
      }


      val test_delete_data = test_data_validation.createNode(" Deleted Records", "Validating Data of Deleted Records")

      try{
        val (deleteCompare,deleteS,deleteT)= assertDataFrameEqualsB(srcDelete.union(srcDelete), tgtDeleteDrop.select(tgtDeleteDrop.columns.filter(colName => !colsToRemove.contains(colName)).map(colName => new Column(colName)): _*), false)
        var deleteData: Boolean = false
        if (deleteCompare == true) {
          deleteData= true
        }


        if (deleteData == true)
          test_delete_data.pass(s"${table} - Validation of Delete Data is successful: For each delete in source there exist two records with same data.  \n Unmatched Rows:  \n From Source :" + deleteS + "\n From Target :" +deleteT)

        else
          test_delete_data.fail(s"${table} - Validation of Delete Data failed.  \n Unmatched Rows:  \n From Source :" + deleteS + "\n From Target :" +deleteT)

      } catch {
        case unknown: Exception => test_delete_data.error(s"${table} - Data validation exception. Validation could not be completed for some other reason. " + unknown)
      }

      val test_update_data = test_data_validation.createNode(" Updated Records", "Validating Data of Updated Records")

      try{
        val (updateCompare,updateS,updateT)= assertDataFrameEqualsB(srcUpdateOld.union(srcUpdateOld).union(srcUpdateNew), tgtUpdateDrop.select(tgtUpdateDrop.columns.filter(colName => !colsToRemove.contains(colName)).map(colName => new Column(colName)): _*), false)
        var updateData: Boolean = false
        if (updateCompare == true) {
          updateData= true
        }


        if (updateData == true)
          test_update_data.pass(s"${table} - Validation of Updated Data is successful: For each update in source there exist three new records: 2 with same data , 1 with updated data. \n Unmatched Rows:  \n From Source :" + updateS + "\n From Target :" +updateT)

        else
          test_update_data.fail(s"${table} - Validation of Update Data failed. \n Unmatched Rows:  \n From Source :" + updateS + "\n From Target :" +updateT)

      } catch {
        case unknown: Exception => test_update_data.error(s"${table} - Data validation exception. Validation could not be completed for some other reason. " + unknown)
      }

      val test_reappear_data = test_data_validation.createNode(" Reappeared Records", "Validating Data of Reappeared Records")

      try{
        val (reappearCompare,reappearS,reappearT)= assertDataFrameEqualsB(srcReappear.union(srcReappear).union(srcReappear), tgtReappearDrop.select(tgtReappearDrop.columns.filter(colName => !colsToRemove.contains(colName)).map(colName => new Column(colName)): _*), false)
        var reappearData: Boolean = false
        if (reappearCompare == true) {
          reappearData= true
        }


        if (reappearData == true)
          test_reappear_data.pass(s"${table} - Validation of Reappeared Data is successful: For each reappeared row in source there exist three new records: 2 with same data , 1 with updated data. \n Unmatched Rows:  \n From Source :" + reappearS + "\n From Target :" +reappearT)

        else
          test_reappear_data.fail(s"${table} - Validation of Update Data failed. \n Unmatched Rows:  \n From Source :" + reappearS + "\n From Target :" +reappearT)

      } catch {
        case unknown: Exception => test_reappear_data.error(s"${table} - Data validation exception. Validation could not be completed for some other reason. " + unknown)
      }





    }

    var form =Try(config.getString("processDateFormat").trim).getOrElse("yyyy-MM-dd hh:mm:ss.SSS")
    var format = new java.text.SimpleDateFormat(form)
    var process_effective_date= format.parse(Load_dt)
    var p_e_date= new java.sql.Timestamp(process_effective_date.getTime)
    var p_e_date1= new java.sql.Timestamp(process_effective_date.getTime- 1000)
    var processHighDate=Try(config.getString("processHighDate").trim).getOrElse("2999-12-31 00:30:00.0")
    var process_end_date=new java.sql.Timestamp(format.parse(processHighDate).getTime)
    var form2=Try(config.getString("businessDateFormat").trim).getOrElse("yyyy-MM-dd")
    var format2=new java.text.SimpleDateFormat(form2)
    var business_high_date=new java.sql.Timestamp(format2.parse(Try(config.getString("businessHighDate").trim).getOrElse("2999-12-31")).getTime).toString
    var business_low_date=new java.sql.Timestamp(format2.parse(Try(config.getString("businessLowDate").trim).getOrElse("1800-01-01")).getTime).toString

    val bitemp_dates = col_test.createNode("Bitemporal Columns  Validation", "Checking whether Values in Bitemporal Columns have been properly updated in target.")

    val bus_eff_dt_values = bitemp_dates.createNode("Values for \"bus_eff_dt\" ", "Validating Data for \"bus_eff_dt\" column ")
    try{
      if (tInputCounts== tgtInsert.withColumn("date1", to_date(tgtInsert(bussEffMap(0).toString))).withColumn("date2", to_date(tgtInsert("bus_eff_dt"))).filter("date1=date2").count){bus_eff_dt_values.pass("All inserted records have Correct value for \"bus_eff_dt_values\" column ")} else {bus_eff_dt_values.fail("Inserted Records:Values not populated correctly for \"bus_eff_dt_values\" column ")}
      if (tDeleteCounts== tgtDelete.withColumn("date1", to_date(tgtDelete(bussEffMap(0).toString))).withColumn("date2", to_date(tgtDelete("bus_eff_dt"))).filter("date1=date2").count){bus_eff_dt_values.pass("All deleted records have Correct value for \"bus_eff_dt_values\" column ")} else {bus_eff_dt_values.fail("Deleted Records:Values not populated correctly for \"bus_eff_dt_values\" column ")}
      if (tUpdateCounts== tgtUpdate.withColumn("date1", to_date(tgtUpdate(bussEffMap(0).toString))).withColumn("date2", to_date(tgtUpdate("bus_eff_dt"))).filter("date1=date2").count){bus_eff_dt_values.pass("All updated records have Correct value for \"bus_eff_dt_values\" column ")} else {bus_eff_dt_values.fail("Updated Records:Values not populated correctly for \"bus_eff_dt_values\" column ")}
      if (tReappearCounts== tgtReappear.withColumn("date1", to_date(tgtReappear(bussEffMap(0).toString))).withColumn("date2", to_date(tgtReappear("bus_eff_dt"))).filter("date1=date2").count){bus_eff_dt_values.pass("All reappeared records have Correct value for \"bus_eff_dt_values\" column ")}else {bus_eff_dt_values.fail("Reappeared Records:Values not populated correctly for \"bus_eff_dt_values\" column ")}


    }
    catch {
      case unknown: Exception => bus_eff_dt_values.error(s"${table} - Data validation for Bitemp column bus_eff_dt. Validation could not be completed for some other reason. " + unknown)
    }

    val bus_expry_dt_values = bitemp_dates.createNode("Values for \"bus_expry_dt\" ", "Validating Data for \"bus_expry_dt\" column ")
    try{
      if (tInputCounts== tgtInsert.filter(s"bus_expry_dt='$business_high_date'").count){bus_expry_dt_values.pass("All inserted records have Correct value for \"bus_expry_dt_values\" column ")} else {bus_expry_dt_values.fail("Inserted Records:Values not populated correctly for \"bus_expry_dt_values\" column ")}
      if (tDeleteCounts== tgtDelete.filter(s"bus_expry_dt='$business_high_date'").count ){bus_expry_dt_values.pass("All deleted records have Correct value for \"bus_expry_dt_values\" column ")} else {bus_expry_dt_values.fail("Deleted Records:Values not populated correctly for \"bus_expry_dt_values\" column ")}
      var tgtBEcheck= tgtUpdate.groupBy(p_key.map(col): _*).agg(max("bus_eff_dt"),min("bus_expry_dt")).withColumn("datediff", datediff($"max(bus_eff_dt)", $"min(bus_expry_dt)")).select("datediff").distinct.map(r => r(0).asInstanceOf[Int]).collect()
      var arrayofone=Array(1)
      if ((2*(tUpdateCounts/3))== tgtUpdate.filter(s"bus_expry_dt='$business_high_date'").count && tgtBEcheck.deep==arrayofone.deep ) {bus_expry_dt_values.pass("All updated records have Correct value for \"bus_expry_dt_values\" column ")} else {bus_expry_dt_values.fail("Updated Records:Values not populated correctly for \"bus_expry_dt_values\" column ")}
      var tgtBERcheck= tgtUpdate.groupBy(p_key.map(col): _*).agg(max("bus_eff_dt"),min("bus_expry_dt")).withColumn("datediff", datediff($"max(bus_eff_dt)", $"min(bus_expry_dt)")).select("datediff").distinct.map(r => r(0).asInstanceOf[Int]).collect()

      if ((2*(tReappearCounts/3))== tgtReappear.filter(s"bus_expry_dt='$business_high_date'").count && tgtBERcheck.deep==arrayofone.deep ){bus_expry_dt_values.pass("All reappeared records have Correct value for \"bus_expry_dt_values\" column ")}else {bus_expry_dt_values.fail("Reappeared Records:Values not populated correctly for \"bus_expry_dt_values\" column ")}


    }
    catch {
      case unknown: Exception => bus_expry_dt_values.error(s"${table} - Data validation for Bitemp column bus_expry_dt. Validation could not be completed for some other reason. " + unknown)
    }

    val proc_eff_ts_values = bitemp_dates.createNode("Values for \"proc_eff_ts\" ", "Validating Data for \"proc_eff_ts\" column ")
    try{
      if (tInputCounts== tgtInsertDrop.filter(s"proc_eff_ts='$p_e_date'").count){proc_eff_ts_values.pass("All inserted records have Correct value for \"proc_eff_ts_values\" column ")} else {proc_eff_ts_values.fail("Inserted Records:Values not populated correctly for \"proc_eff_ts_values\" column ")}
      if ((tDeleteCounts/2)== tgtDeleteDrop.filter(s"proc_eff_ts='$p_e_date'").count ){proc_eff_ts_values.pass("All deleted records have Correct value for \"proc_eff_ts_values\" column ")} else {proc_eff_ts_values.fail("Deleted Records:Values not populated correctly for \"proc_eff_ts_values\" column ")}
      if ((2*(tUpdateCounts/3))== tgtUpdateDrop.filter(s"proc_eff_ts='$p_e_date'").count){proc_eff_ts_values.pass("All updated records have Correct value for \"proc_eff_ts_values\" column ")} else {proc_eff_ts_values.fail("Updated Records:Values not populated correctly for \"proc_eff_ts_values\" column ")}
      if ((2*(tReappearCounts/3))== tgtReappearDrop.filter(s"proc_eff_ts='$p_e_date'").count){proc_eff_ts_values.pass("All reappeared records have Correct value for \"proc_eff_ts_values\" column ")}else {proc_eff_ts_values.fail("Reappeared Records:Values not populated correctly for \"proc_eff_ts_values\" column ")}


    }
    catch {
      case unknown: Exception => proc_eff_ts_values.error(s"${table} - Data validation for Bitemp column proc_eff_ts. Validation could not be completed for some other reason. " + unknown)
    }

    val proc_expry_ts_values = bitemp_dates.createNode("Values for \"proc_expry_ts\" ", "Validating Data for \"proc_expry_ts\" column ")
    try{
      if (tInputCounts== tgtInsertDrop.filter(s"proc_expry_ts='$process_end_date'").count){proc_expry_ts_values.pass("All inserted records have Correct value for \"proc_expry_ts_values\" column ")} else {proc_expry_ts_values.fail("Inserted Records:Values not populated correctly for \"proc_expry_ts_values\" column ")}
      if (tDeleteCounts== (tgtDeleteDrop.filter(s"proc_expry_ts='$process_end_date'").count + tgtDeleteDrop.filter(s"proc_expry_ts='$p_e_date1'").count)){proc_expry_ts_values.pass("All deleted records have Correct value for \"proc_expry_ts_values\" column ")} else {proc_expry_ts_values.fail("Deleted Records:Values not populated correctly for \"proc_expry_ts_values\" column ")}
      if (tUpdateCounts== (tgtUpdateDrop.filter(s"proc_expry_ts='$process_end_date'").count)+(tgtUpdateDrop.filter(s"proc_expry_ts='$p_e_date1'").count)){proc_expry_ts_values.pass("All updated records have Correct value for \"proc_expry_ts_values\" column ")} else {proc_expry_ts_values.fail("Updated Records:Values not populated correctly for \"proc_expry_ts_values\" column ")}
      if (tReappearCounts== (tgtReappearDrop.filter(s"proc_expry_ts='$process_end_date'").count)+(tgtReappearDrop.filter(s"proc_expry_ts='$p_e_date1'").count)){proc_expry_ts_values.pass("All reappeared records have Correct value for \"proc_expry_ts_values\" column ")}else {proc_expry_ts_values.fail("Reappeared Records:Values not populated correctly for \"proc_expry_ts_values\" column ")}


    }
    catch {
      case unknown: Exception => proc_expry_ts_values.error(s"${table} - Data validation for Bitemp column proc_expry_ts. Validation could not be completed for some other reason. " + unknown)
    }

    val row_not_recv_ind_values = bitemp_dates.createNode("Values for \"row_not_recv_ind\" ", "Validating Data for \"row_not_recv_ind\" column ")
    try{
      if (tInputCounts== tgtInsertDrop.filter("row_not_recv_ind=0").count){row_not_recv_ind_values.pass("All inserted records have Correct value for \"row_not_recv_ind\" column ")} else {row_not_recv_ind_values.fail("Inserted Records:Values not populated correctly for \"row_not_recv_ind\" column ")}
      if (tDeleteCounts== (tgtDeleteDrop.filter("row_not_recv_ind=0").count + tgtDeleteDrop.filter("row_not_recv_ind=1").count)){row_not_recv_ind_values.pass("All deleted records have Correct value for \"row_not_recv_ind\" column ")} else {row_not_recv_ind_values.fail("Deleted Records:Values not populated correctly for \"row_not_recv_ind\" column ")}
      if (tUpdateCounts== tgtUpdateDrop.filter("row_not_recv_ind=0").count){row_not_recv_ind_values.pass("All updated records have Correct value for \"row_not_recv_ind\" column ")} else {row_not_recv_ind_values.fail("Updated Records:Values not populated correctly for \"row_not_recv_ind\" column ")}
      if (tReappearCounts== (tgtReappearDrop.filter("row_not_recv_ind=0").count + tgtReappearDrop.filter("row_not_recv_ind=1").count)){row_not_recv_ind_values.pass("All reappeared records have Correct value for \"row_not_recv_ind\" column ")}else {row_not_recv_ind_values.fail("Reappeared Records:Values not populated correctly for \"row_not_recv_ind\" column ")}

    }
    catch {
      case unknown: Exception => row_not_recv_ind_values.error(s"${table} - Data validation for Bitemp column row_not_recv_ind. Validation could not be completed for some other reason. " + unknown)
    }
    val oprtnl_stat_cd_values = bitemp_dates.createNode("Values for \"oprtnl_stat_cd\" ", "Validating Data for \"oprtnl_stat_cd\" column ")
    try{
      if (tInputCounts== tgtInsertDrop.filter("oprtnl_stat_cd=0").count){oprtnl_stat_cd_values.pass("All inserted records have Correct value for \"oprtnl_stat_cd\" column ")} else {oprtnl_stat_cd_values.fail("Inserted Records:Values not populated correctly for \"oprtnl_stat_cd\" column ")}
      if (tDeleteCounts== tgtDeleteDrop.filter("oprtnl_stat_cd=0").count){oprtnl_stat_cd_values.pass("All deleted records have Correct value for \"oprtnl_stat_cd\" column ")} else {oprtnl_stat_cd_values.fail("Deleted Records:Values not populated correctly for \"oprtnl_stat_cd\" column ")}
      if (tUpdateCounts== tgtUpdateDrop.filter("oprtnl_stat_cd=0").count){oprtnl_stat_cd_values.pass("All updated records have Correct value for \"oprtnl_stat_cd\" column ")} else {oprtnl_stat_cd_values.fail("Updated Records:Values not populated correctly for \"oprtnl_stat_cd\" column ")}
      if (tReappearCounts== tgtReappearDrop.filter("oprtnl_stat_cd=0").count ){oprtnl_stat_cd_values.pass("All reappeared records have Correct value for \"oprtnl_stat_cd\" column ")}else {oprtnl_stat_cd_values.fail("Reappeared Records:Values not populated correctly for \"oprtnl_stat_cd\" column ")}

    }
    catch {
      case unknown: Exception => oprtnl_stat_cd_values.error(s"${table} - Data validation for Bitemp column oprtnl_stat_cd. Validation could not be completed for some other reason. " + unknown)
    }








    extent.flush()

    extent.flush()

  }























}