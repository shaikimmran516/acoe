package com.rxcorp.bdf.Utilities.remote

import java.io.FileOutputStream

import com.rxcorp.bdf.Resolver.configs.FTPConfig
import org.apache.commons.net.ftp.{FTP, FTPClient, FTPClientConfig}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.fs.permission.FsPermission
import org.apache.spark.sql.{DataFrame, SparkSession}

/**Crated By Apoorv , inspired From Mansoor.(SLP)
  */
object Ftp {

  /** The `ftpConnect` method makes Ftp connection and download file
    * @param sparkSession The current Spark session started by the hadoop user from Spark job running in the cluster
    * @param alias alias name
    * @param tpath target path
    * @param ftpCon Ftp configs
    * @param tableNm source file name/path
    */

  def ftpConnect(sparkSession:SparkSession,alias:String,tpath:Path,ftpCon: FTPConfig.FTPConf,tableNm:String)={
    val FileName =tableNm.split("/").last
    val tgtPath: Path = tpath
  val fs: FileSystem = FileSystem.get(sparkSession.sparkContext.hadoopConfiguration)
  if(!fs.exists(tgtPath)){
    fs.mkdirs(tgtPath)
    fs.setPermission(tgtPath, new FsPermission("777"))
  }
  val localTmpDir: String = System.getProperty("java.io.tmpdir")
  val ftpClient: FTPClient = new FTPClient
  ftpClient.configure(new FTPClientConfig(ftpCon.ftpSystem))
  ftpClient.connect(ftpCon.ftpHost,ftpCon.ftpPort.toInt)
  ftpClient.login(ftpCon.ftpUser.get,ftpCon.ftpPassword.get)
  ftpClient.setFileType(FTP.ASCII_FILE_TYPE)
  ftpClient.enterLocalPassiveMode()
  if(ftpCon.ftpSystem.equalsIgnoreCase(FTPClientConfig.SYST_MVS)) ftpClient.sendSiteCommand("trailingblanks")
  val os = new FileOutputStream(new java.io.File(s"$localTmpDir/${FileName}.txt"))
  ftpClient.changeWorkingDirectory("/")
  ftpClient.retrieveFile(tableNm, os)
  var srcPath=new Path(s"$localTmpDir/${FileName}.txt")
  fs.moveFromLocalFile(srcPath, tgtPath)
}

}
