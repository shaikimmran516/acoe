package com.rxcorp.bdf.Resolver.table

import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}
import org.apache.spark.sql.Row

import scala.util.Try
/** Created By Apoorv*/

object TableDetailsTLR extends TableConstantsTLR {

  /** The `getTableDetailsTLR` method returns [[TableTLRConf]] case class instance by resolving the tables/delmited files from .csv file for TargetLoadRoot class
    * @param inputString Row contains values from .csv file
    * @return [[TableTLRConf]]
    */

  def getTableDetailsTLR(inputString: Row):TableTLRConf = {
    val srcConType= Try(inputString.getString(0).trim).getOrElse(throw new Exception("Source Connection Type Missing"))
    val srcTableNm= Try(inputString.getString(1).trim).getOrElse(throw new Exception("Source Table Missing"))
    val alias=Try(inputString.getString(2).trim).getOrElse(throw new Exception("Alias is Missing"))
    val srcPrsnlQuery=Try(Some(inputString.getString(3).trim)).getOrElse(None)
    val header=Try(inputString.getString(4).trim.toLowerCase).getOrElse("yes")
    val schemaFile=Try(Some(inputString.getString(5).trim)).getOrElse(None)
    val tgtConType= Try(inputString.getString(6).trim).getOrElse(throw new Exception("Target Connection Type Missing"))
    val tgtTableNm=Try(inputString.getString(7).trim).getOrElse(throw new Exception("Target Table is Missing"))
    val tgtAlias=Try(inputString.getString(8).trim).getOrElse(throw new Exception("Tgt Alias is Missing"))
    val tgtPrsnlQuery=Try(Some(inputString.getString(9).trim)).getOrElse(None)
    val splitColumn=Try(Some(inputString.getString(10).trim)).getOrElse(None)
    val splitTgtColumn=Try(Some(inputString.getString(11).trim)).getOrElse(None)
    val aggColumn=Try(Some(inputString.getString(12).trim)).getOrElse(None)
    val useTargetSchema=Try(inputString.getString(13)).getOrElse("no")
    val zipFile=Try(inputString.getString(14)).getOrElse("no")
    val excludeColumn=Try(Some(inputString.getString(15).trim)).getOrElse(None)
    val excludeRow=Try(Some(inputString.getString(16).trim)).getOrElse(None)
    TableTLRConf(srcConType,srcTableNm,alias,srcPrsnlQuery,header,schemaFile,tgtConType,tgtTableNm,tgtAlias,
      tgtPrsnlQuery,splitColumn,splitTgtColumn,aggColumn,useTargetSchema,zipFile,excludeColumn,excludeRow)
  }


  /** The `TableConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param srcConType   source Connection Type.
    * @param srcTableNm   source Table Name .
    * @param alias         Alias.
    * @param srcPrsnlQuery   source Personal SQL Query .
    * @param header      whether header is present or not .
    * @param schemaFile    schema file hdfs path for files  .
    * @param tgtConType   target Connection Type.
    * @param tgtTableNm       target Table Name  .
    * @param tgtAlias         target Alias.
    * @param tgtPrsnlQuery      target Personal SQL Query .
    * @param splitColumn  Partion column for parallel loading of source table.
    * @param splitTgtColumn  Partion column for parallel loading of target table.
    * @param useTargetSchema defaultt"no" can be made "yes" by user if source table has differnt schema than target.
    * @param aggColumn      comma seperated  list of columns for sum check.
    * @param zipFile     By default "no" , can be made "yes" by user if source is zipped file .
    * @param excludeColumn comma delimited columns to be excluded
    */
  case class TableTLRConf(srcConType:String,srcTableNm:String,alias:String,srcPrsnlQuery:Option[String],header:String,schemaFile:Option[String],tgtConType:String,tgtTableNm:String,tgtAlias:String,
                       tgtPrsnlQuery:Option[String],splitColumn:Option[String],splitTgtColumn:Option[String],aggColumn:Option[String],useTargetSchema:String,zipFile:String,excludeColumn:Option[String],excludeRow:Option[String]) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("srcConType", srcConType)
        .append("srcTableNm", srcTableNm)
        .append("alias", alias)
        .append("srcPrsnlQuery", srcPrsnlQuery)
        .append("header", header)
        .append("schemaFile", schemaFile)
        .append("tgtConType", tgtConType)
        .append("tgtTableNm", tgtTableNm)
        .append("tgtAlias", tgtAlias)
        .append("tgtPrsnlQuery", tgtPrsnlQuery)
        .append("splitColumn", splitColumn)
        .append("splitTgtColumn", splitTgtColumn)
        .append("aggColumn", aggColumn)
        .append("useTargetSchema", useTargetSchema)
        .append("zipFile", zipFile)
        .append("excludeColumn",excludeColumn)
        .append("excludeRow",excludeRow)
        .toString
    }
  }


}
