package com.rxcorp.bdf.Resolver.configs

import com.rxcorp.bdf.Resolver.configs.ConnectDetails.connConf
import com.typesafe.config.Config
import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}

import scala.util.Try

object SMBConfig extends SMBConstants {

  /** The `getSMBConfig` method returns [[SMBConf]] case class instance by resolving the SFTP configurations from user's .conf file.
    * @param config The config object from .conf file
    * @return [[SMBConf]]
    */

  def getSMBConfig(config: Config,connectDetails:connConf):SMBConf = {
    val smbHost=Try(config.getString("SMB_HOST")).getOrElse(throw new Exception("SMB_HOST is missing"))
    val smbUser=Try(connectDetails.smbUser).getOrElse(throw new Exception("smbUser is missing in command line arguments"))
    val smbPassword=Try(connectDetails.smbPass).getOrElse(throw new Exception("smbPass is missing in command line arguments"))
    val smbDelimiter=Try(config.getString("SMB_D")).getOrElse(throw new Exception("SMB_D is missing"))
    val smbPath= Try(config.getString("SMB_PATH")).getOrElse(throw new Exception("SMB_PATH is missing"))
    SMBConf(smbHost,smbUser,smbPassword,smbDelimiter,smbPath)
  }
  /** The `SMBConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param smbHost      host for Sftp connection.
    * @param smbUser      user for Sftp connection.
    * @param smbPassword  password for Sftp connection.
    * @param smbDelimiter delimiter for Sftp connection.
    * @param smbPath   path for smb connection
    */
  case class SMBConf(smbHost:String,smbUser:Option[String],smbPassword:Option[String],smbDelimiter:String,smbPath:String) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("smbHost", smbHost)
        .append("smbUser", smbUser)
        .append("smbPassword", smbPassword)
        .append("smbDelimiter", smbDelimiter)
        .append("smbPath",smbPath)
        .toString
    }
  }

}
