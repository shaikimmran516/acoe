package com.rxcorp.bdf.Utilities.jdbcDialects.oracle

import java.sql.Types

import org.apache.spark.sql.jdbc.{JdbcDialect, JdbcType}
import org.apache.spark.sql.types._

/** The `Dialect` object is used to register the JDBCDialect to be used by Spark based on the source RDBMS.
  * * Taken From Mansoor.(SLP)
  * This Dialect object is registered when the source RDMBS is ORACLE.
  */
object Dialect extends JdbcDialect {

  /**
    * Check if this dialect instance can handle a certain jdbc url.
    * @param connUrl the jdbc url.
    * @return True if the dialect can be applied on the given jdbc url.
    */
  override def canHandle(connUrl: String): Boolean = connUrl.startsWith("jdbc:oracle")

  /**
    * Get the custom datatype mapping for the given jdbc meta information.
    * @param sqlType The sql type (see java.sql.Types)
    * @param typeName The sql type name (e.g. "BIGINT UNSIGNED")
    * @param size The size of the type.
    * @param md Result metadata associated with this type.
    * @return The actual DataType (subclasses of org.apache.spark.sql.types.DataType)
    *         or null if the default type mapping should be used.
    */
  override def getCatalystType(sqlType: Int, typeName: String, size: Int, md: MetadataBuilder): Option[DataType] = {
    if (sqlType == Types.NUMERIC) {
      val scale = if (null != md) md.build().getLong("scale") else 0L
      size match {
        // Handle NUMBER fields that have no precision/scale in special way
        // because JDBC ResultSetMetaData converts this to 0 precision and -127 scale
        // For more details, please see
        // https://github.com/apache/spark/pull/8780#issuecomment-145598968
        // and
        // https://github.com/apache/spark/pull/8780#issuecomment-144541760
        case 0 => Option(DecimalType(DecimalType.MAX_PRECISION, 10))
        case _ if scale == 0 =>
          if(size >= 1 && size < 10) {
            Option(IntegerType)
          }else if(size >= 10 && size < 19){
            Option(LongType)
          }else{
            Option(DecimalType(size, scale.toInt))
          }
        // Handle FLOAT fields in a special way because JDBC ResultSetMetaData converts
        // this to NUMERIC with -127 scale
        // Not sure if there is a more robust way to identify the field as a float (or other
        // numeric types that do not specify a scale.
        case _ if scale == -127L => Option(DoubleType)
        case _ => None
      }
    }else if(sqlType ==  Types.ROWID) {
      Option(BinaryType)
    }else if(sqlType == Types.DATE){
      Option(TimestampType)
    } else {
      None
    }
  }

  /**
    * Retrieve the jdbc / sql type for a given datatype.
    * @param dataType The datatype (e.g. org.apache.spark.sql.types.StringType)
    * @return The new JdbcType if there is an override for this DataType
    */
  override def getJDBCType(dataType: DataType): Option[JdbcType] = dataType match {
    case BooleanType => Some(JdbcType("NUMBER(1)", java.sql.Types.BOOLEAN))
    case IntegerType => Some(JdbcType("NUMBER", java.sql.Types.INTEGER))
    case LongType => Some(JdbcType("NUMBER", java.sql.Types.BIGINT))
    case FloatType => Some(JdbcType("NUMBER", java.sql.Types.DOUBLE))
    case DoubleType => Some(JdbcType("NUMBER", java.sql.Types.DOUBLE))
    case ByteType => Some(JdbcType("NUMBER", java.sql.Types.SMALLINT))
    case ShortType => Some(JdbcType("NUMBER", java.sql.Types.SMALLINT))
    case StringType => Some(JdbcType("VARCHAR2(4000)", java.sql.Types.VARCHAR))
    case BinaryType => Option(JdbcType("BLOB", java.sql.Types.BLOB))
    case TimestampType => Option(JdbcType("TIMESTAMP", java.sql.Types.TIMESTAMP))
    case DateType => Option(JdbcType("DATE", java.sql.Types.DATE))
    case t: DecimalType => Option(JdbcType(s"DECIMAL(${t.precision},${t.scale})", java.sql.Types.DECIMAL))
    case _ => None
  }

  /**
    * Return Some[true] iff `TRUNCATE TABLE` causes cascading default.
    * Some[true] : TRUNCATE TABLE causes cascading.
    * Some[false] : TRUNCATE TABLE does not cause cascading.
    * None: The behavior of TRUNCATE TABLE is unknown (default).
    */
  override def isCascadingTruncateTable(): Option[Boolean] = Some(false)
}
