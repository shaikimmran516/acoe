package com.rxcorp.bdf.Resolver.configs

import com.rxcorp.bdf.Resolver.configs.ConnectDetails.connConf
import com.typesafe.config.Config
import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}

import scala.util.Try

/** The `SFTPConfig` object extends [[SFTPConstants]] trait.
  *
  * This object offers methods to resolve Sftp config from user's .conf file.
  * Created By Apoorv
  */
object SFTPConfig extends SFTPConstants {
  /** The `getFSTPConfig` method returns [[SFTPConf]] case class instance by resolving the SFTP configurations from user's .conf file.
    * @param config The config object from .conf file
    * @return [[SFTPConf]]
    */

  def getSFTPConfig(config: Config,connectDetails:connConf):SFTPConf = {
    val sftpHost=Try(config.getString("SFTP_HOST")).getOrElse(throw new Exception("SFTP_HOST is missing"))
    val sftpUser=Try(connectDetails.sftpUser).getOrElse(throw new Exception("sftpUser is missing in command line arguments"))
    val sftpPassword=Try(connectDetails.sftpPass).getOrElse(throw new Exception("sftpPass is missing in command line arguments"))
    val sftpDelimiter=Try(config.getString("SFTP_D")).getOrElse(throw new Exception("SFTP_D is missing"))
    val sftpHeader=Try(config.getString("SFTP_HEADER")).getOrElse(throw new Exception("SFTP_HEADER is missing"))
    val sftpFileType=Try(config.getString("SFTP_FILE_TYPE")).getOrElse(throw new Exception("SFTP_FILE_TYPE is missing"))
    val sftpFilePath=Try(config.getString("SFTP_FILE_PATH")).getOrElse(throw new Exception("SFTP_FILE_PATH is missing"))
      SFTPConf(sftpHost,sftpUser,sftpPassword,sftpDelimiter,sftpHeader,sftpFileType,sftpFilePath)
  }
  /** The `SFTPConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param sftpHost      host for Sftp connection.
    * @param sftpUser      user for Sftp connection.
    * @param sftpPassword  password for Sftp connection.
    * @param sftpDelimiter delimiter for Sftp connection.
    * @param sftpHeader    header for Sftp connection.
    * @param sftpFileType file_type for Sftp connection.
    * @param sftpFilePath  file_path for Sftp connection.
    */
  case class SFTPConf(sftpHost:String,sftpUser:Option[String],sftpPassword:Option[String],sftpDelimiter:String,sftpHeader:String,sftpFileType:String,sftpFilePath:String) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("sftpHost", sftpHost)
        .append("sftpUser", sftpUser)
        .append("sftpPassword", sftpPassword)
        .append("sftpDelimiter", sftpDelimiter)
        .append("sftpHeader", sftpHeader)
        .append("sftpFileType", sftpFileType)
        .append("sftpFilePath", sftpFilePath)
        .toString
    }
  }

}
