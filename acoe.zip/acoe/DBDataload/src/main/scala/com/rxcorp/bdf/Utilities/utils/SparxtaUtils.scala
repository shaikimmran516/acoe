package com.rxcorp.bdf.Utilities.utils

import com.rxcorp.bdf.Resolver.configs.ConnectDetails.connConf
import com.rxcorp.bdf.Resolver.configs.{ConfFile, Resolver}
import com.rxcorp.bdf.Utilities.Db.DBConnection._
import com.rxcorp.bdf.Resolver.configs.FTPConfig.getFTPConfig
import com.rxcorp.bdf.Resolver.configs.SFTPConfig.getSFTPConfig
import com.rxcorp.bdf.Utilities.files.Constants
import com.rxcorp.bdf.Utilities.remote.Ftp.ftpConnect
import com.rxcorp.bdf.Utilities.remote.Sftp.sftpConnect
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.sparkSession
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext.sql
import com.typesafe.config.Config
import org.apache.hadoop.fs.Path
import org.apache.spark.sql.{DataFrame, Row}
import com.rxcorp.bdf.Utilities.utils.SparxtaFixedUtils.{createFixedSourceDataframe, createTempPath}
import com.rxcorp.bdf.Utilities.utils.Utils._
import com.rxcorp.bdf.Utilities.files.Utils._
import com.rxcorp.bdf.Utilities.remote.SMB
import com.rxcorp.bdf.Resolver.configs.SMBConfig.getSMBConfig
import org.apache.hadoop.conf.Configuration
import org.apache.spark.rdd.RDD

import scala.collection.mutable.ArrayBuffer

/** Created By Apoorv*/
object SparxtaUtils extends Constants {

  /** The `createTargetHive` method returns target hive Dataframe.
    *
    * @param resolver resolver containing all properties of an instance
    * @param config   configurations from .conf file
    * @param tableNM  hive table name
    * @return Dataframe target hive table
    */

  def createTargetHive(resolver: Resolver.resolveConf, config: Config, tableNM: String): DataFrame = {
    var finalTgtDF = getDataframeQuery(sparkSession, resolver.tgtPrsnlQuery.get, tableNM)
    if (resolver.bitemp == "no") {
      finalTgtDF = removeBitempCols(sparkSession, finalTgtDF)
    }
    finalTgtDF
  }

  /** The `createTargetDb` method returns target Dataframe for all databases except hive.
    *
    * @param resolver       resolver containing all properties of an instance
    * @param config         configurations from .conf file
    * @param connectDetails target connection details
    * @return Dataframe target table
    */
  def createTargetDb(resolver: Resolver.resolveConf, config: Config, connectDetails: connConf): DataFrame = {
    val tableDF = resolver.srcConType match {
      case `oracleType` | `db2Type` | `impalaType` | `exasolType` | `netezzaType` | `sqlserverType` | `teiidType` =>
        require(connectDetails.jdbcTgt.equals(null), "Tgt JDBC connection is missing")
        readData(sparkSession, connectDetails.jdbcTgt.get, resolver.tgtConType.get, resolver.splitTgtColumn.get, resolver.tgtTableNm.get)
      case _ => throw new Exception("Unsupported Target Database")
    }
    tableDF
  }

  /** The `getSourceDataframe` method creates dataframe for single/multiple sources.It appends dataframe for multiple sources.
    *
    * @param resolver       resolver containing all properties of an instance
    * @param config         configurations from .conf file
    * @param connectDetails source connection details
    * @return Dataframe source table
    */

  def getSourceDataframe(resolver: Resolver.resolveConf, config: Config, connectDetails: connConf): DataFrame = {
    if (resolver.srcTableNm.trim.split("~").length == 1) {
      val df = resolver.srcConType match {
        case `oracleType` | `db2Type` | `impalaType` | `exasolType` | `netezzaType` | `sqlserverType` | `teiidType` | `hiveType` | `flatPipeType` | `flatCommaType` | `flatTildeType` | `flatTabType` | `flatSemiColonType` | `flatSFTPType` | `flatFTPType` | `flatSMBType` =>
          createSourceDataframe(resolver, config, resolver.srcTableNm, connectDetails)
        case `fixedType` | `fixedSFTPType` | `fixedFTPType` | `fixedSMBType` =>
          createFixedSourceDataframe(resolver, config, connectDetails, resolver.srcTableNm)
      }
      df
    }
    else if (resolver.srcTableNm.trim.split("~").length > 1) {
      val tableArray = getMultipleTableList(resolver)._1
      val tableArrayLen = getMultipleTableList(resolver)._2
      var dfList = ArrayBuffer[DataFrame]()
      for (h <- 0 until tableArrayLen) {
        val tableNm = tableArray(h).trim
        val tableDF = resolver.srcConType match {
          case `oracleType` | `db2Type` | `impalaType` | `exasolType` | `netezzaType` | `sqlserverType` | `teiidType` | `hiveType` | `flatPipeType` | `flatCommaType` | `flatTildeType` | `flatTabType` | `flatSemiColonType` | `flatSFTPType` | `flatFTPType` | `flatSMBType` =>
            createSourceDataframe(resolver, config, tableNm, connectDetails)
          case `fixedType` | `fixedSFTPType` | `fixedFTPType` | `fixedSMBType` =>
            createFixedSourceDataframe(resolver, config, connectDetails, tableNm)
        }
        dfList += tableDF
      }
      val df = dfList.tail.foldLeft(dfList.head) { (df1, df2) => df1.union(df2) }
      df
    } else {
      throw new Exception(s"Source Dataframe Empty : ${resolver.srcTableNm} ")
    }
  }

  /** The `getSourceDataframe` method creates dataframe for single sources.
    *
    * @param resolver       resolver containing all properties of an instance
    * @param config         configurations from .conf file
    * @param tableNM        single table/delimited file name source
    * @param connectDetails source connection details
    * @return Dataframe source table
    */


  def createSourceDataframe(resolver: Resolver.resolveConf, config: Config, tableNM: String, connectDetails: connConf): DataFrame = {
    val confF = ConfFile.getConfig(config)
    var zipSrc = false
    if (resolver.zipFile == "yes") {
      zipSrc = true
    }
    val tableDF = resolver.srcConType match {
      case `oracleType` | `db2Type` | `impalaType` | `exasolType` | `netezzaType` | `sqlserverType` | `teiidType` =>
        val db = com.rxcorp.bdf.Resolver.configs.DatabaseConfig.getDBConfig(config)
        val jdbcURL = if (!(db.jdbcURL.isEmpty)) {
          db.jdbcURL.get
        } else {
          connectDetails.jdbcURL.get
        }
        readData(sparkSession, jdbcURL, resolver.srcConType, resolver.splitColumn.get, tableNM)
      case `hiveType` =>
        val tableName = if (!(tableNM == null)) {
          if (tableNM.endsWith(".query")) {
            getQueryFromFile(sparkSession, tableNM)
          } else {
            s"select * from $tableNM"
          }
        } else {
          s"select * from $tableNM"
        }
        sql(tableName)
      case `flatPipeType` | `flatCommaType` | `flatTildeType` | `flatTabType` | `flatSemiColonType` =>
        val delimiter = getDelimiter(resolver.srcConType)
        getFilesDataframe(sparkSession, tableNM, resolver.schemaFile.get, resolver.srcConType, resolver.header.get, delimiter, zipSrc)
      case `flatSFTPType` =>
        val sftpCon = getSFTPConfig(config, connectDetails)
        if (!(resolver.zipFile == "no")) {
          sftpConnect(sparkSession, sftpCon, tableNM, resolver)
        }
        else {
          val tgtPath: Path = new Path(s"${confF.fixedHDFSpath}/${resolver.alias}/fixed/Sftp/")
          createTempPath(tgtPath)
          com.rxcorp.bdf.Utilities.remote.Sftp.sftpFixedConnect(sparkSession, sftpCon, resolver, config, tableNM)
          val loadFile = s"${confF.fixedHDFSpath}/${resolver.alias}/fixed/Sftp/"
          val unzipped = com.rxcorp.bdf.Utilities.unzip.Unzip.unzip(sparkSession, loadFile)
          val delimiter = getDelimiter(resolver.srcConType)
          getFilesDataframe(sparkSession, unzipped, resolver.schemaFile.get, resolver.srcConType, resolver.header.get, delimiter, zipSrc)
        }
      case `flatFTPType` =>
        val ftpCon = getFTPConfig(config, connectDetails)
        val FileName = tableNM.split("/").last.replace(".csv", "")
        var tgtPath: Path = new Path(s"${confF.fixedHDFSpath}/${resolver.alias}/ftp/${FileName}")
        ftpConnect(sparkSession, resolver.alias, tgtPath, ftpCon, tableNM)
        tgtPath = if (resolver.zipFile == "yes") new Path(com.rxcorp.bdf.Utilities.unzip.Unzip.unzip(sparkSession, tgtPath.toString)) else tgtPath
        getFilesDataframe(sparkSession, tgtPath.toString, resolver.schemaFile.get, resolver.srcConType, resolver.header.get, ftpCon.ftpDelimiter, zipSrc)
      case `flatSMBType` =>
        val tgtPath = s"${confF.fixedHDFSpath}/${resolver.alias}/smb/"
        val hc: Configuration = sparkSession.sparkContext.hadoopConfiguration
        val smbCon = getSMBConfig(config, connectDetails)
        val smbClient: SMB = new SMB(smbCon)
        val smbFile: String = smbClient.withClientSession(session => smbClient.downloadFileToTmp(session)(resolver.srcTableNm))
        val loadFile: String = Utils.moveTmpFileToHDFS(hc, smbFile, tgtPath)
        getFilesDataframe(sparkSession, loadFile, resolver.schemaFile.get, resolver.srcConType, resolver.header.get, smbCon.smbDelimiter, zipSrc)
    }
    tableDF
  }

  /** The `getMultipleTableList` method creates a sequence of multiple sources for same target.
    *
    * @param resolver resolver containing all properties of an instance
    * @return (Seq[String],Int) Sequence of table list with length of array
    */
  def getMultipleTableList(resolver: Resolver.resolveConf): (Seq[String], Int) = {
    val tableArray: Seq[String] = resolver.srcTableNm.trim.split("~").toList
    val tableArrayLen = tableArray.length
    (tableArray, tableArrayLen)
  }


  def resolveTargetDb(resolver: Resolver.resolveConf, config: Config, connectDetails: connConf, runType: Int): DataFrame = {
    val TgtDf = resolveDf(resolver, config, runType, resolver.tgtTableNm.get, connectDetails)
    val finalTgtDF = if (runType == 1) {
      TgtDf
    }
    else if (runType == 2) {
      TgtDf.createOrReplaceTempView(s"${resolver.tgtAlias}")
      getDataframeQuery(sparkSession, resolver.tgtPrsnlQuery.get, resolver.tgtAlias.get)
    } else {
      throw new Exception("Unable to create Target Dataframe")
    }
    finalTgtDF
  }

  def removeRows(resolver: Resolver.resolveConf, finalSrcDF: DataFrame): DataFrame = {
    var srcRDD: RDD[Row] = finalSrcDF.rdd
    val rowNumbers = resolver.excludeRow.get.split(",").map(x => x.toInt)
    val positiveNumbers: Int = rowNumbers.filter(x => x >= 0).head
    val negativeNumbers: Int = rowNumbers.filter(x => x < 0).head
    val fIndex: Long = srcRDD.count() + negativeNumbers
    srcRDD = srcRDD.zipWithIndex().filter { case (_, index) => index < fIndex }.filter { case (_, index) => positiveNumbers < index }.keys
    sparkSession.createDataFrame(srcRDD, finalSrcDF.schema)
  }
}
