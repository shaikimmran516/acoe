package com.rxcorp.bdf.Resolver.configs

trait SMBConstants {


  /** The [[smbHost]] constant value equals `smbHost` */
  final val smbHost: String = "smbHost"
  /** The [[smbUser]] constant value equals `smbUser` */
  final val smbUser: String = "smbUser"
  /** The [[smbPassword]] constant value equals `smbPassword` */
  final val smbPassword: String = "smbPassword"
  /** The [[smbDelimiter]] constant value equals `smbDelimiter` */
  final val smbDelimiter: String = "smbDelimiter"
  /** The [[smbPath]] constant value equals `smbPath` */
  final val smbPath: String = "smbPath"

}
