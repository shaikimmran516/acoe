package com.rxcorp.bdf.Utilities.jdbcDialects.netezza

import com.rxcorp.bdf.Utilities.Db.DBRegexPatterns
import org.apache.spark.sql.types.{DataType, DataTypes, StructField, StructType}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/** The `Utils` object extends [[DBRegexPatterns]] trait.
  * * Taken From Mansoor.(SLP)
  * This object offers methods to resolve source netezza table schema to spark StructType.
  */
object Utils extends DBRegexPatterns {

  /** The `getStructType` method returns StructType from the provided table metadata .
    * @param metaData The LinkedHashMap with keys of netezza table column names
    *                 and values of (netezza datatype, precision, scale, nullable)
    * @return org.apache.spark.sql.types.StructType
    * @throws Exception Unsupported netezza datatype for hive compatible datatype conversion!
    */
  def getStructType(metaData: mutable.LinkedHashMap[String, (String, Int, Int, Boolean)]): StructType = {
    val struct: ArrayBuffer[StructField] = new ArrayBuffer[StructField]()
    for(meta <-  metaData){
      val precision: Int = meta._2._2
      val scale: Int = meta._2._3
      val dt: DataType = meta._2._1.toUpperCase match {
        case BIGINTPattern(dtype, size) => DataTypes.LongType
        case BOOLPattern(dtype, size) => DataTypes.BooleanType
        case BOOLEANPattern(dtype, size) => DataTypes.BooleanType
        case BYTEINTPattern(dtype, size) => DataTypes.IntegerType
        case CHARPattern(dtype, size) => DataTypes.StringType
        case DATEPattern(dtype, size) => DataTypes.StringType
        case DECIMALPattern(dtype, size) => DataTypes.createDecimalType(precision, scale)
        case DOUBLEPattern(dtype, size) => DataTypes.DoubleType
        case DOUBLEPRECISIONPattern(dtype, size) => DataTypes.DoubleType
        case FLOATPattern(dtype, size) => DataTypes.DoubleType
        case INTEGERPattern(dtype, size) => DataTypes.IntegerType
        case INTPattern(dtype, size) => DataTypes.IntegerType
        case INTERVALPattern(dtype, size) => DataTypes.StringType
        case NzINT124Pattern(dtype, size) => DataTypes.IntegerType //case "INT1" => DataTypes.ByteType
        case NzINT8Pattern(dtype, size) => DataTypes.LongType
        case NCHARPattern(dtype, size) => DataTypes.StringType
        case NVARCHARPattern(dtype, size) => DataTypes.StringType
        case NUMERICPattern(dtype, size) => DataTypes.createDecimalType(precision, scale)
        case REALPattern(dtype, size) => DataTypes.FloatType
        case SMALLINTPattern(dtype, size) => DataTypes.IntegerType
        case TIMEPattern(dtype, size) => DataTypes.StringType
        case TIMETZPattern(dtype, size) => DataTypes.TimestampType
        case TIMEWTZPattern(dtype, size) => DataTypes.TimestampType
        case TSPattern(dtype, size) => DataTypes.TimestampType
        case VARCHARPattern(dtype, size) => DataTypes.StringType
        case _ =>
          throw new Exception(s"Unsupported netezza datatype: ${meta._2._1.toUpperCase} for hive compatible datatype conversion!")
      }
      struct += StructField(meta._1, dt, meta._2._4)
    }
    StructType(struct.toArray)
  }
}