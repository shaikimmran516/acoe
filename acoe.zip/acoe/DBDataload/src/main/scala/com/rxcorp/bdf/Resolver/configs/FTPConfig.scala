package com.rxcorp.bdf.Resolver.configs

import com.rxcorp.bdf.Resolver.configs.ConnectDetails.connConf
import com.typesafe.config.Config
import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}

import scala.util.Try

/** The `FTPConfig` object extends [[FTPConstants]] trait.
  *
  * This object offers methods to resolve Ftp config from user's .conf file.
  * Created By Apoorv
  */
object FTPConfig extends FTPConstants {

  /** The `getFTPConfig` method returns [[FTPConf]] case class instance by resolving the FTP configurations from user's .conf file.
    * @param config The config object from .conf file
    * @return [[FTPConf]]
    */
  def getFTPConfig(config: Config,connectDetails:connConf):FTPConf = {
    val ftpSystem: String = Try(config.getString("FTP_SYSTEM")).getOrElse(throw new Exception("FTP_SYSTEM is missing"))
    val ftpHost: String =Try(config.getString("FTP_HOST")).getOrElse(throw new Exception("FTP_HOST is missing"))
    val ftpPort: String =Try(config.getString("FTP_PORT")).getOrElse(throw new Exception("FTP_PORT is missing"))
    val ftpUser: Option[String] =Try(connectDetails.ftpUser).getOrElse(throw new Exception("ftpUser is missing"))
    val ftpPassword: Option[String] =Try(connectDetails.ftpPass).getOrElse(throw new Exception("ftpPass is missing"))
    val ftpDelimiter: String =Try(config.getString("FTP_D")).getOrElse(throw new Exception("FTP_D is missing"))
    FTPConf(ftpSystem,ftpHost,ftpPort,ftpUser,ftpPassword,ftpDelimiter)
  }

  /** The `FTPConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param ftpSystem   system for Ftp connection.
    * @param ftpHost   host for Ftp connection.
    * @param ftpPort    port for Ftp connection.
    * @param ftpUser   user for Ftp connection.
    * @param ftpPassword   password for Ftp connection.
    * @param ftpDelimiter   delimiter for Ftp connection.
    */
  case class FTPConf(ftpSystem:String,ftpHost:String,ftpPort:String,ftpUser:Option[String],ftpPassword:Option[String],ftpDelimiter:String) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("ftpSystem", ftpSystem)
        .append("ftpHost", ftpHost)
        .append("ftpPort", ftpPort)
        .append("ftpUser", ftpUser)
        .append("ftpPassword", ftpPassword)
        .append("ftpDelimiter", ftpDelimiter)
        .toString
    }
  }

}
