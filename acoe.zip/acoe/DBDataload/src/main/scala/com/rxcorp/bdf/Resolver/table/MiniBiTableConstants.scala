package com.rxcorp.bdf.Resolver.table

/** The `MiniBiTableConstants` trait offers constants for different keys expected in .csv file related to [[MiniBiTableDetails]]. */
/** Created By Apoorv*/
trait MiniBiTableConstants {
  /** The [[srcConType]] constant value equals `srcConType` */
  final val srcConType: String = "srcConType"
  /** The [[srcTableNm]] constant value equals `srcTableNm` */
  final val srcTableNm: String = "srcTableNm"
  /** The [[alias]] constant value equals `alias` */
  final val alias: String = "alias"
  /** The [[srcWhere]] constant value equals `srcWhere` */
  final val srcWhere: String = "srcWhere"
  /** The [[tgtWhere]] constant value equals `tgtWhere` */
  final val tgtWhere: String = "tgtWhere"
  /** The [[prevHistory]] constant value equals `prevHistory` */
  final val prevHistory: String = "prevHistory"
  /** The [[currHistory]] constant value equals `currHistory` */
  final val currHistory: String = "currHistory"
  /** The [[primaryKey]] constant value equals `primaryKey` */
  final val primaryKey: String = "primaryKey"
  /** The [[runOption]] constant value equals `runOption` */
  final val runOption: String = "runOption"
  /** The [[bussEffMapping]] constant value equals `bussEffMapping` */
  final val bussEffMapping: String = "bussEffMapping"
  /** The [[useTargetSchema]] constant value equals `useTargetSchema` */
  final val useTargetSchema: String = "useTargetSchema"
  /** The [[mode]] constant value equals `mode` */
  final val mode: String = "mode"
}
