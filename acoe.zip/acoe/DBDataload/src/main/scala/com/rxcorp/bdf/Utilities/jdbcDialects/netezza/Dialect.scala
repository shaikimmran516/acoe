package com.rxcorp.bdf.Utilities.jdbcDialects.netezza

import org.apache.spark.sql.jdbc.{JdbcDialect, JdbcType}
import org.apache.spark.sql.types._

/** The `Dialect` object is used to register the JDBCDialect to be used by Spark based on the source RDBMS.
  * * Taken From Mansoor.(SLP)
  * This Dialect object is registered when the source RDMBS is NETEZZA.
  */
object Dialect extends JdbcDialect {

  /**
    * Check if this dialect instance can handle a certain jdbc url.
    * @param connUrl the jdbc url.
    * @return True if the dialect can be applied on the given jdbc url.
    */
  override def canHandle(connUrl: String): Boolean = connUrl.startsWith("jdbc:netezza")

  /**
    * Get the custom datatype mapping for the given jdbc meta information.
    * @param sqlType The sql type (see java.sql.Types)
    * @param typeName The sql type name (e.g. "BIGINT UNSIGNED")
    * @param size The size of the type.
    * @param md Result metadata associated with this type.
    * @return The actual DataType (subclasses of org.apache.spark.sql.types.DataType)
    *         or null if the default type mapping should be used.
    */
  override def getCatalystType(sqlType: Int, typeName: String, size: Int, md: MetadataBuilder): Option[DataType] = {
    val scale = if (null != md) md.build().getLong("scale") else 0L
    sqlType match {
      case java.sql.Types.DECIMAL
        if size != 0 || scale != 0 => Option(DecimalType(size, scale.toInt))
      case java.sql.Types.NUMERIC
        if size != 0 || scale != 0 => Option(DecimalType(size, scale.toInt))
      case java.sql.Types.BIGINT => Option(LongType)
      case 101 => Option(StringType)
      case _ => None
    }
  }

  /**
    * Retrieve the jdbc / sql type for a given datatype.
    * @param dataType The datatype (e.g. org.apache.spark.sql.types.StringType)
    * @return The new JdbcType if there is an override for this DataType
    */
  override def getJDBCType(dataType: DataType): Option[JdbcType] = dataType match {
    //TODO Need to add any other missing data types
    case StringType => Some(JdbcType("VARCHAR(500)", java.sql.Types.VARCHAR))
    case IntegerType => Some(JdbcType("INTEGER", java.sql.Types.INTEGER))
    case LongType => Some(JdbcType("BIGINT", java.sql.Types.BIGINT))
    case DoubleType => Some(JdbcType("DOUBLE PRECISION", java.sql.Types.DOUBLE))
    case FloatType => Some(JdbcType("REAL", java.sql.Types.FLOAT))
    case ShortType => Some(JdbcType("INTEGER", java.sql.Types.SMALLINT))
    case ByteType => Some(JdbcType("INTEGER", java.sql.Types.TINYINT))
    case BinaryType => Some(JdbcType("BINARY", java.sql.Types.BINARY))
    case TimestampType => Some(JdbcType("DATE", java.sql.Types.DATE))
    case DateType => Some(JdbcType("DATE", java.sql.Types.DATE))
    case dec: DecimalType => Some(JdbcType(s"DECIMAL(${dec.precision},${dec.scale})", java.sql.Types.DECIMAL))
    case _ => None
  }

  /**
    * Return Some[true] iff `TRUNCATE TABLE` causes cascading default.
    * Some[true] : TRUNCATE TABLE causes cascading.
    * Some[false] : TRUNCATE TABLE does not cause cascading.
    * None: The behavior of TRUNCATE TABLE is unknown (default).
    */
  override def isCascadingTruncateTable(): Option[Boolean] = Some(false)
}
