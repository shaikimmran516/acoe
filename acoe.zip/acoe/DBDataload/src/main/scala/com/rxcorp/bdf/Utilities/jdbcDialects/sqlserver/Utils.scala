package com.rxcorp.bdf.Utilities.jdbcDialects.sqlserver

import com.rxcorp.bdf.Utilities.Db.DBRegexPatterns
import org.apache.spark.sql.types.{DataType, DataTypes, StructField, StructType}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/** The `Utils` object extends [[DBRegexPatterns]] trait.
  * Taken From Mansoor.(SLP)
  * This object offers methods to resolve source sqlserver table schema to spark StructType.
  */
object Utils extends DBRegexPatterns {


  /** The `getStructType` method returns StructType from the provided table metadata .
    * @param metaData The LinkedHashMap with keys of sqlserver table column names 
    *                 and values of (sqlserver datatype, precision, scale, nullable)
    * @return org.apache.spark.sql.types.StructType
    * @throws Exception Unsupported sqlserver datatype for hive compatible datatype conversion!
    */
  def getStructType(metaData: mutable.LinkedHashMap[String, (String, Int, Int, Boolean)]): StructType = {
    val struct: ArrayBuffer[StructField] = new ArrayBuffer[StructField]()
    for(meta <-  metaData){
      val precision: Int = meta._2._2
      val scale: Int = meta._2._3
      val dt: DataType = meta._2._1.toUpperCase match {
        case BIGINTPattern(dtype, size) => DataTypes.LongType
        case BIGINTIDENTITYPattern(dtype, size) => DataTypes.LongType
        case BINARYPattern(dtype, size) => DataTypes.BinaryType
        case BITPattern(dtype, size) => DataTypes.BooleanType
        case CHARPattern(dtype, size) => DataTypes.StringType
        case DATEPattern(dtype, size) => DataTypes.StringType
        case DATETIMEPattern(dtype, size) => DataTypes.TimestampType
        case DATETIME2Pattern(dtype, size) => DataTypes.TimestampType
        case DATETIMEOFFSETPattern(dtype, size) => DataTypes.StringType
        case DECIMALPattern(dtype, size) => DataTypes.createDecimalType(precision, scale)
        case FLOATPattern(dtype, size) => DataTypes.DoubleType
        case IMAGEPattern(dtype, size) => DataTypes.BinaryType
        case INTPattern(dtype, size) => DataTypes.IntegerType
        case INTIDENTITYPattern(dtype, size) => DataTypes.IntegerType
        case MONEYPattern(dtype, size) => DataTypes.createDecimalType(precision, scale)
        case NCHARPattern(dtype, size) => DataTypes.StringType
        case NTEXTPattern(dtype, size) => DataTypes.StringType
        case NUMERICPattern(dtype, size) => DataTypes.createDecimalType(precision, scale)
        case NVARCHARPattern(dtype, size) => DataTypes.StringType
        case "NVARCHAR(MAX)" => DataTypes.StringType
        case REALPattern(dtype, size) => DataTypes.DoubleType
        case SMALLDATETIMEPattern(dtype, size) => DataTypes.TimestampType
        case SMALLINTPattern(dtype, size) => DataTypes.IntegerType //DataTypes.ShortType
        case SMALLMONEYPattern(dtype, size) => DataTypes.createDecimalType(precision, scale)
        case TEXTPattern(dtype, size) => DataTypes.StringType
        case TIMEPattern(dtype, size) => DataTypes.StringType
        case TSPattern(dtype, size) => DataTypes.BinaryType
        case TINYINTPattern(dtype, size) => DataTypes.IntegerType
        case UDTPattern(dtype, size) => DataTypes.BinaryType
        case UNIQUEIDENTIFIERPattern(dtype, size) => DataTypes.StringType
        case VARBINARYPattern(dtype, size) => DataTypes.BinaryType
        case "VARBINARY(MAX)" => DataTypes.BinaryType
        case VARCHARPattern(dtype, size) => DataTypes.StringType
        case "VARCHAR(MAX)" => DataTypes.StringType
        case XMLPattern(dtype, size) => DataTypes.StringType
        //        case "SQLVARIANT" => ""
        case _ =>
          throw new Exception(s"Unsupported sqlserver datatype: ${meta._2._1.toUpperCase} for hive compatible datatype conversion!")
      }
      struct += StructField(meta._1, dt, meta._2._4)
    }
    StructType(struct.toArray)
  }
}
