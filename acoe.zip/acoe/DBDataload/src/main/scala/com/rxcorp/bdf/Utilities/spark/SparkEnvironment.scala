package com.rxcorp.bdf.Utilities.spark

/**
  * Created by SSanyal.
  */


import org.apache.spark.sql.SparkSession


/** The `SparkEnvironment` object creates and submits Spark configuration to the current SparkSession
  */

object SparkEnvironment extends Serializable {

  def sparkApplicationException(): Unit = {
    throw new Exception("Application found error in processing")
  }

  val sparkSession = SparkSession.builder
    .enableHiveSupport()
    .config("hive.exec.dynamic.partition", "true")
    .config("hive.exec.dynamic.partition.mode", "nonstrict")
    .config("hive.exec.compress.output", "true")
    .config("mapred.output.compression.codec", "org.apache.hadoop.io.compress.SnappyCodec")
    .config("mapred.output.compression.type", "BLOCK")
    .config("parquet.compression", "SNAPPY")
    .getOrCreate()

  val hiveContext = sparkSession.sqlContext

  hiveContext.setConf("spark.sql.hive.convertMetastoreParquet", "false")
}
