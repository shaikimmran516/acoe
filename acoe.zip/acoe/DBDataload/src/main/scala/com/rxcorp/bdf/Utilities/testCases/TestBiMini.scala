package com.rxcorp.bdf.Utilities.testCases

import java.io.{BufferedReader, InputStreamReader}
import java.nio.file.Paths

import com.aventstack.extentreports.ExtentReports
import com.aventstack.extentreports.reporter.ExtentHtmlReporter
import BitempDataValidation.assertDataFrameEqualsB
import com.aventstack.extentreports.markuputils.MarkupHelper
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.sparkSession
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext
import com.typesafe.config.{Config, ConfigFactory}
import org.scalatest.FunSuite
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext.implicits._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkFiles
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataType, StructType}
import org.apache.spark.sql.{DataFrame, Dataset, Row}

import scala.io.Source
import scala.util.Try

//TODO :Clean up of this class is needed to be in precise code format and standards

class TestBiMini extends FunSuite {

  var config1 = ""
  var table1 = ""
  var src_table = hiveContext.emptyDataFrame
  var prev_tgt_table = hiveContext.emptyDataFrame
  var new_tgt_table = hiveContext.emptyDataFrame
  var source_col = Array[String]()
  var target_col = Array[String]()
  var source_sys = ""
  var src_cnt=0
  var prev_tgt_cnt=0
  var new_tgt_cnt=0
  var runMd=1
  var runOpt=""
  var p_key =  List[String]()

  def param(conf: String, table: String,  sys: String,src_count:Int ,prev_tgt_count:Int,new_tgt_count:Int,runMode:Int,src_tbl:DataFrame,prev_tgt_tbl:DataFrame,new_tgt_tbl:DataFrame,runopt:String,pkey:List[String]): Unit = {
    config1 = conf
    table1 = table
    src_table = src_tbl.cache()
    prev_tgt_table = prev_tgt_tbl.cache()
    new_tgt_table = new_tgt_tbl.cache()
    source_sys = sys
    src_cnt=src_count
    prev_tgt_cnt=prev_tgt_count
    new_tgt_cnt=new_tgt_count
    runMd=runMode
    runOpt=runopt
    p_key=pkey
  }


  test("Sparxta Mini comparison") {

    val fileSystem = FileSystem.get(new Configuration())
    println(fileSystem)
    val jobFile: Path = new Path(config1)
    println(jobFile)
    val reader = new InputStreamReader(fileSystem.open(jobFile))
    val config: Config = ConfigFactory.parseReader(reader).withFallback(ConfigFactory.systemProperties()).resolve()
    val table = table1
    val fixed_path = config.getString("home_hdfs_dir")
    val confFileName = config1.split("\\/").toList.takeRight(1).head.toString.split("\\.").toList.take(1).head.toString
    val htmlReporter = new ExtentHtmlReporter(s"${confFileName}_comparison.html") //config.getString("home_hdfs_dir") +
    val extent = new ExtentReports
    htmlReporter.setAppendExisting(true)
    extent.attachReporter(htmlReporter)
    if (runMd == 1) {
      val col_test = extent.createTest(s"${table} - Validation", "Validating Source and Target Table for 1st Load")
      println("validating table fields")
      val test_count = col_test.createNode(s"Record Count Checking", "Validating Counts")
      try {
        val countException = intercept[org.scalatest.exceptions.TestFailedException] {
          assert(src_cnt === new_tgt_cnt)
        }
        println(countException.getMessage())

        if (!countException.getMessage().isEmpty())
          test_count.fail(s"${table} - Count exception is given below: <br>" + countException)
        else
          test_count.pass(s"${table} - Validating table counts <br> Source table count : "
            + src_cnt + s"<br> Target table count : " + new_tgt_cnt)

      } catch {
        case e: org.scalatest.exceptions.TestFailedException => test_count.pass(s"${table} - Validating table counts <br> " +
          s"Source table count : " + src_cnt + s"<br> Target table count : "
          + new_tgt_cnt)
        case unknown: Exception => test_count.error(s"${table} - Count exception. Validation could not be completed for some other reason. " + unknown)
      }

      extent.flush()
    }
    if (runMd == 2 && runOpt =="snapshot") {
      var window = Window.partitionBy(p_key.map(col): _*).orderBy(p_key.map(col): _*)
      var prev= prev_tgt_table.withColumn("count",count(concat(p_key.map(col): _*)).over(window)).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      var tgt=new_tgt_table.withColumn("count",count(concat(p_key.map(col): _*)).over(window)).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)

      var dataCompare1 = tgt.except(prev).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)

      var tgtUpdates=dataCompare1.filter("count>=2").drop("count").count()
      var tgtInserts = dataCompare1.filter("row_not_recv_ind <> 1").filter("count=1").drop("count").count()
      var tgtDeletes=dataCompare1.filter("row_not_recv_ind=1").filter("count==2").drop("count").count()

      var prevtgtPks= prev_tgt_table.drop("row_not_recv_ind").distinct().count()
      var newtgtPks= new_tgt_table.drop("row_not_recv_ind").distinct().count()
      var countTgtVal= prevtgtPks + tgtInserts - tgtDeletes


      val col_test = extent.createTest(s"${table} - Validation", "Validating Source and Target Table")
      println("validating table fields")

      val test_count = col_test.createNode(s"Record Count Checking", "Validating Counts")
      try {
        val countException = intercept[org.scalatest.exceptions.TestFailedException] {
          assert(src_cnt === countTgtVal)
        }
        println(countException.getMessage())

        if (!countException.getMessage().isEmpty())
          test_count.fail(s"${table} - Count exception is given below: <br>" + countException)
        else
          test_count.pass(s"${table} - Validating table counts <br> Source table count : "
            + src_cnt + s"<br> Target table count : " + "Inserted Primary Keys: " + tgtInserts + " Deleted Primary Keys: " + tgtDeletes + " Updated Primary Keys: " + tgtUpdates +
            " Total Primary Keys " + newtgtPks)

      } catch {
        case e: org.scalatest.exceptions.TestFailedException => test_count.pass(s"${table} - Validating table counts <br> " +
          s"Source table primary Keys count : " + src_cnt + s"<br> Target table count : " + "Inserted Primary Keys: " + tgtInserts + " Deleted Primary Keys: " + tgtDeletes + " Updated Primary Keys: " + tgtUpdates +
           " Total Primary Keys " + newtgtPks)
        case unknown: Exception => test_count.error(s"${table} - Count exception. Validation could not be completed for some other reason. " + unknown)
      }

      extent.flush()
    }
    if (runMd == 2 && runOpt =="delta") {

      var dataCompare1 = new_tgt_table.except(prev_tgt_table).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      var window = Window.partitionBy(p_key.map(col): _*).orderBy(p_key.map(col): _*)
      var tgtChanges= dataCompare1.withColumn("count",count(concat(p_key.map(col): _*)).over(window)).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      var tgtUpdates=tgtChanges.filter("count==2").drop("count").count()
      var tgtInserts=tgtChanges.filter("row_not_recv_ind<>1").withColumn("count",count(concat(p_key.map(col): _*)).over(window)).filter("count==1").drop("count").count()
      var tgtDeletes=tgtChanges.filter("row_not_recv_ind==1").withColumn("count",count(concat(p_key.map(col): _*)).over(window)).filter("count==1").drop("count").count()
      var prevtgtPks= prev_tgt_table.drop("row_not_recv_ind").distinct().count()
      var newtgtPks= new_tgt_table.drop("row_not_recv_ind").distinct().count()
      var countTgtVal= tgtUpdates + tgtInserts + tgtDeletes


      val col_test = extent.createTest(s"${table} - Validation", "Validating Source and Target Table ")
      println("validating table fields")

      val test_count = col_test.createNode(s"Record Count Checking", "Validating Counts")
      try {
        val countException = intercept[org.scalatest.exceptions.TestFailedException] {
          assert(src_cnt === countTgtVal)
        }
        println(countException.getMessage())

        if (!countException.getMessage().isEmpty())
          test_count.fail(s"${table} - Count exception is given below: <br>" + countException)
        else
          test_count.pass(s"${table} - Validating table counts <br> Source table count : "
            + src_cnt + s"<br> Target table count : " + "Inserted Primary Keys: " + tgtInserts + " Deleted Primary Keys: " + tgtDeletes + " Updated Primary Keys: " + tgtUpdates +
            " Total Primary Keys " + newtgtPks)

      } catch {
        case e: org.scalatest.exceptions.TestFailedException => test_count.pass(s"${table} - Validating table counts <br> Source table count : "
          + src_cnt + s"<br> Target table count : " + "Inserted Primary Keys: " + tgtInserts + " Deleted Primary Keys: " + tgtDeletes + " Updated Primary Keys: " + tgtUpdates +
          " Total Primary Keys " + newtgtPks)
        case unknown: Exception => test_count.error(s"${table} - Count exception. Validation could not be completed for some other reason. " + unknown)
      }

      extent.flush()
    }
    if (runMd == 2 && runOpt =="current") {
      var window = Window.partitionBy(p_key.map(col): _*).orderBy(p_key.map(col): _*)
      var prev= prev_tgt_table.withColumn("count",count(concat(p_key.map(col): _*)).over(window)).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      var tgt=new_tgt_table.withColumn("count",count(concat(p_key.map(col): _*)).over(window)).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      var dataCompare1 = tgt.except(prev).persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      var tgtUpdate=dataCompare1.filter("count>=2").drop("count")
      var tgtInserts = dataCompare1.filter("row_not_recv_ind <> 1").filter("count=1").drop("count").count()
      var tgtDelete=dataCompare1.filter("row_not_recv_ind=1").filter("count==2").drop("count")
      var tgtUp=tgtUpdate.drop("row_not_recv_ind").except(tgtDelete.drop("row_not_recv_ind"))
      var tgtDeletes= tgtDelete.count()
      var tgtUpdates=tgtUp.count()
      var prevtgtPks= prev_tgt_table.drop("row_not_recv_ind").distinct().count()
      var newtgtPks= new_tgt_table.drop("row_not_recv_ind").distinct().count()
      var countTgtVal= tgtInserts + prevtgtPks - tgtDeletes


      val col_test = extent.createTest(s"${table} - Validation", "Validating Source and Target")
      println("validating table fields")

      val test_count = col_test.createNode(s"Record Count Checking", "Validating Counts")
      try {
        val countException = intercept[org.scalatest.exceptions.TestFailedException] {
          assert(src_cnt === countTgtVal)
        }
        println(countException.getMessage())

        if (!countException.getMessage().isEmpty())
          test_count.fail(s"${table} - Count exception is given below: <br>" + countException)
        else
          test_count.pass(s"${table} - Validating table counts <br> Source table count : "
            + src_cnt + s"<br> Target table count : " + "Inserted Primary Keys: " + tgtInserts + " Deleted Primary Keys: " + tgtDeletes + " Updated Primary Keys: " + tgtUpdates +
            " Total Primary Keys " + newtgtPks)

      } catch {
        case e: org.scalatest.exceptions.TestFailedException => test_count.pass(s"${table} - Validating table counts <br> Source table count : "
          + src_cnt + s"<br> Target table count : " + "Inserted Primary Keys: " + tgtInserts + " Deleted Primary Keys: " + tgtDeletes + " Updated Primary Keys: " + tgtUpdates +
          " Total Primary Keys " + newtgtPks)
        case unknown: Exception => test_count.error(s"${table} - Count exception. Validation could not be completed for some other reason. " + unknown)
      }

      extent.flush()
    }
  }


}

