package com.rxcorp.bdf.Resolver.configs

import com.rxcorp.bdf.Resolver.table._
import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}


/** The `Resolver` object extends [[ResolverConstants]] trait.
  *
  * This object offers methods to resolve csvArray for Tables/files or Fixed Length files.
  * Created By Apoorv
  */

object Resolver extends ResolverConstants {

  /** The `resolve` method returns [[resolveConf]] case class instance by resolving the configurations from user's .csv file.
    * @param csvArra The csvArra object contains values from .csv file
    * @return [[resolveConf]]
    */
  def resolve(csvArra:Any):resolveConf = {
    csvArra match {
      case csvArray: TableDetails.TableConf =>
        resolveConf(csvArray.srcConType, csvArray.srcTableNm, csvArray.alias, csvArray.srcPrsnlQuery, Some(csvArray.header), csvArray.schemaFile, Some(csvArray.tgtTableNm),
          csvArray.tgtPrsnlQuery, Some(csvArray.bitemp), csvArray.aggColumn, csvArray.splitColumn, Some(csvArray.zipFile), None, None, Some(csvArray.useTargetSchema), None, None, None, None, None, None, None, None, None, None, None, None,None,None,None,csvArray.excludeColumn,csvArray.excludeRow)
      case csvArray: FixedFilesDetails.FixedConf =>
        resolveConf(csvArray.srcConType, csvArray.srcTableNm, csvArray.alias, csvArray.srcPrsnlQuery, Some(csvArray.header), csvArray.schemaFile, Some(csvArray.tgtTableNm),
          csvArray.tgtPrsnlQuery, Some(csvArray.bitemp), csvArray.aggColumn, None, Some(csvArray.zipFile), None, None, None, csvArray.post, Some(csvArray.footer), None, None, None, None, None, None, None, None, None, None,None,None,None,csvArray.excludeColumn,None)
      case csvArray: FixedFileDetailsTLR.FixedTLRConf =>
        resolveConf(csvArray.srcConType, csvArray.srcTableNm, csvArray.alias, csvArray.srcPrsnlQuery, Some(csvArray.header), csvArray.schemaFile, Some(csvArray.tgtTableNm),
          csvArray.tgtPrsnlQuery, None, csvArray.aggColumn, None,Some(csvArray.zipFile), Some(csvArray.tgtConType), Some(csvArray.tgtAlias), None, csvArray.post, Some(csvArray.footer), csvArray.splitTgtColumn, None, None, None, None, None, None, None, None, None,None,None,None,csvArray.excludeColumn,None)
      case csvArray: TableDetailsTLR.TableTLRConf =>
        resolveConf(csvArray.srcConType, csvArray.srcTableNm, csvArray.alias, csvArray.srcPrsnlQuery, Some(csvArray.header), csvArray.schemaFile, Some(csvArray.tgtTableNm),
          csvArray.tgtPrsnlQuery, None, csvArray.aggColumn, csvArray.splitColumn, Some(csvArray.zipFile), Some(csvArray.tgtConType), Some(csvArray.tgtAlias), Some(csvArray.useTargetSchema), None, None, csvArray.splitTgtColumn, None, None, None, None, None, None, None, None, None,None,None,None,csvArray.excludeColumn,csvArray.excludeRow)
      case csvArray: TableBitempDetails.TableBitempConf =>
        resolveConf(csvArray.srcConType, csvArray.srcTableNm, csvArray.alias, csvArray.srcPrsnlQuery, Some(csvArray.header), csvArray.schemaFile, None,
          csvArray.tgtPrsnlQuery, None, csvArray.aggColumn, csvArray.splitColumn, Some(csvArray.zipFile), None, None, Some(csvArray.useTargetSchema),None,None,None,Some(csvArray.prevHistory),Some(csvArray.currHistory),Some(csvArray.primaryKey),Some(csvArray.runOption),Some(csvArray.loadDate)
          ,csvArray.nonComapre,csvArray.bussEffMapping,csvArray.bussExpMapping,csvArray.deltaColumn,None,None,None,None,None)
      case csvArray: FixedFilesBitempDetails.FixedBitempConf=>
        resolveConf(csvArray.srcConType, csvArray.srcTableNm, csvArray.alias, csvArray.srcPrsnlQuery, Some(csvArray.header), csvArray.schemaFile, None,
          csvArray.tgtPrsnlQuery, None, csvArray.aggColumn, None, Some(csvArray.zipFile), None, None, None, csvArray.post, Some(csvArray.footer), None,Some(csvArray.prevHistory),Some(csvArray.currHistory),Some(csvArray.primaryKey),Some(csvArray.runOption),Some(csvArray.loadDate)
          ,csvArray.nonComapre,csvArray.bussEffMapping,csvArray.bussExpMapping,csvArray.deltaColumn,None,None,None,None,None)
      case csvArray: MiniTableDetails.miniTableConf=>
        resolveConf(csvArray.srcConType,csvArray.srcTableNm,csvArray.alias,None,None,None,Some(csvArray.tgtTableNm),None,Some(csvArray.bitemp),None,None,None,None,None,Some(csvArray.useTargetSchema),None,None,None,None,None,None,None,None,None,None,None,None,csvArray.srcWhere,csvArray.tgtWhere,Some(csvArray.mode),None,None)
      case csvArray: MiniFilesDetails.miniFilesConf=>
        resolveConf(csvArray.srcConType,csvArray.srcTableNm,csvArray.alias,None,Some(csvArray.header),csvArray.schemaFile,Some(csvArray.tgtTableNm),None,Some(csvArray.bitemp),None,None,Some(csvArray.zipFile),None,None,None,csvArray.post,Some(csvArray.footer),None,None,None,None,None,None,None,None,None,None,csvArray.srcWhere,csvArray.tgtWhere,Some(csvArray.mode),None,None)
      case csvArray: MiniBiTableDetails.miniBiTableConf=>
        resolveConf(csvArray.srcConType,csvArray.srcTableNm,csvArray.alias,None,None,None,None,None,None,None,None,None,None,None,Some(csvArray.useTargetSchema),None,None,None,Some(csvArray.prevHistory),Some(csvArray.currHistory),Some(csvArray.primaryKey),Some(csvArray.runOption),None,None,csvArray.bussEffMapping,None,None,csvArray.srcWhere,csvArray.tgtWhere,Some(csvArray.mode),None,None)
      case csvArray: MiniBiFilesDetails.miniBiFilesConf=>
        resolveConf(csvArray.srcConType,csvArray.srcTableNm,csvArray.alias,None,Some(csvArray.header),csvArray.schemaFile,None,None,None,None,None,Some(csvArray.zipFile),None,None,None,csvArray.post,Some(csvArray.footer),None,Some(csvArray.prevHistory),Some(csvArray.currHistory),Some(csvArray.primaryKey),Some(csvArray.runOption),None,None,csvArray.bussEffMapping,None,None,csvArray.srcWhere,csvArray.tgtWhere,Some(csvArray.mode),None,None)
      case _ =>
        throw new Exception(s"Unsupported Connection Type")
    }

  }

  /** The `resolveConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param srcConType   source Connection Type.
    * @param srcTableNm   source Table Name .
    * @param alias         Alias.
    * @param srcPrsnlQuery   source Personal SQL Query .
    * @param header      whether header is present or not .
    * @param schemaFile    schema file hdfs path for files  .
    * @param tgtTableNm       target Table Name  .
    * @param tgtPrsnlQuery      target Personal SQL Query .
    * @param bitemp        By default "yes" , can be made "no" by user to remove bitemporal columns .
    * @param aggColumn      comma seperated  list of columns for sum check.
    * @param zipFile     By default "no" , can be made "yes" by user if source is zipped file .
    * @param tgtConType   target Connection Type.
    * @param tgtAlias        target Alias.
    * @param splitColumn  Partion column for parallel loading of source table.
    * @param splitTgtColumn  Partion column for parallel loading of target table.
    * @param useTargetSchema defaultt"no" can be made "yes" by user if source table has differnt schema than target.
    * @param post        Record identifier , if value is specified, then only those records from fixed length file will be extracted.
    * @param footer      whether footer is present or not.
    * @param prevHistory   previous history table.
    * @param currHistory      current history table.
    * @param primaryKey    comma seperated primary keys  .
    * @param runOption      run option .
    * @param loadDate  data load timestamp.
    * @param nonComapre comma separated list of non comparison columns.
    * @param bussEffMapping     column mapped to business effective date.
    * @param bussExpMapping     column mapped to business Expiry date.
    * @param deltaColumn column mapped to delta operation.
    * @param srcWhere   source where Query .
    * @param tgtWhere   target where Query .
    * @param mode By default "overwrite" , can be changed by user to append for incremental load.
    * @param excludeColumn comma delimited columns to be excluded
    */
  case class resolveConf(srcConType:String,srcTableNm:String,alias:String,srcPrsnlQuery:Option[String],header:Option[String],schemaFile:Option[String],tgtTableNm:Option[String],
                       tgtPrsnlQuery:Option[String],bitemp:Option[String],aggColumn:Option[String],splitColumn:Option[String],zipFile:Option[String],tgtConType:Option[String],tgtAlias:Option[String],useTargetSchema:Option[String],post:Option[String],
                         footer:Option[String],splitTgtColumn:Option[String],prevHistory:Option[String]
                         ,currHistory:Option[String],primaryKey:Option[String],runOption:Option[String],loadDate:Option[String],nonComapre:Option[String],bussEffMapping:Option[String],bussExpMapping:Option[String],deltaColumn:Option[String],
                         srcWhere:Option[String],tgtWhere:Option[String],mode:Option[String],excludeColumn:Option[String],excludeRow:Option[String]) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("srcConType", srcConType)
        .append("srcTableNm", srcTableNm)
        .append("alias", alias)
        .append("srcPrsnlQuery", srcPrsnlQuery)
        .append("header", header)
        .append("schemaFile", schemaFile)
        .append("tgtTableNm", tgtTableNm)
        .append("tgtPrsnlQuery", tgtPrsnlQuery)
        .append("bitemp", bitemp)
        .append("aggColumn", aggColumn)
        .append("splitColumn", splitColumn)
        .append("zipFile", zipFile)
        .append("tgtConType", tgtConType)
        .append("tgtAlias", tgtAlias)
        .append("useTargetSchema", useTargetSchema)
        .append("tgtAlias", tgtAlias)
        .append("post", post)
        .append("splitTgtColumn", splitTgtColumn)
        .append("prevHistory", prevHistory)
        .append("currHistory", currHistory)
        .append("primaryKey", primaryKey)
        .append("runOption", runOption)
        .append("loadDate", loadDate)
        .append("nonComapre", nonComapre)
        .append("bussEffMapping", bussEffMapping)
        .append("bussExpMapping", bussExpMapping)
        .append("deltaColumn", deltaColumn)
        .append("srcWhere", srcWhere)
        .append("tgtWhere", tgtWhere)
        .append("mode", mode)
        .append("excludeColumn",excludeColumn)
        .append("excludeRow",excludeRow)
        .toString
    }
  }


}
