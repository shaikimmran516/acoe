package com.rxcorp.bdf.Utilities.remote

import java.io._
import java.util

import com.hierynomus.msdtyp.AccessMask
import com.hierynomus.mssmb2.{SMB2CreateDisposition, SMB2ShareAccess}
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.connection.Connection
import com.hierynomus.smbj.session.Session
import com.hierynomus.smbj.share.DiskShare
import com.rxcorp.bdf.Resolver.configs.SMBConfig.SMBConf

class SMB(remote:SMBConf) {
  ///** The [[logger]] variable is an instance of the customized BDF logger for the application. */
 // val logger: QIMSLogger = QIMSLoggerFactory.getLogger.get

  /** The `withClientSession` method creates SMB connection session for other methods to run the SMB operations. */
  def withClientSession[T](f: Session => T): T  = {
    val client: SMBClient = new SMBClient()
    try {
      val auth: AuthenticationContext = new AuthenticationContext(remote.smbUser.get, remote.smbPassword.get.toCharArray, null)
      val connection: Connection = client.connect(remote.smbHost)
      val session: Session = connection.authenticate(auth)
      f(session)
    } finally{
      client.close()
    }
  }

  /** The `downloadFileToTmp` method downloads the file from remote SMB server into Java temporary directory.
    * @param fileName The absolute path of the file on the SMB server to download
    * @return The absolute path for the downloaded file in Java temporary directory
    */
  def downloadFileToTmp(session: Session)(fileName: String): String = {
    var dlFile: String = null
    var isr: InputStreamReader = null
    var in: BufferedReader = null
    val inputEncoding: String = System.getProperty("input.file.encoding", "UTF-8")
    //logger.info(this.getClass, s"Reading source file with encoding: $inputEncoding")
    var osw: OutputStreamWriter = null
    var out: BufferedWriter = null
    val outputEncoding: String = System.getProperty("output.file.encoding", "UTF-8")
    //logger.info(this.getClass, s"Writing source file content with encoding: $outputEncoding")
    var line: String = null
    try {
     // require(remote.path.isDefined, s"basePath key is excepted in .job file, this basically the mount/share name on smb server. Eg: Data")
      val share: DiskShare = session.connectShare(remote.smbPath.replace("\\", "")).asInstanceOf[DiskShare]
     // logger.info(this.getClass, s"Input smb file exists: ${share.fileExists(fileName)}")
      if(share.fileExists(fileName)) {
        val s: util.HashSet[SMB2ShareAccess] = new util.HashSet[SMB2ShareAccess]()
        s.add(SMB2ShareAccess.ALL.iterator.next)
        val localTmpDir: String = System.getProperty("java.io.tmpdir")
        dlFile = fileName.substring(fileName.lastIndexOf("\\") + 1)
        isr = new InputStreamReader(
          share.openFile(
            fileName,
            util.EnumSet.of(AccessMask.GENERIC_READ),
            null,
            s,
            SMB2CreateDisposition.FILE_OPEN,
            null
          ).getInputStream,
          inputEncoding
        )
        osw = new OutputStreamWriter(
          new FileOutputStream(
            new File(s"$localTmpDir/$dlFile")
          ),
          outputEncoding
        )
        in = new BufferedReader(isr)
        out = new BufferedWriter(osw)
        while ({line = in.readLine; line != null}) {
          out.write(line)
          out.write("\n")
        }
      }
      dlFile
    } catch {
      case ex: Throwable =>
        //logger.error(this.getClass, ex.getMessage, ex)
        dlFile
    } finally {
      if(out != null) out.close()
      if(in != null) in.close()
      if(osw != null) osw.close()
      if(isr != null) isr.close()
    }
  }

}
