package com.rxcorp.bdf.Utilities.jdbcDialects.teiid

import com.rxcorp.bdf.Utilities.Db.DBRegexPatterns
import org.apache.spark.sql.types._

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/** The `Utils` object extends [[DBRegexPatterns]] trait.
  * Taken From Mansoor (SLP)
  * This object offers methods to resolve source teiid table schema to spark StructType.
  */
object Utils extends DBRegexPatterns {



  /** The `getStructType` method returns StructType from the provided table metadata .
    * @param metaData The LinkedHashMap with keys of teiid table column names 
    *                 and values of (teiid datatype, precision, scale, nullable)
    * @return org.apache.spark.sql.types.StructType
    * @throws Exception Unsupported teiid datatype for hive compatible datatype conversion!
    */
  def getStructType(metaData: mutable.LinkedHashMap[String, (String, Int, Int, Boolean)]): StructType = {
    val struct: ArrayBuffer[StructField] = new ArrayBuffer[StructField]()
    for(meta <-  metaData){
      val precision: Int = meta._2._2
      val scale: Int = meta._2._3
      val dt: DataType = meta._2._1.toUpperCase match {
        case BIGDECIMALPattern(dtype, size) => handleDecimal(precision, scale)
        case BIGINTPattern(dtype, size) => DataTypes.LongType
        case BIGINTEGERPattern(dtype, size) => handleDecimal(precision, scale)
        case BOOLEANPattern(dtype, size) => DataTypes.BooleanType
        case BYTEPattern(dtype, size) => DataTypes.IntegerType
        case CHARPattern(dtype, size) => DataTypes.StringType
        case DATEPattern(dtype, size) => DataTypes.StringType
        case DECIMALPattern(dtype, size) => handleDecimal(precision, scale)
        case DOUBLEPattern(dtype, size) => DataTypes.DoubleType
        case FLOATPattern(dtype, size) => DataTypes.DoubleType
        case INTEGERPattern(dtype, size) => DataTypes.IntegerType
        case LONGPattern(dtype, size) => DataTypes.LongType
        case REALPattern(dtype, size) => DataTypes.DoubleType
        case SERIALPattern(dtype, size) => DataTypes.IntegerType
        case SHORTPattern(dtype, size) => DataTypes.IntegerType
        case SMALLINTPattern(dtype, size) => DataTypes.IntegerType
        case STRINGPattern(dtype, size) => DataTypes.StringType
        case TIMEPattern(dtype, size) => DataTypes.StringType
        case TSPattern(dtype, size) => DataTypes.TimestampType
        case TINYINTPattern(dtype, size) => DataTypes.IntegerType
        case VARBINARYPattern(dtype, size) => DataTypes.BinaryType
        case VARCHARPattern(dtype, size) => DataTypes.StringType
        case _ =>
          throw new Exception(s"Unsupported teiid datatype: ${meta._2._1.toUpperCase} for hive compatible datatype conversion!")
      }
      struct += StructField(meta._1, dt, meta._2._4)
    }
    StructType(struct.toArray)
  }

  /** The `handleDecimal` method returns DecimalType by resizing the precision and scale to limit.
    * @param precision The precision value of the Decimal
    * @param scale The scale value of the Decimal
    * @return DataType (DecimalType | StringType)
    */
  def handleDecimal(precision: Int, scale: Int): DataType = {
    if(precision > DecimalType.MAX_PRECISION || scale > DecimalType.MAX_SCALE){
      DataTypes.StringType
    }else{
      DecimalType(precision, scale)
    }
  }
}