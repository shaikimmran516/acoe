package com.rxcorp.bdf.Utilities.testCases

import org.apache.spark.sql.functions.{broadcast, col}
import org.apache.spark.sql.{Column,  Dataset, Row}

/** Created By Apoorv*/
object DataValidation {

  /** The `assertDataFrameEqualsK` method compares 2 dataframes and return the counts of unmatched rows, it also creates 2 sample files with matched and unmatched data
    * in hdfs with sampke 50 records.
    * @param srcData Workflow ID assigned to the job to be launched
    * @param tgtData Execution details
    * @param alias Workflow directory contains the config files for the application run
    * @param fixedPath Run Type of the workflow
    * @param isRelaxed Index of the execution for the current job to process
    * @return True or false with counts from both source and target of unmatched rows.
    */

  def assertDataFrameEqualsK(srcData: Dataset[Row], tgtData: Dataset[Row], alias:String, fixedPath:String,isRelaxed: Boolean): (Boolean,Long,Long) = {

    var counts1:Long=0
    var counts2:Long=0
    try {
      srcData.rdd.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      tgtData.rdd.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      val srcColumns: Array[String] = srcData.columns
      val tgtColumns: Array[String] = tgtData.columns
      scala.util.Sorting.quickSort(srcColumns)
      scala.util.Sorting.quickSort(tgtColumns)
      val srcSeq: Seq[Column] = srcColumns.map(col(_))
      val tgtSeq: Seq[Column] = tgtColumns.map(col(_))
      val srcPrime=  if (isRelaxed){srcData} else {srcData.sort(srcSeq: _*)}
      val tgtPrime=  if (isRelaxed){tgtData} else {tgtData.sort(tgtSeq: _*)}
      val sampleSrcMatch = srcPrime.limit(50)
      sampleSrcMatch.repartition(1).write.mode(saveMode = "overwrite").option("delimiter", ",").option("header","true").csv(s"${fixedPath}/${alias}/csv_match/src")
      val sampleTargetMatch= tgtPrime.intersect(broadcast(sampleSrcMatch))
      sampleTargetMatch.repartition(1).write.mode(saveMode = "overwrite").option("delimiter", ",").option("header","true").csv(s"${fixedPath}/${alias}/csv_match/tgt")
      val srcCompareTgt = srcPrime.except(tgtPrime)
      srcCompareTgt.limit(50).repartition(1).write.mode(saveMode = "overwrite").option("delimiter", ",").csv(s"${fixedPath}/${alias}/csv_mismatch/src")
      counts1 = srcCompareTgt.count()
      val tgtComapreSrc = tgtPrime.except(srcPrime)
      tgtComapreSrc.limit(50).repartition(1).write.mode(saveMode = "overwrite").option("delimiter", ",").csv(s"${fixedPath}/${alias}/csv_mismatch/tgt")
      counts2 = tgtComapreSrc.count()

      if (counts1 != counts2 || counts1 != 0 || counts2 != 0) {
        return (false,counts1,counts2)
      }
    } finally {
      srcData.rdd.unpersist()
      tgtData.rdd.unpersist()
    }
    (true,counts1,counts2)
  }
}
