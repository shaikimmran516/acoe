package com.rxcorp.bdf.Utilities.fixedFiles

import java.sql.Timestamp

import com.rxcorp.bdf.Utilities.files.Schema
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext._
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext.implicits._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{DataTypes, DecimalType, StructType}

import scala.collection.mutable.ListBuffer
import scala.util.Try

/** Features taken From Mansoor.(SLP) Added improvements and features by Apoorv.
  */

object FlatFileGen {

  var flatLstCsvPath = ""

  /** The `FlatFileDF` method returns a Spark DataFrame from an input fixed length file
    * This method gives functionality to read based on lengths a fixed length file.
    * Currently not in use but can be used in case of CPI files
    * This parser does not care about schema data types just only lengths
    * @param inputDataPath input data file path.
    * @param schemapath path for .csv schema file
    * @return A Spark DataFrame
    *
    */
  def FlatFileDF(inputDataPath:String,schemapath:String): DataFrame ={
    flatLstCsvPath = schemapath

    var flatDf = hiveContext.read.option ("delimiter", ",").option ("header", "true")
    .csv (flatLstCsvPath)

    var flatArray = flatDf.collect ()
    var column_nm = Array[String] ()
    var lengths = Array[Int] ()
    flatArray.foreach (b => {
    column_nm = column_nm :+ b.getString (0).trim
    lengths = lengths :+ b.getString(1).trim.toInt
  })
    var lines = sparkSession.read.textFile (inputDataPath).filter (! _.isEmpty)
    def parseLinePerFixedLengths(line: String, lengths: Seq[Int]): Seq[String] = {
    lengths.indices.foldLeft ((line, Array.empty[String] ) ) {case ((rem, fields), idx) =>
    val len = lengths (idx)
    val fld = rem.take (len)
    (rem.drop (len), fields :+ fld)
  }._2
  }

    var leng = lengths.toSeq
    var fields = lines.map (parseLinePerFixedLengths (_, leng) ).withColumnRenamed ("value", "fields")

    var answer = leng.indices.foldLeft (fields) {case (result, idx) =>
    result.withColumn (s"col_$idx", col ("fields").getItem (idx) )
  }

    val clmnNames = column_nm.toSeq
    var answer1 = answer.drop (col ("fields") ).toDF (clmnNames: _*)

    answer1
  }

  /** The `convertFixedLenFileToDF` method returns a Spark DataFrame from an input fixed length file
    * @param sparkSession The current Spark session started by the hadoop user from Spark job running in the cluster
    * @param fileName The absolute path to the input source file to be read
    * @param structType User Defined StructType for the Spark DataFrame
    * @param schema List of Schema from parsed .schema file
    * @return A Spark DataFrame
    *
    */
  def convertFixedLenFileToDF(sparkSession: SparkSession, fileName: String,
                              structType: Option[StructType] = None, schema: Option[List[Schema]] = None): DataFrame = {
    require(schema.isDefined, ".schema file is mandatory to process data from fixed length file!")
    val srcRDD: RDD[String] = sparkSession.read.textFile(fileName).rdd
    srcRDD.cache()
    var processedRDD: RDD[Row] = srcRDD.map(line => getRow(line, structType.get, schema.get))
    sparkSession.createDataFrame(processedRDD, structType.get)
  }

  /** The `convertFixedLenFileToDFW` method returns a Spark DataFrame from an input fixed length file
    * @param sparkSession The current Spark session started by the hadoop user from Spark job running in the cluster
    * @param fileName The absolute path to the input source file to be read
    * @param structType User Defined StructType for the Spark DataFrame
    * @param schema List of Schema from parsed .schema file
    * @return A Spark DataFrame
    *
    * @see http://www.swi.com/spark-rdd-getting-bottom-records/
    */

  def convertFixedLenFileToDFW(sparkSession: SparkSession, fileName: String,
                              structType: Option[StructType] = None, schema: Option[List[Schema]] = None,header:Boolean,footer:Boolean,isCompressed:Boolean): DataFrame = {
    require(schema.isDefined, ".schema file is mandatory to process data from fixed length file!")
    var srcFile: String = fileName
    //if(isCompressed) srcFile = com.rxcorp.bdf.Utilities.unzip.Unzip.unzip(sparkSession, fileName)
    val srcRDD: RDD[String] = sparkSession.read.textFile(srcFile).rdd
    srcRDD.cache()

    var processedRDD: RDD[Row] = srcRDD.map(line => getRow(line, structType.get, schema.get))

    if(header==true){
      val header: String = srcRDD.first()
      processedRDD = srcRDD.filter(lines => lines != header).map(line => getRow(line, structType.get, schema.get))
    }
    processedRDD.cache()
    if(footer==true){
      val footerIndex: Long = processedRDD.count() - 1
      processedRDD = processedRDD.zipWithIndex().filter{ case (_, index) => index < footerIndex }.keys
    }
    sparkSession.createDataFrame(processedRDD, structType.get)
  }

  /** The `getRow` method returns a spark sql Row object by splitting a row of single string into values for corresponding columns
    * @param x Row data
    * @param structType User Defined StructType for the Spark DataFrame
    * @param schema List of Schema from parsed .schema file
    * @return Row
    */
  def getRow(x : String, structType: StructType, schema: List[Schema]) : Row = {
    var columnList: ListBuffer[Any] = new ListBuffer[Any]()
    for(i <- schema.indices){
      val field: String = Try(x.substring(schema(i).posStart.get, schema(i).posEnd.get).trim).getOrElse(null)
      val fieldValue: Any = structType(i).dataType match {
        case DataTypes.StringType => field
        case DataTypes.IntegerType => Try{if (!(field == null || field.isEmpty)) Integer.parseInt(field) else null}.getOrElse(throw new Exception(s"NumberFormatException : For Data ${field} For Starting position: ${schema(i).posStart.get} Ending position :${schema(i).posEnd.get} "))
        case DataTypes.LongType => Try{if (!(field == null ||  field.isEmpty)) java.lang.Long.parseLong(field) else null}.getOrElse(throw new Exception(s"NumberFormatException : For Data ${field} For Starting position: ${schema(i).posStart.get} Ending position :${schema(i).posEnd.get} "))
        case DataTypes.FloatType => Try{if (!(field == null ||  field.isEmpty)) java.lang.Float.parseFloat(field) else null}.getOrElse(throw new Exception(s"NumberFormatException : For Data ${field} For Starting position: ${schema(i).posStart.get} Ending position :${schema(i).posEnd.get} "))
        case DataTypes.DoubleType => Try{if (!(field == null ||  field.isEmpty)) java.lang.Double.parseDouble(field) else null}.getOrElse(throw new Exception(s"NumberFormatException : For Data ${field} For Starting position: ${schema(i).posStart.get} Ending position :${schema(i).posEnd.get} "))
        case DataTypes.ByteType => if (!(field == null ||  field.isEmpty)) java.lang.Byte.parseByte(field) else null
        case dt: DecimalType => if (!(field == null ||  field.isEmpty)) new java.math.BigDecimal(field).setScale(schema(i).scale) else null
        case DataTypes.BooleanType =>
          if (field != null && !field.trim.toLowerCase.equals("true") && !field.trim.toLowerCase.equals("false")) {
            null
          } else {
            if (field != null) java.lang.Boolean.parseBoolean(field) else null
          }
        case DataTypes.ShortType => if (field != null) java.lang.Short.parseShort(field) else null
        case DataTypes.TimestampType => if (field != null) Timestamp.valueOf(field) else null
        case DataTypes.BinaryType => if (field != null) org.apache.parquet.io.api.Binary.fromString(field) else null
        case _ =>
          throw new RuntimeException(s"Unsupported Data type $field")
      }
      columnList += fieldValue
    }
    Row.fromSeq(columnList.toList)
  }
}
