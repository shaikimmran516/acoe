package com.rxcorp.bdf.Resolver.configs

/** The `FTPConstants` trait offers constants for different keys expected in .conf file related to [[FTPConfig]].
  * Created By Apoorv */

trait FTPConstants {

  /** The [[ftpSystem]] constant value equals `ftpSystem` */
  final val ftpSystem: String = "ftpSystem"
  /** The [[ftpHost]] constant value equals `ftpHost` */
  final val ftpHost: String = "ftpHost"
  /** The [[ftpPort]] constant value equals `ftpPort` */
  final val ftpPort: String = "ftpPort"
  /** The [[ftpUser]] constant value equals `ftpUser` */
  final val ftpUser: String = "ftpUser"
  /** The [[ftpPassword]] constant value equals `ftpPassword` */
  final val ftpPassword: String = "ftpPassword"
  /** The [[ftpDelimiter]] constant value equals `ftpDelimiter` */
  final val ftpDelimiter: String = "ftpDelimiter"

}
