package com.rxcorp.bdf.Utilities.utils

import com.rxcorp.bdf.Resolver.configs.ConnectDetails.connConf
import com.rxcorp.bdf.Resolver.configs.{ConfFile, Resolver}
import com.rxcorp.bdf.Resolver.configs.FTPConfig.getFTPConfig
import com.rxcorp.bdf.Resolver.configs.SFTPConfig.getSFTPConfig
import com.rxcorp.bdf.Resolver.configs.SMBConfig.getSMBConfig
import com.rxcorp.bdf.Utilities.files.Constants
import com.rxcorp.bdf.Utilities.remote.Ftp.ftpConnect
import com.rxcorp.bdf.Utilities.remote.Sftp.sftpFixedConnect
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.sparkSession
import com.typesafe.config.Config
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.fs.permission.FsPermission
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.rxcorp.bdf.Utilities.files.Utils._
import com.rxcorp.bdf.Utilities.fixedFiles.FlatFileGen._
import com.rxcorp.bdf.Utilities.remote.SMB
import org.apache.hadoop.conf.Configuration

/** Created By Apoorv*/
object SparxtaFixedUtils extends Constants {

  /** The `createFixedSourceDataframe` method creates dataframe for fixed length files.
    * @param resolver resolver containing all properties of an instance
    * @param config configurations from .conf file
    * @param tableNM source table/file name
    * @return Dataframe source dataframe
    */

  def createFixedSourceDataframe(resolver: Resolver.resolveConf, config: Config,connectDetails:connConf,tableNM:String): DataFrame ={
    val confF = ConfFile.getConfig(config)
    val tableDF = resolver.srcConType match{
      case `fixedType` => {
        getSrcDataframe(sparkSession, resolver, tableNM, config)
      }
      case `fixedSFTPType` =>{
        val tgtPath: Path = new Path(s"${confF.fixedHDFSpath}/${resolver.alias}/fixed/Sftp/")
        createTempPath(tgtPath)
        val sftpCon =getSFTPConfig(config,connectDetails)
        val tb = sftpFixedConnect(sparkSession,sftpCon,resolver,config,tableNM)
        var loadFile= s"${confF.fixedHDFSpath}/${resolver.alias}/fixed/Sftp/"
        loadFile = if(resolver.zipFile=="yes") com.rxcorp.bdf.Utilities.unzip.Unzip.unzip(sparkSession,loadFile) else loadFile
        getSrcDataframe(sparkSession, resolver,loadFile, config)
      }
      case `fixedFTPType` => {
        val FileName =tableNM.split("/").last
        val tgtPath: Path = new Path(s"${confF.fixedHDFSpath}/${resolver.alias}/fixed/${FileName}/Ftp/")
        val ftpCon =getFTPConfig(config,connectDetails)
        ftpConnect(sparkSession,resolver.alias,tgtPath,ftpCon,tableNM)
        var loadFile= s"${confF.fixedHDFSpath}/${resolver.alias}/fixed/${FileName}/Ftp/${FileName}.txt"
        loadFile = if(resolver.zipFile=="yes") com.rxcorp.bdf.Utilities.unzip.Unzip.unzip(sparkSession,loadFile) else loadFile
        getSrcDataframe(sparkSession, resolver,loadFile, config)

      }
      case `fixedSMBType` => {
        val tgtPath = s"${confF.fixedHDFSpath}/${resolver.alias}/smb/"
        val hc: Configuration = sparkSession.sparkContext.hadoopConfiguration
        val smbCon =getSMBConfig(config,connectDetails)
        val smbClient: SMB = new SMB(smbCon)
        val smbFile: String = smbClient.withClientSession(session => smbClient.downloadFileToTmp(session)(resolver.srcTableNm))
        val loadFile: String = Utils.moveTmpFileToHDFS(hc, smbFile, tgtPath)
        getSrcDataframe(sparkSession, resolver,loadFile, config)
      }
    }
    tableDF
  }


  /** The `getSrcDataframe` method reads based on schema the fixed width file and returns a dataframe
    * @param resolver resolver containing all properties of an instance
    * @param config configurations from .conf file
    * @param tableNM source table/file name
    * @return Dataframe source dataframe
    */

  def getSrcDataframe(sparkSession:SparkSession, resolver: Resolver.resolveConf, tableNM:String, config: Config):DataFrame ={
    val confF = ConfFile.getConfig(config)
    val data = if (!(resolver.post.isEmpty)) {
      sparkSession.read.textFile(tableNM).filter(x => x.substring(0,resolver.post.get.length) == resolver.post.get)
    } else{sparkSession.read.textFile(tableNM)}
    val FileName =tableNM.split("/").last
   // val BatchName =tableNM.split("/").takeRight(2).head
    val dataFixed = s"${confF.fixedHDFSpath}/${resolver.alias}/fixed/temp/${FileName}/"
    data.coalesce(1).write.format("text").mode(saveMode = "overwrite").save(dataFixed)
    val schemaFilePath: String = resolver.schemaFile.get
    val structType = Option(parseSchemaFile(sparkSession.sparkContext.hadoopConfiguration, schemaFilePath)._1)
    val schemaList = Option(parseSchemaFile(sparkSession.sparkContext.hadoopConfiguration, schemaFilePath)._2)
    var fixedHeader =false
    if(resolver.header=="yes"){
      fixedHeader =true
    }
    var fixedFooter =false
    if(resolver.footer=="yes"){
      fixedFooter =true
    }
    var fixedZip =false
    if(resolver.zipFile=="yes"){
      fixedZip = true
    }
    val tableDF = convertFixedLenFileToDFW(sparkSession, dataFixed, structType, schemaList,fixedHeader,fixedFooter,fixedZip)
    tableDF
  }

  /** The `createTempPath` method creates a temp path for fixed length files for Sftp/Ftp locations to copy
    * @param tgtPath target path to be created
    */

  def createTempPath(tgtPath: Path): Unit ={
    val fs: FileSystem = FileSystem.get(sparkSession.sparkContext.hadoopConfiguration)
    if(!fs.exists(tgtPath)){
      fs.mkdirs(tgtPath)
      fs.setPermission(tgtPath, new FsPermission("777"))
    }
  }

}
