package com.rxcorp.bdf.Utilities.logger

/** The `RuntimeOpts` case class offers access to the values held in the parameters for an instance.
  * @param environment The environment name.
  * @param asset The asset name.
  * @param countryScope The countryScope name.
  */
case class RuntimeOpts(environment: String, asset: String, countryScope: String)