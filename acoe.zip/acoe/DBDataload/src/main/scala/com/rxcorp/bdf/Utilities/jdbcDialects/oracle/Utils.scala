package com.rxcorp.bdf.Utilities.jdbcDialects.oracle

import com.rxcorp.bdf.Utilities.Db.DBRegexPatterns
import org.apache.spark.sql.types._

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer


/** The `Utils` object extends [[DBRegexPatterns]] trait.
  * * Taken From Mansoor.(SLP)
  * This object offers methods to resolve source oracle table schema to spark StructType.
  *
  * @see [[https://issues.apache.org/jira/browse/SPARK-22303?page=com.atlassian.jira.plugin.system.issuetabpanels%3Aall-tabpanel]]
  */
object Utils extends DBRegexPatterns {
  /** The `getStructType` method returns StructType from the provided table metadata .
    * @param metaData The LinkedHashMap with keys of oracle table column names
    *                 and values of (oracle datatype, precision, scale, nullable)
    * @return org.apache.spark.sql.types.StructType
    * @throws Exception Unsupported oracle datatype for hive compatible datatype conversion!
    */
  def getStructType(metaData: mutable.LinkedHashMap[String, (String, Int, Int, Boolean)]): StructType = {
    val struct: ArrayBuffer[StructField] = new ArrayBuffer[StructField]()
    for(meta <-  metaData){
      val precision: Int = meta._2._2
      val scale: Int = meta._2._3
      val dt: DataType = meta._2._1.toUpperCase match {
        //        case BINARYDOUBLEPattern(dtype, size) => DataTypes.StringType
        //        case BINARYFLOATPattern(dtype, size) => DataTypes.StringType
        case BLOBPattern(dtype, size) => DataTypes.BinaryType
        case CHARPattern(dtype, size) => DataTypes.StringType
        case CLOBPattern(dtype, size) => DataTypes.StringType
        case DATEPattern(dtype, size) => DataTypes.TimestampType
        case DECIMALPattern(dtype, size) => DataTypes.createDecimalType(precision, scale)
        case DOUBLEPRECISIONPattern(dtype, size) => DataTypes.DoubleType
        case FLOATPattern(dtype, size) => DataTypes.DoubleType
        case INTPattern(dtype, size) => DataTypes.IntegerType
        case INTEGERPattern(dtype, size) => DataTypes.IntegerType
        case NCLOBPattern(dtype, size) => DataTypes.StringType
        case NCHARPattern(dtype, size) => DataTypes.StringType
        case NUMBERPattern(dtype, size) =>
          if(scale == 0 && (precision >= 1 && precision < 10)) {
            DataTypes.IntegerType
          }else if(scale == 0 && (precision >= 10 && precision < 19)){
            DataTypes.LongType
          }else if(scale == -127 && precision == 0){
            DataTypes.createDecimalType(DecimalType.MAX_PRECISION, 10)
          }else{
            DataTypes.createDecimalType(precision, scale)
          }
        case NVARCHAR2Pattern(dtype, size) => DataTypes.StringType
        case RAWPattern(dtype, size) => DataTypes.BinaryType
        case REALPattern(dtype, size) => DataTypes.FloatType
        case ROWIDPattern(dtype, size) => DataTypes.BinaryType
        case SMALLINTPattern(dtype, size) => DataTypes.IntegerType
        case TSPattern(dtype, size) => DataTypes.TimestampType
        case UROWIDPattern(dtype, size) => DataTypes.BinaryType
        case VARCHARPattern(dtype, size) => DataTypes.StringType
        case VARCHAR2Pattern(dtype, size) => DataTypes.StringType
        case _ =>
          throw new Exception(s"Unsupported oracle datatype: ${meta._2._1.toUpperCase} for hive compatible datatype conversion!")
      }
      struct += StructField(meta._1, dt, meta._2._4)
    }
    StructType(struct.toArray)
  }
}
