package com.rxcorp.bdf.Resolver.table

/** The `MiniBiFilesConstants` trait offers constants for different keys expected in .csv file related to [[MiniBiFilesDetails]]. */
/** Created By Apoorv*/
trait MiniBiFilesConstants {

  /** The [[srcConType]] constant value equals `srcConType` */
  final val srcConType: String = "srcConType"
  /** The [[srcTableNm]] constant value equals `srcTableNm` */
  final val srcTableNm: String = "srcTableNm"
  /** The [[alias]] constant value equals `alias` */
  final val alias: String = "alias"
  /** The [[srcWhere]] constant value equals `srcWhere` */
  final val srcWhere: String = "srcWhere"
  /** The [[header]] constant value equals `header` */
  final val header: String = "header"
  /** The [[schemaFile]] constant value equals `schemaFile` */
  final val schemaFile: String = "schemaFile"
  /** The [[tgtWhere]] constant value equals `tgtWhere` */
  final val tgtWhere: String = "tgtWhere"
  /** The [[post]] constant value equals `post` */
  final val post: String = "post"
  /** The [[footer]] constant value equals `footer` */
  final val footer: String = "footer"
  /** The [[zipFile]] constant value equals `zipFile` */
  final val zipFile: String = "zipFile"
  /** The [[prevHistory]] constant value equals `prevHistory` */
  final val prevHistory: String = "prevHistory"
  /** The [[currHistory]] constant value equals `currHistory` */
  final val currHistory: String = "currHistory"
  /** The [[primaryKey]] constant value equals `primaryKey` */
  final val primaryKey: String = "primaryKey"
  /** The [[runOption]] constant value equals `runOption` */
  final val runOption: String = "runOption"
  /** The [[bussEffMapping]] constant value equals `bussEffMapping` */
  final val bussEffMapping: String = "bussEffMapping"
  /** The [[mode]] constant value equals `mode` */
  final val mode: String = "mode"
}
