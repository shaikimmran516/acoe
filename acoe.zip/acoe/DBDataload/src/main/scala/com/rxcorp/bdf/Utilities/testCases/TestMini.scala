package com.rxcorp.bdf.Utilities.testCases

import com.aventstack.extentreports.{ExtentReports, ExtentTest}
import com.aventstack.extentreports.reporter.ExtentHtmlReporter
import com.rxcorp.bdf.Resolver.configs.ConfFile
import com.rxcorp.bdf.Utilities.utils.Utils._
import com.rxcorp.bdf.Resolver.configs.Resolver.resolve
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext
import com.typesafe.config.Config
import org.scalatest.FunSuite
import TestCases.{dataMiniValidation, getInfo, getSampleData, recordCountTest}
import org.apache.spark.sql.{DataFrame, Dataset, Row}


class TestMini extends FunSuite{

  var configFileName: String = ""
  var eachRow=Row()
  var srcTable:Dataset[Row] = hiveContext.emptyDataFrame
  var tgtTable:Dataset[Row]= hiveContext.emptyDataFrame
  var srcCnt=0
  var tgtCnt=0
  var env=""
  var asset=""
  var country=""
  var tenant=""
  def param(confFilePath: String, inputRow:Row, srcTbl:Dataset[Row], tgtTbl:Dataset[Row], srcCount:Int, tgtCount:Int): Unit = {
    configFileName = confFilePath
    eachRow=inputRow
    srcTable = srcTbl.cache()
    tgtTable = tgtTbl.cache()
    srcCnt=srcCount
    tgtCnt=tgtCount

  }
  test("Sparxta Mini comparison") {
    val config: Config = readConfFile(configFileName)
    val conf: ConfFile.mainConf = ConfFile.getConfig(config)
    val confFileName = configFileName.split("\\/").toList.takeRight(1).head.split("\\.").toList.take(1).head
    val csvArray = getCsvArray(eachRow,4)
    val values = resolve(csvArray)
    val htmlReporter = new ExtentHtmlReporter( s"${confFileName}_comparison.html")
    val extent = new ExtentReports
    htmlReporter.setAppendExisting(true)
    extent.attachReporter(htmlReporter)
    if (conf.sortSource == "yes"){srcTable=selectInTargetOrder(srcTable,tgtTable)}
    val parentTest: ExtentTest = extent.createTest(s"${values.alias} - Validation", "Validating Source and Target Table")
    println("validating table fields")
    var infoDF: Dataset[Row] = getInfo(parentTest,values,conf,env,asset,country,tenant)
    if(conf.recordCountTest=="yes" || conf.recordCountTest == "" || conf.recordCountTest == null) recordCountTest(parentTest,srcCnt,tgtCnt,values,infoDF)
    getSampleData(parentTest,srcTable,tgtTable)
    dataMiniValidation(parentTest,srcTable,tgtTable,values,conf)
    srcTable.unpersist()
    tgtTable.unpersist()
    extent.flush()
  }

}
