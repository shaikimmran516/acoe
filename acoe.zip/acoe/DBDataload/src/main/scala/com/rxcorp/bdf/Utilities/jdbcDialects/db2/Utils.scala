package com.rxcorp.bdf.Utilities.jdbcDialects.db2

import com.rxcorp.bdf.Utilities.Db.DBRegexPatterns
import org.apache.spark.sql.types.{DataType, DataTypes, StructField, StructType}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer


/** The `Utils` object extends [[DBRegexPatterns]] trait.
  *
  * This object offers methods to resolve source db2 table schema to spark StructType.
  * Taken From Mansoor.(SLP)
  */
object Utils extends DBRegexPatterns {



  /** The `getStructType` method returns StructType from the provided table metadata .
    * @param metaData The LinkedHashMap with keys of db2 table column names
    *                 and values of (db2 datatype, precision, scale, nullable)
    * @return org.apache.spark.sql.types.StructType
    * @throws Exception Unsupported db2 datatype for hive compatible datatype conversion!
    */
  def getStructType(metaData: mutable.LinkedHashMap[String, (String, Int, Int, Boolean)]): StructType = {
    val struct: ArrayBuffer[StructField] = new ArrayBuffer[StructField]()
    for(meta <-  metaData){
      val precision: Int = meta._2._2
      val scale: Int = meta._2._3
      val dt: DataType = meta._2._1.toUpperCase match {
        case BIGINTPattern(dtype, size) => DataTypes.LongType
        case BINARYPattern(dtype, size) => DataTypes.BinaryType
        case BLOBPattern(dtype, size) => DataTypes.BinaryType
        case CHARPattern(dtype, size) => DataTypes.StringType
        case CLOBPattern(dtype, size) => DataTypes.StringType
        case DATEPattern(dtype, size) => DataTypes.StringType
        case DBCLOBPattern(dtype, size) => DataTypes.StringType
        case DECIMALPattern(dtype, size) => DataTypes.createDecimalType(precision, scale)
        case DOUBLEPattern(dtype, size) => DataTypes.DoubleType
        case GRAPHICPattern(dtype, size) => DataTypes.StringType
        case INTEGERPattern(dtype, size) => DataTypes.IntegerType
        case NUMERICPattern(dtype, size) => DataTypes.createDecimalType(precision, scale)
        case REALPattern(dtype, size) => DataTypes.FloatType
        case SMALLINTPattern(dtype, size) => DataTypes.IntegerType
        case TIMEPattern(dtype, size) => DataTypes.StringType
        case TSPattern(dtype, size) => DataTypes.TimestampType
        case VARBINARYPattern(dtype, size) => DataTypes.BinaryType
        case VARCHARPattern(dtype, size) => DataTypes.StringType
        case VARGRAPHICPattern(dtype, size) => DataTypes.StringType
        case XMLPattern(dtype, size) => DataTypes.StringType
        case _ =>
          throw new Exception(s"Unsupported db2 datatype: ${meta._2._1.toUpperCase} for hive compatible datatype conversion!")
      }
      struct += StructField(meta._1, dt, meta._2._4)
    }
    StructType(struct.toArray)
  }
}