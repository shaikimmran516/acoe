package com.rxcorp.bdf.Utilities.logger

import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import com.rxcorp.bdf.logging.log.EventAttribute

/** The `DSLogger` trait offers customized logger functions for BDF logging framework. */
trait DSLogger {

  /** The [[instanceTagOpt]] holds the INSTANCE_TAG property value set at runtime */
  val instanceTagOpt: Option[String] = sys.env.get("INSTANCE_TAG")

  def logFatal(msg:String):Unit

  def fatal(msg: String):Unit = logFatal(msg)

  def fatal(clazz: Class[_],msg: String):Unit = {
    val msgTags: String = createMsgTagString(clazz)
    logFatal(s"$msgTags $msg")
  }

  def logFatal(msg: String, exception: Throwable): Unit

  def fatal(clazz:Class[_], msg: String, exception: Throwable): Unit = {
    val msgTags: String = createMsgTagString(clazz)
    logFatal(s"$msgTags $msg",exception)
  }

  def logDebug(msg: String): Unit

  def debug(clazz: Class[_], msg: String): Unit = {
    val msgTags: String = createMsgTagString(clazz)
    logDebug(s"$msgTags $msg")
  }

  def logInfo(msg: String): Unit

  def info(clazz: Class[_], msg: String): Unit = {
    val msgTags: String = createMsgTagString(clazz)
    logInfo(s"$msgTags $msg")
  }

  def logWarn(msg: String): Unit

  def logWarn(msg: String, exception: Throwable): Unit

  def warn(clazz: Class[_], msg: String): Unit = {
    val msgTags: String = createMsgTagString(clazz)
    logWarn(s"$msgTags")
  }

  def warn(clazz: Class[_], msg: String, exception: Throwable): Unit = {
    val msgTags: String = createMsgTagString(clazz)
    logWarn(s"$msgTags", exception)
  }

  def logError(msg: String): Unit

  def logError(msg: String, exception: Throwable): Unit

  def error(clazz: Class[_], msg: String): Unit = {
    val msgTags: String = createMsgTagString(clazz)
    logError(s"$msgTags $msg")
  }

  def error(clazz: Class[_], msg: String, exception: Throwable): Unit = {
    val msgTags: String = createMsgTagString(clazz)
    logError(s"$msgTags $msg", exception)
  }

  def createMsgTagString(clazz: Class[_]): String = {
    val tagList: mutable.ListBuffer[(String, String)] = ListBuffer()

    if (instanceTagOpt.nonEmpty)
      tagList += (("instance", instanceTagOpt.get))

    tagList += (("class", clazz.getSimpleName))

    val tags: String = tagList.map(x => s"${x._1}=${x._2}").mkString(", ")
    s"[$tags]"
  }

  def addOptions(bag: scala.collection.mutable.Map[EventAttribute, String]): Unit

  def add(item: (EventAttribute, String)):Unit

  def removeOptions(bag: Set[EventAttribute]): Unit

  def remove(item: EventAttribute): Unit

  def logaddOptions(bag: scala.collection.mutable.Map[EventAttribute, String]): Unit = addOptions(bag)

  def logadd(item: (EventAttribute, String)):Unit = add(item)

  def logremoveOptions(bag: Set[EventAttribute]): Unit = removeOptions(bag)

  def logremove(item: EventAttribute): Unit = remove(item)
}
