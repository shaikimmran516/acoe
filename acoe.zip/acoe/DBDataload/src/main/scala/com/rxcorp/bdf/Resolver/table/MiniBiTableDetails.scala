package com.rxcorp.bdf.Resolver.table

import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}
import org.apache.spark.sql.Row

import scala.util.Try
/** Created By Apoorv*/
object MiniBiTableDetails extends MiniBiTableConstants {

  /** The `getMiniBiTableDetails` method returns [[miniBiTableConf]] case class instance by resolving the tables with bitemporality files from .csv file for mini version
    * @param inputString Row contains values from .csv file
    * @return [[miniBiTableConf]]
    */

  def getMiniBiTableDetails(inputString: Row):miniBiTableConf = {
    val srcConType= Try(inputString.getString(0).trim).getOrElse(throw new Exception("Connection Type Missing"))
    val srcTableNm= Try(inputString.getString(1).trim).getOrElse(throw new Exception("Source Table Missing"))
    val alias=Try(inputString.getString(2).trim).getOrElse(throw new Exception("Alias is Missing"))
    val srcWhere=Try(Some(inputString.getString(3).trim)).getOrElse(None)
    val prevHistory= Try(inputString.getString(4).trim).getOrElse(throw new Exception("Previous History Target Table is Missing"))
    val currHistory=Try(inputString.getString(5).trim).getOrElse(throw new Exception("Current History Target Table is Missing"))
    val tgtWhere=Try(Some(inputString.getString(6).trim)).getOrElse(None)
    val primaryKey=Try(inputString.getString(7).trim).getOrElse(throw new Exception("Primary Key is Missing"))
    val runOption=Try(inputString.getString(8).toLowerCase.trim).getOrElse(throw new Exception("Run Option is Missing"))
    val bussEffMapping=Try(Some(inputString.getString(9).trim)).getOrElse(None)
    val useTargetSchema=Try(inputString.getString(10)).getOrElse("no")
    val mode =Try(inputString.getString(11)).getOrElse("overwrite")
    miniBiTableConf(srcConType,srcTableNm,alias,srcWhere,
      tgtWhere,prevHistory,currHistory,primaryKey,runOption,bussEffMapping,useTargetSchema,mode)
  }

  /** The `miniTableConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param srcConType source Connection Type.
    * @param srcTableNm source Table Name .
    * @param alias      Alias.
    * @param srcWhere   source where Query .
    * @param tgtWhere   target where Query .
    * @param prevHistory   previous history table.
    * @param currHistory      current history table.
    * @param primaryKey    comma seperated primary keys  .
    * @param runOption      run option .
    * @param bussEffMapping     column mapped to business effective date.
    * @param useTargetSchema defaultt"no" can be made "yes" by user if source table has differnt schema than target.
    * @param mode By default "overwrite" , can be changed by user to append for incremental load.
    */
  case class miniBiTableConf(srcConType:String,srcTableNm:String,alias:String,srcWhere:Option[String],
                           tgtWhere:Option[String],prevHistory:String,currHistory:String,primaryKey:String,runOption:String,bussEffMapping:Option[String],useTargetSchema:String,mode:String) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("srcConType", srcConType)
        .append("srcTableNm", srcTableNm)
        .append("alias", alias)
        .append("srcWhere", srcWhere)
        .append("tgtWhere", tgtWhere)
        .append("prevHistory", prevHistory)
        .append("currHistory", currHistory)
        .append("primaryKey", primaryKey)
        .append("runOption", runOption)
        .append("bussEffMapping", bussEffMapping)
        .append("useTargetSchema", useTargetSchema)
        .append("mode",mode)
        .toString
    }
  }

}
