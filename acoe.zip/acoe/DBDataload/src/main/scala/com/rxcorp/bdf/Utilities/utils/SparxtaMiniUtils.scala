package com.rxcorp.bdf.Utilities.utils

import com.rxcorp.bdf.Resolver.configs.ConnectDetails.connConf
import com.rxcorp.bdf.Resolver.configs.{ConfFile, Resolver}
import com.rxcorp.bdf.Utilities.files.Constants
import com.rxcorp.bdf.Utilities.Db.DBConnection._
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.sparkSession
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext.sql
import com.rxcorp.bdf.Utilities.utils.SparxtaFixedUtils.createFixedSourceDataframe
import com.rxcorp.bdf.Utilities.utils.SparxtaUtils.{createSourceDataframe, getMultipleTableList}
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame

import scala.collection.mutable.ArrayBuffer

/** Created By Apoorv*/
object SparxtaMiniUtils extends Constants {

  /** The `getSourceCount` method returns count from source and dataframe for mini prod version reolving for single/multiple source files.
    * @param resolver resolver containing all properties of an instance
    * @param config configurations from .conf file
    * @param connectDetails target connection details
    * @return Dataframe sample records
    * @return Int count of records in source
    */

  def getSourceCount(resolver: Resolver.resolveConf, config: Config,connectDetails:connConf):(Int,DataFrame) ={
    if(resolver.srcTableNm.trim.split("~").length==1){
      val (count,srcDF)= getSourceCountsDF(resolver, config, resolver.srcTableNm,connectDetails)
      (count,srcDF)
    }
    else if (resolver.srcTableNm.trim.split("~").length>1){
      val tableArray = getMultipleTableList(resolver)._1
      val tableArrayLen=getMultipleTableList(resolver)._2
      var dfList = ArrayBuffer[DataFrame]()
      var dfCounts =ArrayBuffer[Int]()
      for(h <- 0 until tableArrayLen){
        val tableNm = tableArray(h).trim
        val (cnt,df)= getSourceCountsDF(resolver, config,tableNm,connectDetails)
        dfCounts += cnt
        dfList += df
      }
      val srcDF = dfList.tail.foldLeft(dfList.head){(df1, df2) => df1.union(df2)}
      val count= dfCounts.tail.foldLeft(dfCounts.head){(df1, df2) => df1 + df2}
      (count,srcDF)
    } else{
      throw new Exception(s"Source Dataframe Empty : ${resolver.srcTableNm} ")
    }
  }

  /** The `getSourceCountsDF` method returns count from source and dataframe for mini prod version reolving for single source files.
    * @param resolver resolver containing all properties of an instance
    * @param config configurations from .conf file
    * @param connectDetails target connection details
    * @param tableNM source table/file name
    * @return Dataframe sample records
    * @return Int count of records in source
    */

  def getSourceCountsDF(resolver: Resolver.resolveConf, config: Config, tableNM:String,connectDetails:connConf): (Int,DataFrame) ={
    resolver.srcConType match {
      case `oracleType` | `db2Type` | `impalaType` | `exasolType` | `netezzaType` | `sqlserverType` | `teiidType`  =>
        val countQuery = generateCountQuery(tableNM,resolver.srcConType,resolver.srcWhere.get)
        val srcCount= readData(sparkSession,connectDetails.jdbcURL.get,resolver.srcConType,resolver.splitColumn.get,countQuery)
        val srcCountInt= countToIntResolver(resolver.srcConType,srcCount)
        val srcQuery= generateDataQuery(tableNM,resolver.srcConType,resolver.srcWhere.get,resolver.primaryKey.get)
        val srcDF=readData(sparkSession,connectDetails.jdbcURL.get,resolver.srcConType,resolver.splitColumn.get,srcQuery)
        (srcCountInt,srcDF)
      case `hiveType` =>
        val (srcCountInt,srcDF)= getCountsDF(resolver,config,resolver.srcTableNm,resolver.srcWhere.get,resolver.primaryKey.get)
        (srcCountInt,srcDF)
      case `fixedType` | `fixedSFTPType` | `fixedFTPType` | `fixedSMBType` =>
        val tempDF= createFixedSourceDataframe(resolver,config,connectDetails,tableNM)
        tempDF.createOrReplaceTempView(s"${resolver.alias}")
        val (srcCountInt,srcDF)= getCountsDF(resolver,config,resolver.alias,resolver.srcWhere.get,resolver.primaryKey.get)
        (srcCountInt,srcDF)
      case  `flatPipeType` | `flatCommaType` | `flatTildeType` | `flatTabType` | `flatSemiColonType` | `flatSFTPType` | `flatFTPType` | `flatSMBType` =>
        val tempDF=createSourceDataframe(resolver,config,tableNM,connectDetails)
        tempDF.createOrReplaceTempView(s"${resolver.alias}")
        val (srcCountInt,srcDF)= getCountsDF(resolver,config,resolver.alias,resolver.srcWhere.get,resolver.primaryKey.get)
        (srcCountInt,srcDF)
    }

  }

  /** The `getCountsDF` method returns count from target hive and dataframe for mini prod version.
    * @param resolver resolver containing all properties of an instance
    * @param config configurations from .conf file
    * @param tableNM source table/file name
    * @param where if where clause exist
    * @param primaryKey primary keys comma seperated
    * @return Dataframe sample records
    * @return Int count of records in source
    */

  def getCountsDF(resolver: Resolver.resolveConf, config: Config, tableNM:String,where:String,primaryKey:String): (Int,DataFrame) ={
        val countQuery = generateCountQuery(tableNM,"hive",where)
        val Count= sql(countQuery)
        val CountInt= countToIntResolver("hive",Count)
        val Query= generateDataQuery(tableNM,"hive",where,primaryKey)
        val DF=sql(Query)
        (CountInt,DF)
  }

}
