package com.rxcorp.bdf.Utilities.files

import java.io.{BufferedReader, InputStreamReader}

import com.rxcorp.bdf._
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.{hiveContext, sparkSession}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.StructType

/** Taken From Mansoor.(SLP) + Added features By Apoorv*/

import scala.collection.mutable

object Utils extends Constants {

  /** The [[delimiter]] constant value equals `|`, which separates values of the columns */
  final val delimiter: Char = '|'

  /** The [[metaBound]] constant value equals `%`, used to enclose the database name annotation like %oracle% */
  final val metaBound: String =  "%"

  /** The `parseSchemaFile` method returns StructType by parsing the .schema file
    * provided by a job from .includes file in the workflow directory.
    * @param configuration Hadoop Configuration
    * @param path The absolute path of the .schema file related to the current job of the workflow.
    * @return StructType, Schema list from parsed schema file
    */
  def parseSchemaFile(configuration: Configuration, path: String): (StructType, List[Schema]) = {
    val schemaContent: mutable.LinkedHashMap[Int, Schema] = new mutable.LinkedHashMap[Int, Schema]()
    var schemaLine: Array[String] = Array.empty
    val fs: FileSystem = FileSystem.get(configuration)
    val schemaPath: Path = new Path(path)
    val br: BufferedReader = new BufferedReader(new InputStreamReader(fs.open(schemaPath)))
    val lines: Array[AnyRef] = br.lines().toArray
    require(lines.head.toString.startsWith(metaBound), s"Metatype specification missing for the schema file ${schemaPath.getName}!")
    val metaType: String = lines.head.toString.replace(metaBound, "").trim
    for(line <- lines.filter(l => l.toString.trim.nonEmpty)){
      if(!line.toString.trim.startsWith(metaBound)) {
        schemaLine = line.toString.trim.split(delimiter)
        val schema: Schema = schemaLine.length match {
          case 5 => Schema.apply(metaType, schemaLine(0).trim.toInt, schemaLine(1).trim, schemaLine(2).trim.toLowerCase, schemaLine(3).trim.toInt,  schemaLine(4).trim.toInt)
          case 7 => Schema.apply(metaType, schemaLine(0).trim.toInt, schemaLine(1).trim, schemaLine(2).trim.toLowerCase, schemaLine(3).trim.toInt,  schemaLine(4).trim.toInt,
            Some(schemaLine(5).trim.toInt - 1), Some(schemaLine(6).trim.toInt))
          case _ => throw new Exception("Each line in .schema file is expected be of length 5 for csv and delimited files, length 7 for fixed length file")
        }
        schemaContent += (schema.ordinal -> schema)
      }
    }
    br.close()
    val schema: List[Schema] = schemaContent.toSeq.sortBy(_._1).map(x => x._2).toList

    (unboundSchemaForDB(schemaPath.getName, metaType, schema), schema)
  }

  /** The `getStructType` method returns StructType from the parsed schema file
    * provided by a job from .includes file in the workflow directory.
    * @param schema The list of Schema case class instances with values from parsed .schema file.
    * @return StructType
    */
  def getStructType(schema: List[Schema]): StructType = {
    var st: StructType = new StructType()
    for(item <- schema){
      st = st.add(item.columnName, item.dataType)
    }
    st
  }

  /** The `unboundSchemaForDB` method returns StructType from the parsed schema file
    * provided by a job from .includes file in the workflow directory.
    * @param fileName The file name of the .schema file defined in .includes file within the workflow directory.
    * @param metaType The database name used in the annotation like oracle for %oracle%
    * @param schema The list of Schema case class instances with values from parsed .schema file.
    * @return StructType
    */
  def unboundSchemaForDB(fileName: String, metaType: String, schema: List[Schema]): StructType = {
    val unboundedSchema: mutable.LinkedHashMap[String, (String, Int, Int, Boolean)] = new mutable.LinkedHashMap[String, (String, Int, Int, Boolean)]()
    for(i <- schema.indices){
      val ss: Schema = schema(i)
      unboundedSchema += (ss.columnName -> (ss.dataType, ss.precision, ss.scale, true))
    }
    metaType.toLowerCase match {
      case `hiveType` => getStructType(schema)
      //      case `mysqlType` =>
      case `netezzaType` => Utilities.jdbcDialects.netezza.Utils.getStructType(unboundedSchema)
      case `oracleType` => Utilities.jdbcDialects.oracle.Utils.getStructType(unboundedSchema)
      case `sqlserverType` => Utilities.jdbcDialects.sqlserver.Utils.getStructType(unboundedSchema)
      case `teiidType` => Utilities.jdbcDialects.teiid.Utils.getStructType(unboundedSchema)
      case `exasolType` => Utilities.jdbcDialects.exasol.Utils.getStructType(unboundedSchema)
      case _ => throw new Exception(s"Unsupported metatype $metaType for schema resolvance in file $fileName!")
    }
  }

  /** The `getDelimiter` method returns delimiter depenind on file connection type
    * @param fileType The file connection type from .csv file.
    * @return String
    */

  def getDelimiter(fileType: String): String = {
    fileType match {
      case "flat_file_pipe" => "|"
      case "flat_file_tab" => "\t"
      case "flat_file_semicolon" => ";"
      case "flat_file_tilde" => "~"
      case "flat_file_comma" => ","
      case _ =>
        throw new Exception("Unsupported Database Type")
    }
  }

  /** The `getFilesDataframe` method returns dataframe for delimited files depending whether schema file is present or not.
    * @param sparkSession spark session.
    * @param fileName file path or name.
    * @param schemaPath path for schema file.
    * @param srcSystem source connection type.
    * @param headerPresent whether header is present or not
    * @param delimiter specified delimiter
    * @return DataFrame
    */
  def getFilesDataframe(sparkSession:SparkSession,fileName:String,schemaPath:String,srcSystem:String,headerPresent:String,delimiter:String,isCompressed:Boolean): DataFrame={
    val delimit= delimiter
    var srcFile: String = fileName
    val df = if (headerPresent == "no") {
      val structType = Option(parseSchemaFile(sparkSession.sparkContext.hadoopConfiguration, schemaPath)._1)
      val schemaList = Option(parseSchemaFile(sparkSession.sparkContext.hadoopConfiguration, schemaPath)._2)
      hiveContext.read.schema(structType.get).option("delimiter", delimit).option("header", "false").csv(srcFile)
    } else if (!(headerPresent == "no")) {
      hiveContext.read.option("delimiter", delimit).option("header", "true").csv(srcFile)
    } else hiveContext.emptyDataFrame

    df
  }

}
