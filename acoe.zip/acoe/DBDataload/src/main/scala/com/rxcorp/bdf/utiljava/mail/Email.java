package com.rxcorp.bdf.utiljava.mail;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

/**Created By joydeep , added features by Apoorv*/
public class Email {

    private static String host = "localhost";
    private static String to = "recipient@host.com";
    private static String from = "sender@host.com";
    private static String cc = "";
    private static String bcc = "";
    private static String attachment_file="";
    private static String image_file="";
    private static String image2_file="";



    public static void send(String from, String to_address, String subject, String contents,String attachment_file, String image_file,String image2_file) throws MessagingException,IOException {
        Properties prop = System.getProperties();
        prop.setProperty("mail.smtp.host", host);
        Session session = Session.getDefaultInstance(prop);
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));
        message.setSubject(subject);
        BodyPart messageBodyPart = new MimeBodyPart();
        Multipart multipart = new MimeMultipart();
        messageBodyPart = new MimeBodyPart();
        messageBodyPart.setContent(contents, "text/html");
        File f = new File(attachment_file);
        MimeBodyPart attachmentPart = new MimeBodyPart();
        attachmentPart.attachFile(f);
        multipart.addBodyPart(attachmentPart);
        multipart.addBodyPart(messageBodyPart);
        messageBodyPart = new MimeBodyPart();
        DataSource fds = new FileDataSource(image_file);
        messageBodyPart.setDataHandler(new DataHandler(fds));
        messageBodyPart.setHeader("Content-ID", "<image>");
        multipart.addBodyPart(messageBodyPart);
        messageBodyPart = new MimeBodyPart();
        DataSource fds1 = new FileDataSource(image2_file);
        messageBodyPart.setDataHandler(new DataHandler(fds1));
        messageBodyPart.setHeader("Content-ID", "<image1>");
        multipart.addBodyPart(messageBodyPart);
        message.setContent(multipart);
        List <String> toList = getAddress(to_address);
        for (String address : toList) {
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(address));
        }
        List <String> ccList = getAddress(cc);
        for (String address : ccList) {
            message.addRecipient(Message.RecipientType.CC, new InternetAddress(address));
        }
        List <String> bccList = getAddress(bcc);
        for (String address : bccList) {
            message.addRecipient(Message.RecipientType.BCC, new InternetAddress(address));
        }
        message.addRecipient(Message.RecipientType.BCC, new InternetAddress("apoorv.agrawal@in.imshealth.com"));
        message.addRecipient(Message.RecipientType.BCC, new InternetAddress("nkbidi@in.imshealth.com"));
        message.addRecipient(Message.RecipientType.BCC, new InternetAddress("mreddy@in.imshealth.com"));
        Transport.send(message);
    }

    public static void send(String from, String to_address, String subject, String contents,String attachment_file, String image_file,String image2_file,String excel_file) throws MessagingException,IOException {
        Properties prop = System.getProperties();
        prop.setProperty("mail.smtp.host", host);
        Session session = Session.getDefaultInstance(prop);
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));
        message.setSubject(subject);
        BodyPart messageBodyPart = new MimeBodyPart();
        Multipart multipart = new MimeMultipart();
        messageBodyPart = new MimeBodyPart();
        messageBodyPart.setContent(contents, "text/html");
        File f = new File(attachment_file);
        MimeBodyPart attachmentPart = new MimeBodyPart();
        attachmentPart.attachFile(f);
        multipart.addBodyPart(attachmentPart);
        multipart.addBodyPart(messageBodyPart);
        messageBodyPart = new MimeBodyPart();
        DataSource fds = new FileDataSource(image_file);
        messageBodyPart.setDataHandler(new DataHandler(fds));
        messageBodyPart.setHeader("Content-ID", "<image>");
        multipart.addBodyPart(messageBodyPart);
        messageBodyPart = new MimeBodyPart();
        DataSource fds1 = new FileDataSource(image2_file);
        messageBodyPart.setDataHandler(new DataHandler(fds1));
        messageBodyPart.setHeader("Content-ID", "<image1>");
        multipart.addBodyPart(messageBodyPart);
        messageBodyPart = new MimeBodyPart();
        messageBodyPart.setDataHandler(new DataHandler(new FileDataSource(excel_file)));
        messageBodyPart.setFileName("report.csv");
        multipart.addBodyPart(messageBodyPart);
        message.setContent(multipart);

        List <String> toList = getAddress(to_address);
        for (String address : toList) {
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(address));
        }
        List <String> ccList = getAddress(cc);
        for (String address : ccList) {
            message.addRecipient(Message.RecipientType.CC, new InternetAddress(address));
        }
        List <String> bccList = getAddress(bcc);
        for (String address : bccList) {
            message.addRecipient(Message.RecipientType.BCC, new InternetAddress(address));
        }
        message.addRecipient(Message.RecipientType.BCC, new InternetAddress("apoorv.agrawal@in.imshealth.com"));
        message.addRecipient(Message.RecipientType.BCC, new InternetAddress("nkbidi@in.imshealth.com"));
        message.addRecipient(Message.RecipientType.BCC, new InternetAddress("mreddy@in.imshealth.com"));
        Transport.send(message);
    }
    public static void send(String from, String to_address, String subject, String contents,String attachment_file) throws MessagingException,IOException {
        Properties prop = System.getProperties();
        prop.setProperty("mail.smtp.host", host);
        Session session = Session.getDefaultInstance(prop);
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));
        message.setSubject(subject);
        BodyPart messageBodyPart = new MimeBodyPart();
        Multipart multipart = new MimeMultipart();
        messageBodyPart = new MimeBodyPart();
        messageBodyPart.setContent(contents, "text/html");
        File f = new File(attachment_file);
        MimeBodyPart attachmentPart = new MimeBodyPart();
        attachmentPart.attachFile(f);
        multipart.addBodyPart(attachmentPart);
        multipart.addBodyPart(messageBodyPart);
        message.setContent(multipart);
        List <String> toList = getAddress(to_address);
        for (String address : toList) {
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(address));
        }
        List <String> ccList = getAddress(cc);
        for (String address : ccList) {
            message.addRecipient(Message.RecipientType.CC, new InternetAddress(address));
        }
        List <String> bccList = getAddress(bcc);
        for (String address : bccList) {
            message.addRecipient(Message.RecipientType.BCC, new InternetAddress(address));
        }
        message.addRecipient(Message.RecipientType.BCC, new InternetAddress("apoorv.agrawal@in.imshealth.com"));
        message.addRecipient(Message.RecipientType.BCC, new InternetAddress("nkbidi@in.imshealth.com"));
        message.addRecipient(Message.RecipientType.BCC, new InternetAddress("mreddy@in.imshealth.com"));
        Transport.send(message);
    }

    public static void send(String from, String to_address, String subject, String contents) throws MessagingException {
        Properties prop = System.getProperties();
        prop.setProperty("mail.smtp.host", host);
        Session session = Session.getDefaultInstance(prop);
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));
        message.setSubject(subject);
        BodyPart messageBodyPart = new MimeBodyPart();
        Multipart multipart = new MimeMultipart("related");
        messageBodyPart = new MimeBodyPart();
        messageBodyPart.setContent(contents, "text/html");
        multipart.addBodyPart(messageBodyPart);
        message.setContent(multipart);
        List <String> toList = getAddress(to_address);
        for (String address : toList) {
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(address));
        }
        List <String> ccList = getAddress(cc);
        for (String address : ccList) {
            message.addRecipient(Message.RecipientType.CC, new InternetAddress(address));
        }
        List <String> bccList = getAddress(bcc);
        for (String address : bccList) {
            message.addRecipient(Message.RecipientType.BCC, new InternetAddress(address));
        }
        message.addRecipient(Message.RecipientType.BCC, new InternetAddress("apoorv.agrawal@in.imshealth.com"));
        message.addRecipient(Message.RecipientType.BCC, new InternetAddress("nkbidi@in.imshealth.com"));
        message.addRecipient(Message.RecipientType.BCC, new InternetAddress("mreddy@in.imshealth.com"));
        Transport.send(message);
    }
    public static void send(String subject, String contents) throws MessagingException, IOException {
        send(from, to, subject, contents,attachment_file,image_file,image2_file);
    }

    public static void send1(String from, String to_address, String subject, String contents,String attachment_file) {

    }

    public static List getAddress(String address) {
        List addressList = new ArrayList();
        if (address.isEmpty())
            return addressList;
        if (address.indexOf(";") > 0) {
            String[] addresses = address.split(";");
            for (String a : addresses) {
                addressList.add(a);
            }
        } else {
            addressList.add(address);
        }
        return addressList;
    }
}