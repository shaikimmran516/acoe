package com.rxcorp.bdf.Utilities.utils

import java.io.{BufferedReader, InputStreamReader}

import com.rxcorp.bdf.Resolver.configs.ConnectDetails.connConf
import com.rxcorp.bdf.Resolver.configs.Resolver
import com.rxcorp.bdf.Utilities.files.Constants
import org.apache.spark.sql._
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext.sql
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.hiveContext.implicits._
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import com.rxcorp.bdf.Utilities.utils.SparxtaUtils.createTargetHive
import org.apache.spark.sql.functions.{col, length, lit, when}
import com.rxcorp.bdf.Utilities.utils.SparxtaUtils.createTargetDb
import com.rxcorp.bdf.Resolver.table.FixedFilesBitempDetails._
import com.rxcorp.bdf.Resolver.table.FixedFileDetailsTLR._
import com.rxcorp.bdf.Resolver.table.FixedFilesDetails._
import com.rxcorp.bdf.Resolver.table.MiniBiFilesDetails._
import com.rxcorp.bdf.Resolver.table.MiniBiTableDetails._
import com.rxcorp.bdf.Resolver.table.MiniFilesDetails._
import com.rxcorp.bdf.Resolver.table.MiniTableDetails._
import com.rxcorp.bdf.Resolver.table.TableBitempDetails._
import com.rxcorp.bdf.Resolver.table.TableDetails._
import com.rxcorp.bdf.Resolver.table.TableDetailsTLR._
import org.apache.hadoop.fs.permission.FsPermission

/** Created By Apoorv*/


object Utils extends Constants{

  /** The `getDataframeQuery` method returns Dataframe if personal Query exist.
    * @param personalQuery Personalised source/target sql query to be run in spark-SQL.
    * @param table Alias name in case of databases/actual table name in case of Hive.
    * @param sparkSession The current Spark session started by the hadoop user from Spark job running in the cluster
    * @return Dataframe using the personalised sql query
    */

  def getDataframeQuery(sparkSession: SparkSession, personalQuery: String, table: String): DataFrame = {
    val query=if(!(personalQuery.isEmpty)){if(personalQuery.endsWith(".query")){getQueryFromFile(sparkSession,personalQuery)} else {personalQuery}} else{personalQuery}
    val df = if (!(query == null || query == "")) sql(query) else sql(s"select * from $table")
    df
  }

  /** The `writeDataframe` method writes Dataframe in HDFS location.
    * @param df Dataframe to be written.
    * @param path path in which dataframe needs to be saved.
    * @param sparkSession The current Spark session started by the hadoop user from Spark job running in the cluster
    */

  def writeDataframe(sparkSession: SparkSession, df: DataFrame, path: String): Unit = {
    df.write.format("parquet").option("ignoreLeadingWhiteSpace", false).mode(saveMode = "overwrite").save(path)
  }

  def getQueryFromFile(sparkSession: SparkSession,path:String):String ={
    val fs: FileSystem = FileSystem.get(sparkSession.sparkContext.hadoopConfiguration)
    val queryPath: Path = new Path(path)
    val br: BufferedReader = new BufferedReader(new InputStreamReader(fs.open(queryPath)))
    val query: String = br.lines().toArray.mkString(" ").replace(";", "")
    query
  }

  /** The `removeBitempCols` method removes bitemp columns.
    * @param df Dataframe.
    * @param sparkSession The current Spark session started by the hadoop user from Spark job running in the cluster
    * @return Dataframe after removing bitemp columns.
    */

  def removeBitempCols(sparkSession: SparkSession, df: DataFrame): DataFrame = {
    val colsToRemove = Seq("bus_eff_dt", "bus_expry_dt", "proc_eff_ts", "proc_expry_ts", "row_not_recv_ind", "oprtnl_stat_cd")

    val filteredDF = df.select(df.columns.filter(colName => !colsToRemove.contains(colName)).map(colName => new Column(colName)): _*)
    filteredDF
  }
  /*
  /** The `getTableListArray` reads the csv file craetes a dataframe after filtering converts into Array.
    * @param tableListPath Path to table list file.
    * @param tableListType type of table list 1 for non-fixed length files as source , 2 for fixed length files.
    * @param sparkSession The current Spark session started by the hadoop user from Spark job running in the cluster
    * @return Array[Row] Array of the input tables/file details
    */

  def getTableListArray(sparkSession: SparkSession, tableListPath: String, tableListType: Int): Array[Row] = {
    val df = hiveContext.read.format("com.databricks.spark.csv").option("delimiter", "|").option("header", "true").load(tableListPath).filter(!$"CON_TYP".startsWith("#"))
    val df1 = if (tableListType == 1) {
      df.filter("CON_TYP <> 'fixed'").filter("CON_TYP <> 'fixed_sftp'").filter("CON_TYP <> 'fixed_ftp'")
    }
    else if (tableListType == 2) {
      df.filter("CON_TYP = 'fixed'").union(df.filter("CON_TYP = 'fixed_sftp'")).union(df.filter("CON_TYP = 'fixed_ftp'"))
    } else {
      throw new Exception(s"Unsupported Connection Type")
    }
    df1.collect()
  }*/

  /** The `readConfFile` method reads .conf file.
    * @param confFilePath path to .conf file in hdfs.
    * @return Config object.
    */

  def readConfFile(confFilePath: String): Config = {
    val fileSystem = FileSystem.get(new Configuration())
    val jobFile: Path = new Path(confFilePath)
    val reader = new InputStreamReader(fileSystem.open(jobFile))
    ConfigFactory.parseReader(reader).withFallback(ConfigFactory.systemProperties()).resolve()
  }

  /** The `getTableListArray` reads the csv file craetes a dataframe after filtering converts into Array.
    * @param tableListPath Path to table list file.
    * @param sparkSession The current Spark session started by the hadoop user from Spark job running in the cluster
    * @return Array[Row] Array of the input tables/file details
    */

  def getTableListArray(sparkSession: SparkSession, tableListPath: String): Array[Row] = {
    val df = hiveContext.read.option("delimiter", "|").option("header", "true").csv(tableListPath).filter(!$"CON_TYP".startsWith("#"))
    df.collect()
  }
  /** The `getCsvArray` reads each row of CSV file and resolve it into its respective Type.
    * @param listRow each row of csv file.
    * @param runType runType of job
    * @return Product
    */

  def getCsvArray(listRow: Row,runType:Int): Product = {
    val csvArray= runType match{
      case 1 => listRow.getString(0).trim match {
        case `oracleType` | `db2Type` | `impalaType` | `exasolType` | `netezzaType` | `sqlserverType` | `teiidType` | `hiveType` | `flatPipeType` | `flatCommaType` | `flatTildeType` | `flatTabType` | `flatSemiColonType` | `flatSFTPType` | `flatFTPType` | `flatSMBType` =>
          getTableDetails(listRow)
        case `fixedType` | `fixedSFTPType` | `fixedFTPType` | `fixedSMBType` =>
          getFixedFileDetails(listRow)
      }
      case 2 => listRow.getString(0).trim match {
        case `oracleType` | `db2Type` | `impalaType` | `exasolType` | `netezzaType` | `sqlserverType` | `teiidType` | `hiveType` | `flatPipeType` | `flatCommaType` | `flatTildeType` | `flatTabType` | `flatSemiColonType` | `flatSFTPType` | `flatFTPType` | `flatSMBType` =>
          getTableDetailsTLR(listRow)
        case `fixedType` | `fixedSFTPType` | `fixedFTPType`  | `fixedSMBType` =>
          getFixedFileDetailsTLR(listRow)
      }
      case 3 =>  listRow.getString(0).trim match {
        case `oracleType` | `db2Type` | `impalaType` | `exasolType` | `netezzaType` | `sqlserverType` | `teiidType` | `hiveType` | `flatPipeType` | `flatCommaType` | `flatTildeType` | `flatTabType` | `flatSemiColonType` | `flatSFTPType` | `flatFTPType` | `flatSMBType` =>
          getTableBitempDetails(listRow)
        case `fixedType` | `fixedSFTPType` | `fixedFTPType` | `fixedSMBType` =>
          getFixedFileBitempDetails(listRow)
      }
      case 4 =>listRow.getString(0).trim match {
        case `oracleType` | `db2Type` | `impalaType` | `exasolType` | `netezzaType` | `sqlserverType` | `teiidType` | `hiveType`  =>
          getMiniTableDetails(listRow)
        case `fixedType` | `fixedSFTPType` | `fixedFTPType` | `flatPipeType` | `flatCommaType` | `flatTildeType` | `flatTabType` | `flatSemiColonType` | `flatSFTPType` | `flatFTPType` | `flatSMBType` | `fixedSMBType`=>
          getMiniFileDetails(listRow)
      }
      case 5 =>listRow.getString(0).trim match {
        case `oracleType` | `db2Type` | `impalaType` | `exasolType` | `netezzaType` | `sqlserverType` | `teiidType` | `hiveType`  =>
          getMiniBiTableDetails(listRow)
        case `fixedType` | `fixedSFTPType` | `fixedFTPType` | `flatPipeType` | `flatCommaType` | `flatTildeType` | `flatTabType` | `flatSemiColonType` | `flatSFTPType` | `flatFTPType` | `flatSMBType` | `fixedSMBType`=>
          getBiMiniFileDetails(listRow)
      }

      case _ => throw new Exception("Unsupported Run Type")
    }

    csvArray
  }

  /** The `excludeColumns` method removes columns.
    * @param df Dataframe.
    * @param sparkSession The current Spark session started by the hadoop user from Spark job running in the cluster
    * @param excludeColumns comma delimited excluded columns list
    * @return Dataframe after removing columns.
    */

  def excludeColumns(sparkSession: SparkSession, excludeColumns:String ,df: DataFrame): DataFrame = {
    val colsToRemove = excludeColumns.trim.split(",").toList
    val filteredDF = df.select(df.columns.filter(colName => !colsToRemove.contains(colName)).map(colName => new Column(colName)): _*)
    filteredDF
  }

  /** The `useTargetSchema` method creates source dataframe based on target schema
    * @param resolver resolver containing all properties of an instance
    * @param finalSrcDF source dataframe
    * @param finalTgtDF target Dataframe
    * @return Dataframe source dataframe after schema conversion
    */

  def useTargetSchema(resolver:Resolver.resolveConf, finalSrcDF:DataFrame, finalTgtDF:DataFrame): DataFrame ={
    if (resolver.useTargetSchema == "yes") {
      var srcDF: DataFrame = finalSrcDF.toDF(finalSrcDF.columns map (_.toLowerCase): _*)
      var schema = srcDF.schema.fields
      var ordering = schema.map(f => col(s"${f.name}")).toList
      val cols: List[Column] = finalTgtDF.schema.map(s => (s.name.toLowerCase, s.dataType)).toMap.filterKeys(srcDF.columns.toSet).map({ case (k, v) => col(k).cast(v) }).toList
      val final_src_df1 = srcDF.select(cols: _*)
      val df = final_src_df1.select(ordering: _*)
      df
    } else {
      finalSrcDF
    }

  }

  /** The `nullifyEmptyStrings` converts empty strings to null values.
    * @param df resolver containing all properties of an instance
    * @return Dataframe source dataframe after empty to null conversion
    */

  def nullifyEmptyStrings(df:Dataset[Row]): Dataset[Row] = {
    var in = df
    for (e <- df.columns) {
      in = in.withColumn(e, when(length(col(e))===0, lit(null)).otherwise(col(e)))
    }
    in
  }

  /** The `replaceNulls` converts null values to specified values.
    * @param df resolver containing all properties of an instance
    * @param nullValue vale to be replaced with
    * @return Dataframe source dataframe after empty to null conversion
    */

  def replaceNulls(df:Dataset[Row],nullValue:String): Dataset[Row]={
    val df1 = df.na.fill(nullValue)
    df1
  }

  /** The `selectInTargetOrder` selects source columns in target dataframe order.
    * @param srcdf source dataframe
    * @param tgtdf target dataframe
    * @return Dataframe source dataframe after reordering
    */

  def selectInTargetOrder(srcdf:Dataset[Row],tgtdf:Dataset[Row]):Dataset[Row]={
    val srcDF: DataFrame = srcdf.toDF(srcdf.columns map(_.toLowerCase): _*)
    val schema = tgtdf.schema.fields
    val ordering = schema.map(f => col(s"${f.name}")).toList
    srcDF.select(ordering:_*)
  }

  /** The `resolveDf` method resolve target based on runType , 1 for hive 2 for other databases
    * @param resolver resolver containing all properties of an instance
    * @param config configurations from .conf file
    * @param runType runType
    * @param tableNm Table name
    * @return Dataframe target dataframe
    */


  def resolveDf(resolver: Resolver.resolveConf,config:Config,runType:Int,tableNm:String,connectDetails:connConf):DataFrame={
    if(runType==1){
      createTargetHive(resolver,config,tableNm)
    } else if(runType==2){
      createTargetDb(resolver,config,connectDetails)
    }
    else{
      throw new Exception(s"Unsupported Connection Type")
    }
  }

  def moveTmpFileToHDFS(configuration: Configuration, sourceFile: String, hdfsTemp: String): String = {
    //logger.info(this.getClass, s"Moving  downloaded $sourceFile to HDFS directory $hdfsTemp")
    val localTmpDir: String = System.getProperty("java.io.tmpdir")
    val fs: FileSystem = FileSystem.get(configuration)
    val srcPath: Path = new Path(s"$localTmpDir/$sourceFile")
    val tgtPath: Path = new Path(hdfsTemp)
    if(!fs.exists(tgtPath)){
      fs.mkdirs(tgtPath)
      fs.setPermission(tgtPath, new FsPermission("777"))
    }
    fs.moveFromLocalFile(srcPath, tgtPath)
    //logger.info(this.getClass, s"Moved downloaded $sourceFile to HDFS directory $tgtPath")
    val hdfsFile: String = tgtPath.suffix(s"/$sourceFile").toString
    fs.deleteOnExit(new Path(hdfsFile))
    hdfsFile
  }

}


