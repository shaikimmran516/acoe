package com.rxcorp.bdf.Resolver.table

/** The `FixedFilesBitempConstants` trait offers constants for different keys expected in .csv file related to [[FixedFilesBitempDetails]]. */
/** Created By Apoorv*/

trait FixedFilesBitempConstants {
  /** The [[srcConType]] constant value equals `srcConType` */
  final val srcConType: String = "srcConType"
  /** The [[srcTableNm]] constant value equals `srcTableNm` */
  final val srcTableNm: String = "srcTableNm"
  /** The [[alias]] constant value equals `alias` */
  final val alias: String = "alias"
  /** The [[srcPrsnlQuery]] constant value equals `srcPrsnlQuery` */
  final val srcPrsnlQuery: String = "srcPrsnlQuery"
  /** The [[header]] constant value equals `header` */
  final val header: String = "header"
  /** The [[schemaFile]] constant value equals `schemaFile` */
  final val schemaFile: String = "schemaFile"
  /** The [[tgtPrsnlQuery]] constant value equals `tgtPrsnlQuery` */
  final val tgtPrsnlQuery: String = "tgtPrsnlQuery"
  /** The [[post]] constant value equals `post` */
  final val post: String = "post"
  /** The [[aggColumn]] constant value equals `aggColumn` */
  final val aggColumn: String = "aggColumn"
  /** The [[footer]] constant value equals `footer` */
  final val footer: String = "footer"
  /** The [[zipFile]] constant value equals `zipFile` */
  final val zipFile: String = "zipFile"
  /** The [[prevHistory]] constant value equals `prevHistory` */
  final val prevHistory: String = "prevHistory"
  /** The [[currHistory]] constant value equals `currHistory` */
  final val currHistory: String = "currHistory"
  /** The [[primaryKey]] constant value equals `primaryKey` */
  final val primaryKey: String = "primaryKey"
  /** The [[runOption]] constant value equals `runOption` */
  final val runOption: String = "runOption"
  /** The [[loadDate]] constant value equals `loadDate` */
  final val loadDate: String = "loadDate"
  /** The [[nonComapre]] constant value equals `nonComapre` */
  final val nonComapre: String = "nonComapre"
  /** The [[bussEffMapping]] constant value equals `bussEffMapping` */
  final val bussEffMapping: String = "bussEffMapping"
  /** The [[bussExpMapping]] constant value equals `bussExpMapping` */
  final val bussExpMapping: String = "bussExpMapping"
  /** The [[deltaColumn]] constant value equals `deltaColumn` */
  final val deltaColumn: String = "deltaColumn"
}
