package com.rxcorp.bdf

import better.files.File
import com.rxcorp.bdf.Resolver.configs.ConfFile
import com.rxcorp.bdf.Resolver.configs.ConnectDetails.connConf
import com.rxcorp.bdf.Resolver.configs.Resolver.resolve
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.sparkSession
import com.rxcorp.bdf.Utilities.testCases.TestBiMini
import com.rxcorp.bdf.Utilities.time.Time.convertTime
import com.rxcorp.bdf.Utilities.utils.SparxtaMiniUtils.{getCountsDF, getSourceCount}
import com.rxcorp.bdf.Utilities.utils.Extras._
import com.typesafe.config.Config
import org.apache.spark.sql.DataFrame
import com.rxcorp.bdf.Utilities.utils.Extras.emailBuilder
import com.rxcorp.bdf.Utilities.utils.Utils._

import scala.collection.mutable
import scala.util.control.Breaks.{break, breakable}

object SparxtaMiniBitemp {


  /** The `SparxtaMiniBitemp` method runs method for runType=5, i.e For any soucre to any hive as target with bitemp for Production QC version. This creates HTML report and sends in mail.
    * @param configFile path to .conf file
    * @param environment enviorment name
    * @param asset asset name
    * @param country country name
    * @param tenant tenant name
    */
  def SparxtaBitempMini(configFile:String,connectDetails:connConf,environment:String,asset:String,country:String,tenant:String): Unit = {
    val jobStart = System.nanoTime
    val confFilePath = configFile
    val config: Config = readConfFile(confFilePath)
    val tables = new StringBuilder
    val tableException = mutable.HashMap[String, Exception]()
    val tableLoadingTime = mutable.HashMap[String, String]()
    val confFileName: String = confFilePath.split("\\/").toList.takeRight(1).head.split("\\.").toList.take(1).head
    val confF = ConfFile.getConfig(config)
    val reportHTML = File(s"${confFileName}_comparison.html")
    if (reportHTML.exists) reportHTML.delete()
    val testArray = mutable.HashMap[String, String]()
    val tableListArray = getTableListArray(sparkSession, confF.tableListPath)
    val totalInputs=tableListArray.length

    appendHeader(tables, 1)
    tableListArray.foreach { eachRow =>
      breakable {
        val tableStart = System.nanoTime
        val (srcCount:Int,finalSrcDF:DataFrame,prevTgtCount:Int,prevTgtDF:DataFrame,newTgtCount:Int,newTgtDF:DataFrame)= try {
          val csvArray = getCsvArray(eachRow,5)
          val resolver = resolve(csvArray)
          var (srcCnt,srcDF)=getSourceCount(resolver,config,connectDetails)
          srcDF.cache()
          srcDF = if (!(confF.nullValue.isEmpty)) {replaceNulls(srcDF,confF.nullValue.get)} else srcDF
          srcDF =  if(!(confF.emptyValue.isEmpty)){nullifyEmptyStrings(srcDF)}else srcDF
          var (prevtgtCnt,prevtargetDF) = getCountsDF(resolver,config,resolver.prevHistory.get,resolver.tgtWhere.get,s"${resolver.primaryKey},row_not_recv_ind from")
          var (currtgtCnt,currtargetDF) = getCountsDF(resolver,config,resolver.currHistory.get,resolver.tgtWhere.get,s"${resolver.primaryKey},row_not_recv_ind from")
          srcDF=useTargetSchema(resolver,srcDF,removeBitempCols(sparkSession,currtargetDF))
          val tableEnd = convertTime(System.nanoTime - tableStart)
          tableLoadingTime.put(resolver.alias, tableEnd)
          (srcCnt,srcDF,prevtgtCnt,prevtargetDF,currtgtCnt,currtargetDF)
        }catch{
          case e : Exception => val csvArray = getCsvArray(eachRow,5);val resolver = resolve(csvArray); tableException.put(resolver.alias,e);val tableEnd = convertTime(System.nanoTime - tableStart); tableLoadingTime.put(resolver.alias,tableEnd);
        }
        val testTimeStart = System.nanoTime
        val csvArray = getCsvArray(eachRow,5)
        val resolver: Resolver.configs.Resolver.resolveConf = resolve(csvArray)
        val primaryKey=resolver.primaryKey.get.trim.split(",").toList
        if(tableException contains resolver.alias){
          val testTimeEnd: String = convertTime(System.nanoTime - testTimeStart)
          appendException(tables,resolver,1,tableLoadingTime(resolver.alias),testTimeEnd,tableException(resolver.alias),resolver.currHistory.get)
          break()
        }
        val test = new TestBiMini()
        if (srcCount!=0 || newTgtCount !=0) {
          if (prevTgtCount == 0) {
            test.param(confFilePath, resolver.alias, resolver.srcConType, srcCount,prevTgtCount, newTgtCount, 1,finalSrcDF,prevTgtDF,newTgtDF,resolver.runOption.get,primaryKey)
            test.execute()
          }
          else {
            test.param(confFilePath, resolver.alias, resolver.srcConType, srcCount,prevTgtCount, newTgtCount, 2,finalSrcDF,prevTgtDF,newTgtDF,resolver.runOption.get,primaryKey)
            test.execute()
          }
        } else {if (newTgtCount==0 || srcCount==0 || resolver.mode=="append"){
          val testTimeEnd: String = convertTime(System.nanoTime - testTimeStart)
          appendRow(tables,resolver,2,tableLoadingTime(resolver.alias),testTimeEnd,resolver.currHistory.get)
          break()
        }
        else{
          val testTimeEnd: String = convertTime(System.nanoTime - testTimeStart)
          appendRow(tables,resolver,3,tableLoadingTime(resolver.alias),testTimeEnd,resolver.currHistory.get)
          break()
        }}
        cleanUpHDFS(confF.fixedHDFSpath,resolver.alias,resolver.srcConType,3)
        val testTimeEnd = convertTime(System.nanoTime - testTimeStart)
        testArray.put(resolver.alias,testTimeEnd)
        appendRow(tables,resolver,1,tableLoadingTime(resolver.alias),testTimeEnd,resolver.currHistory.get)
      }
    }
    if (reportHTML.exists) {
      val tableTestCount = HTMLScrapper(s"${confFileName}_comparison.html")._2
      val tableStatus= HTMLScrapper(s"${confFileName}_comparison.html")._3
      val tableStat=createResultTable(tableStatus)
      val jobEnd = convertTime(System.nanoTime - jobStart)
      emailBuilder(1,confFileName,confF.mailIds,jobEnd,tables.toString(),tableStat,tableTestCount.toString,totalInputs.toString,environment,asset,country,tenant)
    }else {
      emailBuilder(2,confFileName,confF.mailIds,null,tables.toString(),null,null,totalInputs.toString,environment,asset,country,tenant)

    }
  }
}
