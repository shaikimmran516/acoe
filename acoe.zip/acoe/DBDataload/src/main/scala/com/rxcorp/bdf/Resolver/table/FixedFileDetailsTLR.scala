package com.rxcorp.bdf.Resolver.table

import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}
import org.apache.spark.sql.Row

import scala.util.Try
/** Created By Apoorv*/
object FixedFileDetailsTLR extends FixedFilesConstantsTLR {
  /** The `getFixedFileDetails` method returns [[FixedTLRConf]] case class instance by resolving the fixed length files from .csv file for TargetLoadRoot Class
    * @param inputString Row contains values from .csv file
    * @return [[FixedTLRConf]]
    */

  def getFixedFileDetailsTLR(inputString: Row):FixedTLRConf = {
    val srcConType= Try(inputString.getString(0).trim).getOrElse(throw new Exception("Connection Type Missing"))
    val srcTableNm= Try(inputString.getString(1).trim).getOrElse(throw new Exception("Source File name Missing"))
    val schemaFile: Option[String] =Try(Some(inputString.getString(2).trim)).getOrElse(throw new Exception("Schema File name Missing"))
    val post=Try(Some(inputString.getString(3))).getOrElse(None)
    val header=Try(inputString.getString(4).trim.toLowerCase).getOrElse("no")
    val footer=Try(inputString.getString(5).trim.toLowerCase).getOrElse("no")
    val alias=Try(inputString.getString(6).trim).getOrElse(throw new Exception("Alias is Missing"))
    val srcPrsnlQuery=Try(Some(inputString.getString(7).trim)).getOrElse(None)
    val tgtConType= Try(inputString.getString(8).trim).getOrElse(throw new Exception("Target Connection Type Missing"))
    val tgtTableNm=Try(inputString.getString(9).trim).getOrElse(throw new Exception("Target Table is Missing"))
    val tgtAlias=Try(inputString.getString(10).trim).getOrElse(throw new Exception("Tgt Alias is Missing"))
    val tgtPrsnlQuery=Try(Some(inputString.getString(11).trim)).getOrElse(None)
    val splitTgtColumn=Try(Some(inputString.getString(12).trim)).getOrElse(None)
    val aggColumn=Try(Some(inputString.getString(13).trim)).getOrElse(None)
    val zipFile=Try(inputString.getString(14)).getOrElse("no")
    val excludeColumn=Try(Some(inputString.getString(15).trim)).getOrElse(None)

    FixedTLRConf(srcConType,srcTableNm,schemaFile,alias,post,header,footer,srcPrsnlQuery,tgtConType,tgtTableNm,tgtAlias,
      tgtPrsnlQuery,splitTgtColumn,aggColumn,zipFile,excludeColumn)
  }

  /** The `FixedTLRConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param srcConType   source Connection Type.
    * @param srcTableNm   source Table Name
    * @param post        Record identifier , if value is specified, then only those records from fixed length file will be extracted.
    * @param alias         Alias.
    * @param srcPrsnlQuery   source Personal SQL Query .
    * @param header      whether header is present or not .
    * @param footer      whether footer is present or not.
    * @param schemaFile    schema file hdfs path for files  .
    * @param tgtConType   target Connection Type.
    * @param tgtTableNm       target Table Name  .
    * @param tgtAlias         target Alias.
    * @param tgtPrsnlQuery      target Personal SQL Query .
    * @param splitTgtColumn  Partion column for parallel loading of target table.
    * @param aggColumn      comma seperated  list of columns for sum check.
    * @param zipFile     By default "no" , can be made "yes" by user if source is zipped file .
    * @param excludeColumn comma delimited columns to be excluded
    */
  case class FixedTLRConf(srcConType:String,srcTableNm:String,schemaFile:Option[String],alias:String,post:Option[String],header:String,footer:String,srcPrsnlQuery:Option[String],tgtConType:String,tgtTableNm:String,tgtAlias:String,
                       tgtPrsnlQuery:Option[String],splitTgtColumn:Option[String],aggColumn:Option[String],zipFile:String,excludeColumn:Option[String]) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("srcConType", srcConType)
        .append("srcTableNm", srcTableNm)
        .append("schemaFile", schemaFile)
        .append("post", post)
        .append("header", header)
        .append("footer", footer)
        .append("alias", alias)
        .append("srcPrsnlQuery", srcPrsnlQuery)
        .append("tgtConType", tgtConType)
        .append("tgtTableNm", tgtTableNm)
        .append("tgtAlias", tgtAlias)
        .append("tgtPrsnlQuery", tgtPrsnlQuery)
        .append("splitTgtColumn", splitTgtColumn)
        .append("aggColumn", aggColumn)
        .append("zipFile", zipFile)
        .append("excludeColumn",excludeColumn)
        .toString
    }
  }

}
