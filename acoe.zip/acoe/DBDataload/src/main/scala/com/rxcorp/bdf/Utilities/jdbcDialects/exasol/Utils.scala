package com.rxcorp.bdf.Utilities.jdbcDialects.exasol

import com.rxcorp.bdf.Utilities.Db.DBRegexPatterns
import org.apache.spark.sql.types.{DataType, DataTypes, StructField, StructType}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/** The `Utils` object extends [[DBRegexPatterns]] trait.
  *
  * This object offers methods to resolve source exasol table schema to spark StructType.
  * Taken From Mansoor.(SLP)
  */
object Utils extends DBRegexPatterns {


  /** The `getStructType` method returns StructType from the provided table metadata .
    * @param metaData The LinkedHashMap with keys of exasol table column names
    *                 and values of (exasol datatype, precision, scale, nullable)
    * @return org.apache.spark.sql.types.StructType
    * @throws Exception Unsupported exasol datatype for hive compatible datatype conversion!
    */
  def getStructType(metaData: mutable.LinkedHashMap[String, (String, Int, Int, Boolean)]): StructType = {
    val struct: ArrayBuffer[StructField] = new ArrayBuffer[StructField]()
    for(meta <-  metaData){
      val precision: Int = meta._2._2
      val scale: Int = meta._2._3
      val dt: DataType = meta._2._1.toUpperCase match {
        case BOOLEANPattern(dtype, size) => DataTypes.BooleanType
        case CHARPattern(dtype, size) => DataTypes.StringType
        case DATEPattern(dtype, size) => DataTypes.StringType
        case DECIMALPattern(dtype, size) => DataTypes.createDecimalType(precision, scale)
        case DOUBLEPRECISIONPattern(dtype, size) => DataTypes.DoubleType
        case TSPattern(dtype, size) => DataTypes.TimestampType
        case VARCHARPattern(dtype, size) => DataTypes.StringType
        case _ =>
          throw new Exception(s"Unsupported exasol datatype: ${meta._2._1.toUpperCase} for hive compatible datatype conversion!")
      }
      struct += StructField(meta._1, dt /*, nullable = meta._2._4 */)
    }
    StructType(struct.toArray)
  }
}
