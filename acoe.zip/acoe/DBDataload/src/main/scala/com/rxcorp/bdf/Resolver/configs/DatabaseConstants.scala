package com.rxcorp.bdf.Resolver.configs

/** The `DatabaseConstants` trait offers constants for different keys expected in .conf file related to [[DatabaseConfig]].
  * Created By Apoorv */

trait DatabaseConstants {

  /** The [[jdbcURL]] constant value equals `jdbcURL` */
  final val jdbcURL: String = "jdbcURL"
  /** The [[jdbcTgt]] constant value equals `jdbcTgt` */
  final val jdbcTgt: String = "jdbcTgt"
}
