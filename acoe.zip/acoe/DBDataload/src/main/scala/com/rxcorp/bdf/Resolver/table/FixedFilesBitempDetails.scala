package com.rxcorp.bdf.Resolver.table

import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}
import org.apache.spark.sql.Row

import scala.util.Try
/** Created By Apoorv*/
object FixedFilesBitempDetails extends FixedFilesBitempConstants {


  /** The `getFixedFileBitempDetails` method returns [[FixedBitempConf]] case class instance by resolving the fixed length files from .csv file for bitemporal Scenarios
    * @param inputString Row contains values from .csv file
    * @return [[FixedBitempConf]]
    */

  def getFixedFileBitempDetails(inputString: Row):FixedBitempConf = {
    val srcConType= Try(inputString.getString(0).trim).getOrElse(throw new Exception("Connection Type Missing"))
    val srcTableNm= Try(inputString.getString(1).trim).getOrElse(throw new Exception("Source File name Missing"))
    val schemaFile=Try(Some(inputString.getString(2).trim)).getOrElse(throw new Exception("Schema File name Missing"))
    val post=Try(Some(inputString.getString(3))).getOrElse(None)
    val header=Try(inputString.getString(4).trim.toLowerCase).getOrElse("no")
    val footer=Try(inputString.getString(5).trim.toLowerCase).getOrElse("no")
    val alias=Try(inputString.getString(6).trim).getOrElse(throw new Exception("Alias is Missing"))
    val srcPrsnlQuery=Try(Some(inputString.getString(7).trim)).getOrElse(None)
    val tgtPrsnlQuery=Try(Some(inputString.getString(10).trim)).getOrElse(None)
    val prevHistory= Try(inputString.getString(8).trim).getOrElse(throw new Exception("Previous History Target Table is Missing"))
    val currHistory=Try(inputString.getString(9).trim).getOrElse(throw new Exception("Current History Target Table is Missing"))
    val primaryKey=Try(inputString.getString(11).trim).getOrElse(throw new Exception("Primary Key is Missing"))
    val runOption=Try(inputString.getString(12).toLowerCase.trim).getOrElse(throw new Exception("Run Option is Missing"))
    val loadDate=Try(inputString.getString(13).toLowerCase.trim).getOrElse(throw new Exception("Load Date is Missing"))
    val nonComapre=Try(Some(inputString.getString(14).trim)).getOrElse(None)
    val bussEffMapping=Try(Some(inputString.getString(15).trim)).getOrElse(None)
    val bussExpMapping=Try(Some(inputString.getString(16).trim)).getOrElse(None)
    val deltaColumn=Try(Some(inputString.getString(17).trim)).getOrElse(None)
    val aggColumn=Try(Some(inputString.getString(18).trim)).getOrElse(None)
    val zipFile=Try(inputString.getString(19)).getOrElse("no")
    FixedBitempConf(srcConType,srcTableNm,schemaFile,alias,post,header,footer,srcPrsnlQuery,
      tgtPrsnlQuery,aggColumn,zipFile,prevHistory,currHistory,primaryKey,runOption,loadDate
      ,nonComapre,bussEffMapping,bussExpMapping,deltaColumn)
  }

  /** The `FixedBitempConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param srcConType   source Connection Type.
    * @param srcTableNm   source Table Name
    * @param post        Record identifier , if value is specified, then only those records from fixed length file will be extracted.
    * @param alias         Alias.
    * @param srcPrsnlQuery   source Personal SQL Query .
    * @param header      whether header is present or not .
    * @param footer      whether footer is present or not.
    * @param schemaFile    schema file hdfs path for files  .
    * @param tgtPrsnlQuery      target Personal SQL Query .
    * @param aggColumn      comma seperated  list of columns for sum check.
    * @param zipFile     By default "no" , can be made "yes" by user if source is zipped file .
    */
  case class FixedBitempConf(srcConType:String,srcTableNm:String,schemaFile:Option[String],alias:String,post:Option[String],header:String,footer:String,srcPrsnlQuery:Option[String],
                       tgtPrsnlQuery:Option[String],aggColumn:Option[String],zipFile:String,prevHistory:String
                             ,currHistory:String,primaryKey:String,runOption:String,loadDate:String,nonComapre:Option[String],bussEffMapping:Option[String],bussExpMapping:Option[String],deltaColumn:Option[String]) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("srcConType", srcConType)
        .append("srcTableNm", srcTableNm)
        .append("schemaFile", schemaFile)
        .append("post", post)
        .append("header", header)
        .append("footer", footer)
        .append("alias", alias)
        .append("srcPrsnlQuery", srcPrsnlQuery)
        .append("tgtPrsnlQuery", tgtPrsnlQuery)
        .append("aggColumn", aggColumn)
        .append("zipFile", zipFile)
        .append("prevHistory", prevHistory)
        .append("currHistory", currHistory)
        .append("primaryKey", primaryKey)
        .append("runOption", runOption)
        .append("loadDate", loadDate)
        .append("nonComapre", nonComapre)
        .append("bussEffMapping", bussEffMapping)
        .append("bussExpMapping", bussExpMapping)
        .append("deltaColumn", deltaColumn)
        .toString
    }
  }


}
