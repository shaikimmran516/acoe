package com.rxcorp.bdf.sparxta

case class CmdManagerArguments(sparkProps: String = "", runType:String="", environment:String="development", jdbcUrl:String ="", jdbcTgt:String="", sftpUser:String="", sftpPass:String ="", ftpUser:String="", ftpPass:String="",smbUser:String="", smbPass:String="")




