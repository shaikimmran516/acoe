package com.rxcorp.bdf.Utilities.logger


import com.rxcorp.bdf.logging.internal.StandardImsLogger
import com.rxcorp.bdf.logging.log.EventAttribute


class QIMSLogger(imsLogger: StandardImsLogger) extends DSLogger {

  override def logDebug(msg: String): Unit = imsLogger.debug(msg)

  override def logInfo(msg: String): Unit = imsLogger.info(msg)

  override def logWarn(msg: String): Unit = imsLogger.warn(msg)

  override def logWarn(msg: String, exception: Throwable): Unit = imsLogger.warn(msg, exception)

  override def logError(msg: String): Unit = imsLogger.error(msg)

  override def logError(msg: String, exception: Throwable): Unit = imsLogger.error(msg, exception)

  override def addOptions(bag: scala.collection.mutable.Map[EventAttribute, String]): Unit = imsLogger.addOptions(bag)

  override def add(item: (EventAttribute, String)):Unit = imsLogger.add(item)

  override def removeOptions(bag: Set[EventAttribute]): Unit = imsLogger.removeOptions(bag)

  override def remove(item: EventAttribute): Unit = imsLogger.remove(item)

  override def logFatal(msg:String):Unit = imsLogger.fatal(msg)

  override def logFatal(msg: String, exception: Throwable): Unit = imsLogger.fatal(msg,exception)

}