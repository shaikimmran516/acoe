package com.rxcorp.bdf.Utilities.time

/** Created By Apoorv*/
object Time {

  /** The `convertTime` method converts Time in nano seconds to a Time string.
    * @param a input Time
    * @return String converted string
    */

  def convertTime(a: Long): String = {
    val f = new StringBuilder()
    var seconds = a / 1000000000
    val days: Long = seconds / (3600 * 24)
    appendCheck(f,days,"d")
    seconds -= (days * 3600 * 24)
    val hours = seconds / 3600
    appendCheck(f,hours, "h")
    seconds -= (hours * 3600)
    val minutes = seconds / 60
    appendCheck(f,minutes, "m")
    seconds -= (minutes * 60)
    appendCheck(f,seconds, "s")
    println(f.toString())
    f.toString.replaceAll("\\s", "")
  }

  /** The `appendCheck` method append to a string after checking if empty or not
    * @param f Time String builder
    * @param value Time value
    * @return text text to be appended
    */

  def appendCheck(f: StringBuilder, value: Long, text: String) = {
    if (value > 0) {
      if (f.length() > 0) {
        f.append(" ");
      }
      f.append(value).append(text);
    }
  }
}














