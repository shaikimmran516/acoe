package com.rxcorp.bdf.Utilities.files

trait Constants {

  /** The [[databaseName]] constant value equals `databaseName` */
  final val databaseName: String = "databaseName"

  /** The [[table]] constant value equals `table` */
  final val table: String = "table"

  /** The [[connectionURL]] constant value equals `connectionURL` */
  final val connectionURL: String = "connectionURL"

  /** The [[userName]] constant value equals `userName` */
  final val userName: String = "userName"

  /** The [[password]] constant value equals `password` */
  final val password: String = "password"

  /** The [[numConnections]] constant value equals `numConnections` */
  final val numConnections: String = "numConnections"

  /** The [[exasolType]] constant value equals `exasol` */
  final val exasolType: String = "exasol"

  /** The [[hiveType]] constant value equals `hive` */
  final val hiveType: String = "hive"

  /** The [[mysqlType]] constant value equals `mysql` */
  final val mysqlType: String = "mysql"

  /** The [[netezzaType]] constant value equals `netezza` */
  final val netezzaType: String = "netezza"

  /** The [[oracleType]] constant value equals `oracle` */
  final val oracleType: String = "oracle"

  /** The [[sqlserverType]] constant value equals `sqlserver` */
  final val sqlserverType: String = "sqlserver"

  /** The [[teiidType]] constant value equals `teiid` */
  final val teiidType: String = "teiid"

  /** The [[db2Type]] constant value equals `db2` */
  final val db2Type: String = "db2"

  /** The [[impalaType]] constant value equals `impala` */
  final val impalaType: String = "impala"

  /** The [[fixedType]] constant value equals `fixed` */
  final val fixedType: String = "fixed"

  /** The [[fixedFTPType]] constant value equals `fixed_ftp` */
  final val fixedFTPType: String = "fixed_ftp"

  /** The [[fixedSFTPType]] constant value equals `fixed_sftp` */
  final val fixedSFTPType: String = "fixed_sftp"

  /** The [[flatPipeType]] constant value equals `flat_file_pipe` */
  final val flatPipeType: String = "flat_file_pipe"

  /** The [[flatCommaType]] constant value equals `flat_file_comma` */
  final val flatCommaType: String = "flat_file_comma"

  /** The [[flatTildeType]] constant value equals `flat_file_tilde` */
  final val flatTildeType: String = "flat_file_tilde"

  /** The [[flatTabType]] constant value equals `flat_file_tab` */
  final val flatTabType: String = "flat_file_tab"

  /** The [[flatSemiColonType]] constant value equals `flat_file_semicolon` */
  final val flatSemiColonType: String = "flat_file_semicolon"

  /** The [[flatSFTPType]] constant value equals `Sftp` */
  final val flatSFTPType: String = "sftp"

  /** The [[flatFTPType]] constant value equals `Ftp` */
  final val flatFTPType: String = "ftp"

  /** The [[flatSMBType]] constant value equals `smb` */
  final val flatSMBType: String = "smb"

  /** The [[fixedSMBType]] constant value equals `fixed_smb` */
  final val fixedSMBType: String = "fixed_smb"



}
