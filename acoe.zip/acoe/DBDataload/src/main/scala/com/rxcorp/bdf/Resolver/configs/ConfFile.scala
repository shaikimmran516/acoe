package com.rxcorp.bdf.Resolver.configs

import com.typesafe.config.Config
import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}

import scala.util.Try

/** The `ConfFile` object extends [[ConfConstants]] trait.
  *
  * This object offers methods to resolve common config from user's .conf file.
  * Created by Apoorv
  */

object ConfFile extends ConfConstants {

  /** The `getConfig` method returns [[mainConf]] case class instance by resolving the configurations from user's .conf file.
    * @param config The config object from .conf file
    * @return [[mainConf]]
    */

  def getConfig(config: Config):mainConf = {
    val tableListPath: String = Try(config.getString("table_list_path")).getOrElse(throw new Exception("table_list_path is missing"))
    val fixedHDFSpath: String = Try(config.getString("home_hdfs_dir")).getOrElse(throw new Exception("home_hdfs_dir is missing"))
    val mailIds: String = Try(config.getString("toAddress")).getOrElse(throw new Exception("toAddress is missing"))
    val columnCountTest: String =Try(config.getString("column_count").trim).getOrElse("yes")
    val fieldNameTest: String =Try(config.getString("field_name").trim).getOrElse("yes")
    val recordCountTest: String =Try(config.getString("record_count").trim).getOrElse("yes")
    val schemaTest: String =Try(config.getString("schema_check").trim).getOrElse("yes")
    val duplicateTest: String =Try(config.getString("duplicate").trim).getOrElse("yes")
    val dataValidationTest: String =Try(config.getString("data_validation").trim).getOrElse("yes")
    val nullCheckTest: String =Try(config.getString("null_check").trim).getOrElse("yes")
    val sumCheckTest: String =Try(config.getString("sum_check").trim).getOrElse("no")
    val dataMismatchTest: String =Try(config.getString("data_mismatch").trim).getOrElse("no")
    val nullValue: Option[String] =Try(Some(config.getString("nullValue"))).getOrElse(None)
    val emptyValue: Option[String] =Try(Some(config.getString("emptyValue"))).getOrElse(None)
    val sortSource: Option[String] =Try(Some(config.getString("sorting"))).getOrElse(None)
    mainConf(tableListPath,fixedHDFSpath,mailIds,columnCountTest,fieldNameTest,recordCountTest,schemaTest,duplicateTest,dataValidationTest,nullCheckTest,sumCheckTest,nullValue,emptyValue,sortSource,dataMismatchTest)
  }

  /** The `mainConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param tableListPath   The path location of table_list.csv file .
    * @param fixedHDFSpath   The temporary hdfs fixed path where all files will be saved .
    * @param mailIds         Semi-colon seperated list of mail-IDs.
    * @param columnCountTest    By default "yes" , can be made "no" by user .
    * @param fieldNameTest      By default "yes" , can be made "no" by user .
    * @param recordCountTest    By default "yes" , can be made "no" by user .
    * @param schemaTest         By default "yes" , can be made "no" by user .
    * @param duplicateTest      By default "yes" , can be made "no" by user .
    * @param dataValidationTest By default "yes" , can be made "no" by user .
    * @param nullCheckTest      By default "yes" , can be made "no" by user .
    * @param sumCheckTest     By default "no" , can be made "yes" by user .
    * @param nullValue        Replacing null value with specified value.
    * @param emptyValue      Replacing empty values with null if "yes". By default "no".
    * @param sortSource       If user wants to select the source dataframe columns in target order.By default "no".
    * @param dataMismatchTest  By default "no" , can be made "yes" by user .
    */
  case class mainConf(tableListPath:String,fixedHDFSpath:String,mailIds:String,columnCountTest:String,fieldNameTest:String,recordCountTest:String,schemaTest:String,
                      duplicateTest:String,dataValidationTest:String,nullCheckTest:String,sumCheckTest:String,nullValue:Option[String],emptyValue:Option[String],sortSource:Option[String],dataMismatchTest:String) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("tableListFilePath", tableListPath)
        .append("fixedHdfsPath", fixedHDFSpath)
        .append("mailIDs",mailIds)
        .append("columnCountTest", columnCountTest)
        .append("fieldNameTest", fieldNameTest)
        .append("recordCountTest", recordCountTest)
        .append("schemaTest", schemaTest)
        .append("duplicateTest", duplicateTest)
        .append("dataValidationTest", dataValidationTest)
        .append("nullCheckTest", nullCheckTest)
        .append("sumCheckTest", sumCheckTest)
        .append("nullValue", nullValue)
        .append("emptyValue", mailIds)
        .append("sortSource", sortSource)
        .append("dataMismatch",dataMismatchTest)
        .toString
    }
  }
}
