package com.rxcorp.bdf.Utilities.unzip

import java.io.{BufferedReader, InputStreamReader}
import java.util.zip.ZipInputStream

import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.input.PortableDataStream
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Unzip {

  /** The `Unzip` method unzips a zipped source file.
    * @param sparkSession Spark session instance
    * @param zipFile zip file path
    * @return string Temp location of unzipped file
    */

  def unzip(sparkSession: SparkSession, zipFile: String): String = {
    val inExt: String = ".zip"
    //require(zipFile.trim.toLowerCase.endsWith(inExt), ".zip file not found")
    val inputEncoding: String = System.getProperty("input.file.encoding", "UTF-8")
    val fs: FileSystem = FileSystem.get(sparkSession.sparkContext.hadoopConfiguration)
    val zipPath: Path = new Path(zipFile)
    val outPath: String = zipPath.toString.replace(inExt, "")
    fs.delete(new Path(outPath), true)
    val srcRDD: RDD[String] = sparkSession.sparkContext.binaryFiles(zipPath.toString, sparkSession.sparkContext.defaultMinPartitions)
      .flatMap{ case (filePath: String, content: PortableDataStream) =>
        val zis: ZipInputStream = new ZipInputStream(content.open)
        Stream.continually(zis.getNextEntry)
          .takeWhile(_ != null)
          .flatMap { x =>
            val br: BufferedReader = new BufferedReader(new InputStreamReader(zis, inputEncoding))
            Stream.continually(br.readLine()).takeWhile(_ != null)
          }
      }
    srcRDD.saveAsTextFile(outPath)
    fs.deleteOnExit(new Path(outPath))
    outPath
  }


}
