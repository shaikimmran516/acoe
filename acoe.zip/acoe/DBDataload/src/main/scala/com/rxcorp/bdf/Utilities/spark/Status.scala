package com.rxcorp.bdf.Utilities.spark

/** The `Status` object offers constants for the Status value of a job. */
object Status {

  /** The [[LOST]] variable holds the value `LOST`. */
  final val LOST: String = "LOST"

  /** The [[PENDING]] variable holds the value `PENDING`. */
  final val PENDING: String = "PENDING"

  /** The [[QUEUED]] variable holds the value `QUEUED`. */
  final val QUEUED: String = "QUEUED"

  /** The [[RUNNING]] variable holds the value `RUNNING`. */
  final val RUNNING: String = "RUNNING"

  /** The [[FINISHED]] variable holds the value `FINISHED`. */
  final val FINISHED: String = "FINISHED"

  /** The [[FAILED]] variable holds the value `FAILED`. */
  final val FAILED: String = "FAILED"

  /** The [[KILLED]] variable holds the value `KILLED`. */
  final val KILLED: String = "KILLED"
}
