package com.rxcorp.bdf.Utilities.Db

import java.util.Properties

import com.rxcorp.bdf.Utilities.files.Constants
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.jdbc.JdbcDialects
import org.apache.spark.sql.SparkSession
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.sparkSession
import com.rxcorp.bdf.Utilities.utils.Utils.getQueryFromFile


/** The `DBConnection` object offers the methods to make jdbc Database connection
  * Created By Apoorv
  */

object DBConnection extends Constants {


  /** The `readData` method reads from user provided RDBMS table name via JDBC on Spark and returns a Spark DataFrame.
    * @param sparkSession The current Spark session started by the hadoop user from Spark job running in the cluster
    * @param jdbcUrl Jdbc utl for connection to database
    * @param dbSystem Database System name to connect
    * @param splitByCol Partition Key column
    * @param tableNm Query or tableName for loading
    * @return Spark DataFrame
    * @throws Exception Spark library exceptions.
    */
  def readData(sparkSession:SparkSession,jdbcUrl :String,dbSystem:String,splitByCol:String,tableNm:String): DataFrame ={
    registerDialect(dbSystem)
    val driverCls= getClassName(dbSystem)
    val df = if (!(splitByCol.isEmpty)) {
      tableConnection(sparkSession,jdbcUrl, tableNm, driverCls, dbSystem, Some(splitByCol))
    } else tableConnection(sparkSession,jdbcUrl, tableNm, driverCls, dbSystem)
    df
  }

  /** The `getClassName` method returns the JDBC Driver ClassName for given Database Type.
    * @param dbType The database type typically (srcFormat from .job file when srcType is database), namely oracle / netezza ..
    * @return JDBC Driver Class Name
    * @throws Exception Unsupported Database Type
    */
  def getClassName(dbType: String): String = {
    dbType match {
      case `exasolType` => "com.exasol.jdbc.EXADriver"
      //      case `mysqlType` => ""
      case `netezzaType` => "org.netezza.Driver"
      case `oracleType` => "oracle.jdbc.driver.OracleDriver"
      case `sqlserverType` => "com.microsoft.sqlserver.jdbc.SQLServerDriver"
      case `teiidType` => "org.teiid.jdbc.TeiidDriver"
      case `db2Type` => "com.ibm.db2.jcc.DB2Driver"
      case `impalaType`=> "com.cloudera.impala.jdbc41.Driver"
      case _ =>
        throw new Exception("Unsupported Database Type")
    }
  }
  /** The `registerDialect` method registers the JDBC Dialect for Spark for better readability of RDBMS table data
    * into Spark Dataframe based on proper mappings between he RDBMS datatype and Spark sql compatible type.
    * @param dbType The database type typically (srcFormat from .job file when srcType is database), namely oracle / netezza ..
    * @throws Exception Unsupported Database Type
    */

  def registerDialect(dbType: String): Unit = {
    dbType match {
      case `exasolType` => JdbcDialects.registerDialect(com.rxcorp.bdf.Utilities.jdbcDialects.exasol.Dialect)
      //      case `mysqlType` => ""
      case `netezzaType` =>
        JdbcDialects.registerDialect(com.rxcorp.bdf.Utilities.jdbcDialects.netezza.Dialect)
      case `oracleType` =>
        //JdbcDialects.unregisterDialect(JdbcDialects.get(url))
        JdbcDialects.registerDialect(com.rxcorp.bdf.Utilities.jdbcDialects.oracle.Dialect)
      case `sqlserverType` =>
        println("no dialect for sqlserver")
        //logger.info(this.getClass, s"No explicit dialect required for $sqlserverType!")
      case `teiidType` =>
        JdbcDialects.registerDialect(com.rxcorp.bdf.Utilities.jdbcDialects.teiid.Dialect)
      case `db2Type` =>
        println("no dialect for db2")
        //logger.info(this.getClass, s"No explicit dialect required for $db2Type!")
      case `impalaType` =>
        println("no dialect for impala")
       // logger.error(this.getClass, "Unsupported Database Type")
      case _ =>
        throw new Exception("Unsupported Database Type")
    }
  }

  /** The `tableConnection` method makes connection with the database if splitColumn is provided
    * @param jdbcURL jdbc URL to connect to database
    * @param tableNm Query or database.table to be
    * @param driverCls Driver class name for the database
    * @param srcTableSystem Database system type
    * @param splitCol partitioned column for loading data in parallel
    */

  def tableConnection(sparkSess:SparkSession,jdbcURL: String, tableNm: String, driverCls: String, srcTableSystem:String, splitCol:Option[String]=None): DataFrame = {
    val tableName=if(!(tableNm==null)){if(tableNm.endsWith(".query")){getQueryFromFile(sparkSess,tableNm)} else {tableNm}} else {tableNm}
    val connectionProperties = new Properties()
    connectionProperties.setProperty("Driver", driverCls)
    connectionProperties.put("fetchsize", 100000.toString)
    val df =if (splitCol.isEmpty){
       sparkSession.read.jdbc(url = jdbcURL, table = tableName, properties = connectionProperties)
    }else{
     sparkSession.read.jdbc(url = jdbcURL, table = tableName ,splitCol.get,0,5,5, connectionProperties)
    }
    df
  }

  def generateCountQuery(tableNM:String,dbType: String,where:String): String = {
    val query = dbType match {
      case `exasolType` | `oracleType` =>
        if (!(where.isEmpty)) s"(SELECT COUNT(*) cnt from $tableNM where $where) A" else s"(SELECT COUNT(*) cnt from $tableNM) A"
      case `netezzaType` | `sqlserverType` |`teiidType` | `db2Type` | `impalaType` =>
        if (!(where.isEmpty)) s"(SELECT COUNT(*) as cnt from $tableNM where $where) as A" else s"(SELECT COUNT(*) as cnt from $tableNM) as A"
      case `hiveType` =>
       val a= if (!(where.isEmpty)) { s"SELECT COUNT(*) as cnt from $tableNM where $where"} else {s"SELECT COUNT(*) as cnt from $tableNM"}
          print(a)
        a
      case _ =>
        throw new Exception("Unsupported Database Type")
    }
    query
  }

  def countToIntResolver(dbType: String,count:DataFrame): Int={
    dbType match {
      case `exasolType` => count.first.getDecimal(0).intValue()
      case `netezzaType` => count.first.toString().toInt
      case `oracleType` => count.first.getDecimal(0).intValue()
      case `sqlserverType` => count.first.getInt(0)
      case `teiidType` => count.first.getDecimal(0).intValue()
      case `db2Type` => count.first.getDecimal(0).intValue()
      case `impalaType`=> count.first.getDecimal(0).intValue()
      case `hiveType` => count.first.getLong(0).toInt
      case _ =>
        throw new Exception("Unsupported Database Type")
    }
  }

  def generateDataQuery(tableNM:String,dbType: String,where:String,primaryKey:String): String = {
    val query = if(primaryKey.isEmpty){dbType match {
      case `exasolType` => if(!(where.isEmpty)) s"(SELECT * from $tableNM where $where limit 200) A" else s"(SELECT * from $tableNM limit 200) A"
      case `oracleType` =>
        if (!(where.isEmpty)) s"(SELECT * from $tableNM where rownum <=200 and $where) A" else s"(SELECT * from $tableNM where rownum <=200) A"
      case `netezzaType` | `sqlserverType` |`teiidType` | `db2Type` | `impalaType` =>
        if (!(where.isEmpty)) s"(SELECT * from $tableNM where $where limit 200) as A" else s"(SELECT * from $tableNM limit 200) as A"
      case `hiveType` =>
        if (!(where.isEmpty)) s"SELECT * from $tableNM where $where" else s"SELECT * from $tableNM"
      case _ =>
        throw new Exception("Unsupported Database Type")
    }}else{dbType match {
      case `exasolType` => if (!(where.isEmpty)) s"(SELECT $primaryKey from $tableNM where $where) A" else s"(SELECT $primaryKey from $tableNM) A"
      case `oracleType` =>
        if (!(where.isEmpty)) s"(SELECT $primaryKey from $tableNM where $where) A" else s"(SELECT $primaryKey from $tableNM) A"
      case `netezzaType` | `sqlserverType` |`teiidType` | `db2Type` | `impalaType` =>
        if (!(where.isEmpty)) s"(SELECT $primaryKey from $tableNM where $where) as A" else s"(SELECT $primaryKey from $tableNM) as A"
      case `hiveType` =>
        if (!(where.isEmpty)) s"SELECT $primaryKey from $tableNM where $where" else s"SELECT $primaryKey from $tableNM"
      case _ =>
        throw new Exception("Unsupported Database Type")

    }}
    query
  }

}
