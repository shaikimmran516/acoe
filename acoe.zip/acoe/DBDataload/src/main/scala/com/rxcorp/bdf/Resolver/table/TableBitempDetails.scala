package com.rxcorp.bdf.Resolver.table

import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}
import org.apache.spark.sql.Row

import scala.util.Try
/** Created By Apoorv*/
object TableBitempDetails extends TableBitempConstants {


  /** The `getTableDetails` method returns [[TableBitempConf]] case class instance by resolving the tables/delmited files from .csv file
    * @param inputString Row contains values from .csv file
    * @return [[TableBitempConf]]
    */

  def getTableBitempDetails(inputString: Row):TableBitempConf = {
    val srcConType= Try(inputString.getString(0).trim).getOrElse(throw new Exception("Connection Type Missing"))
    val srcTableNm= Try(inputString.getString(1).trim).getOrElse(throw new Exception("Source Table Missing"))
    val alias=Try(inputString.getString(2).trim).getOrElse(throw new Exception("Alias is Missing"))
    val srcPrsnlQuery=Try(Some(inputString.getString(3).trim)).getOrElse(None)
    val header=Try(inputString.getString(4).trim.toLowerCase).getOrElse("yes")
    val schemaFile=Try(Some(inputString.getString(5).trim)).getOrElse(None)
    val prevHistory= Try(inputString.getString(6).trim).getOrElse(throw new Exception("Previous History Target Table is Missing"))
    val currHistory=Try(inputString.getString(7).trim).getOrElse(throw new Exception("Current History Target Table is Missing"))
    val tgtPrsnlQuery=Try(Some(inputString.getString(8).trim)).getOrElse(None)
    val primaryKey=Try(inputString.getString(9).trim).getOrElse(throw new Exception("Primary Key is Missing"))
    val runOption=Try(inputString.getString(10).toLowerCase.trim).getOrElse(throw new Exception("Run Option is Missing"))
    val loadDate=Try(inputString.getString(11).toLowerCase.trim).getOrElse(throw new Exception("Load Date is Missing"))
    val nonComapre=Try(Some(inputString.getString(12).trim)).getOrElse(None)
    val bussEffMapping=Try(Some(inputString.getString(13).trim)).getOrElse(None)
    val bussExpMapping=Try(Some(inputString.getString(14).trim)).getOrElse(None)
    val deltaColumn=Try(Some(inputString.getString(15).trim)).getOrElse(None)
    val splitColumn=Try(Some(inputString.getString(16).trim)).getOrElse(None)
    val aggColumn=Try(Some(inputString.getString(17).trim)).getOrElse(None)
    val useTargetSchema=Try(inputString.getString(18)).getOrElse("no")
    val zipFile=Try(inputString.getString(19)).getOrElse("no")
    TableBitempConf(srcConType,srcTableNm,alias,srcPrsnlQuery,header,schemaFile,
      tgtPrsnlQuery,splitColumn,aggColumn,useTargetSchema,zipFile,prevHistory,currHistory,primaryKey,runOption,loadDate
    ,nonComapre,bussEffMapping,bussExpMapping,deltaColumn)
  }


  /** The `TableBitempConf` case class offers access to the values held in the parameters for an instance.
    *
    * @param srcConType   source Connection Type.
    * @param srcTableNm   source Table Name .
    * @param alias         Alias.
    * @param srcPrsnlQuery   source Personal SQL Query .
    * @param header      whether header is present or not .
    * @param schemaFile    schema file hdfs path for files  .
    * @param tgtPrsnlQuery      target Personal SQL Query .
    * @param splitColumn  Partion column for parallel loading of table.
    * @param useTargetSchema defaultt"no" can be made "yes" by user if source table has differnt schema than target.
    * @param aggColumn      comma seperated  list of columns for sum check.
    * @param zipFile     By default "no" , can be made "yes" by user if source is zipped file .
    * @param prevHistory   previous history table.
    * @param currHistory      current history table.
    * @param primaryKey    comma seperated primary keys  .
    * @param runOption      run option .
    * @param loadDate  data load timestamp.
    * @param nonComapre comma separated list of non comparison columns.
    * @param bussEffMapping     column mapped to business effective date.
    * @param bussExpMapping     column mapped to business Expiry date.
    * @param deltaColumn column mapped to delta operation.
    */
  case class TableBitempConf(srcConType:String,srcTableNm:String,alias:String,srcPrsnlQuery:Option[String],header:String,schemaFile:Option[String],
                       tgtPrsnlQuery:Option[String],splitColumn:Option[String],aggColumn:Option[String],useTargetSchema:String,zipFile:String,prevHistory:String
                        ,currHistory:String,primaryKey:String,runOption:String,loadDate:String,nonComapre:Option[String],bussEffMapping:Option[String],bussExpMapping:Option[String],deltaColumn:Option[String]) {
    override def toString: String = {
      new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
        .append("srcConType", srcConType)
        .append("srcTableNm", srcTableNm)
        .append("alias", alias)
        .append("srcPrsnlQuery", srcPrsnlQuery)
        .append("header", header)
        .append("schemaFile", schemaFile)
        .append("tgtPrsnlQuery", tgtPrsnlQuery)
        .append("splitColumn", splitColumn)
        .append("aggColumn", aggColumn)
        .append("useTargetSchema", useTargetSchema)
        .append("prevHistory", prevHistory)
        .append("currHistory", currHistory)
        .append("primaryKey", primaryKey)
        .append("runOption", runOption)
        .append("loadDate", loadDate)
        .append("nonComapre", nonComapre)
        .append("bussEffMapping", bussEffMapping)
        .append("bussExpMapping", bussExpMapping)
        .append("deltaColumn", deltaColumn)

        .toString
    }
  }

}
