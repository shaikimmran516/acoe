package com.rxcorp.bdf.Utilities.spark

import java.util.concurrent.CountDownLatch

import com.rxcorp.bdf.Utilities.logger.{QIMSLogger, QIMSLoggerFactory}
import com.rxcorp.bdf.Utilities.spark.AppResolver.HadoopConfig
import com.rxcorp.bdf.sparxta.SparkResolver
import org.apache.spark.launcher.{SparkAppHandle, SparkLauncher}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.xml.{Elem, NodeSeq, XML}

object SparkLaunch {
  /** The [[rmUrl]] variable holds the YARN Resource Manager URL retrieved form yarn-site.xml */

  lazy val rmUrl: String = getRMURL(hadoopConfig.yarnSiteXML)
  /** The [[logger]] variable is an instance of the customized BDF logger for the application */
  val logger: QIMSLogger = QIMSLoggerFactory.getLogger.get
  /** The [[hadoopConfig]] variable holds the HadoopConfig created by parsing the application config from resources */

  val hadoopConfig: HadoopConfig = AppResolver.readFromConfigFile.hadoopConfig
  /** The [[sparkJar]] variable holds the absolute path to the Spark application jar file */

  var sparkJar: String = ""
  var returnStatus: String = ""


  /** The `invokeSparkJob` method submits the Spark job for the received execution
    * @param sparkResolve sparkResolve contains mandatory spark job properties
    * @param sparkProps contains list of configurable spark properties
    * @return Spark Job Status FINISHED / FAILED based on the exit code for the submitted job
    */
  def invokeSparkJob(sparkResolve: SparkResolver.sparkConf, sparkProps:List[String]): String = {
    sparkJar = sparkResolve.path
    require(sparkJar.nonEmpty, "sparkJar location is required to submit spark job!")

    val distFiles: ArrayBuffer[String] = new ArrayBuffer[String]()
    distFiles += (hadoopConfig.hiveSiteXML,hadoopConfig.yarnSiteXML)


    val appName: String = s"Sparxta_${sparkResolve.countryName}_${sparkResolve.asset}"

    val countDownLatch: CountDownLatch = new CountDownLatch(1)
    def sparkAppListener: SparkAppHandle.Listener = new SparkAppHandle.Listener() {
      override def infoChanged(handle: SparkAppHandle): Unit = {
        val sparkAppId: String = handle.getAppId
        val appState: SparkAppHandle.State = handle.getState
        //        val yarnState: String = Try(getAppStatusFromYarn(handle, sparkAppId)).getOrElse(null)
       logger.info(this.getClass, s"INFO CHANGED: spark app state -- $appState"/*, yarn app state -- $yarnState"*/)
      }
      override def stateChanged(handle: SparkAppHandle): Unit = {
        val sparkAppId: String = handle.getAppId
        val appState: SparkAppHandle.State = handle.getState
        //        val yarnState: String = Try(getAppStatusFromYarn(handle, sparkAppId)).getOrElse(null)
        logger.info(this.getClass, s"STATE CHANGED: spark app state -- $appState"/*, yarn app state -- $yarnState"*/)
        if (appState != null) {
          logger.info(this.getClass, s"Spark job with app id: $sparkAppId, State changed to: spark app state -- $appState"/*, yarn app state -- $yarnState"*/)
        }else {
         logger.info(this.getClass, s"Spark job's state changed to: $appState"/*, yarn app state changed to: $yarnState"*/)
        }
        if (appState != null && appState.isFinal) {
          returnStatus = appState match {
            case SparkAppHandle.State.FINISHED => Status.FINISHED
            case SparkAppHandle.State.FAILED => Status.FAILED
            case SparkAppHandle.State.KILLED => Status.KILLED
            case _ => Status.LOST
          }
          logger.info(this.getClass, s"Spark job with app id: $sparkAppId $returnStatus!")
          countDownLatch.countDown()
        }
      }
    }

    var sparkAppHandle: SparkAppHandle = null
    try {
      val launcher = new SparkLauncher()
        .setSparkHome(hadoopConfig.sparkHome)
        .setAppResource(sparkJar)
        .setConf("spark.yarn.queue", sparkResolve.queue)
        .setConf("spark.yarn.keytab", sparkResolve.keytab)
        .setConf("spark.yarn.principal", sparkResolve.principal)
        .setMainClass("com.rxcorp.bdf.SparxtaDriver")
        .setMaster(hadoopConfig.sparkMaster)
        .setDeployMode(sparkResolve.deployMode)
        //.addJar(utilsJar)
        .setConf("spark.yarn.maxAppAttempts", "2")
        .setConf("spark.port.maxRetries", "64")
       .setConf(SparkLauncher.CHILD_PROCESS_LOGGER_NAME, "automationtestinglogger") // org.apache.spark.launcher.app.qlssparklogger
        .addSparkArg("--files", s"${distFiles.mkString(",")}")
        .addAppArgs("--configFile",sparkResolve.configFile.replaceAll("\"",""))
        .addAppArgs("--runType", sparkResolve.runType)
        .setVerbose(false)

      if (sparkResolve.jdbcUrl.nonEmpty){
        launcher.addAppArgs("--jdbcUrl", sparkResolve.jdbcUrl.get)
      }

      if (sparkResolve.jdbcTgt.nonEmpty){
        launcher.addAppArgs("--jdbcTgt", sparkResolve.jdbcTgt.get)
      }
      if (sparkResolve.sftpUser.nonEmpty){
        launcher.addAppArgs("--sftpUser", sparkResolve.sftpUser.get)
        launcher.addAppArgs("--sftpPass",sparkResolve.sftpPass.get)
      }

      if (sparkResolve.ftpUser.nonEmpty){
        launcher.addAppArgs("--ftpUser", sparkResolve.ftpUser.get)
        launcher.addAppArgs("--ftpPass",sparkResolve.ftpPass.get)
      }

      if (sparkResolve.smbUser.nonEmpty){
        launcher.addAppArgs("--smbUser", sparkResolve.smbUser.get)
        launcher.addAppArgs("--smbPass",sparkResolve.smbPass.get)
      }

      for(conf <- sparkProps){
        if(conf.nonEmpty && conf.trim.split("=", 2).length.equals(2)){
          if(conf.trim.contains(".")) {
            launcher.addSparkArg("--conf", conf.trim)
          }else {
            logger.fatal(this.getClass, s"Please check with ${conf.trim} spark property!")
          }
        }
      }


      if(sparkResolve.environment.nonEmpty) launcher.addAppArgs("--environment", sparkResolve.environment)
      if(sparkResolve.asset.nonEmpty) launcher.addAppArgs("--asset", sparkResolve.asset)
      if(sparkResolve.countryName.nonEmpty) launcher.addAppArgs("--country", sparkResolve.countryName)
      if(sparkResolve.tenant.nonEmpty) launcher.addAppArgs("--tenant", sparkResolve.tenant)


      launcher.setAppName(appName)
      logger.info(this.getClass, "Launching spark application")
      sparkAppHandle = launcher.startApplication(sparkAppListener)
      val sparkAppListenerThread: Thread = new Thread {
        override def run() {
          sparkAppListener
        }
      }
      sparkAppListenerThread.start()
      countDownLatch.await()
      returnStatus
    } catch {
      case ex: Throwable =>
        logger.warn(this.getClass, ex.getMessage, ex)
        Status.FAILED
    } finally {
      try{
        sparkAppHandle.stop()
        sparkAppHandle.disconnect()
      }catch {
        case ex: Throwable =>
         logger.warn(this.getClass, ex.getMessage, ex)
      }
    }
  }


  private def getRMURL(siteXML: String): String = {
    val xmlContent: Elem = XML.loadFile(siteXML)
    val properties: NodeSeq = xmlContent \\ "configuration" \\ "property"
    val propsMap: mutable.LinkedHashMap[String, String] = new mutable.LinkedHashMap[String, String]()
    for(props <- properties){
      val key: String = (props \\ "name").text
      val value: String = (props \\ "value").text
      propsMap += (key -> value)
    }
    val rmId: String = propsMap("yarn.resourcemanager.ha.rm-ids").split(",").head
    propsMap(s"yarn.resourcemanager.webapp.https.address.$rmId")
  }

}
