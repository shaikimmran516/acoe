package com.rxcorp.bdf.Utilities.remote

import com.rxcorp.bdf.Resolver.configs.{ConfFile, Resolver, SFTPConfig}
import com.rxcorp.bdf.Utilities.files.Utils._
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.{hiveContext, sparkSession}
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, SparkSession}

/**Created by Apoorv*/
object Sftp {
  /** The `sftpConnect` method makes Ftp connection and returns a dataframe for .csv files
    * @param sparkSession The current Spark session started by the hadoop user from Spark job running in the cluster
    * @param resolver table details from csv file
    * @param sftpCon Sftp configs
    * @param tableNm source file name/path
    * @return dataframe
    */
def sftpConnect(sparkSession:SparkSession,sftpCon: SFTPConfig.SFTPConf,tableNm:String,resolver: Resolver.resolveConf):DataFrame ={
  val df = if (resolver.header=="no") {
    val schemaFilePath: String = resolver.schemaFile.get
    val structType = Option(parseSchemaFile(sparkSession.sparkContext.hadoopConfiguration, schemaFilePath)._1)
    val schemaList = Option(parseSchemaFile(sparkSession.sparkContext.hadoopConfiguration, schemaFilePath)._2)
    val df1= hiveContext.read.format("com.springml.spark.sftp").option("host", sftpCon.sftpHost).option("username", sftpCon.sftpUser.get).option("password", sftpCon.sftpPassword.get).option("delimiter", sftpCon.sftpDelimiter).option("header", sftpCon.sftpHeader).option("codec", "zip").
      schema(structType.get).option("fileType", sftpCon.sftpFileType).option("inferSchema", "false").load(sftpCon.sftpFilePath + "/" + tableNm)

    df1
  }
  else
  {
   val df1= hiveContext.read.format("com.springml.spark.sftp").option("host", sftpCon.sftpHost).option("username", sftpCon.sftpUser.get).option("password", sftpCon.sftpPassword.get).option("delimiter", sftpCon.sftpDelimiter).option("header", sftpCon.sftpHeader).option("codec", "zip").option("fileType", sftpCon.sftpFileType).option("inferSchema", "false").
      load(sftpCon.sftpFilePath + "/" + tableNm)

    df1
  }

  df
}

  /** The `sftpFixedConnect` method makes Ftp connection and returns a dataframe for .csv files
    * @param sparkSession The current Spark session started by the hadoop user from Spark job running in the cluster
    * @param resolver table details from csv file
    * @param sftpCon Sftp configs
    * @param config object of .conf file details
    * @return dataframe
    */
  def sftpFixedConnect(sparkSession:SparkSession, sftpCon: SFTPConfig.SFTPConf, resolver: Resolver.resolveConf, config: Config,tableNM:String) = {
    val confF = ConfFile.getConfig(config)
    val tb = hiveContext.read.format("com.springml.spark.sftp")
    tb.option("host", sftpCon.sftpHost)
    tb.option("username", sftpCon.sftpUser.get)
    tb.option("password", sftpCon.sftpPassword.get)
    tb.option("header", sftpCon.sftpHeader)
    tb.option("fileType", sftpCon.sftpFileType)
    tb.option("inferSchema", "false")
    tb.option("hdfsTempLocation", s"${confF.fixedHDFSpath}/${resolver.alias}/fixed/Sftp/")
    tb.load(sftpCon.sftpFilePath + "/" + tableNM)
  }



}

