package com.rxcorp.bdf.Utilities.testCases

import com.rxcorp.bdf.Utilities.utils.Utils._
import com.aventstack.extentreports.{ExtentReports, ExtentTest}
import com.aventstack.extentreports.reporter.ExtentHtmlReporter
import com.rxcorp.bdf.Resolver.configs.ConfFile
import com.rxcorp.bdf.Resolver.configs.Resolver.resolve
import com.rxcorp.bdf.Utilities.spark.SparkEnvironment.sparkSession
import com.typesafe.config.Config
import org.scalatest.FunSuite
import TestCases.{columnCountTest, dataDebugTest, dataValidationTest, duplicateTest, fieldNameTest, getInfo, getSampleData, nullCheckTest, recordCountTest, schemaTest, sumCheckTest}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SaveMode}

class TestMain extends FunSuite{

  var configFileName: String = ""
  var aggCols: List[String] =List[String]()
  var eachRow=Row()
  var runType=0
  var env=""
  var asset=""
  var country=""
  var tenant=""
  def param(confFilePath: String, inputRow:Row, aggColumns:List[String],runTp:Int,environment:String,asst:String,con:String,ten:String): Unit = {
    eachRow=inputRow
    configFileName = confFilePath
    aggCols = aggColumns
    runType= runTp
    env=environment
    asset=asst
    country=con
    tenant=ten
  }

  test("HDFS Data frame comparison") {

    val config: Config = readConfFile(configFileName)
    val conf: ConfFile.mainConf = ConfFile.getConfig(config)
    val confFileName = configFileName.split("\\/").toList.takeRight(1).head.split("\\.").toList.take(1).head
    val csvArray = getCsvArray(eachRow,runType)
    val values = resolve(csvArray)
    val htmlReporter = new ExtentHtmlReporter( s"${confFileName}_comparison.html")
    val extent = new ExtentReports
    htmlReporter.setAppendExisting(true)
    extent.attachReporter(htmlReporter)
    var sourceDataframe = sparkSession.read.option("ignoreLeadingWhiteSpace", false).option("ignoreTrailingWhiteSpace", false).parquet(config.getString("home_hdfs_dir") + s"/${values.alias}/src/*")
    sourceDataframe = if (!(conf.nullValue.isEmpty)) {replaceNulls(sourceDataframe,conf.nullValue.get)} else sourceDataframe
    sourceDataframe =  if(!(conf.emptyValue.isEmpty)){nullifyEmptyStrings(sourceDataframe)}else sourceDataframe
    println(s"${values.alias} -Source schema structure")
    sourceDataframe.printSchema()
    println(s"${values.alias} - Source data loading validation successful.")
    val targetDataframe = sparkSession.read.option("ignoreLeadingWhiteSpace", false).option("ignoreTrailingWhiteSpace", false).parquet(config.getString("home_hdfs_dir") + s"/${values.alias}/tgt/*")
    println(s"${values.alias} -Target schema structure")
    targetDataframe.printSchema()
    println(s"${values.alias} - Target data loading validation successful.")

    if ( conf.sortSource == "yes") sourceDataframe=selectInTargetOrder(sourceDataframe,targetDataframe)
    val parentTest: ExtentTest = extent.createTest(s"${values.alias} - Validation", "Validating Source and Target Table")
    println("validating table fields")
    var infoDF: Dataset[Row] = getInfo(parentTest,values,conf,env,asset,country,tenant)
    infoDF = if(conf.columnCountTest=="yes" || conf.columnCountTest == "" || conf.columnCountTest == null) columnCountTest(parentTest,sourceDataframe.columns.length,targetDataframe.columns.length,values,infoDF) else infoDF
    infoDF = if(conf.fieldNameTest=="yes" || conf.fieldNameTest == "" || conf.fieldNameTest == null) fieldNameTest(parentTest,sourceDataframe.schema.fieldNames.map(_.toLowerCase).deep,targetDataframe.schema.fieldNames.map(_.toLowerCase).deep,values,infoDF) else infoDF
    val srcCount = sourceDataframe.count
    val tgtCount = targetDataframe.count
    infoDF = if(conf.recordCountTest=="yes" || conf.recordCountTest == "" || conf.recordCountTest == null) recordCountTest(parentTest,srcCount,tgtCount,values,infoDF) else infoDF
    infoDF = if(conf.schemaTest=="yes" || conf.schemaTest == "" || conf.schemaTest == null) schemaTest(parentTest,sourceDataframe,targetDataframe,values,infoDF) else infoDF
    infoDF = if(conf.duplicateTest=="yes" || conf.duplicateTest == "" || conf.duplicateTest == null) {
      val dupSrcCount = sourceDataframe.distinct().count()
      val duptgtCount = targetDataframe.distinct().count()
      duplicateTest(parentTest,sourceDataframe,targetDataframe,dupSrcCount,duptgtCount,srcCount,tgtCount,values,infoDF)
    }else infoDF
    getSampleData(parentTest,sourceDataframe,targetDataframe)
    infoDF = if(conf.dataValidationTest=="yes" || conf.dataValidationTest == "" || conf.dataValidationTest == null) dataValidationTest(parentTest,sourceDataframe,targetDataframe,values,conf,infoDF) else infoDF
    infoDF = if(conf.sumCheckTest=="yes" || conf.sumCheckTest == "" || conf.sumCheckTest == null) sumCheckTest(parentTest,sourceDataframe,targetDataframe,values,aggCols,infoDF) else infoDF
    infoDF = if(conf.nullCheckTest =="yes" || conf.nullCheckTest == "" || conf.nullCheckTest == null) nullCheckTest(parentTest,sourceDataframe,targetDataframe,srcCount,tgtCount,values,infoDF) else infoDF
    if(conf.dataMismatchTest=="yes" || conf.nullCheckTest == "" || conf.nullCheckTest == null)dataDebugTest(parentTest,sourceDataframe,targetDataframe,values,conf)
    extent.flush()
    extent.flush()
    infoDF.coalesce(1).write.mode(SaveMode.Append).option("delimiter", ",").option("header","true").csv(s"${conf.fixedHDFSpath}/${env}${asset}${tenant}${country}/info/")
  }

}

