package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession

import org.apache.spark.sql.SparkSession
import java.io.File
import org.apache.spark.sql.DataFrame
import com.anthem.hca.ndw.utils.PCADX_SCL_TA_Utilities._
import java.text.SimpleDateFormat
import org.apache.spark.sql.SaveMode
import java.util.Calendar
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel
import java.util.Date
import java.text.SimpleDateFormat



object PCADX_SCL_TA_L2_Member_TGT {



def main(args: Array[String]) {



val dbname: String = args(0)
val SUBJ_AREA_NM: String=args(1)
val PRCS_NM: String=args(2)


val appName = "Datapipe from L2 cases for Member" // we will make this generic going forward

val warehouseLocation = new File("/user/hive/warehouse").getAbsolutePath
val options = Map("path" -> "/user/hive/warehouse")

val spark = SparkSession
.builder()
.appName(appName)
.config("spark.sql.warehouse.dir", warehouseLocation)
.enableHiveSupport()
.getOrCreate()

spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode","INFER_ONLY")
spark.conf.set("spark.sql.crossJoin.enabled","true")

import spark.implicits._
val home_plan_id =spark.sql("select distinct bhi_home_plan_id from "+dbname+"_pcandw1ph_nogbd_r000_wh.bot_bcbsa_plan_sbmsn")
val home_plan=home_plan_id.select("bhi_home_plan_id").collect().map(_(0)).toList
val primaryKeyList = List("BHI_HOME_PLAN_ID", "HOME_PLAN_PROD_ID", "MBR_ID","grp_id","subgrp_id","cvrg_bgn_dt","acct_id")
val primaryKeyListsc = List("BHI_HOME_PLAN_ID", "HOME_PLAN_PROD_ID", "MBR_ID","grp_id","subgrp_id","acct_id")
val duplicateKeyList = List("BHI_HOME_PLAN_ID", "HOME_PLAN_PROD_ID", "MBR_ID","cvrg_bgn_dt")
val tColList = List("BHI_HOME_PLAN_ID", "HOME_PLAN_PROD_ID", "MBR_ID", "CNSSTNT_MBR_ID", "SRC_SYS_CD", "MBR_BRTH_DT", "MBR_CURNT_PRMRY_ZIP_CD", "MBR_CURNT_CNTRY_CD", "MBR_CURNT_CNTY_CD", "MBR_GNDR_CD", "MBR_CNFDNTLTY_CD", "ACCT_ID", "GRP_ID", "SUBGRP_ID", "CVRG_BGN_DT", "CVRG_END_DT", "SBSCRBR_HOME_PLAN_PROD_ID", "SBSCRBR_ID", "MBR_MDCL_COB_CD", "PHRMCY_BNFT_IND", "MH_CD_BNFT_IND", "MDCL_BNFT_IND", "HOSP_BNFT_IND", "FCLTY_BNFTS_BHI_NTWK_CTGRY_CD", "PRFSNL_BNFTS_BHI_NTWK_CTGRY_CD")
val idColList = List("BHI_HOME_PLAN_ID", "HOME_PLAN_PROD_ID", "MBR_ID")

val initDataset=spark.sql("select * from "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp ")
val totalDataSet = create256BitHash(spark, initDataset, primaryKeyList)
totalDataSet.persist(StorageLevel.MEMORY_AND_DISK_SER)
val error303CheckDfList: List[DataFrame] = error303Check(spark, totalDataSet, List("BHI_HOME_PLAN_ID", "HOME_PLAN_PROD_ID", "MBR_ID", "CNSSTNT_MBR_ID", "MBR_GNDR_CD", "MBR_CNFDNTLTY_CD", "ACCT_ID", "GRP_ID", "SUBGRP_ID", "SBSCRBR_HOME_PLAN_PROD_ID", "SBSCRBR_ID", "MBR_MDCL_COB_CD", "FCLTY_BNFTS_BHI_NTWK_CTGRY_CD","PRFSNL_BNFTS_BHI_NTWK_CTGRY_CD","MBR_CURNT_PRMRY_ZIP_CD"))

val audError303Df = error303CheckDfList(1)


val err306ChkDtlsOneCol = List(Map("BHI_HOME_PLAN_ID" -> (dbname+"_pcandw1ph_nogbd_r000_wh", "RFRNC_BCBSA_BHI_HOME_PLAN_ID","bhi_home_plan_id"),
"mbr_gndr_cd" -> (dbname+"_pcandw1ph_nogbd_r000_wh", "RFRNC_BCBSA_GNDR","gndr_cd"),"MBR_CNFDNTLTY_CD" -> (dbname+"_pcandw1ph_nogbd_r000_wh", "RFRNC_BCBSA_MBR_CNFDNTLTY_CD","MBR_CNFDNTLTY_CD"),
"mbr_mdcl_cob_cd" -> (dbname+"_pcandw1ph_nogbd_r000_wh", "RFRNC_BCBSA_MBR_MDCL_COB","mbr_mdcl_cob_cd")))


val error306CheckDfListOneCol: List[DataFrame] = error306CheckColLevel(spark, totalDataSet, err306ChkDtlsOneCol, 1)
val audError306Dfn = error306CheckDfListOneCol(1)


val err306ChkDtlsTwoCol = List(Map("BHI_HOME_PLAN_ID,home_plan_prod_id" -> (dbname+"_pcandw1ph_nogbd_r000_ou", "bcbsa_prod ","bhi_home_plan_id,home_plan_prod_id"),
"BHI_HOME_PLAN_ID,src_sys_cd" -> (dbname+"_pcandw1ph_nogbd_r000_ou", "bcbsa_trcblty_rfrnc","bhi_home_plan_id,sor_cd")))

val error306CheckDfListTwoCol: List[DataFrame] = error306CheckColLevel(spark, totalDataSet, err306ChkDtlsTwoCol, 2)
val audError306DfnTwo = error306CheckDfListTwoCol(1)



val err306ChkDtlsFiveCol = List(Map("BHI_HOME_PLAN_ID,home_plan_prod_id,acct_id,grp_id,subgrp_id" -> (dbname+"_pcandw1ph_nogbd_r000_ou", "bcbsa_prod_clnt_cntrct","bhi_home_plan_id,home_plan_prod_id,acct_id,grp_id,subgrp_id")))
val error306CheckDfListFiveCol: List[DataFrame] = error306CheckColLevel(spark, totalDataSet, err306ChkDtlsFiveCol, 5)
val audError306DfnFive = error306CheckDfListFiveCol(1)

val error308CheckDfList: List[DataFrame] = errorCheck308(spark, totalDataSet, "mbr_brth_dt", 125)
val audError308Df = error308CheckDfList(1)

val error309CheckDfList: List[DataFrame] = error309Check(spark, totalDataSet, "mbr_brth_dt")
val audError309Df = error309CheckDfList(1)

val error411CheckDfList: List[DataFrame] = error411Check(spark, totalDataSet, "cvrg_end_dt", "cvrg_bgn_dt", "CVRG_END_DT")
val audError411Df = error411CheckDfList(1)

val errorA201CheckDfList: List[DataFrame] = errorA201Check(spark, totalDataSet, List( "ACCT_ID", "GRP_ID"))
val audErrorA201Df = errorA201CheckDfList(1)

val error307CheckDfList : List[DataFrame] = error307Check(spark, totalDataSet, List("PHRMCY_BNFT_IND","MH_CD_BNFT_IND","MDCL_BNFT_IND","HOSP_BNFT_IND"),"'Y','N'")
val audError307Df = error307CheckDfList(1)

val error801CheckDfList : List[DataFrame] = error801Check(spark,totalDataSet , tColList, primaryKeyListsc, idColList)
val audError801Df = error801CheckDfList(1)

val error501CheckDfList : List[DataFrame] = duplicate501Check(spark,totalDataSet ,  duplicateKeyList)
val audError501Df = error501CheckDfList(1)

val errorA301CheckDfList : List[DataFrame] = OverlapA301Check(spark,totalDataSet , "BHI_HOME_PLAN_ID ,HOME_PLAN_PROD_ID, MBR_ID,CVRG_BGN_DT,CVRG_END_DT" ,"CVRG_BGN_DT","CVRG_END_DT")
val audErrorA301Df = errorA301CheckDfList(1)

val finalAudErrDf = (audError303Df).union(audError306Dfn).union(audError306DfnFive).union(audError411Df).union(audError306DfnTwo).union(audError308Df).union(audError309Df).union(audErrorA201Df).union(audError307Df).union(audError801Df).union(audError501Df).union(audErrorA301Df)
  

finalAudErrDf.createOrReplaceTempView("auderr")

val a=spark.sql("select ME.*,b.bhi_home_plan_id FROM auderr ME  join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp b on  ME.err_id=b.err_id").persist(StorageLevel.MEMORY_AND_DISK)
a.count
a.createOrReplaceTempView("MemberErr")
val b=spark.sql("select count(*) CNT,bhi_home_plan_id FROM (select distinct err_id,bhi_home_plan_id from MemberErr) ME group by bhi_home_plan_id ").persist(StorageLevel.MEMORY_AND_DISK)
b.count()
b.createOrReplaceTempView("MemberTotalErr")
val c= spark.sql("SELECT count(*) as CNT,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK)
c.count
c.createOrReplaceTempView("Total")
val d=spark.sql(" SELECT  SUM(CASE WHEN SEL.mbr_gndr_cd ='U' THEN SEL.CNT ELSE 0 END) AS A,  SUM(CASE WHEN SEL.mbr_gndr_cd ='M' THEN SEL.CNT ELSE 0 END) AS B,  SUM(CASE WHEN SEL.mbr_gndr_cd ='F' THEN SEL.CNT ELSE 0 END) AS C,  SUM(CASE WHEN SEL.mbr_mdcl_cob_cd IN ('S','M') THEN SEL.CNT ELSE 0 END) AS D,  SUM(CASE WHEN SEL.mh_cd_bnft_ind='N' THEN SEL.CNT ELSE 0 END) AS E,  SUM(CASE WHEN SEL.mdcl_bnft_ind='N' THEN SEL.CNT ELSE 0 END) AS F,  SUM(CASE WHEN SEL.hosp_bnft_ind='N' THEN SEL.CNT ELSE 0 END) AS G,  SUM(CASE WHEN SEL.fclty_bnfts_bhi_ntwk_ctgry_cd='OTH' THEN SEL.CNT ELSE 0 END) AS H,  SUM(CASE WHEN SEL.prfsnl_bnfts_bhi_ntwk_ctgry_cd='OTH' THEN SEL.CNT ELSE 0 END) AS I,  SUM(CASE WHEN SEL.fclty_bnfts_plan_ntwk_ctgry_cd = 'IN' THEN SEL.CNT ELSE 0 END) AS J,  SUM(CASE WHEN SEL.prfsnl_bnfts_plan_ntwk_ctgry_cd = 'IN' THEN SEL.CNT ELSE 0 END) AS K,  SUM(CASE WHEN SEL.phrmcy_crv_out_sbmsn_ind='I' THEN SEL.CNT ELSE 0 END) AS L,  SUM(CASE WHEN SEL.phrmcy_crv_out_sbmsn_ind IN ('C','X') THEN SEL.CNT ELSE 0 END) AS M,  SUM(CASE WHEN SEL.phrmcy_bnft_tiers_nbr_txt='98' THEN SEL.CNT ELSE 0 END) AS N,  SUM(CASE WHEN SEL.phrmcy_bnft_tiers_nbr_txt='IN' THEN SEL.CNT ELSE 0 END) AS O,  SUM(CASE WHEN SEL.mbr_curnt_prmry_zip_cd IN ('','99999','00000','IN') THEN SEL.CNT ELSE 0 END) AS P,bhi_home_plan_id     FROM  (   SELECT 1 AS CNT, mbr_gndr_cd, mbr_mdcl_cob_cd, mh_cd_bnft_ind, mdcl_bnft_ind, hosp_bnft_ind,  fclty_bnfts_bhi_ntwk_ctgry_cd, prfsnl_bnfts_bhi_ntwk_ctgry_cd, fclty_bnfts_plan_ntwk_ctgry_cd, prfsnl_bnfts_plan_ntwk_ctgry_cd,  phrmcy_crv_out_sbmsn_ind, phrmcy_bnft_tiers_nbr_txt, mbr_curnt_prmry_zip_cd,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where    (mbr_gndr_cd IN ('U', 'F', 'M')  OR mbr_mdcl_cob_cd IN ('S', 'M')  OR mh_cd_bnft_ind='N' OR mdcl_bnft_ind='N' OR hosp_bnft_ind='N'  OR fclty_bnfts_bhi_ntwk_ctgry_cd='OTH' OR prfsnl_bnfts_bhi_ntwk_ctgry_cd='OTH'  OR fclty_bnfts_plan_ntwk_ctgry_cd = 'IN' OR prfsnl_bnfts_plan_ntwk_ctgry_cd = 'IN'  OR phrmcy_crv_out_sbmsn_ind IN ('I', 'C', 'X')  OR phrmcy_bnft_tiers_nbr_txt='98' OR phrmcy_bnft_tiers_nbr_txt='IN' OR mbr_curnt_prmry_zip_cd IN ('','99999','00000','IN')) ) SEL group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK)
d.count()
d.createOrReplaceTempView("MemberDetails") 
// Rule 1-4
home_plan.foreach(bhi_home_plan_id => {

val sqlb=" select a.CNT*100/(b.CNT) as AllFieldMemberReject  FROM  (  SELECT  CNT  FROM MemberTotalErr FH where  bhi_home_plan_id='"+bhi_home_plan_id +"'  ) a join (  SELECT  CNT  FROM Total FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"'  ) b    "

val sqlbshow=" select a.CNT*100/(b.CNT) as AllFieldMemberReject  FROM  (  SELECT count(*) as CNT  FROM MemberErr FH  join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp b on  FH.err_id=b.err_id where  bhi_home_plan_id='"+bhi_home_plan_id +"'  ) a join (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"'  ) b    "

val b=spark.sql(sqlb).withColumn("sql",lit(sqlbshow))


//Rule 5

val sqla = "select MemberDateofBirth*100/Total_CNT as MemberDateofBirth,MemberGender*100/Total_CNT as MemberGender,MemberMedicalCOBCode*100/Total_CNT as MemberMedicalCOBCode,MemberPharmacyCOBCode*100/Total_CNT as MemberPharmacyCOBCode,PharmacyBenefitIndicator*100/Total_CNT as PharmacyBenefitIndicator,MHCDBenefitIndicator*100/Total_CNT as MHCDBenefitIndicator,MedicalBenefitIndicator*100/Total_CNT as MedicalBenefitIndicator,HospitalBenefitIndicator*100/Total_CNT as HospitalBenefitIndicator,BHINetworkCategoryFacility*100/Total_CNT as BHINetworkCategoryFacility,BHINetworkCategoryProfessional*100/Total_CNT as BHINetworkCategoryProfessional from  (select SUM(CASE WHEN lower(SEL.FIELD_NM)='mbr_brth_dt' THEN SEL.CNT ELSE 0 END) AS MemberDateofBirth,  SUM(CASE WHEN lower(SEL.FIELD_NM)='mbr_gndr_cd' THEN SEL.CNT ELSE 0 END) AS MemberGender,  SUM(CASE WHEN lower(SEL.FIELD_NM)='mbr_mdcl_cob_cd' THEN SEL.CNT ELSE 0 END) AS MemberMedicalCOBCode,  SUM(CASE WHEN lower(SEL.FIELD_NM)='mbr_phrmcy_cob_cd' THEN SEL.CNT ELSE 0 END) AS MemberPharmacyCOBCode,  SUM(CASE WHEN lower(SEL.FIELD_NM)='phrmcy_bnft_ind' THEN SEL.CNT ELSE 0 END) AS PharmacyBenefitIndicator,  SUM(CASE WHEN lower(SEL.FIELD_NM)='mh_cd_bnft_ind' THEN SEL.CNT ELSE 0 END) AS MHCDBenefitIndicator,  SUM(CASE WHEN lower(SEL.FIELD_NM)='mdcl_bnft_ind' THEN SEL.CNT ELSE 0 END) AS MedicalBenefitIndicator, SUM(CASE WHEN lower(SEL.FIELD_NM)='hosp_bnft_ind' THEN SEL.CNT ELSE 0 END) AS HospitalBenefitIndicator,  SUM(CASE WHEN lower(SEL.FIELD_NM)='fclty_bnfts_bhi_ntwk_ctgry_cd' THEN SEL.CNT ELSE 0 END) AS BHINetworkCategoryFacility,  SUM(CASE WHEN lower(SEL.FIELD_NM)='prfsnl_bnfts_bhi_ntwk_ctgry_cd' THEN SEL.CNT ELSE 0 END) AS BHINetworkCategoryProfessional from (select bhi_home_plan_id,err_id,1 as CNT ,clmn_nm  as FIELD_NM from MemberErr where lower(clmn_nm) in  ('mbr_brth_dt', 'mbr_gndr_cd', 'mbr_mdcl_cob_cd', 'mbr_phrmcy_cob_cd', 'phrmcy_bnft_ind', 'mh_cd_bnft_ind','mdcl_bnft_ind', 'hosp_bnft_ind',  'fclty_bnfts_bhi_ntwk_ctgry_cd', 'prfsnl_bnfts_bhi_ntwk_ctgry_cd')) SEL  where  bhi_home_plan_id='"+bhi_home_plan_id +"') a cross join (SELECT CNT as Total_CNT  FROM Total FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"

val sqlashow = "select MemberDateofBirth*100/Total_CNT as MemberDateofBirth,MemberGender*100/Total_CNT as MemberGender,MemberMedicalCOBCode*100/Total_CNT as MemberMedicalCOBCode,MemberPharmacyCOBCode*100/Total_CNT as MemberPharmacyCOBCode,PharmacyBenefitIndicator*100/Total_CNT as PharmacyBenefitIndicator,MHCDBenefitIndicator*100/Total_CNT as MHCDBenefitIndicator,MedicalBenefitIndicator*100/Total_CNT as MedicalBenefitIndicator,HospitalBenefitIndicator*100/Total_CNT as HospitalBenefitIndicator,BHINetworkCategoryFacility*100/Total_CNT as BHINetworkCategoryFacility,BHINetworkCategoryProfessional*100/Total_CNT as BHINetworkCategoryProfessional from  (select SUM(CASE WHEN lower(SEL.FIELD_NM)='mbr_brth_dt' THEN SEL.CNT ELSE 0 END) AS MemberDateofBirth,  SUM(CASE WHEN lower(SEL.FIELD_NM)='mbr_gndr_cd' THEN SEL.CNT ELSE 0 END) AS MemberGender,  SUM(CASE WHEN lower(SEL.FIELD_NM)='mbr_mdcl_cob_cd' THEN SEL.CNT ELSE 0 END) AS MemberMedicalCOBCode,  SUM(CASE WHEN lower(SEL.FIELD_NM)='mbr_phrmcy_cob_cd' THEN SEL.CNT ELSE 0 END) AS MemberPharmacyCOBCode,  SUM(CASE WHEN lower(SEL.FIELD_NM)='phrmcy_bnft_ind' THEN SEL.CNT ELSE 0 END) AS PharmacyBenefitIndicator,  SUM(CASE WHEN lower(SEL.FIELD_NM)='mh_cd_bnft_ind' THEN SEL.CNT ELSE 0 END) AS MHCDBenefitIndicator,  SUM(CASE WHEN lower(SEL.FIELD_NM)='mdcl_bnft_ind' THEN SEL.CNT ELSE 0 END) AS MedicalBenefitIndicator, SUM(CASE WHEN lower(SEL.FIELD_NM)='hosp_bnft_ind' THEN SEL.CNT ELSE 0 END) AS HospitalBenefitIndicator,  SUM(CASE WHEN lower(SEL.FIELD_NM)='fclty_bnfts_bhi_ntwk_ctgry_cd' THEN SEL.CNT ELSE 0 END) AS BHINetworkCategoryFacility,  SUM(CASE WHEN lower(SEL.FIELD_NM)='prfsnl_bnfts_bhi_ntwk_ctgry_cd' THEN SEL.CNT ELSE 0 END) AS BHINetworkCategoryProfessional from (select err_id,1 as CNT ,clmn_nm  as FIELD_NM from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG where lower(clmn_nm) in  ('mbr_brth_dt', 'mbr_gndr_cd', 'mbr_mdcl_cob_cd', 'mbr_phrmcy_cob_cd', 'phrmcy_bnft_ind', 'mh_cd_bnft_ind','mdcl_bnft_ind', 'hosp_bnft_ind',  'fclty_bnfts_bhi_ntwk_ctgry_cd', 'prfsnl_bnfts_bhi_ntwk_ctgry_cd')) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp b on  SEL.err_id=b.err_id where  bhi_home_plan_id='"+bhi_home_plan_id +"') a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"

val a=spark.sql(sqla).withColumn("sql",lit(sqlashow))

//Rule 6-9
val sqlc = "SELECT  A*100/Total_CNT  as MEMBGENDERCDU  , B*100/Total_CNT as MEMBGENDERCDM, C*100/Total_CNT as MEMBGENDERCDF, D*100/Total_CNT as MEMBCOBCODE24,  E*100/Total_CNT as MEMBMHCDBNFTCD28, F*100/Total_CNT as MEMBMEDIBNFTCD30, G*100/Total_CNT as MEMBHospBNFTCD32,H*100/Total_CNT as MEMBNewFacilBNFTCD34, I*100/Total_CNT as MEMBNewProfBNFTCD36,  J*100/Total_CNT as MEMBPlanNewCatFac37, K*100/Total_CNT as MEMBPlanNewCatProf38, L*100/Total_CNT as MEMBCarveOut39,(N-M)*100/Total_CNT as MEMBPharmaBnftTiers40,  O*100/Total_CNT as MEMBPharmaBnftTiers41,P*100/Total_CNT as MEMBCURRENTPRIMARYZIP from ( SELECT  *  FROM MemberDetails where   bhi_home_plan_id='"+bhi_home_plan_id +"'  )a cross join (SELECT CNT as Total_CNT  FROM Total FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total "

val sqlcshow = "SELECT  A*100/Total_CNT  as MEMBGENDERCDU  , B*100/Total_CNT as MEMBGENDERCDM, C*100/Total_CNT as MEMBGENDERCDF, D*100/Total_CNT as MEMBCOBCODE24,  E*100/Total_CNT as MEMBMHCDBNFTCD28, F*100/Total_CNT as MEMBMEDIBNFTCD30, G*100/Total_CNT as MEMBHospBNFTCD32,H*100/Total_CNT as MEMBNewFacilBNFTCD34, I*100/Total_CNT as MEMBNewProfBNFTCD36,  J*100/Total_CNT as MEMBPlanNewCatFac37, K*100/Total_CNT as MEMBPlanNewCatProf38, L*100/Total_CNT as MEMBCarveOut39,(N-M)*100/Total_CNT as MEMBPharmaBnftTiers40,  O*100/Total_CNT as MEMBPharmaBnftTiers41,P*100/Total_CNT as MEMBCURRENTPRIMARYZIP from ( SELECT  SUM(CASE WHEN SEL.mbr_gndr_cd ='U' THEN SEL.CNT ELSE 0 END) AS A,  SUM(CASE WHEN SEL.mbr_gndr_cd ='M' THEN SEL.CNT ELSE 0 END) AS B,  SUM(CASE WHEN SEL.mbr_gndr_cd ='F' THEN SEL.CNT ELSE 0 END) AS C,  SUM(CASE WHEN SEL.mbr_mdcl_cob_cd IN ('S','M') THEN SEL.CNT ELSE 0 END) AS D,  SUM(CASE WHEN SEL.mh_cd_bnft_ind='N' THEN SEL.CNT ELSE 0 END) AS E,  SUM(CASE WHEN SEL.mdcl_bnft_ind='N' THEN SEL.CNT ELSE 0 END) AS F,  SUM(CASE WHEN SEL.hosp_bnft_ind='N' THEN SEL.CNT ELSE 0 END) AS G,  SUM(CASE WHEN SEL.fclty_bnfts_bhi_ntwk_ctgry_cd='OTH' THEN SEL.CNT ELSE 0 END) AS H,  SUM(CASE WHEN SEL.prfsnl_bnfts_bhi_ntwk_ctgry_cd='OTH' THEN SEL.CNT ELSE 0 END) AS I,  SUM(CASE WHEN SEL.fclty_bnfts_plan_ntwk_ctgry_cd = 'IN' THEN SEL.CNT ELSE 0 END) AS J,  SUM(CASE WHEN SEL.prfsnl_bnfts_plan_ntwk_ctgry_cd = 'IN' THEN SEL.CNT ELSE 0 END) AS K,  SUM(CASE WHEN SEL.phrmcy_crv_out_sbmsn_ind='I' THEN SEL.CNT ELSE 0 END) AS L,  SUM(CASE WHEN SEL.phrmcy_crv_out_sbmsn_ind IN ('C','X') THEN SEL.CNT ELSE 0 END) AS M,  SUM(CASE WHEN SEL.phrmcy_bnft_tiers_nbr_txt='98' THEN SEL.CNT ELSE 0 END) AS N,  SUM(CASE WHEN SEL.phrmcy_bnft_tiers_nbr_txt='IN' THEN SEL.CNT ELSE 0 END) AS O,  SUM(CASE WHEN SEL.mbr_curnt_prmry_zip_cd IN ('','99999','00000','IN') THEN SEL.CNT ELSE 0 END) AS P     FROM  (   SELECT 1 AS CNT, mbr_gndr_cd, mbr_mdcl_cob_cd, mh_cd_bnft_ind, mdcl_bnft_ind, hosp_bnft_ind,  fclty_bnfts_bhi_ntwk_ctgry_cd, prfsnl_bnfts_bhi_ntwk_ctgry_cd, fclty_bnfts_plan_ntwk_ctgry_cd, prfsnl_bnfts_plan_ntwk_ctgry_cd,  phrmcy_crv_out_sbmsn_ind, phrmcy_bnft_tiers_nbr_txt, mbr_curnt_prmry_zip_cd  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp WHERE    bhi_home_plan_id='"+bhi_home_plan_id +"' and    (mbr_gndr_cd IN ('U', 'F', 'M')  OR mbr_mdcl_cob_cd IN ('S', 'M')  OR mh_cd_bnft_ind='N' OR mdcl_bnft_ind='N' OR hosp_bnft_ind='N'  OR fclty_bnfts_bhi_ntwk_ctgry_cd='OTH' OR prfsnl_bnfts_bhi_ntwk_ctgry_cd='OTH'  OR fclty_bnfts_plan_ntwk_ctgry_cd = 'IN' OR prfsnl_bnfts_plan_ntwk_ctgry_cd = 'IN'  OR phrmcy_crv_out_sbmsn_ind IN ('I', 'C', 'X')  OR phrmcy_bnft_tiers_nbr_txt='98' OR phrmcy_bnft_tiers_nbr_txt='IN' OR mbr_curnt_prmry_zip_cd IN ('','99999','00000','IN')) ) SEL )a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total "

val c=spark.sql(sqlc).withColumn("sql",lit(sqlcshow))

val e=output(spark, TestIDGen(spark,ReportOutput(spark,dbname,a).union(ReportOutput(spark,dbname,b)).union(ReportOutput(spark,dbname,c))),SUBJ_AREA_NM,PRCS_NM, bhi_home_plan_id.toString())

e.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_RSLT")
//e(1).write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_SQL")


})



}



}