package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession

import org.apache.spark.sql.SparkSession
import java.io.File
import org.apache.spark.sql.DataFrame
import com.anthem.hca.ndw.utils.PCADX_SCL_TA_Utilities._
import java.text.SimpleDateFormat
import org.apache.spark.sql.SaveMode
import java.util.Calendar
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel
import java.util.Date
import java.text.SimpleDateFormat



object PCADX_SCL_TA_L2_Pharmacy_TGT {


  
def main(args: Array[String]) {
  


val dbname: String = args(0)
val SUBJ_AREA_NM: String=args(1)
val PRCS_NM: String=args(2)


val appName = "Datapipe from L2 cases for Pharmacy" // we will make this generic going forward

val warehouseLocation = new File("/user/hive/warehouse").getAbsolutePath
val options = Map("path" -> "/user/hive/warehouse")

val spark = SparkSession
.builder()
.appName(appName)
.config("spark.sql.warehouse.dir", warehouseLocation)
.enableHiveSupport()
.getOrCreate()

spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode","INFER_ONLY")
spark.conf.set("spark.sql.crossJoin.enabled","true")
spark.conf.set("spark.sql.hive.convertMetastoreParquet", "false")

import spark.implicits._
val home_plan_id =spark.sql("select distinct bhi_home_plan_id from "+dbname+"_pcandw1ph_nogbd_r000_wh.bot_bcbsa_plan_sbmsn")
val  home_plan=home_plan_id.select("bhi_home_plan_id").collect().map(_(0)).toList

spark.sql("select count(*) as CNT,bhi_home_plan_id FROM  "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm_err group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Error")

spark.sql("SELECT count(*) as CNT,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Total")

spark.sql(" select SUM(CASE WHEN trim(SEL.clm_mbr_zip_cd) IN ('99999','','00000') THEN  SEL.CNT ELSE 0 END) AS A,  SUM(CASE WHEN SEL.clm_mbr_cntry_cd IN ('IV','UN') THEN  SEL.CNT ELSE 0 END) AS B,  SUM(CASE WHEN SEL.billg_prov_spclty_cd<>'A5' THEN  SEL.CNT ELSE 0 END) AS D,  SUM(CASE WHEN SEL.ctgry_of_srvc_cd='VOID' THEN  SEL.CNT ELSE 0 END) AS E,  SUM(CASE WHEN SEL.rndrg_prov_spclty_cd<>'A5' THEN  SEL.CNT ELSE 0 END) AS G,  SUM(CASE WHEN SEL.bnft_paymnt_stts_cd = 'Y' THEN  SEL.CNT ELSE 0 END) AS H,  SUM(CASE WHEN SEL.ctgry_of_srvc_cd='PHARM' THEN  SEL.CNT ELSE 0 END) AS I,  SUM(CASE WHEN SEL.CMPND_CD='2' THEN  SEL.CNT ELSE 0 END) AS J,  SUM(CASE WHEN SEL.FRMLRY_IND='N' THEN  SEL.CNT ELSE 0 END) AS K,  SUM(CASE WHEN SEL.prod_srvc_id='99999999999' THEN  SEL.CNT ELSE 0 END) AS L,  SUM(CASE WHEN SEL.awp_sbmtd_amt=0 THEN  SEL.CNT ELSE 0 END) AS M,bhi_home_plan_id  FROM  (  SELECT 1 AS CNT, billg_prov_spclty_cd,rndrg_prov_id,billg_prov_id, ctgry_of_srvc_cd, rndrg_prov_spclty_cd, bnft_paymnt_stts_cd, CMPND_CD, frmlry_ind, prod_srvc_id,  clm_mbr_zip_cd, clm_mbr_cntry_cd,awp_sbmtd_amt,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where  ( billg_prov_spclty_cd<>'A5' OR ctgry_of_srvc_cd IN ('VOID','PHARM') OR rndrg_prov_spclty_cd<>'A5' OR bnft_paymnt_stts_cd = 'Y' OR CMPND_CD='2' OR frmlry_ind='N' OR prod_srvc_id='99999999999' OR awp_sbmtd_amt=0 OR trim(clm_mbr_zip_cd) IN ('99999','','00000') OR clm_mbr_cntry_cd IN ('IV','UN')  )   ) SEL group by bhi_home_plan_id ").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("PharmacyDetails")

spark.sql("select SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_mbr_zip_cd' THEN SEL.CNT ELSE 0 END) AS RxMembZipCd85,  SUM(CASE WHEN lower(SEL.FIELD_NM)='prod_srvc_id' THEN SEL.CNT ELSE 0 END) AS RxProdServiceId100,   SUM(CASE WHEN lower(SEL.FIELD_NM)='ctgry_of_srvc_cd' THEN SEL.CNT ELSE 0 END) AS RxCatService93,  SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_paymnt_stts_cd' THEN SEL.CNT ELSE 0 END) AS RxClmPmtSts96,  SUM(CASE WHEN lower(SEL.FIELD_NM)='plos_cd' THEN SEL.CNT ELSE 0 END) AS RxPlService99,bhi_home_plan_id from (select err_id,load_log_key,1 as CNT ,clmn_nm  as FIELD_NM from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_phrmcy_clm'   and lower(clmn_nm) in  ('prod_srvc_id', 'plos_cd', 'clm_paymnt_stts_cd', 'ctgry_of_srvc_cd', 'clm_mbr_zip_cd' )) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm b on  SEL.err_id=b.err_id and SEL.load_log_key=b.load_log_key group by  bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("AudPharmacy")

spark.sql("select count(*) CNT,bhi_home_plan_id  from  "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm FACHEAD where billg_prov_id='999999999999999999999999999' and npi_billg_prov_id='9999999999' and ctgry_of_srvc_cd<>'VOID' group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("VOIDBilling")

spark.sql("select count(*) CNT ,bhi_home_plan_id from  "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm FACHEAD where rndrg_prov_id='999999999999999999999999999' and npi_rndrg_prov_id='9999999999' and ctgry_of_srvc_cd<>'VOID' group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("VOIDRend")

spark.sql("SELECT count(*) as CNT,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where ctgry_of_srvc_cd<>'VOID' group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("TotalVOID")

// Rule 1-4
home_plan.foreach(bhi_home_plan_id => {

val sqlbshow=" select a.CNT*100/(b.CNT) as Rx84  FROM  (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm_err FH where  bhi_home_plan_id='"+bhi_home_plan_id +"' ) a join (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"') b "   

val sqlb=" select a.CNT*100/(b.CNT) as Rx84  FROM  (  SELECT  CNT  FROM Error FH where  bhi_home_plan_id='"+bhi_home_plan_id +"' ) a join (  SELECT  CNT  FROM Total FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"') b "   

val b=spark.sql(sqlb).withColumn("sql",lit(sqlbshow))


//Rule 5

val sqlashow = "select RxMembZipCd85*100/Total_CNT as RxMembZipCd85,RxProdServiceId100*100/Total_CNT as RxProdServiceId100,RxCatService93*100/Total_CNT as RxCatService93,RxClmPmtSts96*100/Total_CNT as RxClmPmtSts96,RxPlService99*100/Total_CNT as RxPlService99 from  (select SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_mbr_zip_cd' THEN SEL.CNT ELSE 0 END) AS RxMembZipCd85,  SUM(CASE WHEN lower(SEL.FIELD_NM)='prod_srvc_id' THEN SEL.CNT ELSE 0 END) AS RxProdServiceId100,   SUM(CASE WHEN lower(SEL.FIELD_NM)='ctgry_of_srvc_cd' THEN SEL.CNT ELSE 0 END) AS RxCatService93,  SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_paymnt_stts_cd' THEN SEL.CNT ELSE 0 END) AS RxClmPmtSts96,  SUM(CASE WHEN lower(SEL.FIELD_NM)='plos_cd' THEN SEL.CNT ELSE 0 END) AS RxPlService99 from (select err_id,1 as CNT ,clmn_nm  as FIELD_NM from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_phrmcy_clm'   and lower(clmn_nm) in  ('prod_srvc_id', 'plos_cd', 'clm_paymnt_stts_cd', 'ctgry_of_srvc_cd', 'clm_mbr_zip_cd' )) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm b on  SEL.err_id=b.err_id where  bhi_home_plan_id='"+bhi_home_plan_id +"') a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"

val sqla = "select RxMembZipCd85*100/Total_CNT as RxMembZipCd85,RxProdServiceId100*100/Total_CNT as RxProdServiceId100,RxCatService93*100/Total_CNT as RxCatService93,RxClmPmtSts96*100/Total_CNT as RxClmPmtSts96,RxPlService99*100/Total_CNT as RxPlService99 from  (select * from AudPharmacy   where  bhi_home_plan_id='"+bhi_home_plan_id +"') a cross join (SELECT CNT as Total_CNT  FROM Total FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"


val a=spark.sql(sqla).withColumn("sql",lit(sqlashow))



//Rule 6-9
val sqlcshow = "SELECT A*100/Total_CNT as RxMembZipCd86, B*100/Total_CNT as RxMembCntryClm87,  (D-E)*100/Total_CNT as RxBillProvSplCat89,E*100/Total_CNT as RxCatService, (G-E)*100/Total_CNT as RxRndrngProvSplCat91,H*100/Total_CNT as RxBnftPmtStsCd92,I*100/Total_CNT as RxCatService94, J*100/Total_CNT as RxCmpdCd97,  K*100/Total_CNT as RxFrmInd98, L*100/Total_CNT as RxProdServiceId101, (M-E)*100/Total_CNT as RxAvgPz102  from ( select SUM(CASE WHEN trim(SEL.clm_mbr_zip_cd) IN ('99999','','00000') THEN  SEL.CNT ELSE 0 END) AS A,  SUM(CASE WHEN SEL.clm_mbr_cntry_cd IN ('IV','UN') THEN  SEL.CNT ELSE 0 END) AS B,  SUM(CASE WHEN SEL.billg_prov_spclty_cd<>'A5' THEN  SEL.CNT ELSE 0 END) AS D,  SUM(CASE WHEN SEL.ctgry_of_srvc_cd='VOID' THEN  SEL.CNT ELSE 0 END) AS E,  SUM(CASE WHEN SEL.rndrg_prov_spclty_cd<>'A5' THEN  SEL.CNT ELSE 0 END) AS G,  SUM(CASE WHEN SEL.bnft_paymnt_stts_cd = 'Y' THEN  SEL.CNT ELSE 0 END) AS H,  SUM(CASE WHEN SEL.ctgry_of_srvc_cd='PHARM' THEN  SEL.CNT ELSE 0 END) AS I,  SUM(CASE WHEN SEL.CMPND_CD='2' THEN  SEL.CNT ELSE 0 END) AS J,  SUM(CASE WHEN SEL.FRMLRY_IND='N' THEN  SEL.CNT ELSE 0 END) AS K,  SUM(CASE WHEN SEL.prod_srvc_id='99999999999' THEN  SEL.CNT ELSE 0 END) AS L,  SUM(CASE WHEN SEL.awp_sbmtd_amt=0 THEN  SEL.CNT ELSE 0 END) AS M  FROM  (  SELECT 1 AS CNT, billg_prov_spclty_cd,rndrg_prov_id,billg_prov_id, ctgry_of_srvc_cd, rndrg_prov_spclty_cd, bnft_paymnt_stts_cd, CMPND_CD, frmlry_ind, prod_srvc_id,  clm_mbr_zip_cd, clm_mbr_cntry_cd,awp_sbmtd_amt  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  WHERE    bhi_home_plan_id='"+bhi_home_plan_id +"' and  ( billg_prov_spclty_cd<>'A5' OR ctgry_of_srvc_cd IN ('VOID','PHARM') OR rndrg_prov_spclty_cd<>'A5' OR bnft_paymnt_stts_cd = 'Y' OR CMPND_CD='2' OR frmlry_ind='N' OR prod_srvc_id='99999999999' OR awp_sbmtd_amt=0 OR trim(clm_mbr_zip_cd) IN ('99999','','00000') OR clm_mbr_cntry_cd IN ('IV','UN')  )   ) SEL )a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm FH where  bhi_home_plan_id='"+bhi_home_plan_id +"') total "

val sqlc = "SELECT A*100/Total_CNT as RxMembZipCd86, B*100/Total_CNT as RxMembCntryClm87,  (D-E)*100/Total_CNT as RxBillProvSplCat89,E*100/Total_CNT as RxCatService, (G-E)*100/Total_CNT as RxRndrngProvSplCat91,H*100/Total_CNT as RxBnftPmtStsCd92,I*100/Total_CNT as RxCatService94, J*100/Total_CNT as RxCmpdCd97,  K*100/Total_CNT as RxFrmInd98, L*100/Total_CNT as RxProdServiceId101, (M-E)*100/Total_CNT as RxAvgPz102  from ( select * from PharmacyDetails  WHERE    bhi_home_plan_id='"+bhi_home_plan_id +"' )a cross join (SELECT CNT as Total_CNT  FROM Total FH where  bhi_home_plan_id='"+bhi_home_plan_id +"') total "


var c=spark.sql(sqlc).withColumn("sql",lit(sqlcshow))

//Rule 10-13

val sqldshow = " select CNT*100/Total_CNT as RxMembBillProvId88 from (select count(*) CNT from  "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm FACHEAD where   bhi_home_plan_id='"+bhi_home_plan_id +"' and billg_prov_id='999999999999999999999999999' and npi_billg_prov_id='9999999999' and ctgry_of_srvc_cd<>'VOID' ) a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm FH where   bhi_home_plan_id='"+bhi_home_plan_id +"' and ctgry_of_srvc_cd<>'VOID') total"

val sqld = " select CNT*100/Total_CNT as RxMembBillProvId88 from (select count(*) CNT from  VOIDBilling where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) a cross join (SELECT CNT as Total_CNT  FROM TotalVOID FH where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) total"

var d=spark.sql(sqld).withColumn("sql",lit(sqldshow))

val sqlf = " select CNT*100/Total_CNT as RxRndrngProvId90 from (select count(*) CNT from  VOIDRend where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) a cross join (SELECT CNT as Total_CNT  FROM TotalVOID FH where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) total"

val sqlfshow = " select CNT*100/Total_CNT as RxRndrngProvId90 from (select count(*) CNT from  "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm FACHEAD where   bhi_home_plan_id='"+bhi_home_plan_id +"' and rndrg_prov_id='999999999999999999999999999' and npi_rndrg_prov_id='9999999999' and ctgry_of_srvc_cd<>'VOID' ) a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm FH where   bhi_home_plan_id='"+bhi_home_plan_id +"' and ctgry_of_srvc_cd<>'VOID') total"

val f=spark.sql(sqlf).withColumn("sql",lit(sqlfshow)) 


var e=output(spark, TestIDGen(spark,ReportOutput(spark,dbname,a).union(ReportOutput(spark,dbname,b)).union(ReportOutput(spark,dbname,c)).union(ReportOutput(spark,dbname,d)).union(ReportOutput(spark,dbname,f))),SUBJ_AREA_NM,PRCS_NM, bhi_home_plan_id.toString())

e.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_RSLT")
//e(1).write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_SQL")


})



}
  
  

}