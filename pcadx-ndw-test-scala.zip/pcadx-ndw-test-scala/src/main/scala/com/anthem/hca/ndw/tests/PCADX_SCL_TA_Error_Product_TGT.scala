package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Error_Product_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Error_Product_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_Error_Product_TGT(dbname : String, env: String) extends FunSuite {
  
     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())

     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Error"
      val prcss = "Product"
  
   test("Product Error-Reject- Check bhi_home_plan_id column values not located in reference table - 001") {

    val id = Array("001")
    val name = Array("Test case : Check bhi_home_plan_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result2 = sqlContext.sql("""select distinct a.bhi_home_plan_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_PROD' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306'""")

    val result = result2.except(result1)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct a.bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_PROD' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306' not in (select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
      val data = Array("No Invalid bhi_home_plan_id Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct a.bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_PROD' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306' not in (select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
      val data = Array("'bhi_home_plan_id'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }

  }
  
  //============================================================

  test("Product Error- Check Error code when bhi_home_plan_id column values not located in reference table - 002") {

    val id = Array("002")
    val name = Array("Test case : Check Error code when bhi_home_plan_id column values not located in reference table")
    
    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
      val a = result3.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
      val data = Array("'No Invalid ErrorCode Found'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==1)
    } else {
      val a = result3.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
      val data = Array("'ErrorCode'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }

  }
  
  //============================================================

  test("Product Error-Reject- Check bhi_prod_ctgry_cd column values not located in reference table - 003") {

    val id = Array("003")
    val name = Array("Test case : Check bhi_prod_ctgry_cd column values not located in reference table")
   
    val result1 = sqlContext.sql("""select distinct bhi_prod_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_BHI_PROD_CTGRY_INBND""")

    val result2 = sqlContext.sql("""select distinct a.bhi_prod_catgry_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_PROD' and b.clmn_nm='bhi_prod_catgry_cd' and b.err_cd='306'""")

    val result = result2.except(result1)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct a.bhi_prod_ctgry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_PROD' and b.clmn_nm='bhi_prod_ctgry_cd' and b.err_cd='306' not in (select distinct bhi_prod_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_BHI_PROD_CTGRY_INBND)")
      val data = Array("No Invalid bhi_prod_ctgry_cd Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct a.bhi_prod_ctgry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_PROD' and b.clmn_nm='bhi_prod_ctgry_cd' and b.err_cd='306' not in (select distinct bhi_prod_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_BHI_PROD_CTGRY_INBND)")
      val data = Array("'bhi_prod_ctgry_cd'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }

  }
  
  //============================================================
  
  test("Product Error- Check Error code when bhi_prod_ctgry_cd column values not located in reference table - 004") {

    val id = Array("004")
    val name = Array("Test case : Check Error code when bhi_prod_ctgry_cd column values not located in reference table")
     
    val result1 = sqlContext.sql("""select distinct bhi_prod_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_BHI_PROD_CTGRY_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bhi_prod_catgry_cd') and a.bhi_prod_catgry_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
      val a = result3.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_prod_catgry_cd') and a.bhi_prod_catgry_cd NOT IN (select distinct bhi_prod_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_BHI_PROD_CTGRY_INBND)")
      val data = Array("'No Invalid ErrorCode Found'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==1)
    } else {
      val a = result3.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_prod_catgry_cd') and a.bhi_prod_catgry_cd NOT IN (select distinct bhi_prod_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_BHI_PROD_CTGRY_INBND)")
      val data = Array("'ErrorCode'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }

  }
  
  //============================================================
  
  test("Product Error- Check Error code when bhi_home_plan_id column has spaces - 005") {

   val id = Array("005")
    val name = Array("Test case : Check Error code when bhi_home_plan_id column has spaces")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0")
      val data = Array("'No Invalid ErrorCode Found'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0")
      val data = Array("'ErrorCode'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }

  }
  
  //============================================================

  test("Product Error- Check Error code when home_plan_prod_id column has spaces - 006") {

    val id = Array("006")
    val name = Array("Test case : Check Error code when home_plan_prod_id column has spaces")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.home_plan_prod_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.home_plan_prod_id, ''),' ', '')))=0")
      val data = Array("'No Invalid ErrorCode Found'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.home_plan_prod_id, ''),' ', '')))=0")
      val data = Array("'ErrorCode'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }

  }
  
  //============================================================

  test("Product Error- Check Error code when bhi_prod_catgry_cd column has spaces - 007") {

    val id = Array("007")
    val name = Array("Test case : Check Error code when bhi_prod_catgry_cd column has spaces")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.bhi_prod_catgry_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.bhi_prod_catgry_cd, ''),' ', '')))=0")
      val data = Array("'No Invalid ErrorCode found'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.bhi_prod_catgry_cd, ''),' ', '')))=0")
      val data = Array("'ErrorCode'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }

  }
  
  //============================================================

  test("Product Error- Check Error code when sor_cd column has spaces - 008") {

    val id = Array("008")
    val name = Array("Test case : Check Error code when sor_cd column has spaces")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.sor_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1)) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sor_cd, ''),' ', '')))=0")
      val data = Array("'No Invalid ErrorCode Found'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sor_cd, ''),' ', '')))=0")
      val data = Array("'ErrorCode'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }

  }
  
}