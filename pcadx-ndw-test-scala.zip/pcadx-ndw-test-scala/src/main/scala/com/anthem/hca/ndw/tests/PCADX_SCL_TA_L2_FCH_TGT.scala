package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession

import org.apache.spark.sql.SparkSession
import java.io.File
import org.apache.spark.sql.DataFrame
import com.anthem.hca.ndw.utils.PCADX_SCL_TA_Utilities._
import java.text.SimpleDateFormat
import org.apache.spark.sql.SaveMode
import java.util.Calendar
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel
import java.util.Date
import java.text.SimpleDateFormat



object PCADX_SCL_TA_L2_FCH_TGT {


  
def main(args: Array[String]) {
  


val dbname: String = args(0)
val SUBJ_AREA_NM: String=args(1)
val PRCS_NM: String=args(2)


val appName = "Datapipe from L2 cases for FCH" // we will make this generic going forward

val warehouseLocation = new File("/user/hive/warehouse").getAbsolutePath
val options = Map("path" -> "/user/hive/warehouse")

val spark = SparkSession
.builder()
.appName(appName)
.config("spark.sql.warehouse.dir", warehouseLocation)
.enableHiveSupport()
.getOrCreate()

spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode","INFER_ONLY")
spark.conf.set("spark.sql.crossJoin.enabled","true")
spark.conf.set("spark.sql.hive.convertMetastoreParquet", "false")


import spark.implicits._
val home_plan_id =spark.sql("select distinct bhi_home_plan_id from "+dbname+"_pcandw1ph_nogbd_r000_wh.bot_bcbsa_plan_sbmsn")
val  home_plan=home_plan_id.select("bhi_home_plan_id").collect().map(_(0)).toList

spark.sql("select count(*) as CNT,bhi_home_plan_id FROM  "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Error")

spark.sql("SELECT count(*) as CNT,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Total")

spark.sql("   select SUM(CASE WHEN SEL.prncpal_icd9_diag_cd='UN' AND SEL.prncpal_icd10_diag_cd='UN' THEN  SEL.CNT ELSE 0 END) AS A,  SUM(CASE WHEN SEL.prncpal_icd10_diag_cd='UN' THEN  SEL.CNT ELSE 0 END) AS A10,  SUM(CASE WHEN SEL.prncpal_proc_cd='IN' THEN  SEL.CNT ELSE 0 END) AS B,  SUM(CASE WHEN SEL.prncpal_icd10_proc_cd='IN' THEN  SEL.CNT ELSE 0 END) AS B10,  SUM(CASE WHEN SEL.srvc_ctgry_cd IN ('IP ACUTE', 'IP NON-ACUTE') THEN  SEL.CNT ELSE 0 END) AS C,  SUM(CASE WHEN SEL.srvc_ctgry_cd='OP FAC' THEN  SEL.CNT ELSE 0 END) AS D,  SUM(CASE WHEN SEL.clm_paymnt_stts_cd = 'D' THEN  SEL.CNT ELSE 0 END) AS E,  SUM(CASE WHEN SEL.plos_cd IN ('12', '21', '22', '23', '24', '25', '26', '31', '32', '33', '34', '51', '52', '53', '54', '55', '56', '57', '61', '62', '65') THEN  SEL.CNT ELSE 0 END) AS F,  SUM(CASE WHEN trim(SEL.clm_mbr_zip_cd) IN ('IN','') THEN  SEL.CNT ELSE 0 END) AS G,  SUM(CASE WHEN SEL.clm_mbr_cntry_cd IN ('IV','UN') THEN  SEL.CNT ELSE 0 END) AS H,bhi_home_plan_id    FROM  (  SELECT 1 AS CNT, prncpal_icd9_diag_cd, prncpal_icd10_diag_cd, prncpal_proc_cd, prncpal_icd10_proc_cd, srvc_ctgry_cd, clm_paymnt_stts_cd, plos_cd,  clm_mbr_zip_cd, clm_mbr_cntry_cd,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  WHERE   ((prncpal_icd9_diag_cd='UN'  OR prncpal_icd10_diag_cd='UN' OR prncpal_proc_cd='IN' OR prncpal_icd10_proc_cd='IN'  OR srvc_ctgry_cd IN ('IP ACUTE', 'IP NON-ACUTE', 'OP FAC')  OR clm_paymnt_stts_cd = 'D' OR trim(clm_mbr_zip_cd) IN ('IN','') OR clm_mbr_cntry_cd IN ('IV','UN')  OR plos_cd IN ('12', '21', '22', '23', '24', '25', '26', '31', '32', '33', '34', '51', '52', '53', '54', '55', '56', '57', '61', '62', '65'))   )) SEL group by bhi_home_plan_id ").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("FCHDetails")

spark.sql("select SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_mbr_zip_cd' THEN SEL.CNT ELSE 0 END) AS FacHdrMembZipClm43,  SUM(CASE WHEN lower(SEL.FIELD_NM)='prncpal_icd9_diag_cd' THEN SEL.CNT ELSE 0 END) AS FacHdIcd9DiagCD46,  SUM(CASE WHEN lower(SEL.FIELD_NM)='prncpal_icd10_diag_cd' THEN SEL.CNT ELSE 0 END) AS FacHdIcd10DiagCD113,  SUM(CASE WHEN lower(SEL.FIELD_NM)='srvc_ctgry_cd' THEN SEL.CNT ELSE 0 END) AS FacHdCatofServicecCD49,  SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_paymnt_stts_cd' THEN SEL.CNT ELSE 0 END) AS FacHdClmPmtSts52,  SUM(CASE WHEN lower(SEL.FIELD_NM)='plos_cd' THEN SEL.CNT ELSE 0 END) AS FacHdPlService54,bhi_home_plan_id from (select 1 as CNT ,clmn_nm  as FIELD_NM,err_id,load_log_key from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_fclty_clm_hdr' and lower(clmn_nm) in  ('clm_mbr_zip_cd', 'prncpal_icd10_diag_cd', 'prncpal_icd9_diag_cd', 'srvc_ctgry_cd', 'clm_paymnt_stts_cd', 'plos_cd')) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr b on    SEL.err_id=b.err_id and  SEL.load_log_key=b.load_log_key group by  bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("AudFCH")

spark.sql("select SUM(CASE WHEN lower(SEL.FIELD_NM)='billg_prov_id' AND billg_prov_cntrctg_stts_ind = 'Y' THEN SEL.CNT ELSE 0 END) AS A, SUM(CASE WHEN lower(SEL.FIELD_NM)='rndrg_prov_id' AND rndrg_prov_cntrctg_stts_ind = 'Y' THEN SEL.CNT ELSE 0 END) AS D,bhi_home_plan_id from (select 1 as CNT ,clmn_nm  as FIELD_NM,err_id,LOAD_LOG_KEY from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_fclty_clm_hdr'  ) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FACHEAD on SEL.err_id=FACHEAD.err_id and SEL.LOAD_LOG_KEY=FACHEAD.LOAD_LOG_KEY WHERE  FACHEAD.srvc_ctgry_cd <> 'VOID' AND ((FACHEAD.billg_prov_cntrctg_stts_ind = 'Y' AND lower(SEL.FIELD_NM) = 'billg_prov_id') OR (FACHEAD.rndrg_prov_cntrctg_stts_ind='Y' AND lower(SEL.FIELD_NM) = 'rndrg_prov_id')) group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("VOID")

// Rule 1-4
home_plan.foreach(bhi_home_plan_id => {
val sqlbshow=" select a.CNT*100/(b.CNT) as FacHdrAll42  FROM  (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err FH where bhi_home_plan_id='"+bhi_home_plan_id +"' ) a join (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b    "

val sqlb=" select a.CNT*100/(b.CNT) as FacHdrAll42  FROM  (  SELECT  CNT  FROM Error FH where bhi_home_plan_id='"+bhi_home_plan_id +"' ) a join (  SELECT  CNT  FROM Total FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b    "

var b=spark.sql(sqlb).withColumn("sql",lit(sqlbshow))


//Rule 5
val sqlashow = "select FacHdrMembZipClm43*100/Total_CNT as FacHdrMembZipClm43,FacHdIcd9DiagCD46*100/Total_CNT as FacHdIcd9DiagCD46,FacHdIcd10DiagCD113*100/Total_CNT as FacHdIcd10DiagCD113,FacHdCatofServicecCD49*100/Total_CNT as FacHdCatofServicecCD49,FacHdClmPmtSts52*100/Total_CNT as FacHdClmPmtSts52,FacHdPlService54*100/Total_CNT as FacHdPlService54 from  (select SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_mbr_zip_cd' THEN SEL.CNT ELSE 0 END) AS FacHdrMembZipClm43,  SUM(CASE WHEN lower(SEL.FIELD_NM)='prncpal_icd9_diag_cd' THEN SEL.CNT ELSE 0 END) AS FacHdIcd9DiagCD46,  SUM(CASE WHEN lower(SEL.FIELD_NM)='prncpal_icd10_diag_cd' THEN SEL.CNT ELSE 0 END) AS FacHdIcd10DiagCD113,  SUM(CASE WHEN lower(SEL.FIELD_NM)='srvc_ctgry_cd' THEN SEL.CNT ELSE 0 END) AS FacHdCatofServicecCD49,  SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_paymnt_stts_cd' THEN SEL.CNT ELSE 0 END) AS FacHdClmPmtSts52,  SUM(CASE WHEN lower(SEL.FIELD_NM)='plos_cd' THEN SEL.CNT ELSE 0 END) AS FacHdPlService54 from (select 1 as CNT ,clmn_nm  as FIELD_NM,err_id,load_log_key from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_fclty_clm_hdr' and lower(clmn_nm) in  ('clm_mbr_zip_cd', 'prncpal_icd10_diag_cd', 'prncpal_icd9_diag_cd', 'srvc_ctgry_cd', 'clm_paymnt_stts_cd', 'plos_cd')) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr b on  SEL.err_id=b.err_id and SEL.load_log_key=b.load_log_key  where  bhi_home_plan_id='"+bhi_home_plan_id +"'  ) a  join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FH where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) total "

val sqla = "select FacHdrMembZipClm43*100/Total_CNT as FacHdrMembZipClm43,FacHdIcd9DiagCD46*100/Total_CNT as FacHdIcd9DiagCD46,FacHdIcd10DiagCD113*100/Total_CNT as FacHdIcd10DiagCD113,FacHdCatofServicecCD49*100/Total_CNT as FacHdCatofServicecCD49,FacHdClmPmtSts52*100/Total_CNT as FacHdClmPmtSts52,FacHdPlService54*100/Total_CNT as FacHdPlService54 from  (select * from AudFCH  where  bhi_home_plan_id='"+bhi_home_plan_id +"'  ) a  join (SELECT CNT as Total_CNT  FROM Total FH where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) total "

var a=spark.sql(sqla).withColumn("sql",lit(sqlashow))


//Rule 6-9
val sqlcshow = "SELECT case when A*100/Total_CNT <=A10*100/Total_CNT  then A*100/Total_CNT else A10*100/Total_CNT end as FacHdIcd9DiagCD47  ,case when B*100/Total_CNT <= B10*100/Total_CNT then B*100/Total_CNT else B10*100/Total_CNT end as FacHdPrincProcCD48, C*100/Total_CNT as FacHdCatofServicecCD50, D*100/Total_CNT as FacHdCatofServicecCD51,  E*100/Total_CNT as FacHdClmPmtSts53, F*100/Total_CNT as FacHdPlService55, G*100/Total_CNT as FacHdrMembZipClm44,H*100/Total_CNT as FacHdrMembCntryClm45 from ( select SUM(CASE WHEN SEL.prncpal_icd9_diag_cd='UN' and SEL.prncpal_icd10_diag_cd='UN' THEN  SEL.CNT ELSE 0 END) AS A,  SUM(CASE WHEN SEL.prncpal_icd10_diag_cd='UN' THEN  SEL.CNT ELSE 0 END) AS A10,  SUM(CASE WHEN SEL.prncpal_proc_cd='IN' THEN  SEL.CNT ELSE 0 END) AS B,  SUM(CASE WHEN SEL.prncpal_icd10_proc_cd='IN' THEN  SEL.CNT ELSE 0 END) AS B10,  SUM(CASE WHEN SEL.srvc_ctgry_cd IN ('IP ACUTE', 'IP NON-ACUTE') THEN  SEL.CNT ELSE 0 END) AS C,  SUM(CASE WHEN SEL.srvc_ctgry_cd='OP FAC' THEN  SEL.CNT ELSE 0 END) AS D,  SUM(CASE WHEN SEL.clm_paymnt_stts_cd = 'D' THEN  SEL.CNT ELSE 0 END) AS E,  SUM(CASE WHEN SEL.plos_cd IN ('12', '21', '22', '23', '24', '25', '26', '31', '32', '33', '34', '51', '52', '53', '54', '55', '56', '57', '61', '62', '65') THEN  SEL.CNT ELSE 0 END) AS F,  SUM(CASE WHEN trim(SEL.clm_mbr_zip_cd) IN ('IN','') THEN  SEL.CNT ELSE 0 END) AS G,  SUM(CASE WHEN SEL.clm_mbr_cntry_cd IN ('IV','UN') THEN  SEL.CNT ELSE 0 END) AS H    FROM  (  SELECT 1 AS CNT, prncpal_icd9_diag_cd, prncpal_icd10_diag_cd, prncpal_proc_cd, prncpal_icd10_proc_cd, srvc_ctgry_cd, clm_paymnt_stts_cd, plos_cd,  clm_mbr_zip_cd, clm_mbr_cntry_cd  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  WHERE    bhi_home_plan_id='"+bhi_home_plan_id +"' and  ((prncpal_icd9_diag_cd='UN'  OR prncpal_icd10_diag_cd='UN' OR prncpal_proc_cd='IN' OR prncpal_icd10_proc_cd='IN'  OR srvc_ctgry_cd IN ('IP ACUTE', 'IP NON-ACUTE', 'OP FAC')  OR clm_paymnt_stts_cd = 'D' OR trim(clm_mbr_zip_cd) IN ('IN','') OR clm_mbr_cntry_cd IN ('IV','UN')  OR plos_cd IN ('12', '21', '22', '23', '24', '25', '26', '31', '32', '33', '34', '51', '52', '53', '54', '55', '56', '57', '61', '62', '65'))   )) SEL )a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total "

val sqlc = "SELECT case when A*100/Total_CNT <=A10*100/Total_CNT  then A*100/Total_CNT else A10*100/Total_CNT end as FacHdIcd9DiagCD47  ,case when B*100/Total_CNT <= B10*100/Total_CNT then B*100/Total_CNT else B10*100/Total_CNT end as FacHdPrincProcCD48, C*100/Total_CNT as FacHdCatofServicecCD50, D*100/Total_CNT as FacHdCatofServicecCD51,  E*100/Total_CNT as FacHdClmPmtSts53, F*100/Total_CNT as FacHdPlService55, G*100/Total_CNT as FacHdrMembZipClm44,H*100/Total_CNT as FacHdrMembCntryClm45 from ( select * from FCHDetails where   bhi_home_plan_id='"+bhi_home_plan_id +"')a cross join (SELECT CNT as Total_CNT  FROM Total FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total "

var c=spark.sql(sqlc).withColumn("sql",lit(sqlcshow))

//Rule 10-13
val sqldshow = "select A*100/Total_CNT as FacHdrBillProv105,D*100/Total_CNT as FacHdrRendProv106 from  (select SUM(CASE WHEN lower(SEL.FIELD_NM)='billg_prov_id' AND billg_prov_cntrctg_stts_ind = 'Y' THEN SEL.CNT ELSE 0 END) AS A, SUM(CASE WHEN lower(SEL.FIELD_NM)='rndrg_prov_id' AND rndrg_prov_cntrctg_stts_ind = 'Y' THEN SEL.CNT ELSE 0 END) AS D from (select 1 as CNT ,clmn_nm  as FIELD_NM,err_id,LOAD_LOG_KEY from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_fclty_clm_hdr'  ) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FACHEAD on SEL.err_id=FACHEAD.err_id and SEL.LOAD_LOG_KEY=FACHEAD.LOAD_LOG_KEY WHERE  FACHEAD.srvc_ctgry_cd <> 'VOID' AND ((FACHEAD.billg_prov_cntrctg_stts_ind = 'Y' AND lower(SEL.FIELD_NM) = 'billg_prov_id') OR (FACHEAD.rndrg_prov_cntrctg_stts_ind='Y' AND lower(SEL.FIELD_NM) = 'rndrg_prov_id')) where   bhi_home_plan_id='"+bhi_home_plan_id +"') a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"

val sqld = "select A*100/Total_CNT as FacHdrBillProv105,D*100/Total_CNT as FacHdrRendProv106 from  (select * from VOID  where   bhi_home_plan_id='"+bhi_home_plan_id +"') a cross join (SELECT count(*) as Total_CNT  FROM Total FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"

var d=spark.sql(sqld).withColumn("sql",lit(sqldshow))


var e=output(spark, TestIDGen(spark,ReportOutput(spark,dbname,a).union(ReportOutput(spark,dbname,b)).union(ReportOutput(spark,dbname,c)).union(ReportOutput(spark,dbname,d))),SUBJ_AREA_NM,PRCS_NM, bhi_home_plan_id.toString())

e.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_RSLT")
//e(1).write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_SQL")


})



}
  
  

}