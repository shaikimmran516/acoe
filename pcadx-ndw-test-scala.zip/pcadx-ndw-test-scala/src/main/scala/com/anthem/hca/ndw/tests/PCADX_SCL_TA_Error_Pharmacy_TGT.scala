package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Error_Pharmacy_TGT {
 
  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Error_Pharmacy_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}


 class PCADX_SCL_TA_Error_Pharmacy_TGT(dbname : String, env: String) extends FunSuite{
   
     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
     
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Error"
      val prcss = "Pharmacy"
      
   test("Pharmacy Error- Check bhi_home_plan_id column values should not located in reference table - 001") {
      
    val id = Array("001")
    val name = Array("Test case : Check bhi_home_plan_id column values should not located in reference table")

    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result2 = sqlContext.sql("""select distinct a.bhi_home_plan_id from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bhi_home_plan_id') and b.err_cd='306'""")

    val result = result1.intersect(result2)
     
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') and bhi_home_plan_id in (select distinct a.bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and b.err_cd='306')")
       val data = Array("'BHI_Home_Plan_ID': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') and bhi_home_plan_id in (select distinct a.bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and b.err_cd='306')")
       val data = Array("'BHI_Home_Plan_ID'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Pharmacy Error- Check Error code when bhi_home_plan_id column values not located in reference table - 002") {

    val id = Array("002")
    val name = Array("Test case : Check Error code when bhi_home_plan_id column values not located in reference table")
    
    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("'Error_Code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("'Error_Code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Pharmacy Error- Check trcblty_fld_cd column values not located in reference table - 003") {

    val id = Array("003")
    val name = Array("Test case : Check trcblty_fld_cd column values not located in reference table")
  
    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,sor_cd) as trcblty_fld_cd from 
      """+dbname+"""_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT""")

    val result2 = sqlContext.sql("""select distinct concat(a.bhi_home_plan_id,a.trcblty_fld_cd) as trcblty_fld_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('trcblty_fld_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
     
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,sor_cd) as trcblty_fld_cd from  '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT where concat(bhi_home_plan_id,sor_cd) in (select distinct concat(a.bhi_home_plan_id,a.trcblty_fld_cd) as trcblty_fld_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('trcblty_fld_cd') and b.err_cd='306')")
       val data = Array("'Traceability_Field_Code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,sor_cd) as trcblty_fld_cd from  '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT where concat(bhi_home_plan_id,sor_cd) in (select distinct concat(a.bhi_home_plan_id,a.trcblty_fld_cd) as trcblty_fld_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('trcblty_fld_cd') and b.err_cd='306')")
       val data = Array("'Traceability_Field_Code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Pharmacy Error- Check host_plan_id column values not located in reference table - 004") {

    val id = Array("004")
    val name = Array("Test case : Check host_plan_id column values not located in reference table")
    
    val result1 = sqlContext.sql("""select distinct host_plan_id_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOST_PLAN_ID_INBND""")

    val result2 = sqlContext.sql("""select distinct a.host_plan_id from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('host_plan_id') and b.err_cd='306'""")

    val result = result1.intersect(result2)
     
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct host_plan_id_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOST_PLAN_ID_INBND where host_plan_id_cd in (select distinct a.host_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('host_plan_id') and b.err_cd='306')")
       val data = Array("'HostPlanID': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct host_plan_id_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOST_PLAN_ID_INBND where host_plan_id_cd in (select distinct a.host_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('host_plan_id') and b.err_cd='306')")
       val data = Array("'HostPlanID'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Pharmacy Error- Check Error code when host_plan_id column values not located in reference table - 005") {

    val id = Array("005")
    val name = Array("Test case : Check Error code when host_plan_id column values not located in reference table")
    
    val result1 = sqlContext.sql("""select distinct host_plan_id_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOST_PLAN_ID_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('host_plan_id') and a.host_plan_id NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('host_plan_id') and a.host_plan_id NOT IN (select distinct host_plan_id_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOST_PLAN_ID_INBND)")
       val data = Array("'Error_Code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('host_plan_id') and a.host_plan_id NOT IN (select distinct host_plan_id_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOST_PLAN_ID_INBND)")
       val data = Array("'Error_Code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

 test("Pharmacy Error- Check home_plan_prod_id column values not located in reference table - 006") {

    val id = Array("006")
    val name = Array("Test case :  Check home_plan_prod_id column values not located in reference table")
    
    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,home_plan_prod_id) as home_plan_prod_id from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_prod""")

    val result2 = sqlContext.sql("""select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id) as home_plan_prod_id from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm='home_plan_prod_id' and b.err_cd='306'""")

    val result = result1.intersect(result2)
     
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,home_plan_prod_id) as home_plan_prod_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_prod where concat(bhi_home_plan_id,home_plan_prod_id) in (select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id) as home_plan_prod_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm='home_plan_prod_id' and b.err_cd='306')")
       val data = Array("'Home_Plan_Prod_ID': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,home_plan_prod_id) as home_plan_prod_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_prod where concat(bhi_home_plan_id,home_plan_prod_id) in (select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id) as home_plan_prod_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm='home_plan_prod_id' and b.err_cd='306')")
       val data = Array("'Home_Plan_Prod_ID'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
 
 //============================================================
 
  test("Pharmacy Error- Check acct_cd column values not located in reference table - 007") {

    val id = Array("007")
    val name = Array("Test case : Check acct_cd column values not located in reference table")
  
    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,home_plan_prod_id,acct_id,grp_id,subgrp_id) as acct_id from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT""")

    val result2 = sqlContext.sql("""select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id,a.acct_cd,a.grp_cd,a.subgrp_cd) as acct_id from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id 
        where b.clmn_nm=UPPER('acct_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
     
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,home_plan_prod_id,acct_id,grp_id,subgrp_id) as acct_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT where concat(bhi_home_plan_id,home_plan_prod_id,acct_id,grp_id,subgrp_id) in (select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id,a.acct_cd,a.grp_cd,a.subgrp_cd) as acct_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id  where b.clmn_nm=UPPER('acct_cd') and b.err_cd='306')")
       val data = Array("'Account_ID': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,home_plan_prod_id,acct_id,grp_id,subgrp_id) as acct_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT where concat(bhi_home_plan_id,home_plan_prod_id,acct_id,grp_id,subgrp_id) in (select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id,a.acct_cd,a.grp_cd,a.subgrp_cd) as acct_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id  where b.clmn_nm=UPPER('acct_cd') and b.err_cd='306')")
       val data = Array("'Account_ID'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Pharmacy Error- Check mbr_id column values not located in reference table - 008") {

    val id = Array("008")
    val name = Array("Test case : Check mbr_id column values not located in reference table")
   
    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,home_plan_prod_id,mbr_id) as mbr_id from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP""")

    val result2 = sqlContext.sql("""select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id,a.mbr_id) as mbr_id from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('mbr_id') and b.err_cd='306'""")

    val result = result1.intersect(result2)
     
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,home_plan_prod_id,mbr_id) as mbr_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP where concat(bhi_home_plan_id,home_plan_prod_id,mbr_id) in (select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id,a.mbr_id) as mbr_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('mbr_id') and b.err_cd='306')")
       val data = Array("'MBR_ID': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,home_plan_prod_id,mbr_id) as mbr_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP where concat(bhi_home_plan_id,home_plan_prod_id,mbr_id) in (select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id,a.mbr_id) as mbr_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('mbr_id') and b.err_cd='306')")
       val data = Array("'MBR_ID'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Pharmacy Error- Check clm_mbr_zip_cd column values not located in reference table - 009") {

    val id = Array("009")
    val name = Array("Test case : Check clm_mbr_zip_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct zip_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ZIP_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.clm_mbr_zip_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('clm_mbr_zip_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
     
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct zip_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ZIP_CD_INBND where zip_cd in (select distinct a.clm_mbr_zip_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_zip_cd') and b.err_cd='306')")
       val data = Array("'Zip_Code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct zip_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ZIP_CD_INBND where zip_cd in (select distinct a.clm_mbr_zip_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_zip_cd') and b.err_cd='306')")
       val data = Array("'Zip_Code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Pharmacy Error- Check Error code when clm_mbr_zip_cd column values not located in reference table - 010") {

    val id = Array("010")
    val name = Array("Test case : Check Error code when clm_mbr_zip_cd column values not located in reference table")
    
    val result1 = sqlContext.sql("""select distinct zip_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ZIP_CD_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('clm_mbr_zip_cd') and a.clm_mbr_zip_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_zip_cd') and a.clm_mbr_zip_cd NOT IN (select distinct zip_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ZIP_CD_INBND)")
       val data = Array("'Error_Code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_zip_cd') and a.clm_mbr_zip_cd NOT IN (select distinct zip_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ZIP_CD_INBND)")
       val data = Array("'Error_Code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Pharmacy Error- Check clm_mbr_cntry_cd column values not located in reference table - 011") {

    val id = Array("011")
    val name = Array("Test case : Check clm_mbr_cntry_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct cntry_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRY_INBND""")

    val result2 = sqlContext.sql("""select distinct a.clm_mbr_cntry_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('clm_mbr_cntry_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
     
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct cntry_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRY_INBND where cntry_cd in (select distinct a.clm_mbr_cntry_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_cntry_cd') and b.err_cd='306')")
       val data = Array("'Country_Code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct cntry_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRY_INBND where cntry_cd in (select distinct a.clm_mbr_cntry_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_cntry_cd') and b.err_cd='306')")
       val data = Array("'Country_Code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Pharmacy Error- Check Error code when clm_mbr_cntry_cd column values not located in reference table - 012") {

    val id = Array("012")
    val name = Array("Test case : Check Error code when clm_mbr_cntry_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct cntry_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRY_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('clm_mbr_cntry_cd') and a.clm_mbr_cntry_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_cntry_cd') and a.clm_mbr_cntry_cd NOT IN (select distinct cntry_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRY_INBND)")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_cntry_cd') and a.clm_mbr_cntry_cd NOT IN (select distinct cntry_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRY_INBND)")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
   test("Pharmacy Error- Check Error code when clm_line_nbr not in correct nu-meric format - 013") {

     val id = Array("013")
     val name = Array("Test case : Check Error code when clm_line_nbr not in correct nu-meric format")

     val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr rlike '[^0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("310") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr rlike '[^0-9]'")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr rlike '[^0-9]'")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Pharmacy Error- Check Error code when clm_line_nbr less than 000 - 014") {

    val id = Array("014")
    val name = Array("Test case : Check Error code when clm_line_nbr less than 000")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr < 000""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr < 000")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr < 000")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Pharmacy Error- Check Error code when clm_line_nbr exceeds 999 -  015") {

    val id = Array("015")
    val name = Array("Test case : Check Error code when clm_line_nbr exceeds 999")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr > 999""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr > 999")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr > 999")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Pharmacy Error- Check Error code when adjstmnt_sqnc_nbr not in correct nu-meric format - 016") {

    val id = Array("016")
    val name = Array("Test case : Check Error code when adjstmnt_sqnc_nbr not in correct nu-meric format")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('adjstmnt_sqnc_nbr') and b.adjstmnt_sqnc_nbr rlike '[^0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("310") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('adjstmnt_sqnc_nbr') and b.adjstmnt_sqnc_nbr rlike '[^0-9]'")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('adjstmnt_sqnc_nbr') and b.adjstmnt_sqnc_nbr rlike '[^0-9]'")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Pharmacy Error- Check Error code when home_plan_cd column has spaces - 017") {

    val id = Array("017")
    val name = Array("Test case : Check Error code when home_plan_cd column has spaces")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('bhi_home_plan_id') and length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('bhi_home_plan_id') and length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('bhi_home_plan_id') and length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Pharmacy Error- Check Error code when clm_nbr column has spaces - 018") {

    val id = Array("018")
    val name = Array("Test case : Check Error code when clm_nbr column has spaces")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('clm_id') and length(trim(regexp_replace(coalesce(b.clm_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_id') and length(trim(regexp_replace(coalesce(b.clm_id, ''),' ', '')))=0")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_id') and length(trim(regexp_replace(coalesce(b.clm_id, ''),' ', '')))=0")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Pharmacy Error- Check Error code when trcblty_fld_cd column has spaces - 019") {

    val id = Array("019")
    val name = Array("Test case : Check Error code when trcblty_fld_cd column has spaces")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('trcblty_fld_cd') and length(trim(regexp_replace(coalesce(b.trcblty_fld_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('trcblty_fld_cd') and length(trim(regexp_replace(coalesce(b.trcblty_fld_cd, ''),' ', '')))=0")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('trcblty_fld_cd') and length(trim(regexp_replace(coalesce(b.trcblty_fld_cd, ''),' ', '')))=0")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Pharmacy Error- Check Error code when host_plan_id column has spaces - 020") {

    val id = Array("020")
    val name = Array("Test case : Check Error code when host_plan_id column has spaces")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('host_plan_id') and length(trim(regexp_replace(coalesce(b.host_plan_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('host_plan_id') and length(trim(regexp_replace(coalesce(b.host_plan_id, ''),' ', '')))=0")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('host_plan_id') and length(trim(regexp_replace(coalesce(b.host_plan_id, ''),' ', '')))=0")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Pharmacy Error- Check Error code when home_plan_prod_id column has spaces - 021") {

    val id = Array("021")
    val name = Array("Test case : Check Error code when home_plan_prod_id column has spaces")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id
        where a.clmn_nm='home_plan_prod_id' and length(trim(regexp_replace(coalesce(b.home_plan_prod_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm='home_plan_prod_id' and length(trim(regexp_replace(coalesce(b.home_plan_prod_id, ''),' ', '')))=0")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm='home_plan_prod_id' and length(trim(regexp_replace(coalesce(b.home_plan_prod_id, ''),' ', '')))=0")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Pharmacy Error- Check Error code when acct_cd column has spaces - 022") {

    val id = Array("022")
    val name = Array("Test case : Check Error code when acct_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('acct_cd') and length(trim(regexp_replace(coalesce(b.acct_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('acct_cd') and length(trim(regexp_replace(coalesce(b.acct_cd, ''),' ', '')))=0")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('acct_cd') and length(trim(regexp_replace(coalesce(b.acct_cd, ''),' ', '')))=0")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Pharmacy Error- Check Error code when grp_cd column has spaces - 023") {
    
    val id = Array("023")
    val name = Array("Test case : Check Error code when grp_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('grp_cd') and length(trim(regexp_replace(coalesce(b.grp_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('grp_cd') and length(trim(regexp_replace(coalesce(b.grp_cd, ''),' ', '')))=0")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('grp_cd') and length(trim(regexp_replace(coalesce(b.grp_cd, ''),' ', '')))=0")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Pharmacy Error- Check Error code when subgrp_cd column has spaces - 024") {

    val id = Array("024")
    val name = Array("Test case : Check Error code when subgrp_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('subgrp_cd') and length(trim(regexp_replace(coalesce(b.subgrp_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('subgrp_cd') and length(trim(regexp_replace(coalesce(b.subgrp_cd, ''),' ', '')))=0")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('subgrp_cd') and length(trim(regexp_replace(coalesce(b.subgrp_cd, ''),' ', '')))=0")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Pharmacy Error- Check Error code when mbr_id column has spaces - 025") {

    val id = Array("025")
    val name = Array("Test case : Check Error code when mbr_id column has spaces")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('mbr_id') and length(trim(regexp_replace(coalesce(b.mbr_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('mbr_id') and length(trim(regexp_replace(coalesce(b.mbr_id, ''),' ', '')))=0")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('mbr_id') and length(trim(regexp_replace(coalesce(b.mbr_id, ''),' ', '')))=0")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Pharmacy Error- Check Error code when clm_mbr_cntry_cd column has spaces - 026") {

    val id = Array("026")
    val name = Array("Test case : Check Error code when clm_mbr_cntry_cd column has spaces")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('clm_mbr_cntry_cd') and length(trim(regexp_replace(coalesce(b.clm_mbr_cntry_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_mbr_cntry_cd') and length(trim(regexp_replace(coalesce(b.clm_mbr_cntry_cd, ''),' ', '')))=0")
       val data = Array("'Error code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       
      assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_mbr_cntry_cd') and length(trim(regexp_replace(coalesce(b.clm_mbr_cntry_cd, ''),' ', '')))=0")
       val data = Array("'Error code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
 }