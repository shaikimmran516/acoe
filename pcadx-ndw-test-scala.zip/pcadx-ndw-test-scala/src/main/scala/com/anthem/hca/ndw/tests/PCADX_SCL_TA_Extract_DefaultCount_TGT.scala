package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import java.util.Date
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel


object PCADX_SCL_TA_Extract_DefaultCount_TGT {
 
  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_DefaultCount_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}


class PCADX_SCL_TA_Extract_DefaultCount_TGT(dbname: String, env: String) extends FunSuite {

     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
  
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
 //===========================================
 //=========================================== Non-Claim
   test("Member - Pharmacy Indicators counts should be in sync") {
    val subjtArea = "Member"
    val testCase = "Pharmacy Indicators"

    val totalCounts = sql(f""" select a1.bhi_home_plan_id, count(*) as totalCounts from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a1 group by a1.bhi_home_plan_id order by a1.bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

  
      
      val colName = List("mbr_phrmcy_cob_cd","phrmcy_bnft_ind","phrmcy_crv_out_sbmsn_ind","phrmcy_bnft_tiers_nbr_txt")
      
      colName.foreach(colName =>{
        val con = ""
        if(colName == "mbr_phrmcy_cob_cd" || colName == "phrmcy_bnft_ind"){
          val con = "N"
        }else if(colName == "phrmcy_crv_out_sbmsn_ind"){
          val con = "X"
        }else{
        val con = "98"
        }  
        
       val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from 
        ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a1 where $colName="$con" group by a1.bhi_home_plan_id order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")
 
       val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
      "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
      "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)
    
      result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")
   
      })
      
   }

   //===========================================check once again
   
   test("PCC -  Counts") {
    val subjtArea = "PCC"
    //val testCase = ""
    
    val con = List("Y","N")
    val totalCounts = sql(f""" select a1.bhi_home_plan_id, count(*) as totalCounts from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_prod_clnt_cntrct a1 group by a1.bhi_home_plan_id order by a1.bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

    val colName = List("aso_cd","cstm_ntwk_ind")
      
    colName.foreach(colName =>{
    var testCase = ""
     if(colName == "aso_cd"){
      testCase = "ASO Code"
     }else{
     testCase = "Custom Network Indicator"
     } 
    con.foreach(con =>{

    val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_prod_clnt_cntrct a1 where $colName="$con" group by a1.bhi_home_plan_id order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")

    val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
    "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
    "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)

    result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")
    })
    })
   }

   //===========================================
   
  test("Member - Medical and Hospital Benefit Ind") {
      
    val subjtArea = "Member"
    val testCase = "Medical and Hospital Benefit Ind"
    
    val totalCounts = sql(f""" select a1.bhi_home_plan_id, count(*) as totalCounts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a1 group by a1.bhi_home_plan_id order by a1.bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

    val colName = List("mdcl_bnft_ind","mbr_mdcl_cob_cd","hosp_bnft_ind")  
    val con = "N"

    colName.foreach(colName =>{

    val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a1 where $colName="$con" group by a1.bhi_home_plan_id order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")

    val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
    "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
    "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)

    result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")

    })
   }

   //===========================================
  
  test("Member - MHCD Fields") {
      
    val subjtArea = "Member"
    val testCase = "MHCD Fields"
    
    val totalCounts = sql(f""" select a1.bhi_home_plan_id, count(*) as totalCounts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a1 group by a1.bhi_home_plan_id order by a1.bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

    val colName = List("mh_cd_enrlmnt_bnft_cd","mh_cd_bnft_ind")  
    val con = "N"

    colName.foreach(colName =>{

    val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a1 where $colName="$con" group by a1.bhi_home_plan_id order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")

    val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
    "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
    "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)

    result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")

    })
   }

   //===========================================
   
   test("Member - Deductible Category Code") {
      
    val subjtArea = "Member"
    val testCase = "Deductible Category Code"
    val totalCounts = sql(f""" select a1.bhi_home_plan_id, count(*) as totalCounts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a1 group by a1.bhi_home_plan_id order by a1.bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

    val colName = "ddctbl_ctgry_cd"  
    val con = "U"


    val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a1 where $colName="$con" group by a1.bhi_home_plan_id order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")

    val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
    "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
    "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)

    result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")

   }

   //===========================================
     
   test("MBR_Demo -  Counts") {
    val subjtArea = "MBR_Demo"
    val testCase = "Counts"

    val totalCounts = sql(f""" select bhi_home_plan_id,count(*) as totalCounts 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc group by bhi_home_plan_id order by bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

      
      val colName = List("mbr_last_nm","mbr_frst_nm","mbr_prmry_str_adrs_1_txt","mbr_prmry_city_nm","mbr_prmry_st_cd","mbr_prmry_zip_cd")
      
      colName.foreach(colName =>{
       val con = "NULL or Space"
       
       val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a1 
         where (length(trim(regexp_replace($colName,' ', '')))=0 OR $colName is NULL ) group by a1.bhi_home_plan_id 
         order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")
         
       val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
      "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
      "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)
    
      result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")
   
      })
      
      val colName1 = "mbr_prmry_zip_plus4_cd"
      val con1 = "NULL or Space or 0000"
 
      val query2 = sql(f""" select a1.bhi_home_plan_id, count($colName1) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a1 
        where (length(trim(regexp_replace($colName1,' ', '')))=0 OR $colName1 is NULL OR $colName1 ="0000") group by a1.bhi_home_plan_id order by a1.bhi_home_plan_id""").createOrReplaceTempView("query2Df")
   
      val result2 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName1" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
"$con1" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,"$currdate1" as load_date from totalCntDF a inner join query2Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)

      result2.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")

   }

   //===========================================   
   //=========================================== Claim
   
   test("FCD - Claim Counts") {
    val subjtArea = "FCD"
    val testCase = "Claim Counts"

    val totalCounts = sql(f""" select bhi_home_plan_id,count(*) as totalCounts 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_HDR group by bhi_home_plan_id order by bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

      
      val colName = List("NPI_BILLG_PROV_ID","NPI_RNDRG_PROV_ID","BILLG_PROV_ID","RNDRG_PROV_ID","billg_prov_ZIP_CD","rndrg_prov_ZIP_CD","CLM_MBR_ZIP_CD")
      
      colName.foreach(colName =>{
       val con = "NULL or Space or 99999s"
       
       val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_HDR a1 
         where (length(trim(regexp_replace($colName,' ', '')))=0 OR $colName is NULL OR $colName LIKE '%%99999%%' ) group by a1.bhi_home_plan_id 
         order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")
         
       val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
      "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
      "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)
    
      result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")
   
      })
      
   }
   
   //===========================================

   test("Pharmacy - Claim Member Zip Code Counts") {
    val subjtArea = "Pharmacy"
    val testCase = "Claim Member Zip Code"

    val totalCounts = sql(f""" select bhi_home_plan_id,count(*) as totalCounts 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm group by bhi_home_plan_id order by bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

      
      val colName = "CLM_MBR_ZIP_CD"
      val con = "NULL or Space or 99999s"
       
      val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm a1 
         where (length(trim(regexp_replace($colName,' ', '')))=0 OR $colName is NULL OR $colName LIKE '%%99999%%' ) group by a1.bhi_home_plan_id 
         order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")
         
      val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
      "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
      "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)
    
      result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")
    
      
   }
   
   //===========================================
   
   test("FCH - Claim Member Zip Code Counts") {
    val subjtArea = "FCH"
    val testCase = "Claim Member Zip Code"

    val totalCounts = sql(f""" select bhi_home_plan_id,count(*) as totalCounts 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr group by bhi_home_plan_id order by bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

      
      val colName = "CLM_MBR_ZIP_CD"
      val con = "NULL or Space or 99999s"
       
      val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr a1 
         where (length(trim(regexp_replace($colName,' ', '')))=0 OR $colName is NULL OR $colName LIKE '%%99999%%' ) group by a1.bhi_home_plan_id 
         order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")
         
      val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
      "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
      "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)
    
      result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")
    
      
   }
   
   //===========================================
   
   test("FCH - Denied Claim Payment Status") {
    val subjtArea = "FCH"
    val testCase = "Denied Claim Payment Status"

    val totalCounts = sql(f""" select bhi_home_plan_id,count(*) as totalCounts 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where clm_paymnt_stts_cd='D' group by bhi_home_plan_id order by bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

      
      val colName = "CLM_PAYMNT_STTS_CD"
      val con = "clm_paymnt_stts_cd=D non_cvrd_amt>0"
       
      val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr a1 
         where a1.clm_paymnt_stts_cd='D' and a1.non_cvrd_amt>0 group by a1.bhi_home_plan_id 
         order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")
         
      val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
      "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
      "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)
    
      result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")
    
      
   }
   
   //===========================================
   /*
   test("FCH - Birth Weight Code Counts") {
    val subjtArea = "FCH"
    val testCase = "Birth Weight Code Counts"

    val totalCounts = sql(f""" select bhi_home_plan_id,count(*) as totalCounts 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where clm_paymnt_stts_cd='D' group by bhi_home_plan_id order by bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

      
      val colName = "CLM_PAYMNT_STTS_CD"
      val con = "clm_paymnt_stts_cd=D non_cvrd_amt>0"
       
      val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr a1 
         where a1.clm_paymnt_stts_cd='D' and a1.non_cvrd_amt>0 group by a1.bhi_home_plan_id 
         order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")
         
      val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
      "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
      "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)
    
      result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")
    
      
   }
   */
   //===========================================
   
   test("POS - Claim Counts") {
    val subjtArea = "POS"
    val testCase = "Claim Counts"

    val totalCounts = sql(f""" select bhi_home_plan_id,count(*) as totalCounts 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS group by bhi_home_plan_id order by bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

      
      val colName = List("NPI_BILLG_PROV_ID","NPI_RNDRG_PROV_ID","BILLG_PROV_ID","RNDRG_PROV_ID","billg_prov_ZIP_CD","rndrg_prov_ZIP_CD","CLM_MBR_ZIP_CD")
      
      colName.foreach(colName =>{
       val con = "NULL or Space or 99999s"
       
       val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS a1 
         where (length(trim(regexp_replace($colName,' ', '')))=0 OR $colName is NULL OR $colName LIKE '%%99999%%' ) group by a1.bhi_home_plan_id 
         order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")
         
       val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
      "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
      "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)
    
      result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")
   
      })
      
   }
   
   //===========================================
   
   test("POS - Host Plan ID Counts") {
    val subjtArea = "POS"
    val testCase = "Host Plan ID Counts"

    val totalCounts = sql(f""" select bhi_home_plan_id,count(*) as totalCounts 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS group by bhi_home_plan_id order by bhi_home_plan_id """).createOrReplaceTempView("totalCntDF")

      
      val colName = "HOST_PLAN_ID"
      val con = "HOM and Non-HOM Counts"
       
       val query1 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS a1 
         where a1.host_plan_id = "HOM" group by a1.bhi_home_plan_id 
         order by a1.bhi_home_plan_id""").createOrReplaceTempView("query1Df")
         
       val result1 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
      "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
      "$currdate1" as load_date from totalCntDF a inner join query1Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)
    
      result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")
   
      val query2 = sql(f""" select a1.bhi_home_plan_id, count($colName) as col_cnts from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS a1 
         where a1.host_plan_id <> "HOM" group by a1.bhi_home_plan_id 
         order by a1.bhi_home_plan_id""").createOrReplaceTempView("query2Df")
         
       val result2 = sql(f""" select "$subjtArea" as subjt_area, "$testCase" as test_case, "$colName" as col_name, a.bhi_home_plan_id, a.totalCounts as total_col_cnts, 
      "$con" as cndtn_on_col, b.col_cnts as col_cnts, ((b.col_cnts/a.totalCounts)*100) as col_prcntg, null as trshld,
      "$currdate1" as load_date from totalCntDF a inner join query2Df b on a.bhi_home_plan_id=b.bhi_home_plan_id order by a.bhi_home_plan_id """)
    
      result2.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_dq_rslt_stats ")
   
      
   }
   
   //===========================================
   
   

      
}
