package com.anthem.hca.ndw.tests

import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import org.apache.spark.sql._
import java.util.Calendar
import java.util.Date
import java.text.SimpleDateFormat

object ClaimAdjKeysTest {

  def main(args: Array[String]) {

    (new ClaimAdjKeysTest(args(0), args(1), args(2), args(3))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class ClaimAdjKeysTest(dbname : String, startDt: String, endDt: String, mbrTbl: String) extends FunSuite  {
  
     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
  
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val spark = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import spark.implicits._
      import spark.sql

    spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode", "INFER_ONLY")
    spark.conf.set("spark.sql.crossJoin.enabled", "true")

val cll = spark.sql(""" select distinct cdh_load_log_key from """+dbname+f"""_pcandw1ph_nogbd_r000_in.CDH_LOAD_LOG
where from_unixtime(unix_timestamp(load_end_dtm,'yyyy:MM:dd HH:mm:ss'))>to_date("$startDt") and 
from_unixtime(unix_timestamp(load_end_dtm,'yyyy:MM:dd HH:mm:ss'))<=to_date("$endDt") and pblsh_ind="Y" """).createOrReplaceTempView("cllDF")
  
//CLM Table

val a = spark.sql("""
select distinct trim(CLM.clm_adjstmnt_key) as clm_adjstmnt_key, 
trim(CLM.cdh_updtd_load_log_key) as cdh_updtd_load_log_key, "CLM" as clm_tbl_nm from """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM CLM
inner join cllDF AXL
on trim(CLM.cdh_updtd_load_log_key)=trim(AXL.cdh_load_log_key) 
where AXL.cdh_load_log_key is NOT NULL and
CLM.SRVC_RNDRG_TYPE_CD IN('PHYSN','PANCL') AND 
CLM.CLM_ITS_HOST_CD not in ('HOST', 'JAACL')
""")

//CLM_LINE

val b = spark.sql("""
select distinct trim(CLM.clm_adjstmnt_key) as clm_adjstmnt_key, 
trim(CLM.cdh_updtd_load_log_key) as cdh_updtd_load_log_key, "CLM_LINE" as clm_tbl_nm from """+dbname+f"""_pcandw1ph_nogbd_r000_in.CLM_LINE CLM 
inner join cllDF AXL
on trim(CLM.cdh_updtd_load_log_key)=trim(AXL.cdh_load_log_key) 
where AXL.cdh_load_log_key is NOT NULL and
CLM.CLM_LINE_SRVC_STRT_DT BETWEEN to_date('01-01-2015') AND to_date('$endDt')
""")


//CLM Paid

val c = spark.sql("""
select distinct trim(CLM.clm_adjstmnt_key) as clm_adjstmnt_key, 
trim(CLM.cdh_updtd_load_log_key) as cdh_updtd_load_log_key, "CLM_PAID" as clm_tbl_nm from """+dbname+f"""_pcandw1ph_nogbd_r000_in.CLM_PAID CLM 
inner join cllDF AXL
on trim(CLM.cdh_updtd_load_log_key)=trim(AXL.cdh_load_log_key) 
where AXL.cdh_load_log_key is NOT NULL and
CLM.GL_POST_DT BETWEEN to_date('01-01-2015') AND to_date('$endDt')
""")



//CLM MAX RVSN

val d = spark.sql("""
select distinct trim(CLM.clm_adjstmnt_key) as clm_adjstmnt_key, 
trim(CLM.cdh_updtd_load_log_key) as cdh_updtd_load_log_key, "CLM_MAX_RVSN" as clm_tbl_nm  from """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM_MAX_RVSN CLM 
inner join cllDF AXL
on trim(CLM.cdh_updtd_load_log_key)=trim(AXL.cdh_load_log_key) 
where AXL.cdh_load_log_key is NOT NULL
""")


val result = a.union(b).union(c).union(d).distinct()
result.write.mode("overwrite").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_cdl_clmadj_key_tmp")

val clm_tables= List("CLM_ADDNL",
"CLM_LINE_COA",
"CLM_LINE_CDHP",
"CLM_LINE_TOS",
"CLM_LINE_HCS_MDFR",
"CLM_ICD_PROC",
"CLM_LINE_DIAG",
"CLM_PROV",
"CLM_LINE_PROV",
"CLM_LINE_EOB",
"FCLTY_CLM",
"DRG_GRPR",
"PHRMCY_CLM_LINE",
"ESTMTD_PHRMCY_CLM_LINE")


clm_tables.foreach(clm_tables => {

val result1 = spark.sql(f""" select trim(CLM.clm_adjstmnt_key) as clm_adjstmnt_key, 
trim(CLM.cdh_updtd_load_log_key) as cdh_updtd_load_log_key, "$clm_tables" as clm_tbl_nm from """+dbname+f"""_pcandw1ph_nogbd_r000_in.$clm_tables CLM
left outer join cllDF AXL
on trim(CLM.cdh_updtd_load_log_key)=trim(AXL.cdh_load_log_key)
where AXL.cdh_load_log_key is NOT NULL """)

result1.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_cdl_clmadj_key_tmp")

}
)

  val finalCDC = spark.sql(""" select distinct CLADJ.clm_adjstmnt_key, SUPP.mbr_key, CLADJ.cdh_updtd_load_log_key, CLADJ.clm_tbl_nm 
  from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_ta_cdl_clmadj_key_tmp CLADJ 
  left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM CLM on trim(CLADJ.clm_adjstmnt_key)=trim(CLM.CLM_ADJSTMNT_KEY) 
  left outer join """+dbname+"""_pcandw1ph_nogbd_r000_ou."""+mbrTbl+""" SUPP on trim(CLM.MBR_KEY)=trim(SUPP.MBR_KEY) 
  where CLM.CLM_ADJSTMNT_KEY is not NULL and SUPP.MBR_KEY is not NULL """)
   
  finalCDC.write.mode("overwrite").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_cdl_clmadj_key")
   
}