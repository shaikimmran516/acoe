package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Error_NCF_CARE_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Error_NCF_CARE_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_Error_NCF_CARE_TGT(dbname : String, env: String) extends FunSuite  {

	   val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())

     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Error"
      val prcss = "NCF_CARE"

   test("NCF Care Error - Check Error Code when Consistent Member ID contains spaces - 001") {

     val id = Array("001")
     val name = Array("Test case : Check Error Code when Consistent Member ID contains spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where a.clmn_nm="CNSSTNT_MBR_ID" and length(trim(b.cnsstnt_mbr_id))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='CNSSTNT_MBR_ID' and length(trim(b.cnsstnt_mbr_id))=0")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='CNSSTNT_MBR_ID' and length(trim(b.cnsstnt_mbr_id))=0")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }
	   }
 
  
  //============================================================   
      
	  test("NCF Care Error - Check Error Code when ITS Subscriber ID contains spaces  - 002") {

     val id = Array("002")
     val name = Array("Test case : Check Error Code when ITS Subscriber ID contains spaces ")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where a.clmn_nm="ITS_SBSCRBR_ID" and length(trim(b.its_sbscrbr_id))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='ITS_SBSCRBR_ID' and length(trim(b.its_sbscrbr_id))=0 ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='ITS_SBSCRBR_ID' and length(trim(b.its_sbscrbr_id))=0 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }
	  }
 
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when ITS Subscriber ID are not AlphaNumeric - 003") {

     val id = Array("003")
     val name = Array("Test case : Check Error Code when ITS Subscriber ID are not AlphaNumeric ")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where a.clmn_nm="ITS_SBSCRBR_ID" and substring(b.its_sbscrbr_id,0,3) LIKE '%[^A-z0-9]%'  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("305") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join  '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='ITS_SBSCRBR_ID' and substring(b.its_sbscrbr_id,0,3) LIKE '%[^A-z0-9]%' ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join  '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='ITS_SBSCRBR_ID' and substring(b.its_sbscrbr_id,0,3) LIKE '%[^A-z0-9]%' ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  
	  test("NCF Care Error - Check Error Code when ITS Subscriber ID are all Numeric - 004") {

     val id = Array("004")
     val name = Array("Test case : Check Error Code when ITS Subscriber ID are all Numeric ")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where a.clmn_nm="ITS_SBSCRBR_ID" and substring(b.its_sbscrbr_id,0,3) LIKE '%[0-9]%' """)

    if (result.count == 0 || (result.collectAsList.toString.contains("305") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where a.clmn_nm='ITS_SBSCRBR_ID' substring(b.its_sbscrbr_id,0,3) LIKE '%[0-9]%'")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where a.clmn_nm='ITS_SBSCRBR_ID' substring(b.its_sbscrbr_id,0,3) LIKE '%[0-9]%'")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Member ID contains spaces - 005") {

     val id = Array("005")
     val name = Array("Test case : Check Error Code when Member ID contains spaces ")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where a.clmn_nm="MBR_ID" and length(trim(b.mbr_id))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where a.clmn_nm='MBR_ID' and length(trim(b.mbr_id))=0")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where a.clmn_nm='MBR_ID' and length(trim(b.mbr_id))=0")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Home Plan ID contains spaces - 006") {

     val id = Array("006")
     val name = Array("Test case : Check Error Code when Home Plan ID contains spaces ")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where a.clmn_nm="BHI_HOME_PLAN_ID" and length(trim(b.bhi_home_plan_id))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303","306") && result.count() >= 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where a.clmn_nm='BHI_HOME_PLAN_ID' and length(trim(b.bhi_home_plan_id))=0")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where a.clmn_nm='BHI_HOME_PLAN_ID' and length(trim(b.bhi_home_plan_id))=0")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Home Plan ID not found in Reference table - 007") {

     val id = Array("007")
     val name = Array("Test case : Check Error Code when Home Plan ID not found in Reference table")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
      """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
        where a.clmn_nm="BHI_HOME_PLAN_ID" and b.bhi_home_plan_id NOT IN (select distinct r.bhi_home_plan_id from 
        """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd r where r.bhi_home_plan_id in 
          ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')) """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303","306") && result.count() >= 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where a.clmn_nm='BHI_HOME_PLAN_ID' and b.bhi_home_plan_id NOT IN (select distinct r.bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd r where r.bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where a.clmn_nm='BHI_HOME_PLAN_ID' and b.bhi_home_plan_id NOT IN (select distinct r.bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd r where r.bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Host Plan ID contains spaces - 008") {

     val id = Array("008")
     val name = Array("Test case : Check Error Code when Host Plan ID contains spaces ")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where a.clmn_nm="BHI_HOST_PLAN_ID" and length(trim(b.bhi_host_plan_id))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303","306") && result.count() >= 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='BHI_HOST_PLAN_ID' and length(trim(b.bhi_host_plan_id))=0")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='BHI_HOST_PLAN_ID' and length(trim(b.bhi_host_plan_id))=0")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Host Plan ID not found in Reference table - 009") {

     val id = Array("009")
     val name = Array("Test case : Check Error Code when Host Plan ID not found in Reference table")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
      """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
        where a.clmn_nm="BHI_HOST_PLAN_ID" and b.bhi_host_plan_id NOT IN (select distinct r.host_plan_id_cd from 
        """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_host_plan_id_inbnd r) """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303","306") && result.count() >= 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join  '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where a.clmn_nm='BHI_HOST_PLAN_ID' and b.bhi_host_plan_id NOT IN (select distinct r.host_plan_id_cd from  '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_host_plan_id_inbnd r)")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join  '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where a.clmn_nm='BHI_HOST_PLAN_ID' and b.bhi_host_plan_id NOT IN (select distinct r.host_plan_id_cd from  '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_host_plan_id_inbnd r)")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Payee Provider ID contains spaces - 010") {

     val id = Array("010")
     val name = Array("Test case : Check Error Code when Payee Provider ID contains spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PAYEE_PROV_ID" and length(trim(b.payee_prov_id))=0  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_ID' and length(trim(b.payee_prov_id))=0 ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where a.clmn_nm='PAYEE_PROV_ID' and length(trim(b.payee_prov_id))=0 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Payee NPI Provider ID contains spaces  - 011") {

     val id = Array("011")
     val name = Array("Test case : Check Error Code when Payee NPI Provider ID contains spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PAYEE_PROV_NPI" and length(trim(b.payee_prov_npi))=0  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_NPI' and length(trim(b.payee_prov_npi))=0  ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_NPI' and length(trim(b.payee_prov_npi))=0 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	   
	  test("NCF Care Error - Check Error Code when Payee NPI Provider ID are not Numeric - 012") {

     val id = Array("012")
     val name = Array("Test case : Check Error Code when Payee NPI Provider ID are not Numeric  ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PAYEE_PROV_NPI" and b.payee_prov_npi LIKE '%[^0-9]%'  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("310") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_NPI' and b.payee_prov_npi LIKE '%[^0-9]%'  ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_NPI' and b.payee_prov_npi LIKE '%[^0-9]%' ' ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Payee Provider First Name+Last Name contains spaces and Organisation Name contains spaces - 013") {

     val id = Array("013")
     val name = Array("Test case : Check Error Code when Payee Provider First Name+Last Name contains spaces and Organisation Name contains spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PAYEE_PROV_FRST_NM"  and length(trim(b.payee_prov_frst_nm))=0 and length(trim(b.payee_prov_last_nm))=0 and 
length(trim(b.prov_org_nm))=0  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_FRST_NM' and length(trim(b.payee_prov_frst_nm))=0 and length(trim(b.payee_prov_last_nm))=0 and length(trim(b.prov_org_nm))=0 ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_FRST_NM' and length(trim(b.payee_prov_frst_nm))=0 and length(trim(b.payee_prov_last_nm))=0 and length(trim(b.prov_org_nm))=0 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Payee Provider First Name contains spaces and Last Name is not spaces- 014") {

     val id = Array("014")
     val name = Array("Test case : Check Error Code when Payee Provider First Name contains spaces and Last Name is not spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PAYEE_PROV_FRST_NM"  and length(trim(b.payee_prov_frst_nm))=0 and length(trim(b.payee_prov_last_nm))>=1  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_FRST_NM'  and length(trim(b.payee_prov_frst_nm))=0 and length(trim(b.payee_prov_last_nm))>=1 ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_FRST_NM'  and length(trim(b.payee_prov_frst_nm))=0 and length(trim(b.payee_prov_last_nm))>=1")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Payee Provider Last Name+First Name contains spaces and Organisation Name contains spaces  - 015") {

     val id = Array("015")
     val name = Array("Test case : Check Error Code when Payee Provider Last Name+First Name contains spaces and Organisation Name contains spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PAYEE_PROV_LAST_NM" and length(trim(b.payee_prov_frst_nm))=0 and length(trim(b.payee_prov_last_nm))=0 and 
length(trim(b.prov_org_nm))=0  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_LAST_NM' and length(trim(b.payee_prov_frst_nm))=0 and length(trim(b.payee_prov_last_nm))=0 and length(trim(b.prov_org_nm))=0 ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_LAST_NM' and length(trim(b.payee_prov_frst_nm))=0 and length(trim(b.payee_prov_last_nm))=0 and length(trim(b.prov_org_nm))=0 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Payee Provider Last Name+Organisation Name contains spaces and First Name is not Spaces - 016") {

     val id = Array("016")
     val name = Array("Test case : Check Error Code when Payee Provider Last Name+Organisation Name contains spaces and First Name is not Spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PAYEE_PROV_LAST_NM"  and length(trim(b.payee_prov_frst_nm))>=1 and length(trim(b.payee_prov_last_nm))=0 and 
length(trim(b.prov_org_nm))=0  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_LAST_NM'  and length(trim(b.payee_prov_frst_nm))>=1 and length(trim(b.payee_prov_last_nm))=0 and length(trim(b.prov_org_nm))=0")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYEE_PROV_LAST_NM'  and length(trim(b.payee_prov_frst_nm))>=1 and length(trim(b.payee_prov_last_nm))=0 and length(trim(b.prov_org_nm))=0")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	 test("NCF Care Error - Check Error Code when  Provider Organisation Name contains spaces and First Name+Last Name contains spaces - 017") {

     val id = Array("017")
     val name = Array("Test case : Check Error Code when Provider Organisation Name contains spaces and First Name+Last Name contains spaces")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PROV_ORG_NM"  and length(trim(b.payee_prov_frst_nm))=0 and length(trim(b.payee_prov_last_nm))=0 and length(trim(b.prov_org_nm))=0  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_ORG_NM'  and length(trim(b.payee_prov_frst_nm))=0 and length(trim(b.payee_prov_last_nm))=0 and length(trim(b.prov_org_nm))=0 ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_ORG_NM'  and length(trim(b.payee_prov_frst_nm))=0 and length(trim(b.payee_prov_last_nm))=0 and length(trim(b.prov_org_nm))=0 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Provider Street Address 1 contains spaces - 018") {

     val id = Array("018")
     val name = Array("Test case : Check Error Code when Provider Street Address 1 contains spaces")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PROV_STR_ADRS_1_TXT" and length(trim(b.prov_str_adrs_1_txt))=0  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_STR_ADRS_1_TXT' and length(trim(b.prov_str_adrs_1_txt))=0  ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_STR_ADRS_1_TXT' and length(trim(b.prov_str_adrs_1_txt))=0  ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Provider City contains spaces - 019") {

     val id = Array("019")
     val name = Array("Test case : Check Error Code when Provider City contains spaces - 019")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PROV_CITY_NM" and length(trim(b.prov_city_nm))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_CITY_NM' and length(trim(b.prov_city_nm))=0 ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_CITY_NM' and length(trim(b.prov_city_nm))=0 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Provider State contains spaces - 020") {

     val id = Array("020")
     val name = Array("Test case : Check Error Code when Provider State contains spaces")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PROV_ST_CD" and length(trim(b.prov_st_cd))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303","307") && result.count() >= 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_ST_CD' and length(trim(b.prov_st_cd))=0  ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_ST_CD' and length(trim(b.prov_st_cd))=0 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Provider State not in list of Valid State Codes - 021") {

     val id = Array("021")
     val name = Array("Test case : Check Error Code when Provider State not in list of Valid State Codes")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PROV_ST_CD" and b.prov_st_cd NOT IN (select distinct r.st_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd r)""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303","307") && result.count() >= 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_ST_CD' and b.prov_st_cd NOT IN (select distinct r.st_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd r)")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_ST_CD' and b.prov_st_cd NOT IN (select distinct r.st_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd r)")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  
	  test("NCF Care Error - Check Error Code when Provider ZIP Code contains spaces  - 022") {

     val id = Array("022")
     val name = Array("Test case : Check Error Code when Provider ZIP Code contains spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PROV_ZIP_CD" and length(trim(b.prov_zip_cd))=0  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_ZIP_CD' and length(trim(b.prov_zip_cd))=0 ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_ZIP_CD' and length(trim(b.prov_zip_cd))=0 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Provider ZIP Code not in Refernce Table - 023") {

     val id = Array("023")
     val name = Array("Test case : Check Error Code when Provider ZIP Code not in Refernce Table")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PROV_ZIP_CD" and b.prov_zip_cd  NOT IN (select distinct r.zip_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd r) """)

    if (result.count == 0 || (result.collectAsList.toString.contains("409") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_ZIP_CD' and b.prov_zip_cd  NOT IN (select distinct r.zip_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd r)")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PROV_ZIP_CD' and b.prov_zip_cd  NOT IN (select distinct r.zip_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd r)")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Performance Cycle Begin Date contains spaces - 024") {

     val id = Array("024")
     val name = Array("Test case : Check Error Code when Performance Cycle Begin Date contains spaces")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PRFRMN_CYCL_STRT_DT" and length(trim(b.prfrmn_cycl_strt_dt))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PRFRMN_CYCL_STRT_DT' and length(trim(b.prfrmn_cycl_strt_dt))=0")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PRFRMN_CYCL_STRT_DT' and length(trim(b.prfrmn_cycl_strt_dt))=0")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Performance Cycle End Date contains spaces - 025") {

     val id = Array("025")
     val name = Array("Test case : Check Error Code when Performance Cycle End Date contains spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PRFRMN_CYCL_END_DT" and length(trim(b.prfrmn_cycl_end_dt))=0  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PRFRMN_CYCL_END_DT' and length(trim(b.prfrmn_cycl_end_dt))=0")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PRFRMN_CYCL_END_DT' and length(trim(b.prfrmn_cycl_end_dt))=0")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Payee Payment Amount contains spaces - 026") {

     val id = Array("026")
     val name = Array("Test case : Check Error Code when Payee Payment Amount contains spacess ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PAYE_PAYMNT_AMT" and length(trim(b.paye_paymnt_amt))=0  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYE_PAYMNT_AMT' and length(trim(b.paye_paymnt_amt))=0")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYE_PAYMNT_AMT' and length(trim(b.paye_paymnt_amt))=0")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Payment Begin Date contains spaces - 027") {

     val id = Array("027")
     val name = Array("Test case : Check Error Code when Payment Begin Date contains spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PAYMNT_BGN_DT" and length(trim(b.paymnt_bgn_dt))=0  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYMNT_BGN_DT' and length(trim(b.paymnt_bgn_dt))=0")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYMNT_BGN_DT' and length(trim(b.paymnt_bgn_dt))=0")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Payment End Date contains spaces - 028") {

     val id = Array("028")
     val name = Array("Test case : Check Error Code when Payment End Date contains spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PAYMNT_END_DT" and length(trim(b.paymnt_end_dt))=0  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYMNT_END_DT' and length(trim(b.paymnt_end_dt))=0")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYMNT_END_DT' and length(trim(b.paymnt_end_dt))=0")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  
	  test("NCF Care Error - Check Error Code when Value-Based Program ID contains spaces - 029") {

     val id = Array("029")
     val name = Array("Test case : Check Error Code when Value-Based Program ID contains spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="VBP_ID" and length(trim(b.vbp_id))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303","301") && result.count() >= 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='VBP_ID' and length(trim(b.vbp_id))=0 ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='VBP_ID' and length(trim(b.vbp_id))=0 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Value-Based Program ID is not equal to 7 Characters  - 030") {

     val id = Array("030")
     val name = Array("Test case : Check Error Code when Value-Based Program ID is not equal to 7 Characters ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="VBP_ID" and length(trim(b.vbp_id))>0 and length(trim(b.vbp_id))<7  """)

    if (result.count == 0 || (result.collectAsList.toString.contains("301") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='VBP_ID' and length(trim(b.vbp_id))>0 and length(trim(b.vbp_id))<7  ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='VBP_ID' and length(trim(b.vbp_id))>0 and length(trim(b.vbp_id))<7 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Non-claim financial payment type contains spaces - 031") {

     val id = Array("031")
     val name = Array("Test case : Check Error Code when Non-claim financial payment type contains spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="NCF_PAYMNT_TYPE_CD" and length(trim(b.ncf_paymnt_type_cd))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='NCF_PAYMNT_TYPE_CD' and length(trim(b.ncf_paymnt_type_cd))=0 ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='NCF_PAYMNT_TYPE_CD' and length(trim(b.ncf_paymnt_type_cd))=0 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ 
	  
	  test("NCF Care Error - Check Error Code when Non-claim financial payment type is not 'C' - 032") {

     val id = Array("032")
     val name = Array("Test case : Check Error Code when Non-claim financial payment is not 'C' ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="NCF_PAYMNT_TYPE_CD" and b.ncf_paymnt_type_cd <> "C" """)

    if (result.count == 0 || (result.collectAsList.toString.contains("305") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='NCF_PAYMNT_TYPE_CD' and b.ncf_paymnt_type_cd <> 'C' ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='NCF_PAYMNT_TYPE_CD' and b.ncf_paymnt_type_cd <> 'C' ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================ Done
	 
	  test("NCF Care Error - Check Error Code when Payment Category Type contains spaces - 033") {

     val id = Array("033")
     val name = Array("Test case : Check Error Code when Payment Category Type contains spaces ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PAYMNT_TYPE_CD" and length(trim(b.paymnt_type_cd))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYMNT_TYPE_CD' and length(trim(b.paymnt_type_cd))=0 ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYMNT_TYPE_CD' and length(trim(b.paymnt_type_cd))=0 ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
	  
	   test("NCF Care Error - Check Error Code when Payment Category Type is not 'OA' or 'CA' - 034") {

     val id = Array("034")
     val name = Array("Test case : Check Error Code when Payment Category Type is not 'OA' or 'CA' ")


    val result = sqlContext.sql(""" select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join 
"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key 
where a.clmn_nm="PAYMNT_TYPE_CD" and b.paymnt_type_cd NOT IN ('OA','CA') """)

    if (result.count == 0 || (result.collectAsList.toString.contains("305") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYMNT_TYPE_CD' and b.paymnt_type_cd NOT IN ('QA','CA') ")
       val data = Array("Error Code :  No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_non_clm_fncl_care_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where a.clmn_nm='PAYMNT_TYPE_CD' and b.paymnt_type_cd NOT IN ('QA','CA') ")
       val data = Array("Error Code :  Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/NcfCare/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
	  
}