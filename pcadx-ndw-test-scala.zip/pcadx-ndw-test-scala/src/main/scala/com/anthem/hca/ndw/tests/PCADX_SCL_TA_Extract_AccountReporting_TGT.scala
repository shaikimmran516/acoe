package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import java.util.Date
import java.text.SimpleDateFormat

object PCADX_SCL_TA_Extract_AccountReporting_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_AccountReporting_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}


class PCADX_SCL_TA_Extract_AccountReporting_TGT(dbname : String, env: String) extends FunSuite  {
  
     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
  
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Extract"
      val prcss = "AccountReporting"
  

 
  test("AccountReport -Validate One record for each BHI Home Plan ID and Home Product ID and Account ID- 001") {
    
     val id = Array("001")
     val name = Array("Test case : Validate One record for each BHI Home Plan ID and Home Product ID and Account ID")
    
    val result = sqlContext.sql("""select bhi_home_plan_id ,home_plan_prod_id,acct_id,count(*) as count from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg group by bhi_home_plan_id,home_plan_prod_id,acct_id""")
    result.createOrReplaceTempView("resultDF")
    
    val invalid = sqlContext.sql("""select * from resultDF where count > 1 """)
    
    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id ,home_plan_prod_id,acct_id,count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg group by bhi_home_plan_id,home_plan_prod_id,acct_id) where count > 1  ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID','COUNT'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from (select bhi_home_plan_id ,home_plan_prod_id,acct_id,count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg group by bhi_home_plan_id,home_plan_prod_id,acct_id) where count > 1  ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID','COUNT' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
     //===========================================
  

  test("AccountReport -Validate that all the records have the correct [BHI Home Plan ID] as per Anthem - 002") {

    val id = Array("002")
     val name = Array("Test case : Validate that all the records have the correct [BHI Home Plan ID] as per Anthem")

    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,acct_id,err_id,exclsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where
    bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748')  """)
     
         
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,acct_id,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748')   ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID','ERR_ID','EXCLSN_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,acct_id,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748')   ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID','ERR_ID','EXCLSN_ID' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================

  test("AccountReport -Validate that BHI Home Plan ID is not NULL or contains blank spaces - 003") {
    
    val id = Array("003")
     val name = Array("Test case : Validate that BHI Home Plan ID is not NULL or contains blank spaces")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,acct_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg
        where length(trim(regexp_replace(coalesce(bhi_home_plan_id, "")," ", "")))=0  """)
       
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0   ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0   ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================

  test("AccountReport -Validate that Home Plan ProductID field is not NULL or contains blank spaces  - 004") {
    
    val id = Array("004")
     val name = Array("Test case : Validate that Home Plan ProductID field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,acct_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg
        where length(trim(regexp_replace(coalesce(home_plan_prod_id, "")," ", "")))=0  """)
        
    
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where length(trim(regexp_replace(coalesce(home_plan_prod_id, ''),' ', '')))=0   ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where length(trim(regexp_replace(coalesce(home_plan_prod_id, ''),' ', '')))=0   ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    
  }
  
  //===========================================
  
  test("AccountReport -Validate that Account field is not NULL or contains blank spaces - 005") {
    
    val id = Array("005")
     val name = Array("Test case : Validate that Account field is not NULL or contains blank spaces")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,acct_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg
        where length(trim(regexp_replace(coalesce(acct_id, "")," ", "")))=0 """)
        
    
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where length(trim(regexp_replace(coalesce(acct_id, ''),' ', '')))=0   ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where length(trim(regexp_replace(coalesce(acct_id, ''),' ', '')))=0   ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
  
  //===========================================

  test("AccountReport -Validate that ReportingAccountID field is not NULL or contains blank spaces  - 006") {
   
    val id = Array("006")
     val name = Array("Test case : Validate that ReportingAccountID field is not NULL or contains blank spaces")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,rptg_acct_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg
        where length(trim(regexp_replace(coalesce(rptg_acct_id, "")," ", "")))=0 """)
    
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,rptg_acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where length(trim(regexp_replace(coalesce(rptg_acct_id, ''),' ', '')))=0   ")
      val data = Array("'BHI HPID','PRODUCT_ID','REPORT_ACCOUNT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,rptg_acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where length(trim(regexp_replace(coalesce(rptg_acct_id, ''),' ', '')))=0   ")
      val data = Array("'BHI HPID','PRODUCT_ID','REPORT_ACCOUNT_ID' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  //===========================================
  
  test("AccountReport -Validate that Account Name field is not NULL or contains blank spaces - 007") {
    
    val id = Array("007")
     val name = Array("Test case : Validate that Account Name field is not NULL or contains blank spaces")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,acct_id,rptg_acct_nm from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg
        where length(trim(regexp_replace(coalesce(rptg_acct_nm, "")," ", "")))=0 """)
        
     if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select bhi_home_plan_id,home_plan_prod_id,acct_id,rptg_acct_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where length(trim(regexp_replace(coalesce(rptg_acct_nm, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID','ACCOUNT_NAME'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select bhi_home_plan_id,home_plan_prod_id,acct_id,rptg_acct_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where length(trim(regexp_replace(coalesce(rptg_acct_nm, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID','ACCOUNT_NAME' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  //===========================================
  
  test("AccountReport -Validate if BHI Home Plan ID does not contains any special character - 008") {
   
    val id = Array("008")
     val name = Array("Test case : Validate if BHI Home Plan ID does not contains any special character")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,acct_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a
      where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%'""")

          
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select bhi_home_plan_id,home_plan_prod_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%' ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select bhi_home_plan_id,home_plan_prod_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%' ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================

  test("AccountReport -Validate that Home Plan ProductID field does not contains Special Characters - 009") {
    
    val id = Array("009")
     val name = Array("Test case : Validate that Home Plan ProductID field does not contains Special Characters")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,acct_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a
      where a.home_plan_prod_id  LIKE '%[^A-z0-9]%'""")
    
        
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select bhi_home_plan_id,home_plan_prod_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a where a.home_plan_prod_id  LIKE '%[^A-z0-9]%' ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select bhi_home_plan_id,home_plan_prod_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a where a.home_plan_prod_id  LIKE '%[^A-z0-9]%' ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   
   //===========================================
  
  test("AccountReport -Validate that Account field does not contain Special Characters - 010") {
   
    val id = Array("010")
     val name = Array("Test case : Validate that Account field does not contain Special Characters")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,acct_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a
      where a.acct_id  LIKE '%[^A-z0-9]%'""")
    
        
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a where a.acct_id  LIKE '%[^A-z0-9]%'  ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a where a.acct_id  LIKE '%[^A-z0-9]%'  ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================

  test("AccountReport -Validate that ReportingAccountID field does not contain Special Characters - 011") {
    
    val id = Array("011")
     val name = Array("Test case : Validate that ReportingAccountID field does not contain Special Characters")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,rptg_acct_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a
      where a.rptg_acct_id  LIKE '%[^A-z0-9]%'""")
   
        
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,rptg_acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a where a.rptg_acct_id  LIKE '%[^A-z0-9]%'  ")
      val data = Array("'BHI HPID','PRODUCT_ID','REPORT_ACCOUNT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,rptg_acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a where a.rptg_acct_id  LIKE '%[^A-z0-9]%'  ")
      val data = Array("'BHI HPID','PRODUCT_ID','REPORT_ACCOUNT_ID' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  

   //===========================================
  
  test("AccountReport -Validate that Account Name field does not contain Special Characters - 012") {
    
    val id = Array("012")
     val name = Array("Test case : Validate that Account Name field does not contain Special Characters")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,acct_id,rptg_acct_nm from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a
      where a.rptg_acct_nm  LIKE '%[^A-z0-9]%'""")
    
        
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select bhi_home_plan_id,home_plan_prod_id,acct_id,rptg_acct_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a where a.rptg_acct_nm  LIKE '%[^A-z0-9]%' ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID','ACCOUNT_NAME'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select bhi_home_plan_id,home_plan_prod_id,acct_id,rptg_acct_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg a where a.rptg_acct_nm  LIKE '%[^A-z0-9]%' ")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_ID','ACCOUNT_NAME' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
  
  test("AccountReport - Validate that there are 14 BHI Home Plan ID  - 013") {
    
    val id = Array("013")
     val name = Array("Test case : Validate that there are 14 BHI Home Plan ID ")
     
    val result = sqlContext.sql(""" select count(distinct bhi_home_plan_id) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_acct_rptg """)
    
        
    if (result.collectAsList.toString.contains("14")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_acct_rptg ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_acct_rptg ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //===========================================
  
  test("AccountReport - Validate that all account ids present in PCC are there in Account Reporting extract  - 014") {
    
    val id = Array("014")
     val name = Array("Test case : Validate that all account ids present in PCC are there in Account Reporting extract ")
     
    val result = sqlContext.sql(""" select distinct trim(AR.acct_id) 
                                    from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg AR
                                    left outer join """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct PCC
                                    on trim(AR.acct_id)=trim(PCC.acct_id)
                                    where PCC.acct_id is NULL """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select distinct trim(AR.acct_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg AR left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct PCC on trim(AR.acct_id)=trim(PCC.acct_id) where PCC.acct_id is NULL ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select distinct trim(AR.acct_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg AR left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct PCC on trim(AR.acct_id)=trim(PCC.acct_id) where PCC.acct_id is NULL ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //===========================================
  
  test("AccountReport - Validate that all product ids present in PCC are there in Account Reporting extract  - 015") {
    
    val id = Array("015")
     val name = Array("Test case : Validate that all product ids present in PCC are there in Account Reporting extract ")
     
    val result = sqlContext.sql(""" select distinct trim(AR.home_plan_prod_id) 
                                    from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg AR
                                    left outer join """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct PCC
                                    on trim(AR.home_plan_prod_id)=trim(PCC.home_plan_prod_id)
                                    where PCC.home_plan_prod_id is NULL """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select distinct trim(AR.home_plan_prod_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg AR left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct PCC on trim(AR.home_plan_prod_id)=trim(PCC.home_plan_prod_id) where PCC.home_plan_prod_id is NULL ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select distinct trim(AR.home_plan_prod_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg AR left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct PCC on trim(AR.home_plan_prod_id)=trim(PCC.home_plan_prod_id) where PCC.home_plan_prod_id is NULL ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //===========================================
  
  /*
  test("AccountReport - Validate that the [Reporting Account Name] field values have the correct values as per the PRCHSR_ORG_DMGRPHC.PRCHSR_ORG_NM - 014") {
    
    val id = Array("014")
     val name = Array("Test case : Validate that the [Reporting Account Name] field values have the correct values as per the PRCHSR_ORG_DMGRPHC.PRCHSR_ORG_NM")
    
    val result1 = sqlContext.sql("""Select distinct rptg_acct_nm from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where err_id = '0' and exclsn_ind = 0 """)
    
    val result2 = sqlContext.sql("""Select distinct prchsr_org_nm from """+dbname+"""_pcandw1ph_nogbd_r000_in.prchsr_org_dmgrphc """)
     
    val result = result1.except(result2)
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : Select distinct rptg_acct_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where err_id = '0' and exclsn_ind = 0 and rptg_acct_nm not in (Select distinct prchsr_org_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_in.prchsr_org_dmgrphc) ")
      val data = Array("'Invalid Record of ACCOUNT_NAME'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : Select distinct rptg_acct_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg where err_id = '0' and exclsn_ind = 0 and rptg_acct_nm not in (Select distinct prchsr_org_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_in.prchsr_org_dmgrphc) ")
      val data = Array("ACCOUNT_NAME : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AccountReporting/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  //===========================================
   
  test("AccountReport - Validate Source and Target table - 001") {
       
       val id = Array("NCEAP002")
       val name = Array("Test case : Validate Source and Target table")
     
        ExcelTableValidation.tableCompare("select trim(a.bhi_home_plan_id), trim(b.prod_cf_cd), trim(c.accnt_nbr), trim(c.accnt_nbr), trim(c.prchsr_org_nm) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_home_plan_cd_xwalk_inbnd a  inner join """+dbname+"""_pcandw1ph_nogbd_r000_wh.all_mbr b on trim(a.mbu_cf_cd) = trim(b.mbu_cf_cd)  and trim(a.cmpny_chrt_fld_cd) = trim(b.cmpny_cf_cd) inner join """+dbname+"""_pcandw1ph_nogbd_r000_wh.all_prod c on trim(b.prod_ofrg_key) = trim(c.prod_ofrg_key)", 
       "select trim(bhi_home_plan_id) , trim(home_plan_prod_id), trim(acct_id), trim(rptg_acct_id ), trim(rptg_acct_nm) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg",
       "bcbsa_acct_rptg","bhi_home_plan_id, home_plan_prod_id, acct_id, rptg_acct_id, rptg_acct_nm",sc)

    //assert(1 == 1)
    
  }
  */
  
  
  
}