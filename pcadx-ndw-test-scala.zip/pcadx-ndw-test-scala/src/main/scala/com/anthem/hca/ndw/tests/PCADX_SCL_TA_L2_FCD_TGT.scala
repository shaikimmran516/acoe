package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession

import org.apache.spark.sql.SparkSession
import java.io.File
import org.apache.spark.sql.DataFrame
import com.anthem.hca.ndw.utils.PCADX_SCL_TA_Utilities._
import java.text.SimpleDateFormat
import org.apache.spark.sql.SaveMode
import java.util.Calendar
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel
import java.util.Date
import java.text.SimpleDateFormat



object PCADX_SCL_TA_L2_FCD_TGT {


  
def main(args: Array[String]) {
  


val dbname: String = args(0)
val SUBJ_AREA_NM: String=args(1)
val PRCS_NM: String=args(2)


val appName = "Datapipe from L2 cases for FCD" // we will make this generic going forward

val warehouseLocation = new File("/user/hive/warehouse").getAbsolutePath
val options = Map("path" -> "/user/hive/warehouse")

val spark = SparkSession
.builder()
.appName(appName)
.config("spark.sql.warehouse.dir", warehouseLocation)
.enableHiveSupport()
.getOrCreate()

spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode","INFER_ONLY")
spark.conf.set("spark.sql.crossJoin.enabled","true")

import spark.implicits._
val home_plan_id =spark.sql("select distinct bhi_home_plan_id from "+dbname+"_pcandw1ph_nogbd_r000_wh.bot_bcbsa_plan_sbmsn")
val  home_plan=home_plan_id.select("bhi_home_plan_id").collect().map(_(0)).toList

spark.sql("select count(*) as CNT,bhi_home_plan_id FROM  "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err group by bhi_home_plan_id ").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Error")

spark.sql("SELECT count(*) as CNT,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Total")

spark.sql("SELECT  SUM(CASE WHEN SEL.bnft_paymnt_stts_cd='O' THEN  SEL.CNT ELSE 0 END) AS FacClmDtlBnftPmtSts58,  SUM(CASE WHEN SEL.clm_paymnt_stts_cd='D' THEN  SEL.CNT ELSE 0 END) AS FacClmDtlClmPmtSts60,  SUM(CASE WHEN trim(SEL.rvnu_cd) IN ('NA','') THEN  SEL.CNT ELSE 0 END) AS FacClmDtlRevCd62,bhi_home_plan_id    FROM  (  SELECT 1 AS CNT, bnft_paymnt_stts_cd, clm_paymnt_stts_cd, rvnu_cd,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  WHERE (bnft_paymnt_stts_cd='O' OR clm_paymnt_stts_cd='D' OR trim(rvnu_cd) IN ('NA',''))   ) SEL group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("FCHDetails")

spark.sql("select SUM(CASE WHEN lower(SEL.FIELD_NM)='cpt_hcpcs_cd' THEN SEL.CNT ELSE 0 END) AS FacClmDtlCPTHCPCS57,  SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_paymnt_stts_cd' THEN SEL.CNT ELSE 0 END) AS FacClmDtlClmPmtSts59,  SUM(CASE WHEN lower(SEL.FIELD_NM)='rvnu_cd' THEN SEL.CNT ELSE 0 END) AS FacClmDtlRevCd61,bhi_home_plan_id from (select err_id,1 as CNT ,clmn_nm  as FIELD_NM from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_fclty_clm_dtl' and lower(clmn_nm) in  ('cpt_hcpcs_cd', 'clm_paymnt_stts_cd', 'rvnu_cd')) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl b on  SEL.err_id=b.err_id group by   bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("FCHAud")

// Rule 1-4
home_plan.foreach(bhi_home_plan_id => {


val sqlb=" select a.CNT*100/(b.CNT) as FacClmDtl56 from  (  SELECT  CNT  FROM Error FD where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) a join   (SELECT  CNT  FROM Total FD where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b   "  

val sqlbshow=" select a.CNT*100/(b.CNT) as FacClmDtl56 from  (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err FD where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) a join   (SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl FD where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b   " 

  

var b=spark.sql(sqlb).withColumn("sql",lit(sqlbshow))


//Rule 5

val sqlashow = "select FacClmDtlCPTHCPCS57*100/Total_CNT as FacClmDtlCPTHCPCS57,FacClmDtlClmPmtSts59*100/Total_CNT as FacClmDtlClmPmtSts59,FacClmDtlRevCd61*100/Total_CNT as FacClmDtlRevCd61 from  (select SUM(CASE WHEN lower(SEL.FIELD_NM)='cpt_hcpcs_cd' THEN SEL.CNT ELSE 0 END) AS FacClmDtlCPTHCPCS57,  SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_paymnt_stts_cd' THEN SEL.CNT ELSE 0 END) AS FacClmDtlClmPmtSts59,  SUM(CASE WHEN lower(SEL.FIELD_NM)='rvnu_cd' THEN SEL.CNT ELSE 0 END) AS FacClmDtlRevCd61 from (select err_id,1 as CNT ,clmn_nm  as FIELD_NM from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_fclty_clm_dtl' and lower(clmn_nm) in  ('cpt_hcpcs_cd', 'clm_paymnt_stts_cd', 'rvnu_cd')) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl b on  SEL.err_id=b.err_id where  bhi_home_plan_id='"+bhi_home_plan_id +"') a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"

val sqla = "select FacClmDtlCPTHCPCS57*100/Total_CNT as FacClmDtlCPTHCPCS57,FacClmDtlClmPmtSts59*100/Total_CNT as FacClmDtlClmPmtSts59,FacClmDtlRevCd61*100/Total_CNT as FacClmDtlRevCd61 from  (select * from FCHAud where   bhi_home_plan_id='"+bhi_home_plan_id +"') a cross join (SELECT CNT as Total_CNT  FROM Total FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"




val a=spark.sql(sqla).withColumn("sql",lit(sqlashow))



//Rule 6-9

val sqlcshow = "select FacClmDtlBnftPmtSts58*100/Total_CNT as FacClmDtlBnftPmtSts58,FacClmDtlClmPmtSts60*100/Total_CNT as FacClmDtlClmPmtSts60,FacClmDtlRevCd62*100/Total_CNT as FacClmDtlRevCd62 from  (SELECT  SUM(CASE WHEN SEL.bnft_paymnt_stts_cd='O' THEN  SEL.CNT ELSE 0 END) AS FacClmDtlBnftPmtSts58,  SUM(CASE WHEN SEL.clm_paymnt_stts_cd='D' THEN  SEL.CNT ELSE 0 END) AS FacClmDtlClmPmtSts60,  SUM(CASE WHEN trim(SEL.rvnu_cd) IN ('NA','') THEN  SEL.CNT ELSE 0 END) AS FacClmDtlRevCd62    FROM  (  SELECT 1 AS CNT, bnft_paymnt_stts_cd, clm_paymnt_stts_cd, rvnu_cd  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  WHERE (bnft_paymnt_stts_cd='O' OR clm_paymnt_stts_cd='D' OR trim(rvnu_cd) IN ('NA','')) and     bhi_home_plan_id='"+bhi_home_plan_id +"'  ) SEL)a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"

val sqlc = "select FacClmDtlBnftPmtSts58*100/Total_CNT as FacClmDtlBnftPmtSts58,FacClmDtlClmPmtSts60*100/Total_CNT as FacClmDtlClmPmtSts60,FacClmDtlRevCd62*100/Total_CNT as FacClmDtlRevCd62 from  (SELECT  * from FCHDetails where   bhi_home_plan_id='"+bhi_home_plan_id +"')a cross join (SELECT CNT as Total_CNT  FROM Total FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"


val c=spark.sql(sqlc).withColumn("sql",lit(sqlcshow))






var e=output(spark, TestIDGen(spark,ReportOutput(spark,dbname,a).union(ReportOutput(spark,dbname,b)).union(ReportOutput(spark,dbname,c))),SUBJ_AREA_NM,PRCS_NM, bhi_home_plan_id.toString())

e.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_RSLT")
//e(1).write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_SQL")


})



}
  
  

}