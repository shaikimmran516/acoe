package com.anthem.hca.vbp

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
//import com.holdenkarau.spark.testing.SharedSparkContext
//import com.holdenkarau.spark.testing.RDDComparisons
//import com.holdenkarau.spark.testing.DataFrameSuiteBase
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._
import sys.process._
import java.text.SimpleDateFormat
import java.sql.Timestamp
import org.joda.time._
import org.joda.time.format.DateTimeFormat
import java.util.Calendar
import java.sql.Timestamp
import java.text.SimpleDateFormat
import org.apache.spark.sql.DataFrame
import org.scalatest.exceptions.TestFailedException
import org.scalacheck.Prop
import org.scalacheck.Prop._
import org.scalatest.prop.Checkers
import org.scalacheck.Arbitrary._
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path

object PCADX_SCL_TA_Extract_NCF_CARE_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_NCF_CARE_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }
}

class PCADX_SCL_TA_Extract_NCF_CARE_TGT(dbname: String, env: String) extends FunSuite {

  val now = Calendar.getInstance().getTime()
  val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
  val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
  val currdate = formatter.format(new Date())
  val currdate1 = formatter1.format(new Date())
  val user = System.getProperty("user.name")
  val warehouseLocation = new File("/user/hive/warehouse").getAbsolutePath

  val sc = SparkContext.getOrCreate()
  sc.setLogLevel("ERROR")

  val spark = SparkSession.builder().appName("Automation test cases for VBP NCF Care Catchup")
    .config("spark.sql.warehouse.dir", warehouseLocation)
    .config("spark.sql.parquet.compression.codec", "snappy")
    .config("hive.warehouse.data.skipTrash", "true")
    .config("spark.sql.parquet.writeLegacyFormat", "true").enableHiveSupport().getOrCreate()

  spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode", "INFER_ONLY")
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  spark.conf.set("spark.sql.shuffle.partitons", 2010)
  // spark.conf.set("spark.sql.hive.convertMetastoreParquet", false)

  import spark.implicits._
  import spark.sql

  val llk = spark.sql(f"""select distinct(load_log_key),load_dt from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care order by load_dt desc limit 1""")

  var df1 = llk.select($"load_log_key").rdd.first()(0)

  val subj = "Extract"
  val prcss = "NCFCare"
  val fs = FileSystem.get(sc.hadoopConfiguration)
  val out = "SIT_TRAN_HOME_SOURCE"

  val sday = Calendar.getInstance()
  //val startday=sday.set(Calendar.DATE, sday.getActualMinimum(Calendar.DATE))
  sday.add(Calendar.MONTH, -1)

  val startday = sday.get(Calendar.YEAR) + "-" + "%02d".format(sday.get(Calendar.MONTH).+(1)) + "-" + "%02d".format(sday.getActualMinimum(Calendar.DATE))
  //val endday=sday.set(Calendar.DATE, sday.getActualMaximum(Calendar.DATE))
  val endday = sday.get(Calendar.YEAR) + "-" + "%02d".format(sday.get(Calendar.MONTH).+(1)) + "-" + "%02d".format(sday.getActualMaximum(Calendar.DATE))

  val RUNEND = endday.toString
  val RUNSTART = startday.toString()

  var startdateFnl = ""
  var enddateFnl = ""

  // we dont have to get the dates from AIX table. Instead we can get the last day of the running month in the sql using built in functions - not required for test cycle 3
  val ACTDatesSql1 = sql(f"""Select  strt_dtm,end_dtm  FROM ${dbname}_pcandw1ph_nogbd_r000_wh.BOT_BCBSA_EXTRCT_PRCSG WHERE subj_area_nm = "VBP_BCBSA_NON_CLM_FIN_CC"""")
  if (!ACTDatesSql1.head(1).isEmpty) {
    val actdates = ACTDatesSql1.rdd.map(x => (x.getTimestamp(0), x.getTimestamp(1)))
    val list: List[(Timestamp, Timestamp)] = actdates.collect().toList
    val startdate: List[Timestamp] = list.map(_._1)
    val enddate: List[Timestamp] = list.map(_._2)
    startdateFnl = startdate(0).toString().substring(0, 10)
    enddateFnl = enddate(0).toString().substring(0, 10)
  } else {
    startdateFnl = RUNSTART
    enddateFnl = RUNEND
  }

  print(startdateFnl)
  print(enddateFnl)

  //--------------------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate that MMI Identifier is not NULL - 001") {

    val id = Array("001")

    val name = Array("Validate that MMI Identifier is not NULL - 001")
    val src = (f"""select distinct cnsstnt_mbr_id,pe_id,mmi_id 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id is NULL""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate that Consistent Member ID is not NULL or contains blank spaces - 002") {

    val id = Array("002")

    val name = Array("Validate that Consistent Member ID is not NULL or contains blank spaces - 002")

    val result = spark.sql(s""" select distinct(b.cnsstnt_mbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b where length(trim(regexp_replace(cnsstnt_mbr_id," ",""))) = 0 or cnsstnt_mbr_id is null""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(b.cnsstnt_mbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b where length(trim(regexp_replace(cnsstnt_mbr_id,' ',''))) = 0 or cnsstnt_mbr_id is null")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(b.cnsstnt_mbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b where  length(trim(regexp_replace(cnsstnt_mbr_id,' ',''))) = 0 or cnsstnt_mbr_id is null")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate that ITS Subscriber ID is not NULL or contains blank spaces - 003") {

    val id = Array("003")

    val name = Array("LCLAtrbn - Validate that ITS Subscriber ID is not NULL or contains blank spaces - 003")

    val result = spark.sql(s""" select distinct(its_sbscrbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where length(trim(regexp_replace(its_sbscrbr_id," ", "")))=0 or its_sbscrbr_id is null""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(its_sbscrbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where length(trim(regexp_replace(its_sbscrbr_id,' ', '')))=0 or its_sbscrbr_id is null")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(its_sbscrbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where length(trim(regexp_replace(its_sbscrbr_id,' ', '')))=0 or its_sbscrbr_id is null")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate for Home Plan Member ID is not NULL or contains blank spaces - 004") {

    val id = Array("004")

    val name = Array("Validate that Home Plan Member ID - 004 is not NULL or contains blank spaces")

    val result = spark.sql(s""" select distinct(b.mbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b where length(trim(regexp_replace(mbr_id," ",""))) = 0 or mbr_id is null""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(b.mbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b where length(trim(regexp_replace(mbr_id,' ',''))) = 0 or mbr_id is null")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(b.mbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b where length(trim(regexp_replace(mbr_id,' ',''))) = 0 or mbr_id is null")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate the NDW Home Plan ID - 005") {

    val id = Array("005")

    val name = Array("Validate the NDW Home Plan ID - 005")
    
    val src = (f"""select cnsstnt_mbr_id,pe_id,e.bhi_home_plan_id,'HOME' as member_type 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care e where mmi_id = '' and 
      e.bhi_home_plan_id not in (select distinct(x.bhi_home_plan_id) 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_xwalk x) union all 
      select cnsstnt_mbr_id,pe_id,e.bhi_home_plan_id,'HOST' as member_type 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care e where trim(mmi_id) <> '' and 
      e.bhi_home_plan_id not in (select distinct(x.NDW_PLAN_CD) 
      from ${dbname}_pcandw1ph_nogbd_r000_in.BCBSA_MBR_PROD x)""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate the NDW Host Plan ID - 006") {

    val id = Array("006")

    val name = Array("Validate the NDW Host Plan ID - 006")
    
    val src = (f"""select cnsstnt_mbr_id,pe_id,e.bhi_host_plan_id,'HOST' as member_type 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care e where trim(mmi_id) <> '' and 
      e.bhi_host_plan_id not in (select distinct(x.HOST_PLAN_CD) 
      from ${dbname}_pcandw1ph_nogbd_r000_in.BCBSA_MBR_PROD x)""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate the Payee Provider ID is not NULL or contains blank spaces - 007") {

    val id = Array("007")

    val name = Array("Validate the Payee Provider ID is not NULL or contains blank spaces - 007")
    
    val src = (f"""select cnsstnt_mbr_id,pe_id,payee_prov_id from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b WHERE length(trim(regexp_replace(payee_prov_id,' ',''))) = 0 or payee_prov_id is null""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate that Payee Provider First Name - 008") {

    val id = Array("008")

    val name = Array("Validate that Payee Provider First Name - 008")

    val result = spark.sql(f"""select cnsstnt_mbr_id,pe_id,b.payee_prov_frst_nm,'HOME' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist e
      ON b.payee_prov_frst_nm=e.atrbd_prov_frst_nm where mmi_id='' AND 
      trim(b.payee_prov_frst_nm)<>'' union all 
      select cnsstnt_mbr_id,pe_id,b.payee_prov_frst_nm,'HOST' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN e
      ON b.payee_prov_frst_nm=e.atrbd_prov_frst_nm where trim(mmi_id)<>'' AND 
      trim(b.payee_prov_frst_nm)<>''""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : select cnsstnt_mbr_id,pe_id,b.payee_prov_frst_nm,'HOME' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist e ON b.payee_prov_frst_nm=e.atrbd_prov_frst_nm where mmi_id='' AND trim(b.payee_prov_frst_nm)<>'' union all select cnsstnt_mbr_id,pe_id,b.payee_prov_frst_nm,'HOST' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN e ON b.payee_prov_frst_nm=e.atrbd_prov_frst_nm where trim(mmi_id)<>'' AND trim(b.payee_prov_frst_nm)<>''")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : select cnsstnt_mbr_id,pe_id,b.payee_prov_frst_nm,'HOME' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist e ON b.payee_prov_frst_nm=e.atrbd_prov_frst_nm where mmi_id='' AND trim(b.payee_prov_frst_nm)<>'' union all select cnsstnt_mbr_id,pe_id,b.payee_prov_frst_nm,'HOST' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN e ON b.payee_prov_frst_nm=e.atrbd_prov_frst_nm where trim(mmi_id)<>'' AND trim(b.payee_prov_frst_nm)<>''")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate that Payee Provider Last Name  - 009") {

    val id = Array("009")

    val name = Array("Validate that Payee Provider Last Name  - 009")

    val result = spark.sql(f"""select cnsstnt_mbr_id,pe_id,b.payee_prov_last_nm,'HOME' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist e
      ON b.payee_prov_last_nm=e.atrbd_prov_last_nm where mmi_id='' AND 
      trim(b.payee_prov_last_nm)<>'' union all 
      select cnsstnt_mbr_id,pe_id,b.payee_prov_last_nm,'HOST' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN e
      ON b.payee_prov_last_nm=e.atrbd_prov_last_nm where trim(mmi_id)<>'' AND 
      trim(b.payee_prov_last_nm)<>''""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : select cnsstnt_mbr_id,pe_id,b.payee_prov_last_nm,'HOME' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist e ON b.payee_prov_last_nm=e.atrbd_prov_last_nm where mmi_id='' AND trim(b.payee_prov_last_nm)<>'' union all select cnsstnt_mbr_id,pe_id,b.payee_prov_last_nm,'HOST' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN e ON b.payee_prov_last_nm=e.atrbd_prov_last_nm where trim(mmi_id)<>'' AND trim(b.payee_prov_last_nm)<>''")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : select cnsstnt_mbr_id,pe_id,b.payee_prov_last_nm,'HOME' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist e ON b.payee_prov_last_nm=e.atrbd_prov_last_nm where mmi_id='' AND trim(b.payee_prov_last_nm)<>'' union all select cnsstnt_mbr_id,pe_id,b.payee_prov_last_nm,'HOST' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN e ON b.payee_prov_last_nm=e.atrbd_prov_last_nm where trim(mmi_id)<>'' AND trim(b.payee_prov_last_nm)<>''")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate that Payee Provider Organization Name  - 010") {

    val id = Array("010")

    val name = Array("Validate that Payee Provider Organization Name - 010")

    val result = spark.sql(f"""select cnsstnt_mbr_id,pe_id,b.prov_org_nm from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e
      ON b.prov_org_nm=e.EP_ORG_NM where trim(b.prov_org_nm)<>''""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : select cnsstnt_mbr_id,pe_id,b.prov_org_nm from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e ON b.prov_org_nm=e.EP_ORG_NM where trim(b.prov_org_nm)<>''")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : select cnsstnt_mbr_id,pe_id,b.prov_org_nm from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e ON b.prov_org_nm=e.EP_ORG_NM where trim(b.prov_org_nm)<>''")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate that Payee Provider Street Address 1  - 011") {

    val id = Array("011")

    val name = Array("Validate that Payee Provider Street Address 1 - 011")

    val src = f"""select cnsstnt_mbr_id,pe_id,b.prov_str_adrs_1_txt,'HOME' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist e
      ON b.prov_str_adrs_1_txt=e.atrbd_prov_str_adrs_1_txt where mmi_id='' AND 
      trim(b.prov_str_adrs_1_txt)<>'' union all 
      select cnsstnt_mbr_id,pe_id,b.prov_str_adrs_1_txt,'HOST' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN e
      ON b.prov_str_adrs_1_txt=e.atrbd_prov_str_adrs_1_txt where trim(mmi_id)<>'' AND 
      trim(b.prov_str_adrs_1_txt)<>''"""

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate the Payee Provider Street Address 2  - 012") {

    val id = Array("012")

    val name = Array("Validate the Payee Provider Street Address 2 - 012")

    val src = (f"""select cnsstnt_mbr_id,pe_id,b.prov_str_adrs_2_txt from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.EP_ADRS e
      ON b.prov_str_adrs_2_txt=e.EP_ADRS_LINE_2_TXT where trim(b.prov_str_adrs_2_txt)<>''""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate the Payee Provider City  - 013") {

    val id = Array("013")

    val name = Array("Validate the Payee Provider City  - 013")
   
    val src = (f"""select cnsstnt_mbr_id,pe_id,b.prov_city_nm from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.EP_ADRS e
      ON b.prov_city_nm=e.EP_ADRS_CITY_NM where trim(b.prov_city_nm)<>''""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate the Payee Provider State - 014") {

    val id = Array("014")

    val name = Array("Validate the Payee Provider State  - 014")

    val src = (f"""select cnsstnt_mbr_id,pe_id,b.prov_st_cd from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.EP_ADRS e
      ON b.prov_st_cd=e.EP_ADRS_ST_PRVNC_CD where trim(b.prov_st_cd)<>''""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate the Payee Provider ZIP Code  - 015") {

    val id = Array("015")

    val name = Array("Validate the Payee Provider ZIP Code - 015")

    val src = (f"""select cnsstnt_mbr_id,pe_id,b.prov_zip_cd from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.EP_ADRS e
      ON b.prov_zip_cd=e.EP_ADRS_POSTL_CD where trim(b.prov_zip_cd)<>''""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate the Performance Cycle Begin Date is not null or spaces - 016") {

    val id = Array("016")

    val name = Array("Validate the Performance Cycle Begin Date is not null or spaces - 016")

    val src = (f"""select cnsstnt_mbr_id,pe_id,prfrmn_cycl_strt_dt from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      WHERE length(trim(regexp_replace(prfrmn_cycl_strt_dt,' ',''))) = 0 or prfrmn_cycl_strt_dt is null""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate for Performance Cycle End Date  - 017") {

    val id = Array("017")

    val name = Array("Validate for Performance Cycle End Date  - 017")

    val src = (f"""select cnsstnt_mbr_id,pe_id,prfrmn_cycl_end_dt from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      WHERE length(trim(regexp_replace(prfrmn_cycl_end_dt,' ',''))) = 0 or prfrmn_cycl_end_dt is null""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate for Value-Based Program ID - 018") {

    val id = Array("018")

    val name = Array("Validate for Value-Based Program ID - 018")
  
    val src = (f"""select cnsstnt_mbr_id,pe_id,b.VBP_ID from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PI_BCBSA_PGM_PG_VBP e
      ON b.VBP_ID=e.BDTC_VBP_ID""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate for Provider Entity Identifier - 019") {

    val id = Array("019")

    val name = Array("Validate for Provider Entity Identifier - 019")

    val result = spark.sql(f""" select distinct(b.pe_id) 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
        LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PI_ATRBN_MCID e
        ON b.pe_id=e.PG_ID""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(b.pe_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PI_ATRBN_MCID e ON b.pe_id=e.PG_ID")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(b.pe_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PI_ATRBN_MCID e ON b.pe_id=e.PG_ID")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate for Provider Entity Name is as per the transformation logic- 020") {

    val id = Array("020")

    val name = Array("Validate for Provider Entity Name is as per the transformation logic- 020")

     val result = spark.sql(f""" select b.PE_ID,b.PE_NM 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
        LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.pg_dtl e
        ON b.PE_NM=e.PG_NM""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select b.PE_ID,b.PE_NM from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.pg_dtl e ON b.PE_NM=e.PG_NM ")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select b.PE_ID,b.PE_NM from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.pg_dtl e ON b.PE_NM=e.PG_NM ")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF-CareCoordination - Validate for Payment Category Type is not NULL or spaces- 021") {

    val id = Array("021")

    val name = Array("Validate for Payment Category Type is not NULL or spaces- 021")
    
    val src = (f"""select cnsstnt_mbr_id,pe_id,paymnt_type_cd from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care b 
      WHERE length(trim(regexp_replace(paymnt_type_cd,' ',''))) = 0 or paymnt_type_cd is null""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-------------------------------------------------------------------------------

  test("VBP_CARECoordination  - HOME - Fetching data from pi_fcs_mbr_trnsctn_hist table for HOME records- 022") {
    val id = Array("022")
    val name = Array("Test case : HOME - Fetching data from pi_fcs_mbr_trnsctn_hist table for HOME records - 022 ")

    val resultN = spark.sql(s"""SELECT MBR_KEY,mcid,trim(srvcg_npi) as srvcg_npi,fundg_type_paymnt_amt,
      cpttn_incrd_from_dt,cpttn_incrd_to_dt,trim(cpttn_paymnt_type_cd) as cpttn_paymnt_type_cd,
      trim(PSGL_PROD_CD) as PSGL_PROD_CD,trim(CPTTN_FUNDG_TYPE_CD) as CPTTN_FUNDG_TYPE_CD,
      trim(PAYMNT_TYPE_CD) as PAYMNT_TYPE_CD,trim(CHK_PAYMNT_IND) as CHK_PAYMNT_IND,
      trim(PG_ID) as PG_ID,cpttn_fundg_from_dt ,cpttn_fundg_to_dt,trim(PI_PGM_ID) as PI_PGM_ID,
      trim(mbrshp_sor_cd) as mbrshp_sor_cd,uniq_rcrd_nbr
      FROM ${dbname}_pcandw1ph_nogbd_r000_in.pi_fcs_mbr_trnsctn_hist
      where CPTTN_FUNDG_TYPE_CD IN ('CARE', 'CCESS','CCCOO') AND PAYMNT_TYPE_CD in ('CARE')
      AND CHK_PAYMNT_IND = 'Y' and RCRD_STTS_CD<>'DEL'AND MBRSHP_SOR_CD <> '1005'""")

    //result.persist()

    resultN.write.format("parquet").mode("overwrite").insertInto(f"${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOME_CARE_VBP")
    val result = spark.sql(f"select * from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOME_CARE_VBP")
    val rc = result.count

    println("result count is ======================= " + rc.toInt)

    if (rc > 0) {
      result.createOrReplaceTempView("SIT_TRAN_HOME_SOURCE")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT MBR_KEY,mcid,trim(srvcg_npi) as srvcg_npi,fundg_type_paymnt_amt,cpttn_incrd_from_dt,cpttn_incrd_to_dt,trim(cpttn_paymnt_type_cd) as cpttn_paymnt_type_cd,trim(PSGL_PROD_CD) as PSGL_PROD_CD,trim(CPTTN_FUNDG_TYPE_CD) as CPTTN_FUNDG_TYPE_CD,trim(PAYMNT_TYPE_CD) as PAYMNT_TYPE_CD,trim(CHK_PAYMNT_IND) as CHK_PAYMNT_IND,trim(PG_ID) as PG_ID,cpttn_fundg_from_dt ,cpttn_fundg_to_dt,trim(PI_PGM_ID) as PI_PGM_ID,trim(mbrshp_sor_cd) as mbrshp_sor_cd,uniq_rcrd_nbr FROM '''+dbname+'''_pcandw1ph_nogbd_r000_in.pi_fcs_mbr_trnsctn_hist where CPTTN_FUNDG_TYPE_CD IN ( 'CARE', 'CCESS','CCCOO') AND PAYMNT_TYPE_CD in ('CARE') AND CHK_PAYMNT_IND = 'Y' and RCRD_STTS_CD<>'DEL'AND MBRSHP_SOR_CD <> '1005' ")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_TRAN_HOME_SOURCE")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT MBR_KEY,mcid,trim(srvcg_npi) as srvcg_npi,fundg_type_paymnt_amt,cpttn_incrd_from_dt,cpttn_incrd_to_dt,trim(cpttn_paymnt_type_cd) as cpttn_paymnt_type_cd,trim(PSGL_PROD_CD) as PSGL_PROD_CD,trim(CPTTN_FUNDG_TYPE_CD) as CPTTN_FUNDG_TYPE_CD,trim(PAYMNT_TYPE_CD) as PAYMNT_TYPE_CD,trim(CHK_PAYMNT_IND) as CHK_PAYMNT_IND,trim(PG_ID) as PG_ID,cpttn_fundg_from_dt ,cpttn_fundg_to_dt,trim(PI_PGM_ID) as PI_PGM_ID,trim(mbrshp_sor_cd) as mbrshp_sor_cd,uniq_rcrd_nbr FROM '''+dbname+'''_pcandw1ph_nogbd_r000_in.pi_fcs_mbr_trnsctn_hist where CPTTN_FUNDG_TYPE_CD IN ( 'CARE', 'CCESS','CCCOO') AND PAYMNT_TYPE_CD in ('CARE') AND CHK_PAYMNT_IND = 'Y' and RCRD_STTS_CD<>'DEL'AND MBRSHP_SOR_CD <> '1005'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARECoordination  - Feteching data from SIT_TRAN_HOME_SOURCE table - 023") {

    val id = Array("023")
    val name = Array("Test case : Feteching data from SIT_TRAN_HOME_SOURCE table - 023 ")

    val result = spark.sql(s"""select MCID,PG_ID,srvcg_npi,CPTTN_INCRD_FROM_DT,CPTTN_FUNDG_TYPE_CD,
      sum(FUNDG_TYPE_PAYMNT_AMT) as FUNDG_TYPE_PAYMNT_AMT from SIT_TRAN_HOME_SOURCE
      group by MCID, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT, CPTTN_FUNDG_TYPE_CD""")

    result.persist()

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_VBP_CA_AMT6")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  MCID, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT, CPTTN_FUNDG_TYPE_CD, sum(FUNDG_TYPE_PAYMNT_AMT) as FUNDG_TYPE_PAYMNT_AMT from SIT_TRAN_HOME_SOURCE group by MCID, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT, CPTTN_FUNDG_TYPE_CD")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_VBP_CA_AMT6")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  MCID, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT, CPTTN_FUNDG_TYPE_CD, sum(FUNDG_TYPE_PAYMNT_AMT) as FUNDG_TYPE_PAYMNT_AMT from SIT_TRAN_HOME_SOURCE group by MCID, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT, CPTTN_FUNDG_TYPE_CD")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARECoordination  - HOME - Fetching data from bcbsa_vbp_lcl_atrbn_hist table - 024") {

    val id = Array("024")
    val name = Array("Test case : HOME - Fetching data from bcbsa_vbp_lcl_atrbn_hist table- 024 ")

    val result3 = spark.sql(s"""SELECT * FROM (SELECT LCL_ATR_HST.*,
      RANK() OVER (PARTITION BY LCL_ATR_HST.CNSSTNT_MBR_ID,LCL_ATR_HST.ATRBN_PRD_BGN_DT,
      LCL_ATR_HST.ATRBN_PRD_END_DT ORDER BY LCL_ATR_HST.atrbn_prd_bgn_dt DESC ) AS RNK
      FROM ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist LCL_ATR_HST) as A WHERE RNK=1""")

    result3.persist()

    // val rc=result.count

    if (result3.count > 0) {
      result3.createOrReplaceTempView("SIT_ATRBN_HIST_TBL")
      val a = result3.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT * FROM (SELECT LCL_ATR_HST.*, RANK() OVER (PARTITION BY LCL_ATR_HST.CNSSTNT_MBR_ID,LCL_ATR_HST.ATRBN_PRD_BGN_DT,LCL_ATR_HST.ATRBN_PRD_END_DT ORDER BY LCL_ATR_HST.atrbn_prd_bgn_dt DESC ) AS RNK FROM '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist LCL_ATR_HST) as A WHERE RNK=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result3.createOrReplaceTempView("SIT_ATRBN_HIST_TBL")
      val a = result3.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT * FROM (SELECT LCL_ATR_HST.*, RANK() OVER (PARTITION BY LCL_ATR_HST.CNSSTNT_MBR_ID,LCL_ATR_HST.ATRBN_PRD_BGN_DT,LCL_ATR_HST.ATRBN_PRD_END_DT ORDER BY LCL_ATR_HST.atrbn_prd_bgn_dt DESC ) AS RNK FROM '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist LCL_ATR_HST) as A WHERE RNK=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOME - Feteching data from bcbsa_vbp_lcl_atrbn_hist based on ATRBD_PROV_NPI- 025") {

    val id = Array("025")
    val name = Array("Test case : HOME - Feteching data from bcbsa_vbp_lcl_atrbn_hist based on ATRBD_PROV_NPI- 025 ")

    val result4 = spark.sql(s"""SELECT * FROM (SELECT LCL_ATR_HST.*,
      RANK() OVER (PARTITION BY LCL_ATR_HST.CNSSTNT_MBR_ID,LCL_ATR_HST.ATRBD_PROV_NPI,
      LCL_ATR_HST.ATRBN_PRD_BGN_DT,LCL_ATR_HST.ATRBN_PRD_END_DT ORDER BY LCL_ATR_HST.atrbn_prd_bgn_dt DESC)
      AS RNK1 FROM ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist LCL_ATR_HST) as A
      WHERE RNK1=1""")

    result4.persist()

    //  val rc=result.count

    if (result4.count > 0) {
      result4.createOrReplaceTempView("SIT_ATRBN_HIST_NPI_TBL")
      val a = result4.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT * FROM (SELECT LCL_ATR_HST.*, RANK() OVER (PARTITION BY LCL_ATR_HST.CNSSTNT_MBR_ID,LCL_ATR_HST.ATRBD_PROV_NPI,LCL_ATR_HST.ATRBN_PRD_BGN_DT,LCL_ATR_HST.ATRBN_PRD_END_DT ORDER BY LCL_ATR_HST.atrbn_prd_bgn_dt DESC ) AS RNK1 FROM '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist LCL_ATR_HST) as A WHERE RNK1=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result4.createOrReplaceTempView("SIT_ATRBN_HIST_NPI_TBL")
      val a = result4.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT * FROM (SELECT LCL_ATR_HST.*, RANK() OVER (PARTITION BY LCL_ATR_HST.CNSSTNT_MBR_ID,LCL_ATR_HST.ATRBD_PROV_NPI,LCL_ATR_HST.ATRBN_PRD_BGN_DT,LCL_ATR_HST.ATRBN_PRD_END_DT ORDER BY LCL_ATR_HST.atrbn_prd_bgn_dt DESC ) AS RNK1 FROM '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist LCL_ATR_HST) as A WHERE RNK1=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARECoordination  - HOME - Fetching data from SIT_TRAN_HOME_SOURCE- 026") {

    val id = Array("026")
    val name = Array("Test case : Fetching data from SIT_TRAN_HOME_SOURCE- 026 ")

    val result = spark.sql(s"""select distinct MCID, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT from
      SIT_TRAN_HOME_SOURCE where CPTTN_PAYMNT_TYPE_CD in ('MP','BP')""")

    //result.persist()

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_TRAN_HOME_SOURCE_CURR")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct MCID, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT from SIT_TRAN_HOME_SOURCE where CPTTN_PAYMNT_TYPE_CD in ('MP','BP')")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_TRAN_HOME_SOURCE_CURR")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct MCID, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT from SIT_TRAN_HOME_SOURCE where CPTTN_PAYMNT_TYPE_CD in ('MP','BP')")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARECoordination  - HOME - combining tables- 027") {

    val id = Array("027")
    val name = Array("Test case : HOME - combining tables- 027 ")

    val result6 = spark.sql(f"""SELECT DISTINCT '' as MMI_ID, MBR_HIST.MCID as CNSSTNT_MBR_ID,
      MBR_HIST.MCID as mbr_id, MBR_HIST.srvcg_npi as payee_prov_npi,
      CASE WHEN A.MSRMNT_PRD_STRT_DT is NULL then '1111-01-01' ELSE A.MSRMNT_PRD_STRT_DT END
      as prfrmn_cycl_strt_dt, CASE WHEN A.MSRMNT_PRD_END_DT is NULL then '8888-12-31'
      ELSE A.MSRMNT_PRD_END_DT END as prfrmn_cycl_end_dt, MBR_HIST.CPTTN_PAYMNT_TYPE_CD,
      case when MBR_HIST.CPTTN_PAYMNT_TYPE_CD in ('MP', 'BP') then MBR_HIST.fundg_type_paymnt_amt
      when CPTTN_PAYMNT_TYPE_CD in ('MA', 'BR') then CAAmount.fundg_type_paymnt_amt end as paye_paymnt_amt,
      MBR_HIST.cpttn_incrd_from_dt as paymnt_bgn_dt, last_day(MBR_HIST.CPTTN_INCRD_FROM_DT) as paymnt_end_dt,
      MBR_HIST.pg_id, 'C' as ncf_paymnt_type_cd, MBR_HIST.PSGL_PROD_CD, MBR_HIST.cpttn_fundg_from_dt ,
      MBR_HIST.cpttn_fundg_to_dt, MBR_HIST.cpttn_incrd_from_dt, MBR_HIST.CPTTN_INCRD_TO_DT
      FROM (select * from SIT_TRAN_HOME_SOURCE WHERE CAST(CPTTN_FUNDG_FROM_DT AS DATE)='${startdateFnl}')
      MBR_HIST LEFT OUTER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PGM_MSRMNT_PRD A
      ON A.PI_PGM_ID = MBR_HIST.PI_PGM_ID AND CAST(MBR_HIST.CPTTN_INCRD_FROM_DT AS DATE)
      BETWEEN CAST(CASE WHEN A.MSRMNT_PRD_STRT_DT is NULL then '1111-01-01' ELSE A.MSRMNT_PRD_STRT_DT END
      AS DATE) and CAST(CASE WHEN A.MSRMNT_PRD_END_DT is NULL then '8888-12-31' ELSE A.MSRMNT_PRD_END_DT END
      AS DATE) left outer join SIT_VBP_CA_AMT6 CAAmount on MBR_HIST.MCID=CAAmount.MCID
      and MBR_HIST.PG_ID=CAAmount.PG_ID and MBR_HIST.srvcg_npi=CAAmount.srvcg_npi
      and MBR_HIST.CPTTN_INCRD_FROM_DT=CAAmount.CPTTN_INCRD_FROM_DT
      and MBR_HIST.CPTTN_FUNDG_TYPE_CD=CAAmount.CPTTN_FUNDG_TYPE_CD""")

    result6.persist()

    if (result6.count > 0) {
      result6.createOrReplaceTempView("SIT_TRAN_HOME_SOURCE_FNL_INT")
      val a = result6.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from SIT_TRAN_HOME_SOURCE_FNL_INT")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result6.createOrReplaceTempView("SIT_TRAN_HOME_SOURCE_FNL_INT")
      val a = result6.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from SIT_TRAN_HOME_SOURCE_FNL_INT")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOME - Fetching data from BCBSA_VBP_NON_CLM_FNCL_CARE_ERR table- 028") {

    val id = Array("028")
    val name = Array("Test case : HOME - Fetching data from BCBSA_VBP_NON_CLM_FNCL_CARE_ERR table- 028 ")

    val result7 = spark.sql(s"""select distinct cnsstnt_mbr_id, pe_id, payee_prov_npi, paymnt_bgn_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.BCBSA_VBP_NON_CLM_FNCL_CARE_ERR where paymnt_type_cd='OA'""")

    result7.persist()

    //  val rc=result.count

    if (result7.count > 0) {
      result7.createOrReplaceTempView("SIT_TRAN_HOME_NCFERR")
      val a = result7.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct cnsstnt_mbr_id, pe_id, payee_prov_npi, paymnt_bgn_dt  from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_VBP_NON_CLM_FNCL_CARE_ERR where paymnt_type_cd='OA'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result7.createOrReplaceTempView("SIT_TRAN_HOME_NCFERR")
      val a = result7.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct cnsstnt_mbr_id, pe_id, payee_prov_npi, paymnt_bgn_dt  from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_VBP_NON_CLM_FNCL_CARE_ERR where paymnt_type_cd='OA'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOME - Fetching data from BCBSA_VBP_NON_CLM_FNCL_CARE_HIST table - 029") {

    val id = Array("029")
    val name = Array("Test case : HOME - Fetching data from BCBSA_VBP_NON_CLM_FNCL_CARE_HIST table- 029 ")

    val result8 = spark.sql(s"""select distinct cnsstnt_mbr_id, pe_id, payee_prov_npi, paymnt_bgn_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.BCBSA_VBP_NON_CLM_FNCL_CARE_HIST where paymnt_type_cd='OA'""")

    result8.persist()

    //  val rc=result.count

    if (result8.count > 0) {
      result8.createOrReplaceTempView("SIT_TRAN_HOME_NCFHIST")
      val a = result8.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct cnsstnt_mbr_id, pe_id, payee_prov_npi, paymnt_bgn_dt  from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_VBP_NON_CLM_FNCL_CARE_HIST where paymnt_type_cd='OA'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result8.createOrReplaceTempView("SIT_TRAN_HOME_NCFHIST")
      val a = result8.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct cnsstnt_mbr_id, pe_id, payee_prov_npi, paymnt_bgn_dt  from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_VBP_NON_CLM_FNCL_CARE_HIST where paymnt_type_cd='OA'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOME - combining tables - 030") {

    val id = Array("030")
    val name = Array("Test case : HOME - combining tables- 030 ")

    val resultN = spark.sql(s"""SELECT MBR_HIST.*,R1.its_sbscrbr_id,R1.bhi_home_plan_id, R1.bhi_host_plan_id,
      LCL_ATR_HST.atrbd_prov_id as payee_prov_id,LCL_ATR_HST.atrbd_prov_frst_nm as payee_prov_frst_nm,
      LCL_ATR_HST.atrbd_prov_last_nm as payee_prov_last_nm, LCL_ATR_HST.atrbd_prov_org_nm as prov_org_nm,
      LCL_ATR_HST.atrbd_prov_str_adrs_1_txt as prov_str_adrs_1_txt, LCL_ATR_HST.atrbd_prov_str_adrs_2_txt
      as prov_str_adrs_2_txt, LCL_ATR_HST.atrbd_prov_city_nm as prov_city_nm, LCL_ATR_HST.atrbd_prov_st_cd
      as prov_st_cd, LCL_ATR_HST.atrbd_prov_zip_cd as prov_zip_cd,LCL_ATR_HST.vbp_id,
      case when MBR_HIST.CPTTN_PAYMNT_TYPE_CD in ('MP', 'BP') then 'OA'
      when CPTTN_PAYMNT_TYPE_CD in ('MA', 'BR') and NCFERR.cnsstnt_mbr_id is not null
      and NCFHIST.cnsstnt_mbr_id is null and NCFCURR.MCID is null then 'OA' else 'CA' end as paymnt_type_cd,
      DTL.PG_NM AS PE_NM FROM SIT_TRAN_HOME_SOURCE_FNL_INT MBR_HIST
      INNER JOIN ${dbname}_PCANDW1PH_nogbd_r000_in.PG_DTL DTL ON MBR_HIST.PG_ID=DTL.PG_ID
      AND CAST(MBR_HIST.CPTTN_INCRD_FROM_DT AS DATE) BETWEEN CAST(DTL.pg_dtl_efctv_dt AS DATE)
      AND CAST(DTL.pg_dtl_trmntn_dt AS DATE)
      and CAST(DTL.pg_dtl_efctv_dt AS DATE) <> CAST(DTL.pg_dtl_trmntn_dt AS DATE)
      left outer join SIT_TRAN_HOME_NCFERR NCFERR on MBR_HIST.CNSSTNT_MBR_ID=NCFERR.cnsstnt_mbr_id
      and  MBR_HIST.PG_ID=NCFERR.pe_id and  MBR_HIST.payee_prov_npi=NCFERR.payee_prov_npi
      and  MBR_HIST.paymnt_bgn_dt=NCFERR.paymnt_bgn_dt
      left outer join SIT_TRAN_HOME_NCFHIST NCFHIST on MBR_HIST.CNSSTNT_MBR_ID=NCFHIST.cnsstnt_mbr_id
      and  MBR_HIST.PG_ID=NCFHIST.pe_id and  MBR_HIST.payee_prov_npi=NCFHIST.payee_prov_npi
      and  MBR_HIST.paymnt_bgn_dt=NCFHIST.paymnt_bgn_dt
      left outer join SIT_TRAN_HOME_SOURCE_CURR NCFCURR on MBR_HIST.CNSSTNT_MBR_ID=NCFCURR.MCID
      and MBR_HIST.PG_ID=NCFCURR.PG_ID and  MBR_HIST.payee_prov_npi=NCFCURR.srvcg_npi
      and MBR_HIST.paymnt_bgn_dt=NCFCURR.CPTTN_INCRD_FROM_DT
      LEFT OUTER JOIN SIT_ATRBN_HIST_TBL R1 ON MBR_HIST.CNSSTNT_MBR_ID=R1.CNSSTNT_MBR_ID
      AND MBR_HIST.paymnt_bgn_dt = R1.ATRBN_PRD_BGN_DT AND MBR_HIST.PG_ID  = R1.PE_ID
      LEFT OUTER JOIN SIT_ATRBN_HIST_NPI_TBL LCL_ATR_HST ON MBR_HIST.CNSSTNT_MBR_ID=LCL_ATR_HST.CNSSTNT_MBR_ID
      AND MBR_HIST.payee_prov_npi=LCL_ATR_HST.ATRBD_PROV_NPI AND MBR_HIST.PG_ID = LCL_ATR_HST.PE_ID
      AND MBR_HIST.paymnt_bgn_dt = LCL_ATR_HST.ATRBN_PRD_BGN_DT""")

    resultN.write.format("parquet").mode("overwrite").insertInto(f"${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOME_CARE_VBP_FNL")
    val result9 = spark.sql(f"select * from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOME_CARE_VBP_FNL")

    //result9.persist()

    //    val rc=result.count

    if (result9.count > 0) {
      result9.createOrReplaceTempView("SIT_TRAN_HOME_SOURCE_FNL")
      val a = result9.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from SIT_TRAN_HOME_SOURCE_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"

      assert(1 == 1)
    } else {
      result9.createOrReplaceTempView("SIT_TRAN_HOME_SOURCE_FNL")
      val a = result9.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from SIT_TRAN_HOME_SOURCE_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"

      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOME - MINUS query -1 (Reconcile amounts at record level) - 031") {

    val id = Array("031")
    val name = Array("Test case : - MINUS query -1 (Reconcile amounts at record level) - 031 ")

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where mmi_id = '' and load_log_key= ${df1}""")

    //  result1.createOrReplaceTempView("SIT_TRAN_HOME_SOURCE_FNL")

    val result2 = spark.sql(s"""select DISTINCT CNSSTNT_MBR_ID, PG_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from SIT_TRAN_HOME_SOURCE_FNL""")

    val result = result1.except(result2)

    result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where mmi_id = '' and load_log_key= ${df1} minus select DISTINCT CNSSTNT_MBR_ID, PG_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from SIT_TRAN_HOME_SOURCE_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where mmi_id = '' and load_log_key= ${df1} minus select DISTINCT CNSSTNT_MBR_ID, PG_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from SIT_TRAN_HOME_SOURCE_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOME - MINUS query -2 (Reconcile amounts at PG_ID level) - 032") {

    val id = Array("032")
    val name = Array("Test case : - MINUS query -2 (Reconcile amounts at PG_ID level) - 032 ")

    val result1 = spark.sql(s"""select a.pe_id,sum(paye_paymnt_amt ) from( select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where load_log_key=${df1} and mmi_id = '') a group by a.pe_id""")

    val result2 = spark.sql(s"""select pg_id,sum(paye_paymnt_amt ) from (select distinct cnsstnt_mbr_id, pg_id, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from SIT_TRAN_HOME_SOURCE_FNL) A group by pg_id order by pg_id""")

    val result = result1.except(result2)

    result.persist()
    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select a.pe_id,sum(paye_paymnt_amt ) from( select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where load_log_key=${df1} and mmi_id = '') a group by a.pe_id minus select pg_id,sum(paye_paymnt_amt ) from (select distinct cnsstnt_mbr_id, pg_id, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from SIT_TRAN_HOME_SOURCE_FNL) A group by pg_id order by pg_id")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select a.pe_id,sum(paye_paymnt_amt ) from( select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where load_log_key=${df1} and mmi_id = '') a group by a.pe_id minus select pg_id,sum(paye_paymnt_amt ) from (select distinct cnsstnt_mbr_id, pg_id, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from SIT_TRAN_HOME_SOURCE_FNL) A group by pg_id order by pg_id")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOME - MINUS query -3 (Validate Plan level details) - 033") {

    val id = Array("033")
    val name = Array("Test case : - MINUS query -3 (Validate Plan level details) - 033 ")

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where mmi_id = '' and load_log_key=${df1}""")
    val result2 = spark.sql("""select DISTINCT CNSSTNT_MBR_ID,MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PG_ID, PE_NM, vbp_id from SIT_TRAN_HOME_SOURCE_FNL""")

    val result = result1.except(result2)
    result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where mmi_id = '' and load_log_key=${df1} minus select DISTINCT CNSSTNT_MBR_ID,MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PG_ID, PE_NM, vbp_id from SIT_TRAN_HOME_SOURCE_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where mmi_id = '' and load_log_key=${df1} minus select DISTINCT CNSSTNT_MBR_ID,MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PG_ID, PE_NM, vbp_id from SIT_TRAN_HOME_SOURCE_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOME - MINUS query -4 (Validate payment details) - 034") {

    val id = Array("034")
    val name = Array("Test case : - MINUS query -4 (Validate payment details) - 034 ")

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where mmi_id = '' and load_log_key=${df1}""")
    val result2 = spark.sql(s"""select DISTINCT cnsstnt_mbr_id, PG_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from SIT_TRAN_HOME_SOURCE_FNL""")

    val result = result1.except(result2)
    result.persist()
    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where mmi_id = '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PG_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from SIT_TRAN_HOME_SOURCE_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where mmi_id = '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PG_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from SIT_TRAN_HOME_SOURCE_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOME - MINUS query -5 (Validate provider details) - 035") {

    val id = Array("035")
    val name = Array("Test case : - MINUS query -5 (Validate provider details) - 035 ")

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where mmi_id = '' and load_log_key=${df1}""")
    val result2 = spark.sql(s"""select DISTINCT cnsstnt_mbr_id, PG_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from SIT_TRAN_HOME_SOURCE_FNL""")

    val result = result1.except(result2)

    result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where mmi_id = '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PG_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from SIT_TRAN_HOME_SOURCE_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where mmi_id = '' union all select distinct cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where mmi_id = '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PG_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from SIT_TRAN_HOME_SOURCE_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOST - Fetching data from pi_fcs_mbr_trnsctn_hist table for host- 036") {

    val id = Array("036")
    val name = Array("Test case :Fetching data from pi_fcs_mbr_trnsctn_hist tabke for host - 036 ")

    val resultN = spark.sql(s"""SELECT MBR_KEY,home_plan_mbr_id,cnsstnt_mbr_id,bcbsa_mmi_id,mcid,
      trim(srvcg_npi) as srvcg_npi,fundg_type_paymnt_amt,cpttn_incrd_from_dt,cpttn_incrd_to_dt,
      trim(cpttn_paymnt_type_cd) as cpttn_paymnt_type_cd,trim(PSGL_PROD_CD) as PSGL_PROD_CD,
      trim(CPTTN_FUNDG_TYPE_CD) as CPTTN_FUNDG_TYPE_CD,trim(PAYMNT_TYPE_CD) as PAYMNT_TYPE_CD,
      trim(CHK_PAYMNT_IND) as CHK_PAYMNT_IND,trim(PG_ID) as PG_ID,cpttn_fundg_from_dt,
      cpttn_fundg_to_dt,trim(PI_PGM_ID) as PI_PGM_ID, trim(mbrshp_sor_cd) as mbrshp_sor_cd,
      uniq_rcrd_nbr FROM ${dbname}_pcandw1ph_nogbd_r000_in.pi_fcs_mbr_trnsctn_hist
      where CPTTN_FUNDG_TYPE_CD IN ( 'CARE', 'CCESS','CCCOO') AND CHK_PAYMNT_IND = 'Y'
      and RCRD_STTS_CD<>'DEL' AND MBRSHP_SOR_CD = '1005'""")

    //result.persist()
    resultN.write.format("parquet").mode("overwrite").insertInto(f"${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOST_CARE_VBP")
    val result = spark.sql(f"select * from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOST_CARE_VBP")
    val rc = result.count

    println("result count is ======================= " + rc.toInt)

    if (rc > 0) {
      result.createOrReplaceTempView("SIT_TRAN_HOST_SOURCE")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :SELECT MBR_KEY,home_plan_mbr_id,cnsstnt_mbr_id,bcbsa_mmi_id,mcid,trim(srvcg_npi) as srvcg_npi,fundg_type_paymnt_amt,cpttn_incrd_from_dt,cpttn_incrd_to_dt,trim(cpttn_paymnt_type_cd) as cpttn_paymnt_type_cd,trim(PSGL_PROD_CD) as PSGL_PROD_CD,trim(CPTTN_FUNDG_TYPE_CD) as CPTTN_FUNDG_TYPE_CD,trim(PAYMNT_TYPE_CD) as PAYMNT_TYPE_CD,trim(CHK_PAYMNT_IND) as CHK_PAYMNT_IND,trim(PG_ID) as PG_ID,cpttn_fundg_from_dt,cpttn_fundg_to_dt,trim(PI_PGM_ID) as PI_PGM_ID, trim(mbrshp_sor_cd) as mbrshp_sor_cd,uniq_rcrd_nbr FROM ${dbname}_pcandw1ph_nogbd_r000_in.pi_fcs_mbr_trnsctn_histwhere CPTTN_FUNDG_TYPE_CD IN ( 'CARE', 'CCESS','CCCOO') AND CHK_PAYMNT_IND = 'Y'and RCRD_STTS_CD<>'DEL' AND MBRSHP_SOR_CD = '1005'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_TRAN_HOST_SOURCE")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :SELECT MBR_KEY,home_plan_mbr_id,cnsstnt_mbr_id,bcbsa_mmi_id,mcid,trim(srvcg_npi) as srvcg_npi,fundg_type_paymnt_amt,cpttn_incrd_from_dt,cpttn_incrd_to_dt,trim(cpttn_paymnt_type_cd) as cpttn_paymnt_type_cd,trim(PSGL_PROD_CD) as PSGL_PROD_CD,trim(CPTTN_FUNDG_TYPE_CD) as CPTTN_FUNDG_TYPE_CD,trim(PAYMNT_TYPE_CD) as PAYMNT_TYPE_CD,trim(CHK_PAYMNT_IND) as CHK_PAYMNT_IND,trim(PG_ID) as PG_ID,cpttn_fundg_from_dt,cpttn_fundg_to_dt,trim(PI_PGM_ID) as PI_PGM_ID, trim(mbrshp_sor_cd) as mbrshp_sor_cd,uniq_rcrd_nbr FROM ${dbname}_pcandw1ph_nogbd_r000_in.pi_fcs_mbr_trnsctn_histwhere CPTTN_FUNDG_TYPE_CD IN ( 'CARE', 'CCESS','CCCOO') AND CHK_PAYMNT_IND = 'Y'and RCRD_STTS_CD<>'DEL' AND MBRSHP_SOR_CD = '1005'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOST - Fetching data from SIT_TRAN_HOST_SOURCE table - 037") {

    val id = Array("037")
    val name = Array("Test case :Fetching data from SIT_TRAN_HOST_SOURCE table - 037 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(s"""select cnsstnt_mbr_id, BCBSA_MMI_ID, HOME_PLAN_MBR_ID, PG_ID, srvcg_npi,
      CPTTN_INCRD_FROM_DT, CPTTN_FUNDG_TYPE_CD, sum(FUNDG_TYPE_PAYMNT_AMT) as FUNDG_TYPE_PAYMNT_AMT
      from SIT_TRAN_HOST_SOURCE
      group by cnsstnt_mbr_id, BCBSA_MMI_ID, HOME_PLAN_MBR_ID, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT, CPTTN_FUNDG_TYPE_CD""")

    result.persist()

    //   val rc=result.count

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_VBP_HOST_AMT5")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, BCBSA_MMI_ID, HOME_PLAN_MBR_ID, PG_ID, srvcg_npi,CPTTN_INCRD_FROM_DT, CPTTN_FUNDG_TYPE_CD, sum(FUNDG_TYPE_PAYMNT_AMT) as FUNDG_TYPE_PAYMNT_AMTfrom SIT_TRAN_HOST_SOURCE group by cnsstnt_mbr_id, BCBSA_MMI_ID, HOME_PLAN_MBR_ID, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT, CPTTN_FUNDG_TYPE_CD")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_VBP_HOST_AMT5")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, BCBSA_MMI_ID, HOME_PLAN_MBR_ID, PG_ID, srvcg_npi,CPTTN_INCRD_FROM_DT, CPTTN_FUNDG_TYPE_CD, sum(FUNDG_TYPE_PAYMNT_AMT) as FUNDG_TYPE_PAYMNT_AMTfrom SIT_TRAN_HOST_SOURCE group by cnsstnt_mbr_id, BCBSA_MMI_ID, HOME_PLAN_MBR_ID, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT, CPTTN_FUNDG_TYPE_CD")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOST - pulling data for host for BCBSA_MBR_PROD - 038") {

    val id = Array("038")
    val name = Array("Test case :HOST - pulling data for host for BCBSA_MBR_PROD - 038 ")

    val result = spark.sql(s"""select * from (select distinct MBR_KEY,BCBSA_MSTR_MBR_ID, CNSSTNT_MBR_ID,
      HOME_PLAN_MBR_ID, NDW_PLAN_CD , HOST_PLAN_CD ,BCBSA_BGN_DT, BCBSA_END_DT,VRSN_CLOS_DT,
      RANK() OVER(PARTITION BY MBR_KEY ORDER BY BCBSA_BGN_DT DESC, BCBSA_END_DT DESC, VRSN_CLOS_DT DESC)as rnm
      from ${dbname}_pcandw1ph_nogbd_r000_in.BCBSA_MBR_PROD MBR
      LEFT SEMI JOIN SIT_TRAN_HOST_SOURCE MBR_HIST ON MBR.MBR_KEY=MBR_HIST.MBR_KEY) A where rnm=1 """)

    result.persist()

    //  val rc=result.count

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_VBP_BCBSA_MBR")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select * from (select distinct MBR_KEY,BCBSA_MSTR_MBR_ID, CNSSTNT_MBR_ID,HOME_PLAN_MBR_ID, NDW_PLAN_CD , HOST_PLAN_CD ,BCBSA_BGN_DT, BCBSA_END_DT,VRSN_CLOS_DT,RANK() OVER(PARTITION BY MBR_KEY ORDER BY BCBSA_BGN_DT DESC, BCBSA_END_DT DESC, VRSN_CLOS_DT DESC)as rnmfrom ${dbname}_pcandw1ph_nogbd_r000_in.BCBSA_MBR_PROD MBRLEFT SEMI JOIN SIT_TRAN_HOST_SOURCE MBR_HIST ON MBR.MBR_KEY=MBR_HIST.MBR_KEY) A where rnm=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_VBP_BCBSA_MBR")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select * from (select distinct MBR_KEY,BCBSA_MSTR_MBR_ID, CNSSTNT_MBR_ID,HOME_PLAN_MBR_ID, NDW_PLAN_CD , HOST_PLAN_CD ,BCBSA_BGN_DT, BCBSA_END_DT,VRSN_CLOS_DT,RANK() OVER(PARTITION BY MBR_KEY ORDER BY BCBSA_BGN_DT DESC, BCBSA_END_DT DESC, VRSN_CLOS_DT DESC)as rnmfrom ${dbname}_pcandw1ph_nogbd_r000_in.BCBSA_MBR_PROD MBRLEFT SEMI JOIN SIT_TRAN_HOST_SOURCE MBR_HIST ON MBR.MBR_KEY=MBR_HIST.MBR_KEY) A where rnm=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOST - pulling data for host attribution - 039") {

    val id = Array("039")
    val name = Array("Test case :HOST - pulling data for host attribution - 039 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(s"""SELECT * FROM (SELECT HOST_ATR_HST.*,
      RANK() OVER (PARTITION BY HOST_ATR_HST.mmi_id,HOST_ATR_HST.ndw_home_plan_mbr_id,
      HOST_ATR_HST.CNSSTNT_MBR_ID,HOST_ATR_HST.atrbd_prd_end_dt ORDER BY HOST_ATR_HST.atrbd_prd_bgn_dt DESC )
      AS RNK1 from ${dbname}_pcandw1ph_nogbd_r000_WH.BCBSA_VBP_HOST_ATRBN HOST_ATR_HST) as A WHERE RNK1=1 """)

    result.persist()

    //   val rc=result.count

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_BCBSA_VBP_HOST_ATRBN_CNSSTNT_NPI")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :SELECT * FROM (SELECT HOST_ATR_HST.*,RANK() OVER (PARTITION BY HOST_ATR_HST.mmi_id,HOST_ATR_HST.ndw_home_plan_mbr_id,HOST_ATR_HST.CNSSTNT_MBR_ID,HOST_ATR_HST.atrbd_prd_end_dt ORDER BY HOST_ATR_HST.atrbd_prd_bgn_dt DESC )AS RNK1 from ${dbname}_pcandw1ph_nogbd_r000_WH.BCBSA_VBP_HOST_ATRBN HOST_ATR_HST) as A WHERE RNK1=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_BCBSA_VBP_HOST_ATRBN_CNSSTNT_NPI")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :SELECT * FROM (SELECT HOST_ATR_HST.*,RANK() OVER (PARTITION BY HOST_ATR_HST.mmi_id,HOST_ATR_HST.ndw_home_plan_mbr_id,HOST_ATR_HST.CNSSTNT_MBR_ID,HOST_ATR_HST.atrbd_prd_end_dt ORDER BY HOST_ATR_HST.atrbd_prd_bgn_dt DESC )AS RNK1 from ${dbname}_pcandw1ph_nogbd_r000_WH.BCBSA_VBP_HOST_ATRBN HOST_ATR_HST) as A WHERE RNK1=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOST - Fetching data from SIT_TRAN_HOST_SOURCE- 040") {

    val id = Array("040")
    val name = Array("Test case :Fetching data from SIT_TRAN_HOST_SOURCE - 040 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(s"""select distinct cnsstnt_mbr_id, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT,
      mbrshp_sor_cd from SIT_TRAN_HOST_SOURCE where CPTTN_PAYMNT_TYPE_CD in ('MP','BP') """)

    //result.persist()

    //   val rc=result.count

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_TRAN_HOST_SOURCE_CURR")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select distinct cnsstnt_mbr_id, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT,mbrshp_sor_cd from SIT_TRAN_HOST_SOURCE where CPTTN_PAYMNT_TYPE_CD in ('MP','BP')")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_TRAN_HOST_SOURCE_CURR")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select distinct cnsstnt_mbr_id, PG_ID, srvcg_npi, CPTTN_INCRD_FROM_DT,mbrshp_sor_cd from SIT_TRAN_HOST_SOURCE where CPTTN_PAYMNT_TYPE_CD in ('MP','BP')")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOST - combining previous tables- 041") {

    val id = Array("041")
    val name = Array("Test case :HOST - combining previous tables - 041 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val resultN = spark.sql(s"""SELECT DISTINCT MBR.BCBSA_MSTR_MBR_ID as MMI_ID,
      MBR.CNSSTNT_MBR_ID as CNSSTNT_MBR_ID, HOST_ATR_HST.its_sbscrbr_id, MBR.HOME_PLAN_MBR_ID as mbr_id,
      MBR.NDW_PLAN_CD as bhi_home_plan_id, MBR.HOST_PLAN_CD as bhi_host_plan_id,
      HOST_ATR_HST.atrbd_prov_id as payee_prov_id, MBR_HIST.srvcg_npi as payee_prov_npi,
      HOST_ATR_HST.atrbd_prov_frst_nm as payee_prov_frst_nm,HOST_ATR_HST.atrbd_prov_last_nm
      as payee_prov_last_nm, HOST_ATR_HST.atrbd_prov_org_nm as prov_org_nm,
      HOST_ATR_HST.atrbd_prov_str_adrs_1_txt as prov_str_adrs_1_txt,
      HOST_ATR_HST.atrbd_prov_str_adrs_2_txt as prov_str_adrs_2_txt,
      HOST_ATR_HST.atrbd_prov_city_nm as prov_city_nm, HOST_ATR_HST.atrbd_prov_st_cd as prov_st_cd,
      HOST_ATR_HST.atrbd_prov_zip_cd as prov_zip_cd,
      CASE WHEN A.MSRMNT_PRD_STRT_DT is NULL then '1111-01-01' ELSE A.MSRMNT_PRD_STRT_DT END
      as prfrmn_cycl_strt_dt, CASE WHEN A.MSRMNT_PRD_END_DT is NULL then '8888-12-31' ELSE A.MSRMNT_PRD_END_DT
      END as prfrmn_cycl_end_dt,
      case when MBR_HIST.CPTTN_PAYMNT_TYPE_CD in ('MP', 'BP') then MBR_HIST.fundg_type_paymnt_amt
      when CPTTN_PAYMNT_TYPE_CD in ('MA', 'BR') then CAAmount_host.fundg_type_paymnt_amt end as paye_paymnt_amt,
      MBR_HIST.cpttn_incrd_from_dt as paymnt_bgn_dt, last_day(MBR_HIST.CPTTN_INCRD_FROM_DT) as paymnt_end_dt,
      HOST_ATR_HST.vbp_id, MBR_HIST.pg_id, 'C' as ncf_paymnt_type_cd,
      case when MBR_HIST.CPTTN_PAYMNT_TYPE_CD in ('MP', 'BP') then 'OA' when CPTTN_PAYMNT_TYPE_CD in ('MA', 'BR')
      and NCFERR.cnsstnt_mbr_id is not null and NCFHIST.cnsstnt_mbr_id is null and NCFCURR_host.cnsstnt_mbr_id is null then 'OA' else 'CA' end  as paymnt_type_cd,
      MBR_HIST.PSGL_PROD_CD, MBR_HIST.cpttn_fundg_from_dt , MBR_HIST.cpttn_fundg_to_dt,
      MBR_HIST.cpttn_incrd_from_dt, MBR_HIST.CPTTN_INCRD_TO_DT
      FROM (select * from SIT_TRAN_HOST_SOURCE where CPTTN_FUNDG_FROM_DT='${startdateFnl}') MBR_HIST
      INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PG_DTL DTL ON MBR_HIST.PG_ID=DTL.PG_ID
      AND CAST(MBR_HIST.CPTTN_INCRD_FROM_DT AS DATE) BETWEEN CAST(DTL.pg_dtl_efctv_dt AS DATE)
      AND CAST(DTL.pg_dtl_trmntn_dt AS DATE) and CAST(DTL.pg_dtl_efctv_dt AS DATE) <> CAST(DTL.pg_dtl_trmntn_dt AS DATE)
      INNER JOIN  SIT_VBP_BCBSA_MBR MBR  ON MBR.MBR_KEY=MBR_HIST.MBR_KEY
      LEFT OUTER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PGM_MSRMNT_PRD A ON A.PI_PGM_ID = MBR_HIST.PI_PGM_ID
      AND CAST(MBR_HIST.CPTTN_INCRD_FROM_DT AS DATE) BETWEEN
      CAST(CASE WHEN A.MSRMNT_PRD_STRT_DT is NULL then '1111-01-01' ELSE A.MSRMNT_PRD_STRT_DT END AS DATE)
      and CAST(CASE WHEN A.MSRMNT_PRD_END_DT is NULL then '8888-12-31' ELSE A.MSRMNT_PRD_END_DT END AS DATE)
      left outer join SIT_BCBSA_VBP_HOST_ATRBN_CNSSTNT_NPI HOST_ATR_HST
      ON MBR.CNSSTNT_MBR_ID=HOST_ATR_HST.CNSSTNT_MBR_ID
      AND MBR_HIST.CPTTN_INCRD_FROM_DT=HOST_ATR_HST.atrbd_prd_bgn_dt
      and  MBR_HIST.srvcg_npi = HOST_ATR_HST.atrbd_npi_prov_id and MBR_HIST.pg_id=HOST_ATR_HST.pe_id
      and MBR.BCBSA_MSTR_MBR_ID=HOST_ATR_HST.mmi_id AND MBR.HOME_PLAN_MBR_ID=HOST_ATR_HST.ndw_home_plan_mbr_id
      left outer join SIT_VBP_HOST_AMT5 CAAmount_host on MBR_HIST.cnsstnt_mbr_id=CAAmount_host.cnsstnt_mbr_id
      and  MBR_HIST.PG_ID=CAAmount_host.PG_ID and MBR_HIST.BCBSA_MMI_ID=CAAmount_host.BCBSA_MMI_ID and
      MBR_HIST.HOME_PLAN_MBR_ID=CAAmount_host.HOME_PLAN_MBR_ID and
      MBR_HIST.srvcg_npi=CAAmount_host.srvcg_npi and MBR_HIST.CPTTN_INCRD_FROM_DT=CAAmount_host.CPTTN_INCRD_FROM_DT and
      MBR_HIST.CPTTN_FUNDG_TYPE_CD=CAAmount_host.CPTTN_FUNDG_TYPE_CD
      left outer join SIT_TRAN_HOME_NCFERR NCFERR  on MBR_HIST.MCID=NCFERR.cnsstnt_mbr_id
      and MBR_HIST.PG_ID=NCFERR.pe_id and  MBR_HIST.srvcg_npi=NCFERR.payee_prov_npi
      and MBR_HIST.CPTTN_INCRD_FROM_DT=NCFERR.paymnt_bgn_dt
      left outer join SIT_TRAN_HOME_NCFHIST NCFHIST on MBR_HIST.MCID=NCFHIST.cnsstnt_mbr_id
      and MBR_HIST.PG_ID=NCFHIST.pe_id and  MBR_HIST.srvcg_npi=NCFHIST.payee_prov_npi
      and MBR_HIST.CPTTN_INCRD_FROM_DT=NCFHIST.paymnt_bgn_dt
      left outer join SIT_TRAN_HOST_SOURCE_CURR NCFCURR_host on MBR_HIST.MCID=NCFCURR_host.cnsstnt_mbr_id
      and  MBR_HIST.PG_ID=NCFCURR_host.PG_ID and  MBR_HIST.srvcg_npi=NCFCURR_host.srvcg_npi
      and  MBR_HIST.CPTTN_INCRD_FROM_DT=NCFCURR_host.CPTTN_INCRD_FROM_DT """)

    resultN.write.format("parquet").mode("overwrite").insertInto(f"${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOST_CARE_VBP_FNL")
    val result = spark.sql(f"select * from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOST_CARE_VBP_FNL")

    //result.persist()

    //   val rc=result.count

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_TRAN_HOST_FNL")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select * from SIT_TRAN_HOST_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_TRAN_HOST_FNL")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select * from SIT_TRAN_HOST_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOST - target query- 042") {

    val id = Array("042")
    val name = Array("Test case :HOST - target query - 042 ")

    val result = spark.sql(s"""select cnsstnt_mbr_id,MMI_ID, MBR_ID, PE_ID, payee_prov_npi, paymnt_bgn_dt,
      paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care
      where trim(mmi_id) <> '' union all
      select cnsstnt_mbr_id, MMI_ID, MBR_ID, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt
      from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> ''
      and load_log_key=${df1}""")

    //result.persist()

    //    val rc=result.count

    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id,MMI_ID, MBR_ID, PE_ID, payee_prov_npi, paymnt_bgn_dt,paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_carewhere trim(mmi_id) <> '' union allselect cnsstnt_mbr_id, MMI_ID, MBR_ID, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amtfrom ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> ''and load_log_key=${df1}")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id,MMI_ID, MBR_ID, PE_ID, payee_prov_npi, paymnt_bgn_dt,paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_carewhere trim(mmi_id) <> '' union allselect cnsstnt_mbr_id, MMI_ID, MBR_ID, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amtfrom ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> ''and load_log_key=${df1}")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOST - MINUS query -6 (Reconcile amounts at record level) - 043") {

    val id = Array("043")
    val name = Array("Test case : - HOST - MINUS query -6 (Reconcile amounts at record level) - 043 ")

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, MMI_ID, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id,MMI_ID, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=${df1}""")
    val result2 = spark.sql(s"""select DISTINCT CNSSTNT_MBR_ID,MMI_ID, PG_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from SIT_TRAN_HOST_FNL""")

    val result = result1.except(result2)

    result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, MMI_ID, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id,MMI_ID, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT CNSSTNT_MBR_ID,MMI_ID, PG_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from SIT_TRAN_HOST_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, MMI_ID, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id,MMI_ID, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT CNSSTNT_MBR_ID,MMI_ID, PG_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from SIT_TRAN_HOST_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOST - MINUS query -7 (Reconcile amounts at PG_ID level) - 044") {

    val id = Array("044")
    val name = Array("Test case : - HOST - MINUS query -7 (Reconcile amounts at PG_ID level) - 044 ")

    //val result1 = spark.sql(s"""select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> ''""")
    //val result2 = spark.sql(s"""select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=""" + df1)

    val result3 = spark.sql(s"""select a.pe_id,sum(paye_paymnt_amt ) from( select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where load_log_key=${df1} and trim(mmi_id) <> '') a group by a.pe_id order by a.pe_id""")

    // result3.createTempView("res3")

    //  val result4 = spark.sql(s"""select pe_id,sum(paye_paymnt_amt ) from res3 group by pe_id order by pe_id""")

    val result5 = spark.sql(s"""select pg_id,sum(paye_paymnt_amt ) from (select distinct cnsstnt_mbr_id, pg_id, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from SIT_TRAN_HOST_FNL) A group by pg_id order by pg_id""")

    val result = result3.except(result5)

    result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select a.pe_id,sum(paye_paymnt_amt ) from( select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where load_log_key=${df1} and trim(mmi_id) <> '') a group by a.pe_id order by a.pe_id minus select pg_id,sum(paye_paymnt_amt ) from (select distinct cnsstnt_mbr_id, pg_id, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from SIT_TRAN_HOST_FNL) A group by pg_id order by pg_id")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select a.pe_id,sum(paye_paymnt_amt ) from( select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where load_log_key=${df1} and trim(mmi_id) <> '') a group by a.pe_id order by a.pe_id minus select pg_id,sum(paye_paymnt_amt ) from (select distinct cnsstnt_mbr_id, pg_id, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from SIT_TRAN_HOST_FNL) A group by pg_id order by pg_id")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOST - MINUS query -8 (Validate Plan level details) - 045") {

    val id = Array("045")
    val name = Array("Test case : - HOST - MINUS query -8 (Validate Plan level details) - 045 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    //val llk = spark.sql("""select distinct(load_log_key),load_dt from ts_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care order by load_dt desc limit 1""")

    //val df1 = llk.select($"load_log_key").rdd.first()(0)

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=${df1}""")
    val result2 = spark.sql(s"""select DISTINCT CNSSTNT_MBR_ID,MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PG_ID, vbp_id from SIT_TRAN_HOST_FNL""")

    val result = result1.except(result2)

    result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT CNSSTNT_MBR_ID,MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PG_ID, vbp_id from SIT_TRAN_HOST_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT CNSSTNT_MBR_ID,MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PG_ID, vbp_id from SIT_TRAN_HOST_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOST - MINUS query -9 (Validate payment details) - 046") {

    val id = Array("046")
    val name = Array("Test case : - HOST - MINUS query -9 (Validate payment details) - 046 ")

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=${df1}""")
    val result2 = spark.sql(s"""select DISTINCT cnsstnt_mbr_id, PG_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from SIT_TRAN_HOST_FNL""")

    val result = result1.except(result2)

    result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PG_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from SIT_TRAN_HOST_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PG_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from SIT_TRAN_HOST_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - HOST - MINUS query -10 (Validate provider details) - 047") {

    val id = Array("047")
    val name = Array("Test case : - HOST - MINUS query -10 (Validate provider details) - 047 ")

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=${df1}""")
    val result2 = spark.sql(s"""select DISTINCT cnsstnt_mbr_id, PG_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from SIT_TRAN_HOST_FNL""")

    val result = result1.except(result2)

    result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PG_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from SIT_TRAN_HOST_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PG_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from SIT_TRAN_HOST_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - Default columns check - 048") {

    val id = Array("048")
    val name = Array("Test case : - Default columns check - 048 ")

    val result = spark.sql(s"""select distinct ncf_paymnt_type_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where ncf_paymnt_type_cd <> 'C'""")

    result.persist()

    //   val rc=result.count

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select distinct ncf_paymnt_type_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where ncf_paymnt_type_cd <> 'C'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select distinct ncf_paymnt_type_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care where ncf_paymnt_type_cd <> 'C'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("VBP_CARE  - Duplicate check - 049") {

    val id = Array("049")
    val name = Array("Test case : - Duplicate check - 049 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(s"""select MMI_ID,cnsstnt_mbr_id,bhi_home_plan_id,bhi_host_plan_id,paymnt_bgn_dt,ncf_paymnt_type_cd,count(1) as record_count from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care group by MMI_ID,cnsstnt_mbr_id,bhi_home_plan_id,bhi_host_plan_id,paymnt_bgn_dt,ncf_paymnt_type_cd having count(1)>1""")

    result.persist()

    //   val rc=result.count

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select MMI_ID,cnsstnt_mbr_id,bhi_home_plan_id,bhi_host_plan_id,paymnt_bgn_dt,ncf_paymnt_type_cd,count(1) as record_count from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care group by MMI_ID,cnsstnt_mbr_id,bhi_home_plan_id,bhi_host_plan_id,paymnt_bgn_dt,ncf_paymnt_type_cd having count(1)>1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select MMI_ID,cnsstnt_mbr_id,bhi_home_plan_id,bhi_host_plan_id,paymnt_bgn_dt,ncf_paymnt_type_cd,count(1) as record_count from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_care group by MMI_ID,cnsstnt_mbr_id,bhi_home_plan_id,bhi_host_plan_id,paymnt_bgn_dt,ncf_paymnt_type_cd having count(1)>1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCFCare/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

}