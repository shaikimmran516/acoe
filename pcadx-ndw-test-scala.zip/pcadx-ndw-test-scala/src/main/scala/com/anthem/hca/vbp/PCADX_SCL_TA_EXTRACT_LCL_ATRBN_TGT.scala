package com.anthem.hca.vbp

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
//import com.holdenkarau.spark.testing.SharedSparkContext
//import com.holdenkarau.spark.testing.RDDComparisons
//import com.holdenkarau.spark.testing.DataFrameSuiteBase
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._
import sys.process._
import java.text.SimpleDateFormat
import java.sql.Timestamp
import org.joda.time._
import org.joda.time.format.DateTimeFormat
import java.util.Calendar
import java.sql.Timestamp
import java.text.SimpleDateFormat
import org.apache.spark.sql.DataFrame

object PCADX_SCL_TA_EXTRACT_LCL_ATRBN_TGT {
 
  def main(args: Array[String]) {

    (new PCADX_SCL_TA_EXTRACT_LCL_ATRBN_TGT(args(0),args(1),args(2))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_EXTRACT_LCL_ATRBN_TGT(dbname : String, env : String, pg_id:String) extends FunSuite {

 val now = Calendar.getInstance().getTime()
  val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
  val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
  val currdate = formatter.format(new Date())
  val currdate1 = formatter1.format(new Date())

  /*   val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()


      import sqlContext.implicits._
      import sqlContext.sql	*/

  val warehouseLocation = new File("/user/hive/warehouse").getAbsolutePath

  val sc = SparkContext.getOrCreate()
  sc.setLogLevel("ERROR")

  val spark = SparkSession.builder().appName("Automation test cases for VBP NCF Care Catchup").config("spark.sql.warehouse.dir", warehouseLocation).enableHiveSupport().getOrCreate()

  spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode", "INFER_ONLY")
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  spark.conf.set("spark.sql.shuffle.partitons", 2010)
 // spark.conf.set("spark.sql.hive.convertMetastoreParquet",false)

  import spark.implicits._
  import spark.sql

  val subj = "Extract"
  val prcss = "LCL_ARTBN"

  val llk = spark.sql(f"""select distinct(load_log_key),load_dt from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn order by load_dt desc limit 1""")

  var df1 = llk.select($"load_log_key").rdd.first()(0)

  val sday = Calendar.getInstance()
  val startday = sday.get(Calendar.YEAR) + "-" + "%02d".format(sday.get(Calendar.MONTH).+(1)) + "-" + sday.getActualMinimum(Calendar.DATE)
  val endday = sday.get(Calendar.YEAR) + "-" + "%02d".format(sday.get(Calendar.MONTH).+(1)) + "-" + sday.getActualMaximum(Calendar.DATE)

  val RUNEND = endday.toString
  val RUNSTART = startday.toString()
  var startdateFnl = ""
  var enddateFnl = ""

  val ACTDatesSql1 = sql(f"""Select  strt_dtm,end_dtm  FROM ${dbname}_pcandw1ph_nogbd_r000_wh.BOT_BCBSA_EXTRCT_PRCSG WHERE subj_area_nm = "VBP_BCBSA_LCL_ATRBN"""")
  if (!ACTDatesSql1.head(1).isEmpty) {
    val actdates = ACTDatesSql1.rdd.map(x => (x.getTimestamp(0), x.getTimestamp(1)))
    val list: List[(Timestamp, Timestamp)] = actdates.collect().toList
    val startdate: List[Timestamp] = list.map(_._1)
    val enddate: List[Timestamp] = list.map(_._2)
    startdateFnl = startdate(0).toString().substring(0, 10)
    enddateFnl = enddate(0).toString().substring(0, 10)
  } else {
    startdateFnl = RUNSTART
    enddateFnl = RUNEND
  } 
      
      

  //----------------------------------------------------------------------------------------------------------- 
      
     test("LCLAtrbn - Validate that MMI Identifier is not NULL or contains blank spaces - 001") {
 
       val id = Array("001")
       
       val name = Array("Validate that MMI Identifier is not NULL or contains blank spaces - 001")

val result = spark.sql(s""" select distinct mmi_id from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn""")

if (result.count == 1) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct mmi_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct mmi_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate that Consistent Member ID is not NULL or contains blank spaces - 002") {
 
       val id = Array("002")
       
       val name = Array("Validate that Consistent Member ID is not NULL or contains blank spaces - 002")

val result = spark.sql(s""" select distinct(b.cnsstnt_mbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where length(trim(regexp_replace(cnsstnt_mbr_id," ",""))) = 0""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(b.cnsstnt_mbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where length(trim(regexp_replace(cnsstnt_mbr_id,' ',''))) = 0")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(b.cnsstnt_mbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where  length(trim(regexp_replace(cnsstnt_mbr_id,' ',''))) = 0")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate that ITS Subscriber ID is not NULL or contains blank spaces - 003") {
 
       val id = Array("003")
       
       val name = Array("LCLAtrbn - Validate that ITS Subscriber ID is not NULL or contains blank spaces - 003")

val result = spark.sql(s""" select distinct(its_sbscrbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where length(trim(regexp_replace(its_sbscrbr_id," ", "")))=0 or its_sbscrbr_id is null""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(its_sbscrbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where length(trim(regexp_replace(its_sbscrbr_id,' ', '')))=0 or its_sbscrbr_id is null")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(its_sbscrbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where length(trim(regexp_replace(its_sbscrbr_id,' ', '')))=0 or its_sbscrbr_id is null")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate for Home Plan Member ID - 004") {
 
       val id = Array("004")
       
       val name = Array("Validate that Home Plan Member ID - 004")

val result = spark.sql(s""" select distinct(b.mbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where length(trim(regexp_replace(mbr_id," ",""))) = 0""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(b.mbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where length(trim(regexp_replace(mbr_id,' ',''))) = 0")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(b.mbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where length(trim(regexp_replace(mbr_id,' ',''))) = 0")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate the NDW Home Plan ID - 005") {
 
       val id = Array("005")
       
       val name = Array("Validate the NDW Home Plan ID - 005")

val result = spark.sql(s""" select distinct(e.bhi_home_plan_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn e where e.bhi_home_plan_id not in (select distinct(x.bhi_home_plan_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_xwalk x)""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(e.bhi_home_plan_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn e where e.bhi_home_plan_id not in (select distinct(x.bhi_home_plan_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_xwalk x)")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(e.bhi_home_plan_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn e where e.bhi_home_plan_id not in (select distinct(x.bhi_home_plan_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_xwalk x)")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate the NDW Host Plan ID - 006") {
 
       val id = Array("006")
       
       val name = Array("Validate the NDW Host Plan ID - 006")

val result = spark.sql(s""" select distinct (b.bhi_host_plan_id)  from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where b.bhi_host_plan_id not in 
( select distinct (x.bhi_home_plan_id) from ${dbname}_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_home_plan_cd_xwalk_inbnd x)""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct (b.bhi_host_plan_id)  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where b.bhi_host_plan_id not in ( select distinct (x.bhi_home_plan_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_home_plan_cd_xwalk_inbnd x)")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct (b.bhi_host_plan_id)  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where b.bhi_host_plan_id not in ( select distinct (x.bhi_home_plan_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_home_plan_cd_xwalk_inbnd x)")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate the Attributed Provider ID  - 007") {
 
       val id = Array("007")
       
       val name = Array("Validate the Attributed Provider ID - 007")

val result = spark.sql(s""" select count(*) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where b.atrbd_prov_id in (select distinct(e.SRC_SYS_ID_VAL_TXT) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_alt_src_id_altid e left outer join ${dbname}_pcandw1ph_nogbd_r000_in.pi_atrbn_mcid p on p.IP_NPI = e.EP_ALTID_VAL_TXT and e.EP_SOR_CD = 'EPDS V2')""")

if (result.count > 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select count(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where b.atrbd_prov_id in (select distinct(e.SRC_SYS_ID_VAL_TXT) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.ep_alt_src_id_altid e left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.pi_atrbn_mcid p on p.IP_NPI = e.EP_ALTID_VAL_TXT and e.EP_SOR_CD = 'EPDS V2')")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select count(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where b.atrbd_prov_id in (select distinct(e.SRC_SYS_ID_VAL_TXT) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.ep_alt_src_id_altid e left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.pi_atrbn_mcid p on p.IP_NPI = e.EP_ALTID_VAL_TXT and e.EP_SOR_CD = 'EPDS V2')")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
} 

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate that Attributed Provider First Name - 008") {
 
       val id = Array("008")
       
       val name = Array("Validate that Attributed Provider First Name - 008")
       

val result = spark.sql(s""" select distinct(b.atrbd_prov_frst_nm) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_LGL_FRST_NM) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e where trim(b.atrbd_prov_frst_nm) = trim(e.EP_LGL_FRST_NM)) and length(trim(regexp_replace(b.atrbd_prov_frst_nm," ",""))) = 0 and b.load_log_key = ${df1}""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_frst_nm) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_LGL_FRST_NM) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e where trim(b.atrbd_prov_frst_nm) = trim(e.EP_LGL_FRST_NM)) and length(trim(regexp_replace(b.atrbd_prov_frst_nm,' ',''))) = 0 and b.load_log_key = ${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query :select distinct(b.atrbd_prov_frst_nm) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_LGL_FRST_NM) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e where trim(b.atrbd_prov_frst_nm) = trim(e.EP_LGL_FRST_NM)) and length(trim(regexp_replace(b.atrbd_prov_frst_nm,' ',''))) = 0 and b.load_log_key = ${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate that Attributed Provider Last Name  - 009") {
 
       val id = Array("009")
       
       val name = Array("Validate that Attributed Provider Last Name  - 009")
       

val result = spark.sql(s""" select distinct(b.atrbd_prov_last_nm) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_LGL_LAST_NM) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e where trim(b.atrbd_prov_last_nm) = trim(e.EP_LGL_LAST_NM)) and length(trim(regexp_replace(b.atrbd_prov_last_nm," ",""))) = 0 and b.load_log_key =${df1}""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_last_nm) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_LGL_LAST_NM) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e where trim(b.atrbd_prov_last_nm) = trim(e.EP_LGL_LAST_NM)) and length(trim(regexp_replace(b.atrbd_prov_last_nm,' ',''))) = 0 and b.load_log_key =${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_last_nm) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_LGL_LAST_NM) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e where trim(b.atrbd_prov_last_nm) = trim(e.EP_LGL_LAST_NM)) and length(trim(regexp_replace(b.atrbd_prov_last_nm,' ',''))) = 0 and b.load_log_key =${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate that Attributed Provider Organization Name  - 010") {
 
       val id = Array("010")
       
       val name = Array("Validate that Attributed Provider Organization Name - 010")
       

val result = spark.sql(s""" select distinct(b.atrbd_prov_org_nm) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_ORG_NM) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e where trim(b.atrbd_prov_org_nm) = trim(e.EP_ORG_NM)) and length(trim(regexp_replace(b.atrbd_prov_org_nm," ",""))) = 0 and b.load_log_key =${df1}""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_org_nm) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_ORG_NM) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e where trim(b.atrbd_prov_org_nm) = trim(e.EP_ORG_NM)) and length(trim(regexp_replace(b.atrbd_prov_org_nm,' ',''))) = 0 and b.load_log_key =${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_org_nm) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_ORG_NM) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e where trim(b.atrbd_prov_org_nm) = trim(e.EP_ORG_NM)) and length(trim(regexp_replace(b.atrbd_prov_org_nm,' ',''))) = 0 and b.load_log_key =${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate that Attributed Provider Street Address 1  - 011") {
 
       val id = Array("011")
       
       val name = Array("Validate that Attributed Provider Street Address 1 - 011")
       

val result = spark.sql(s""" select distinct(b.atrbd_prov_str_adrs_1_txt) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_ADRS_LINE_1_TXT) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e where trim(b.atrbd_prov_str_adrs_1_txt) = trim(e.EP_ADRS_LINE_1_TXT)) and b.load_log_key =${df1}""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_str_adrs_1_txt) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_ADRS_LINE_1_TXT) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e where trim(b.atrbd_prov_str_adrs_1_txt) = trim(e.EP_ADRS_LINE_1_TXT)) and b.load_log_key =${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_str_adrs_1_txt) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_ADRS_LINE_1_TXT) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e where trim(b.atrbd_prov_str_adrs_1_txt) = trim(e.EP_ADRS_LINE_1_TXT)) and b.load_log_key =${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate the Attributed Provider Street Address 2  - 012") {
 
       val id = Array("012")
       
       val name = Array("Validate the Attributed Provider Street Address 2 - 012")
       

val result = spark.sql(s""" select distinct(b.atrbd_prov_str_adrs_2_txt) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e ON trim(b.atrbd_prov_str_adrs_2_txt) = trim(e.EP_ADRS_LINE_2_TXT) WHERE trim(b.atrbd_prov_str_adrs_2_txt)<>''""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_str_adrs_2_txt) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e ON trim(b.atrbd_prov_str_adrs_2_txt) = trim(e.EP_ADRS_LINE_2_TXT) WHERE trim(b.atrbd_prov_str_adrs_2_txt)<>''")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_str_adrs_2_txt) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e ON trim(b.atrbd_prov_str_adrs_2_txt) = trim(e.EP_ADRS_LINE_2_TXT) WHERE trim(b.atrbd_prov_str_adrs_2_txt)<>''")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate the Attributed Provider City  - 013") {
 
       val id = Array("013")
       
       val name = Array("Validate the Attributed Provider City  - 013")
       

val result = spark.sql(s""" select distinct(b.atrbd_prov_city_nm) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_ADRS_CITY_NM) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e where trim(b.atrbd_prov_city_nm) = trim(e.EP_ADRS_CITY_NM)) and b.load_log_key =${df1}""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_city_nm) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_ADRS_CITY_NM) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e where trim(b.atrbd_prov_city_nm) = trim(e.EP_ADRS_CITY_NM)) and b.load_log_key =${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_city_nm) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_ADRS_CITY_NM) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e where trim(b.atrbd_prov_city_nm) = trim(e.EP_ADRS_CITY_NM)) and b.load_log_key =${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate the Attributed Provider State - 014") {
 
       val id = Array("014")
       
       val name = Array("Validate the Attributed Provider State  - 014")
       

val result = spark.sql(s""" select distinct(b.atrbd_prov_st_cd) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_ADRS_ST_PRVNC_CD) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e where trim(b.atrbd_prov_st_cd) = trim(e.EP_ADRS_ST_PRVNC_CD)) and b.load_log_key =${df1}""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_st_cd) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_ADRS_ST_PRVNC_CD) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e where trim(b.atrbd_prov_st_cd) = trim(e.EP_ADRS_ST_PRVNC_CD)) and b.load_log_key =${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_st_cd) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where not exists (select distinct(e.EP_ADRS_ST_PRVNC_CD) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e where trim(b.atrbd_prov_st_cd) = trim(e.EP_ADRS_ST_PRVNC_CD)) and b.load_log_key =${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate the Attributed Provider ZIP Code  - 015") {
 
       val id = Array("015")
       
       val name = Array("Validate the Attributed Provider ZIP Code - 015")
      
val result = spark.sql(s""" select distinct(h.atrbd_prov_zip_cd) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn h where not exists (select distinct(e.EP_ADRS_POSTL_CD) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e where h.atrbd_prov_zip_cd = e.EP_ADRS_POSTL_CD) and h.load_log_key =${df1}""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(h.atrbd_prov_zip_cd) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn h where not exists (select distinct(e.EP_ADRS_POSTL_CD) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e where h.atrbd_prov_zip_cd = e.EP_ADRS_POSTL_CD) and h.load_log_key =${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(h.atrbd_prov_zip_cd) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn h where not exists (select distinct(e.EP_ADRS_POSTL_CD) from ${dbname}_pcandw1ph_nogbd_r000_in.ep_adrs e where h.atrbd_prov_zip_cd = e.EP_ADRS_POSTL_CD) and h.load_log_key =${df1}")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate the Attribution Period Begin Date - 016") {
 
       val id = Array("016")
       
       val name = Array("Validate the Attribution Period Begin Date  - 016")

val result = spark.sql(s""" select distinct(atrbn_prd_bgn_dt) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where trunc(atrbn_prd_bgn_dt,'MM') <> trunc(atrbn_prd_bgn_dt,'MM')""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query :select distinct(atrbn_prd_bgn_dt) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where trunc(atrbn_prd_bgn_dt,'MM') <> trunc(atrbn_prd_bgn_dt,'MM') ")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(atrbn_prd_bgn_dt) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where trunc(atrbn_prd_bgn_dt,'MM') <> trunc(atrbn_prd_bgn_dt,'MM')")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate for Attribution Period End Date  - 017") {
 
       val id = Array("017")
       
       val name = Array("Validate for Attribution Period End Date  - 017")

val result = spark.sql(s""" select distinct((atrbn_prd_end_dt)) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where last_day(atrbn_prd_end_dt) <> last_day(atrbn_prd_end_dt)""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct((atrbn_prd_end_dt)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where last_day(atrbn_prd_end_dt) <> last_day(atrbn_prd_end_dt)")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct((atrbn_prd_end_dt)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where last_day(atrbn_prd_end_dt) <> last_day(atrbn_prd_end_dt)")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate for Attributed Provider Tax ID - 018") {
 
       val id = Array("018")
       
       val name = Array("Validate for Attributed Provider Tax ID - 018")
       

val result = spark.sql(s""" select distinct(b.atrbd_prov_tax_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where b.atrbd_prov_tax_id not in (select distinct(e.PROV_ORG_TAX_ID) from ${dbname}_pcandw1ph_nogbd_r000_in.pi_atrbn_mcid e) and b.atrbd_prov_tax_id is null and load_log_key =${df1}""")

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_tax_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where b.atrbd_prov_tax_id not in (select distinct(e.PROV_ORG_TAX_ID) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.pi_atrbn_mcid e) and b.atrbd_prov_tax_id is null and load_log_key =  +df1")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(b.atrbd_prov_tax_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where b.atrbd_prov_tax_id not in (select distinct(e.PROV_ORG_TAX_ID) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.pi_atrbn_mcid e)")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate for Provider Entity Identifier - 019") {
 
       val id = Array("019")
       
       val name = Array("Validate for Provider Entity Identifier - 019")

val result = spark.sql(s""" select distinct(b.pe_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where b.pe_id not in (select distinct(e.PG_ID) from ${dbname}_pcandw1ph_nogbd_r000_in.PI_ATRBN_MCID e) """)

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(b.pe_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where b.pe_id not in (select distinct(e.PG_ID) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.pi_atrbn e)")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(b.pe_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b where b.pe_id not in (select distinct(e.PG_ID) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.pi_atrbn e)")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate for Member-Selected PCP Indicator is as per the transformation logic- 020") {
 
       val id = Array("020")
       
       val name = Array("Validate for PMember-Selected PCP Indicator is as per the transformation logic - 020")

val result = spark.sql(s""" select distinct(mbr_sl_pcp_ind) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn""")

if (result.count == 1) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(mbr_sl_pcp_ind) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(mbr_sl_pcp_ind) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate for Filler1 is as per the transformation logic- 021") {
 
       val id = Array("021")
       
       val name = Array("Validate for Filler1 is as per the transformation logic- 021")

val result = spark.sql(s""" select distinct(fillr_2) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn """)

if (result.count == 1) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(fillr_2) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn ")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(fillr_2) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where atrbn_prd_bgn_dt = '2018-12-01' ")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate for Filler2 is as per the transformation logic- 022") {
 
       val id = Array("022")
       
       val name = Array("Validate for Filler2 is as per the transformation logic- 022")

val result = spark.sql(s""" select distinct(fillr_2) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn """)

if (result.count == 1) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(fillr_2) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn ")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(fillr_2) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where atrbn_prd_bgn_dt = '2018-12-01' ")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate for Attribution Indicator not having other than value 'Y'- 023") {
 
       val id = Array("023")
       
       val name = Array("Validate for Attribution Indicator not having other than value 'Y'- 023")

val result = spark.sql(s""" select distinct(atrbn_ind) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where atrbn_ind <> 'Y' """)

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(atrbn_ind) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where atrbn_ind <> 'Y'")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(atrbn_ind) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn where atrbn_ind <> 'Y'")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate for Not Attributed Reason Code is as per the transformation logic- 024") {
 
       val id = Array("024")
       
       val name = Array("Validate for Not Attributed Reason Code is as per the transformation logic- 024")

val result = spark.sql(s""" select distinct(not_atrbd_rsn_cd) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn""")

if (result.count == 1) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(not_atrbd_rsn_cd) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(not_atrbd_rsn_cd) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate for Host Plan Corporate Plan Code is as per the transformation logic- 025") {
 
       val id = Array("025")
       
       val name = Array("Validate for Host Plan Corporate Plan Code is as per the transformation logic- 025")

val result = spark.sql(s""" select distinct(host_plan_crprt_plan_cd) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn""")

if (result.count == 1) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(host_plan_crprt_plan_cd) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(host_plan_crprt_plan_cd) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate for Home Plan Corporate Plan Code is as per the transformation logic- 026") {
 
       val id = Array("026")
       
       val name = Array("Validate for Home Plan Corporate Plan Code is as per the transformation logic- 026")

val result = spark.sql(s""" select distinct(home_plan_crprt_plan_cd) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn""")

if (result.count == 1) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query : select distinct(home_plan_crprt_plan_cd) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select distinct(home_plan_crprt_plan_cd) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//--------------------------------------------------------------------------------------

test("LCLAtrbn - Validate for Provider Entity Name is as per the transformation logic- 027") {

       val id = Array("027")
       
       val name = Array("Validate for Provider Entity Name is as per the transformation logic- 027")

val result = spark.sql(s""" select b.atrbn_prov_pgm_nm from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b LEFT outer JOIN ${dbname}_pcandw1ph_nogbd_r000_in.pg_dtl e ON b.atrbn_prov_pgm_nm=e.PG_NM where e.PG_NM is null and length(trim(regexp_replace(b.atrbn_prov_pgm_nm," ",""))) = 0 """)

if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
	   val query = Array("Test Query :select b.atrbn_prov_pgm_nm from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b LEFT outer JOIN ${dbname}_pcandw1ph_nogbd_r000_in.pg_dtl e ON b.atrbn_prov_pgm_nm=e.PG_NM where e.PG_NM is null and length(trim(regexp_replace(b.atrbn_prov_pgm_nm,' ',''))) = 0 ")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==1)  
}
else {
val a = result.limit(10).rdd
       val status = Array("FAILED")
	   val query = Array("Test Query : select b.atrbn_prov_pgm_nm from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn b LEFT outer JOIN ${dbname}_pcandw1ph_nogbd_r000_in.pg_dtl e ON b.atrbn_prov_pgm_nm=e.PG_NM where e.PG_NM is null and length(trim(regexp_replace(b.atrbn_prov_pgm_nm,' ',''))) = 0")
	   
sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
assert(1==2)  
}
}

//-----------------------------------------------------------------------------------------------

  test("LCL_ATRBN - Fetch data from PI_ATRBN_MCID table for latest attribution dates - 028") {

    val id = Array("028")
    val name = Array("Test case : Fetch data from PI_ATRBN_MCID table for latest attribution dates - 028 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(f"""select distinct  PA.MCID, PA.MBR_KEY, PA.PG_ID, PA.IP_NPI, PA.PROV_ORG_TAX_ID, 
PA.ATRBN_EFCTV_DT, PA.ATRBN_TRMNTN_DT, PA.PI_PGM_ID from ${dbname}_pcandw1ph_nogbd_r000_in.PI_ATRBN_MCID 
PA WHERE PA.RCRD_STTS_CD<>'DEL' AND PA.VRSN_CLOS_DT= '8888-12-31' AND PA.ATRBN_EFCTV_DT<='${enddateFnl}' AND 
PA.ATRBN_TRMNTN_DT >=CURRENT_DATE AND PG_ID='${pg_id}'""")

    println("select distinct  PA.MCID, PA.MBR_KEY, PA.PG_ID, PA.IP_NPI, PA.PROV_ORG_TAX_ID, PA.ATRBN_EFCTV_DT, PA.ATRBN_TRMNTN_DT, PA.PI_PGM_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_in.PI_ATRBN_MCID PA WHERE PA.RCRD_STTS_CD<>'DEL' AND PA.VRSN_CLOS_DT= '8888-12-31' AND PA.ATRBN_EFCTV_DT<='2018-10-31' AND PA.ATRBN_TRMNTN_DT >='2018-01-01' AND PG_ID='${pg_id}'")

    result.persist()

    val rc = result.count()

    println("result count is ============================= " + result.count().toInt)

    if (rc > 0) {
      result.createOrReplaceTempView("SIT_ATRBN")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct  PA.MCID, PA.MBR_KEY, PA.PG_ID, PA.IP_NPI, PA.PROV_ORG_TAX_ID, PA.ATRBN_EFCTV_DT, PA.ATRBN_TRMNTN_DT, PA.PI_PGM_ID from ${dbname}_pcandw1ph_nogbd_r000_in.PI_ATRBN_MCID PA WHERE PA.RCRD_STTS_CD<>'DEL' AND PA.VRSN_CLOS_DT= '8888-12-31' AND PA.ATRBN_EFCTV_DT<='${enddateFnl}' AND PA.ATRBN_TRMNTN_DT >=CURRENT_DATE AND PG_ID='${pg_id}'")

  sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct  PA.MCID, PA.MBR_KEY, PA.PG_ID, PA.IP_NPI, PA.PROV_ORG_TAX_ID, PA.ATRBN_EFCTV_DT, PA.ATRBN_TRMNTN_DT, PA.PI_PGM_ID from ${dbname}_pcandw1ph_nogbd_r000_in.PI_ATRBN_MCID PA WHERE PA.RCRD_STTS_CD<>'DEL' AND PA.VRSN_CLOS_DT= '8888-12-31' AND PA.ATRBN_EFCTV_DT<='${enddateFnl}' AND PA.ATRBN_TRMNTN_DT >=CURRENT_DATE AND PG_ID='${pg_id}'")

   sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Filter data from previous step based on PGM_TYPE_CD IN ('8000','8001','8004','8005','8024') and matching members in BCBSA_MBRSHP_XWALK table - 029") {

    val id = Array("029")
    val name = Array("Test case : Filter data from previous step based on PGM_TYPE_CD IN ('8000','8001','8004','8005','8024') and matching members in BCBSA_MBRSHP_XWALK table - 029 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(f"""select distinct XWALK.BHI_HOME_PLAN_ID,  PA.MCID, XWALK.cnsstnt_mbr_id, 
      XWALK.MBR_KEY AS XWALK_MBR_KEY, PA.MBR_KEY AS PA_MBR_KEY, PA.PG_ID, PA.IP_NPI, DTL.PG_NM, 
      pgm.pgm_type_cd, PGM.PI_PGM_ID AS PGM_PI_PGM_ID, PA.PROV_ORG_TAX_ID, PA.PI_PGM_ID AS VBP_PI_PGM_ID, 
      PA.ATRBN_EFCTV_DT as PA_ATRBN_EFCTV_DT, PA.ATRBN_TRMNTN_DT AS PA_ATRBN_TRMNTN_DT, XWALK.cvrg_bgn_dt 
      AS cvrg_bgn_dt, XWALK.cvrg_end_dt AS cvrg_end_dt , DTL.PG_DTL_EFCTV_DT AS PG_DTL_EFCTV_DT, 
      DTL.PG_DTL_TRMNTN_DT AS PG_DTL_TRMNTN_DT from SIT_ATRBN PA  
      INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_XWALK XWALK 
        ON PA.MCID=XWALK.cnsstnt_mbr_id 
        LEFT OUTER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PG_DTL DTL ON PA.PG_ID=DTL.PG_ID 
          inner join ${dbname}_pcandw1ph_nogbd_r000_in.pi_pgm pgm on PA.pi_pgm_id=pgm.pi_pgm_id 
            AND PA.ATRBN_EFCTV_DT BETWEEN DTL.PG_DTL_EFCTV_DT AND DTL.PG_DTL_TRMNTN_DT 
            WHERE PGM.PGM_TYPE_CD IN ('8000','8001','8004','8005','8024') 
            AND PA.ATRBN_EFCTV_DT<>PA.ATRBN_TRMNTN_DT AND PA.atrbn_efctv_dt<=XWALK.cvrg_end_dt 
            and PA.atrbn_trmntn_dt>=XWALK.cvrg_bgn_dt AND PGM.PI_PGM_ID  NOT LIKE 'OA%%'""")

    result.persist()

    val rc = result.count()

    if (rc > 0) {
      result.createOrReplaceTempView("SIT_ATRBN_INT")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct XWALK.BHI_HOME_PLAN_ID,  PA.MCID, XWALK.cnsstnt_mbr_id, XWALK.MBR_KEY AS XWALK_MBR_KEY, PA.MBR_KEY AS PA_MBR_KEY, PA.PG_ID, PA.IP_NPI, DTL.PG_NM, pgm.pgm_type_cd, PGM.PI_PGM_ID AS PGM_PI_PGM_ID, PA.PROV_ORG_TAX_ID, PA.PI_PGM_ID AS VBP_PI_PGM_ID, PA.ATRBN_EFCTV_DT as PA_ATRBN_EFCTV_DT, PA.ATRBN_TRMNTN_DT AS PA_ATRBN_TRMNTN_DT, XWALK.cvrg_bgn_dt AS cvrg_bgn_dt, XWALK.cvrg_end_dt AS cvrg_end_dt , DTL.PG_DTL_EFCTV_DT AS PG_DTL_EFCTV_DT, DTL.PG_DTL_TRMNTN_DT AS PG_DTL_TRMNTN_DT from SIT_ATRBN PA INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_XWALK XWALK ON PA.MCID=XWALK.cnsstnt_mbr_id LEFT OUTER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PG_DTL DTL ON PA.PG_ID=DTL.PG_ID inner join ${dbname}_pcandw1ph_nogbd_r000_in.pi_pgm pgm on PA.pi_pgm_id=pgm.pi_pgm_id AND PA.ATRBN_EFCTV_DT BETWEEN DTL.PG_DTL_EFCTV_DT AND DTL.PG_DTL_TRMNTN_DT WHERE PGM.PGM_TYPE_CD IN ('8000','8001','8004','8005','8024') AND PA.ATRBN_EFCTV_DT<>PA.ATRBN_TRMNTN_DT AND PA.atrbn_efctv_dt<=XWALK.cvrg_end_dt and PA.atrbn_trmntn_dt>=XWALK.cvrg_bgn_dt AND PGM.PI_PGM_ID  NOT LIKE 'OA%%'")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_ATRBN_INT")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct XWALK.BHI_HOME_PLAN_ID,  PA.MCID, XWALK.cnsstnt_mbr_id, XWALK.MBR_KEY AS XWALK_MBR_KEY, PA.MBR_KEY AS PA_MBR_KEY, PA.PG_ID, PA.IP_NPI, DTL.PG_NM, pgm.pgm_type_cd, PGM.PI_PGM_ID AS PGM_PI_PGM_ID, PA.PROV_ORG_TAX_ID, PA.PI_PGM_ID AS VBP_PI_PGM_ID, PA.ATRBN_EFCTV_DT as PA_ATRBN_EFCTV_DT, PA.ATRBN_TRMNTN_DT AS PA_ATRBN_TRMNTN_DT, XWALK.cvrg_bgn_dt AS cvrg_bgn_dt, XWALK.cvrg_end_dt AS cvrg_end_dt , DTL.PG_DTL_EFCTV_DT AS PG_DTL_EFCTV_DT, DTL.PG_DTL_TRMNTN_DT AS PG_DTL_TRMNTN_DT from SIT_ATRBN PA INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_XWALK XWALK ON PA.MCID=XWALK.cnsstnt_mbr_id LEFT OUTER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PG_DTL DTL ON PA.PG_ID=DTL.PG_ID inner join ${dbname}_pcandw1ph_nogbd_r000_in.pi_pgm pgm on PA.pi_pgm_id=pgm.pi_pgm_id AND PA.ATRBN_EFCTV_DT BETWEEN DTL.PG_DTL_EFCTV_DT AND DTL.PG_DTL_TRMNTN_DT WHERE PGM.PGM_TYPE_CD IN ('8000','8001','8004','8005','8024') AND PA.ATRBN_EFCTV_DT<>PA.ATRBN_TRMNTN_DT AND PA.atrbn_efctv_dt<=XWALK.cvrg_end_dt and PA.atrbn_trmntn_dt>=XWALK.cvrg_bgn_dt AND PGM.PI_PGM_ID  NOT LIKE 'OA%%' ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Fetch data from ALL_MBR table - 030") {

    val id = Array("030")
    val name = Array("Test case : Fetch data from ALL_MBR table - 030 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(f"""SELECT A.mbr_key, A.HC_ID, A.ALPH_PRFX_ID,A.mbr_prod_enrlmnt_efctv_dt, 
      A.mbr_prod_enrlmnt_trmntn_dt from ${dbname}_pcandw1ph_nogbd_r000_wh.all_mbr A 
      LEFT SEMI JOIN SIT_ATRBN_INT B ON A.MBR_KEY=B.XWALK_MBR_KEY""")

    //result.persist()

    val rc = result.count()
 
    if (rc > 0) {
      result.createOrReplaceTempView("SIT_ATRBN_MBR_INT")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT A.mbr_key, A.HC_ID, A.ALPH_PRFX_ID,A.mbr_prod_enrlmnt_efctv_dt, A.mbr_prod_enrlmnt_trmntn_dt from ${dbname}_pcandw1ph_nogbd_r000_wh.all_mbr A LEFT SEMI JOIN SIT_ATRBN_INT B ON A.MBR_KEY=B.XWALK_MBR_KEY")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_ATRBN_MBR_INT")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT A.mbr_key, A.HC_ID, A.ALPH_PRFX_ID,A.mbr_prod_enrlmnt_efctv_dt, A.mbr_prod_enrlmnt_trmntn_dt from ${dbname}_pcandw1ph_nogbd_r000_wh.all_mbr A LEFT SEMI JOIN SIT_ATRBN_INT B ON A.MBR_KEY=B.XWALK_MBR_KEY ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Combine data from #29 and #30 - 031") {

    val id = Array("031")
    val name = Array("Test case : Combine data from #29 and #30 - 031 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(f""" SELECT DISTINCT * FROM (SELECT B.MCID, B.PA_ATRBN_EFCTV_DT, A.mbr_key, A.HC_ID, 
      A.ALPH_PRFX_ID,A.mbr_prod_enrlmnt_efctv_dt, A.mbr_prod_enrlmnt_trmntn_dt,
      RANK() OVER(PARTITION BY B.MCID, B.PA_ATRBN_EFCTV_DT, A.mbr_prod_enrlmnt_trmntn_dt, 
      A.mbr_prod_enrlmnt_efctv_dt ORDER BY A.mbr_prod_enrlmnt_trmntn_dt DESC,A.mbr_prod_enrlmnt_efctv_dt desc,
      ALPH_PRFX_ID ASC) AS RNK from SIT_ATRBN_MBR_INT A 
      INNER JOIN SIT_ATRBN_INT B ON A.MBR_KEY=B.XWALK_MBR_KEY) as B WHERE RNK=1 """)

    //result.persist()

    val rc = result.count()

    if (rc > 0) {
      result.createOrReplaceTempView("SIT_ATRBN_MBR")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT DISTINCT * FROM (SELECT B.MCID, B.PA_ATRBN_EFCTV_DT, A.mbr_key, A.HC_ID, A.ALPH_PRFX_ID,A.mbr_prod_enrlmnt_efctv_dt, A.mbr_prod_enrlmnt_trmntn_dt,RANK() OVER(PARTITION BY B.MCID, B.PA_ATRBN_EFCTV_DT, A.mbr_prod_enrlmnt_trmntn_dt, A.mbr_prod_enrlmnt_efctv_dt ORDER BY A.mbr_prod_enrlmnt_trmntn_dt DESC,A.mbr_prod_enrlmnt_efctv_dt desc,ALPH_PRFX_ID ASC) AS RNK from SIT_ATRBN_MBR_INT A INNER JOIN SIT_ATRBN_INT B ON A.MBR_KEY=B.XWALK_MBR_KEY) as B WHERE RNK=1")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_ATRBN_MBR")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT DISTINCT * FROM (SELECT B.MCID, B.PA_ATRBN_EFCTV_DT, A.mbr_key, A.HC_ID, A.ALPH_PRFX_ID,A.mbr_prod_enrlmnt_efctv_dt, A.mbr_prod_enrlmnt_trmntn_dt,RANK() OVER(PARTITION BY B.MCID, B.PA_ATRBN_EFCTV_DT, A.mbr_prod_enrlmnt_trmntn_dt, A.mbr_prod_enrlmnt_efctv_dt ORDER BY A.mbr_prod_enrlmnt_trmntn_dt DESC,A.mbr_prod_enrlmnt_efctv_dt desc,ALPH_PRFX_ID ASC) AS RNK from SIT_ATRBN_MBR_INT A INNER JOIN SIT_ATRBN_INT B ON A.MBR_KEY=B.XWALK_MBR_KEY) as B WHERE RNK=1 ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Fetch Provider id data- 032") {

    val id = Array("032")
    val name = Array("Test case : Fetch Provider id data - 032 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(f"""select distinct XWALK.BHI_HOME_PLAN_ID, XWALK.MCID, XWALK.cnsstnt_mbr_id, 
      XWALK.PA_MBR_KEY,XWALK.XWALK_MBR_KEY, XWALK.PG_ID, XWALK.IP_NPI, XWALK.PG_NM, XWALK.pgm_type_cd, 
      XWALK.PGM_PI_PGM_ID, XWALK.PROV_ORG_TAX_ID, XWALK.VBP_PI_PGM_ID, XWALK.PA_ATRBN_EFCTV_DT, 
      XWALK.PA_ATRBN_TRMNTN_DT, XWALK.cvrg_bgn_dt, XWALK.cvrg_end_dt , XWALK.PG_DTL_EFCTV_DT, 
      XWALK.PG_DTL_TRMNTN_DT, CASE WHEN  SUBSTR(TRIM(bmd.HC_ID),1,3)=TRIM(bmd.ALPH_PRFX_ID) 
      THEN TRIM(bmd.HC_ID) else CONCAT_ws('',TRIM(bmd.ALPH_PRFX_ID),TRIM(bmd.HC_ID)) END  AS ITS_SBSCRBR_ID, 
      A.SRC_SYS_ID_VAL_TXT ,A.EP_SOR_CD,A.EP_ADRS_ID ,A.EP_ADRS_TYPE_CD,A.SRC_SYS_SOR_CD,A.SOR_DTM,
      A.EP_ID,A.EP_ALTID_VAL_TXT,A.EP_ALTID_TYPE_CD, B.SRC_SYS_ID_VAL_TXT as ALT_SRC_SYS_ID_VAL_TXT,
      B.EP_ALTID_VAL_TXT as ALT_EP_ALTID_VAL_TXT from SIT_ATRBN_INT XWALK 
      INNER JOIN SIT_ATRBN_MBR bmd on XWALK.MCID=bmd.MCID AND XWALK.PA_ATRBN_EFCTV_DT=bmd.PA_ATRBN_EFCTV_DT 
      INNER join ${dbname}_pcandw1ph_nogbd_r000_in.EP_ALT_SRC_ID_ALTID a on XWALK.IP_NPI=a.EP_ALTID_VAL_TXT 
      AND A.EP_ALTID_TYPE_CD  IN ('8014','33','8015') AND A.RCRD_STTS_CD <> 'DEL' 
      and A.SRC_SYS_SOR_CD NOT IN ('GBD') 
      LEFT OUTER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.EP_ALT_SRC_ID_ALTID B 
      ON A.SRC_SYS_ID_VAL_TXT=B.SRC_SYS_ID_VAL_TXT AND B.EP_ALTID_TYPE_CD  IN ('8039') 
      AND B.RCRD_STTS_CD <> 'DEL' and B.EP_SOR_CD='EPDS V2' WHERE A.EP_SOR_CD='EPDS V2'""")

    result.persist()

    val rc = result.count()

    if (rc > 0) {
      result.createOrReplaceTempView("SIT_ATRBN_FNL_NEW")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct XWALK.BHI_HOME_PLAN_ID, XWALK.MCID, XWALK.cnsstnt_mbr_id,XWALK.PA_MBR_KEY,XWALK.XWALK_MBR_KEY, XWALK.PG_ID, XWALK.IP_NPI, XWALK.PG_NM, XWALK.pgm_type_cd,XWALK.PGM_PI_PGM_ID, XWALK.PROV_ORG_TAX_ID, XWALK.VBP_PI_PGM_ID, XWALK.PA_ATRBN_EFCTV_DT,XWALK.PA_ATRBN_TRMNTN_DT, XWALK.cvrg_bgn_dt, XWALK.cvrg_end_dt , XWALK.PG_DTL_EFCTV_DT,XWALK.PG_DTL_TRMNTN_DT, CASE WHEN  SUBSTR(TRIM(bmd.HC_ID),1,3)=TRIM(bmd.ALPH_PRFX_ID)THEN TRIM(bmd.HC_ID) else CONCAT_ws('',TRIM(bmd.ALPH_PRFX_ID),TRIM(bmd.HC_ID)) END  AS ITS_SBSCRBR_ID,A.SRC_SYS_ID_VAL_TXT,A.EP_SOR_CD,A.EP_ADRS_ID,A.EP_ADRS_TYPE_CD,A.SRC_SYS_SOR_CD,A.SOR_DTM,A.EP_ID,A.EP_ALTID_VAL_TXT,A.EP_ALTID_TYPE_CD, B.SRC_SYS_ID_VAL_TXT as ALT_SRC_SYS_ID_VAL_TXT,B.EP_ALTID_VAL_TXT as ALT_EP_ALTID_VAL_TXT from SIT_ATRBN_INT XWALKINNER JOIN SIT_ATRBN_MBR bmd on XWALK.MCID=bmd.MCID AND XWALK.PA_ATRBN_EFCTV_DT=bmd.PA_ATRBN_EFCTV_DTINNER join ${dbname}_pcandw1ph_nogbd_r000_in.EP_ALT_SRC_ID_ALTID a on XWALK.IP_NPI=a.EP_ALTID_VAL_TXTAND A.EP_ALTID_TYPE_CD  IN ('8014','33','8015') AND A.RCRD_STTS_CD <> 'DEL'and A.SRC_SYS_SOR_CD NOT IN ('GBD')LEFT OUTER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.EP_ALT_SRC_ID_ALTID BON A.SRC_SYS_ID_VAL_TXT=B.SRC_SYS_ID_VAL_TXT AND B.EP_ALTID_TYPE_CD  IN ('8039')AND B.RCRD_STTS_CD <> 'DEL' and B.EP_SOR_CD='EPDS V2' WHERE A.EP_SOR_CD='EPDS V2'")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_ATRBN_FNL_NEW")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct XWALK.BHI_HOME_PLAN_ID, XWALK.MCID, XWALK.cnsstnt_mbr_id,XWALK.PA_MBR_KEY,XWALK.XWALK_MBR_KEY, XWALK.PG_ID, XWALK.IP_NPI, XWALK.PG_NM, XWALK.pgm_type_cd,XWALK.PGM_PI_PGM_ID, XWALK.PROV_ORG_TAX_ID, XWALK.VBP_PI_PGM_ID, XWALK.PA_ATRBN_EFCTV_DT,XWALK.PA_ATRBN_TRMNTN_DT, XWALK.cvrg_bgn_dt, XWALK.cvrg_end_dt , XWALK.PG_DTL_EFCTV_DT,XWALK.PG_DTL_TRMNTN_DT, CASE WHEN  SUBSTR(TRIM(bmd.HC_ID),1,3)=TRIM(bmd.ALPH_PRFX_ID)THEN TRIM(bmd.HC_ID) else CONCAT_ws('',TRIM(bmd.ALPH_PRFX_ID),TRIM(bmd.HC_ID)) END  AS ITS_SBSCRBR_ID,A.SRC_SYS_ID_VAL_TXT,A.EP_SOR_CD,A.EP_ADRS_ID,A.EP_ADRS_TYPE_CD,A.SRC_SYS_SOR_CD,A.SOR_DTM,A.EP_ID,A.EP_ALTID_VAL_TXT,A.EP_ALTID_TYPE_CD, B.SRC_SYS_ID_VAL_TXT as ALT_SRC_SYS_ID_VAL_TXT,B.EP_ALTID_VAL_TXT as ALT_EP_ALTID_VAL_TXT from SIT_ATRBN_INT XWALKINNER JOIN SIT_ATRBN_MBR bmd on XWALK.MCID=bmd.MCID AND XWALK.PA_ATRBN_EFCTV_DT=bmd.PA_ATRBN_EFCTV_DTINNER join ${dbname}_pcandw1ph_nogbd_r000_in.EP_ALT_SRC_ID_ALTID a on XWALK.IP_NPI=a.EP_ALTID_VAL_TXTAND A.EP_ALTID_TYPE_CD  IN ('8014','33','8015') AND A.RCRD_STTS_CD <> 'DEL'and A.SRC_SYS_SOR_CD NOT IN ('GBD')LEFT OUTER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.EP_ALT_SRC_ID_ALTID BON A.SRC_SYS_ID_VAL_TXT=B.SRC_SYS_ID_VAL_TXT AND B.EP_ALTID_TYPE_CD  IN ('8039')AND B.RCRD_STTS_CD <> 'DEL' and B.EP_SOR_CD='EPDS V2' WHERE A.EP_SOR_CD='EPDS V2' ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Pick provider data based on Provider id, give priority to Type-1 provider data - 033") {

    val id = Array("033")
    val name = Array("Test case : Pick provider data based on Provider id, give priority to Type-1 provider data - 033 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(s"""SELECT * FROM (SELECT A.*, rank() OVER(PARTITION BY CNSSTNT_MBR_ID1,BHI_HOME_PLAN_ID1,EP_ALTID_VAL_TXT ORDER BY pref ASC) AS RNK FROM (select distinct 1 as pref, CNSSTNT_MBR_ID as CNSSTNT_MBR_ID1,BHI_HOME_PLAN_ID as BHI_HOME_PLAN_ID1,CASE WHEN ALT_EP_ALTID_VAL_TXT is not null THEN ALT_EP_ALTID_VAL_TXT else 'ERR_ALTID' END AS ATRBD_PROV_ID,EPL.ATRBD_PROV_FRST_NM,EPL.ATRBD_PROV_LAST_NM,EPL.ATRBD_PROV_ORG_NM, EP_PRMRY_ADRS_CD , EP_ADRS_TRMNTN_DT , EA.EP_ADRS_EFCTV_DT , EA.SOR_DTM as SOR_DTM_EA, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD, WORK_EP_ALTID.EP_ALTID_VAL_TXT ,WORK_EP_ALTID.SRC_SYS_SOR_CD ,EP_ADRS_LINE_1_TXT ,WORK_EP_ALTID.SRC_SYS_ID_VAL_TXT ,EP_ADRS_LINE_2_TXT ,EP_ADRS_CITY_NM , EP_ADRS_ST_PRVNC_CD ,EP_ADRS_POSTL_CD ,WORK_EP_ALTID.SOR_DTM as SOR_DTM_ALT FROM SIT_ATRBN_FNL_NEW WORK_EP_ALTID inner join ( select EP.EP_ID as EP_ID_PRFL,EP_SOR_CD,EP.EP_LGL_FRST_NM AS ATRBD_PROV_FRST_NM, EP.EP_LGL_LAST_NM AS ATRBD_PROV_LAST_NM,EP_CTGRY_CD, EP.EP_ORG_NM AS ATRBD_PROV_ORG_NM from ${dbname}_pcandw1ph_nogbd_r000_in.EP_PRFL EP WHERE EP.RCRD_STTS_CD<>'DEL') EPL on trim(WORK_EP_ALTID.EP_ID)=trim(EPL.EP_ID_PRFL) AND trim(WORK_EP_ALTID.EP_SOR_CD) = trim(EPL.EP_SOR_CD) INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_IN.EP_ALT_SRC_ID_RLTNSHP_ADRS REL ON trim(WORK_EP_ALTID.EP_ID) = trim(REL.EP_ID) AND REL.RCRD_STTS_CD <> 'DEL' INNER JOIN (Select distinct EP_ID, EP_TAX_ID FROM ${dbname}_pcandw1ph_nogbd_r000_IN.EP_TAX_ID WHERE RCRD_STTS_CD <> 'DEL' ) TAX ON REL.EP_RLTD_PROV_ID = TAX.EP_ID AND  WORK_EP_ALTID.PROV_ORG_TAX_ID = TAX.EP_TAX_ID inner join (SELECT DISTINCT Ea.EP_ID as EP_ID_ADRS,EP_SOR_CD,EP_ADRS_ID,EP_ADRS_TYPE_CD, EA.EP_ADRS_LINE_1_TXT AS ATRBD_PROV_STR_ADRS_1_TXT, EA.EP_ADRS_LINE_2_TXT AS ATRBD_PROV_STR_ADRS_2_TXT, EA.EP_ADRS_CITY_NM AS ATRBD_PROV_CITY_NM, EA.EP_ADRS_ST_PRVNC_CD AS ATRBD_PROV_ST_CD, EA.EP_ADRS_POSTL_CD AS ATRBD_PROV_ZIP_CD, EP_PRMRY_ADRS_CD , EP_ADRS_TRMNTN_DT , EP_ADRS_EFCTV_DT , SOR_DTM ,EA.EP_ADRS_LINE_1_TXT ,EA.EP_ADRS_LINE_2_TXT ,EA.EP_ADRS_CITY_NM , EA.EP_ADRS_ST_PRVNC_CD ,EA.EP_ADRS_POSTL_CD from ${dbname}_pcandw1ph_nogbd_r000_in.EP_ADRS EA) EA on REL.EP_ID=EA.EP_ID_ADRS AND REL.EP_SOR_CD = EA.EP_SOR_CD AND REL.EP_ADRS_ID = EA.EP_ADRS_ID AND REL.EP_ADRS_TYPE_CD = EA.EP_ADRS_TYPE_CD where REL.EP_RLTNSHP_TYPE_CD = '1918' AND EPL.EP_CTGRY_CD = '181' AND EA.EP_ADRS_TYPE_CD = '178' AND REL.EP_ADRS_ID <> 'UNK' UNION ALL select distinct 2 as pref, CNSSTNT_MBR_ID as CNSSTNT_MBR_ID1,BHI_HOME_PLAN_ID as BHI_HOME_PLAN_ID1,CASE WHEN ALT_EP_ALTID_VAL_TXT is not null THEN ALT_EP_ALTID_VAL_TXT else 'ERR_ALTID' END AS ATRBD_PROV_ID,EPL.ATRBD_PROV_FRST_NM,EPL.ATRBD_PROV_LAST_NM,EPL.ATRBD_PROV_ORG_NM, EP_PRMRY_ADRS_CD , EP_ADRS_TRMNTN_DT , EA.EP_ADRS_EFCTV_DT , EA.SOR_DTM as SOR_DTM_EA, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD, WORK_EP_ALTID.EP_ALTID_VAL_TXT ,WORK_EP_ALTID.SRC_SYS_SOR_CD ,EP_ADRS_LINE_1_TXT ,WORK_EP_ALTID.SRC_SYS_ID_VAL_TXT ,EP_ADRS_LINE_2_TXT ,EP_ADRS_CITY_NM , EP_ADRS_ST_PRVNC_CD ,EP_ADRS_POSTL_CD ,WORK_EP_ALTID.SOR_DTM as SOR_DTM_ALT FROM SIT_ATRBN_FNL_NEW WORK_EP_ALTID inner join ( select distinct EP.EP_ID as EP_ID_PRFL,EP_SOR_CD,EP.EP_LGL_FRST_NM AS ATRBD_PROV_FRST_NM, EP.EP_LGL_LAST_NM AS ATRBD_PROV_LAST_NM,EP_CTGRY_CD, EP.EP_ORG_NM AS ATRBD_PROV_ORG_NM from ${dbname}_pcandw1ph_nogbd_r000_in.EP_PRFL EP WHERE EP.RCRD_STTS_CD<>'DEL') EPL on trim(WORK_EP_ALTID.EP_ID)=trim(EPL.EP_ID_PRFL) AND trim(WORK_EP_ALTID.EP_SOR_CD) = trim(EPL.EP_SOR_CD) inner join (SELECT DISTINCT Ea.EP_ID as EP_ID_ADRS,EP_SOR_CD,EP_ADRS_ID,EP_ADRS_TYPE_CD, EA.EP_ADRS_LINE_1_TXT AS ATRBD_PROV_STR_ADRS_1_TXT, EA.EP_ADRS_LINE_2_TXT AS ATRBD_PROV_STR_ADRS_2_TXT, EA.EP_ADRS_CITY_NM AS ATRBD_PROV_CITY_NM, EA.EP_ADRS_ST_PRVNC_CD AS ATRBD_PROV_ST_CD, EA.EP_ADRS_POSTL_CD AS ATRBD_PROV_ZIP_CD, EP_PRMRY_ADRS_CD , EP_ADRS_TRMNTN_DT , EP_ADRS_EFCTV_DT , SOR_DTM ,EA.EP_ADRS_LINE_1_TXT ,EA.EP_ADRS_LINE_2_TXT ,EA.EP_ADRS_CITY_NM , EA.EP_ADRS_ST_PRVNC_CD ,EA.EP_ADRS_POSTL_CD from ${dbname}_pcandw1ph_nogbd_r000_in.EP_ADRS EA WHERE EA.RCRD_STTS_CD<>'DEL') EA on WORK_EP_ALTID.EP_ID=EA.EP_ID_ADRS AND WORK_EP_ALTID.EP_SOR_CD = EA.EP_SOR_CD where EPL.EP_CTGRY_CD = '182' AND EA.EP_ADRS_TYPE_CD = '178') A) B WHERE RNK=1""")

    //result.persist()

    val rc = result.count()

    if (rc > 0) {
      result.createOrReplaceTempView("SIT_ATRBN_FNL_NEW_PROV")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from SIT_ATRBN_FNL_NEW_PROV")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_ATRBN_FNL_NEW_PROV")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from SIT_ATRBN_FNL_NEW_PROV ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - combine #32 and #33 - 034") {

    val id = Array("034")
    val name = Array("Test case :combine #32 and #33  - 034 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(s"""SELECT DISTINCT MPA.BHI_HOME_PLAN_ID,MPA.mcid, MPA.cnsstnt_mbr_id, 
      MPA.pa_mbr_key, MPA.xwalk_mbr_key, MPA.pg_id, MPA.ip_npi, MPA.pg_nm, MPA.pgm_type_cd, MPA.pgm_pi_pgm_id, 
      MPA.prov_org_tax_id, MPA.vbp_pi_pgm_id, MPA.pa_atrbn_efctv_dt, MPA.pa_atrbn_trmntn_dt, 
      MPA.pg_dtl_efctv_dt, MPA.pg_dtl_trmntn_dt, MPA.its_sbscrbr_id, MPA.ep_altid_val_txt, 
      MPA.ep_altid_type_cd, MPA.alt_src_sys_id_val_txt,SUBSTR(TRIM(MPA.PG_ID),1,2) AS PLAN_ST_CD, 
      ATRBD_PROV_ID, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_STR_ADRS_1_TXT, 
      ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD,ATRBD_PROV_ORG_NM,
      atrbd_prov_zip_cd, SOR_DTM_EA,EP_ADRS_TRMNTN_DT,EP_ADRS_EFCTV_DT, 
      RANK() OVER(PARTITION BY CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,IP_NPI,PROV_ORG_TAX_ID, PA_ATRBN_EFCTV_DT 
      ORDER BY case when ATRBD_PROV_ID='ERR_ALTID' or ATRBD_PROV_ID is null then null else ATRBD_PROV_ID end DESC,
      SOR_DTM_EA DESC,EP_ADRS_TRMNTN_DT DESC, EP_ADRS_EFCTV_DT DESC ) AS RNK1 
      FROM SIT_ATRBN_FNL_NEW MPA left outer JOIN SIT_ATRBN_FNL_NEW_PROV WORK_EP_ALTID 
      ON MPA.CNSSTNT_MBR_ID=WORK_EP_ALTID.CNSSTNT_MBR_ID1 
      and MPA.BHI_HOME_PLAN_ID=WORK_EP_ALTID.BHI_HOME_PLAN_ID1 
      AND MPA.IP_NPI=WORK_EP_ALTID.EP_ALTID_VAL_TXT""")

    result.persist()

    val rc = result.count()

    if (rc > 0) {
      result.createOrReplaceTempView("SIT_ATRBN_FNL_INT_2")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT DISTINCT MPA.BHI_HOME_PLAN_ID,MPA.mcid, MPA.cnsstnt_mbr_id,MPA.pa_mbr_key, MPA.xwalk_mbr_key, MPA.pg_id, MPA.ip_npi, MPA.pg_nm, MPA.pgm_type_cd, MPA.pgm_pi_pgm_id,MPA.prov_org_tax_id, MPA.vbp_pi_pgm_id, MPA.pa_atrbn_efctv_dt, MPA.pa_atrbn_trmntn_dt, MPA.pg_dtl_efctv_dt, MPA.pg_dtl_trmntn_dt, MPA.its_sbscrbr_id, MPA.ep_altid_val_txt,MPA.ep_altid_type_cd, MPA.alt_src_sys_id_val_txt,SUBSTR(TRIM(MPA.PG_ID),1,2) AS PLAN_ST_CD,ATRBD_PROV_ID, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_STR_ADRS_1_TXT,ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD,ATRBD_PROV_ORG_NM,atrbd_prov_zip_cd, SOR_DTM_EA,EP_ADRS_TRMNTN_DT,EP_ADRS_EFCTV_DT, RANK() OVER(PARTITION BY CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,IP_NPI,PROV_ORG_TAX_ID, PA_ATRBN_EFCTV_DT ORDER BY case when ATRBD_PROV_ID='ERR_ALTID' or ATRBD_PROV_ID is null then null else ATRBD_PROV_ID end DESC,SOR_DTM_EA DESC,EP_ADRS_TRMNTN_DT DESC, EP_ADRS_EFCTV_DT DESC ) AS RNK1 FROM SIT_ATRBN_FNL_NEW MPA left outer JOIN SIT_ATRBN_FNL_NEW_PROV WORK_EP_ALTID ON MPA.CNSSTNT_MBR_ID=WORK_EP_ALTID.CNSSTNT_MBR_ID1 and MPA.BHI_HOME_PLAN_ID=WORK_EP_ALTID.BHI_HOME_PLAN_ID1 AND MPA.IP_NPI=WORK_EP_ALTID.EP_ALTID_VAL_TXT")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_ATRBN_FNL_INT_2")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT DISTINCT MPA.BHI_HOME_PLAN_ID,MPA.mcid, MPA.cnsstnt_mbr_id,MPA.pa_mbr_key, MPA.xwalk_mbr_key, MPA.pg_id, MPA.ip_npi, MPA.pg_nm, MPA.pgm_type_cd, MPA.pgm_pi_pgm_id,MPA.prov_org_tax_id, MPA.vbp_pi_pgm_id, MPA.pa_atrbn_efctv_dt, MPA.pa_atrbn_trmntn_dt, MPA.pg_dtl_efctv_dt, MPA.pg_dtl_trmntn_dt, MPA.its_sbscrbr_id, MPA.ep_altid_val_txt,MPA.ep_altid_type_cd, MPA.alt_src_sys_id_val_txt,SUBSTR(TRIM(MPA.PG_ID),1,2) AS PLAN_ST_CD,ATRBD_PROV_ID, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_STR_ADRS_1_TXT,ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD,ATRBD_PROV_ORG_NM,atrbd_prov_zip_cd, SOR_DTM_EA,EP_ADRS_TRMNTN_DT,EP_ADRS_EFCTV_DT, RANK() OVER(PARTITION BY CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,IP_NPI,PROV_ORG_TAX_ID, PA_ATRBN_EFCTV_DT ORDER BY case when ATRBD_PROV_ID='ERR_ALTID' or ATRBD_PROV_ID is null then null else ATRBD_PROV_ID end DESC,SOR_DTM_EA DESC,EP_ADRS_TRMNTN_DT DESC, EP_ADRS_EFCTV_DT DESC ) AS RNK1 FROM SIT_ATRBN_FNL_NEW MPA left outer JOIN SIT_ATRBN_FNL_NEW_PROV WORK_EP_ALTID ON MPA.CNSSTNT_MBR_ID=WORK_EP_ALTID.CNSSTNT_MBR_ID1 and MPA.BHI_HOME_PLAN_ID=WORK_EP_ALTID.BHI_HOME_PLAN_ID1 AND MPA.IP_NPI=WORK_EP_ALTID.EP_ALTID_VAL_TXT ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Fetch Host Plan code from RFRNC_BCBSA_HOME_PLAN_CD_XWALK_INBND - 035") {

    val id = Array("035")
    val name = Array("Test case : Fetch Host Plan code from RFRNC_BCBSA_HOME_PLAN_CD_XWALK_INBND - 035 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(f"""SELECT DISTINCT ' ' AS MMI_ID, PA.CNSSTNT_MBR_ID, PA.its_sbscrbr_id, 
      PA.MCID AS MBR_ID, PA.BHI_HOME_PLAN_ID AS BHI_HOME_PLAN_ID, BOT.bhi_home_plan_id AS BHI_HOST_PLAN_ID,
      PA.ATRBD_PROV_ID, PA.IP_NPI AS atrbd_prov_npi, COALESCE(PA.ATRBD_PROV_FRST_NM,' ') AS ATRBD_PROV_FRST_NM, 
      COALESCE(PA.ATRBD_PROV_LAST_NM,' ') AS ATRBD_PROV_LAST_NM, 
      COALESCE(PA.ATRBD_PROV_ORG_NM,' ') AS ATRBD_PROV_ORG_NM, 
      COALESCE(PA.ATRBD_PROV_STR_ADRS_1_TXT,' ') AS ATRBD_PROV_STR_ADRS_1_TXT, 
      COALESCE(PA.ATRBD_PROV_STR_ADRS_2_TXT,' ') AS ATRBD_PROV_STR_ADRS_2_TXT, 
      COALESCE(PA.ATRBD_PROV_CITY_NM,' ') AS ATRBD_PROV_CITY_NM, 
      COALESCE(PA.ATRBD_PROV_ST_CD,' ') AS ATRBD_PROV_ST_CD, 
      COALESCE(PA.ATRBD_PROV_ZIP_CD,' ') AS ATRBD_PROV_ZIP_CD, 
      CAST(from_unixtime(unix_timestamp(CAST('$startdateFnl' AS String), 'yyyy-MM-dd')) AS TIMESTAMP) 
      AS ATRBN_PRD_BGN_DT, CAST(from_unixtime(unix_timestamp(CAST('$enddateFnl' AS String), 'yyyy-MM-dd')) 
      AS TIMESTAMP)  AS ATRBN_PRD_END_DT, PA.PROV_ORG_TAX_ID AS ATRBD_PROV_TAX_ID, PA.PG_ID AS PE_ID, 
      ' ' AS MBR_SL_PCP_IND, ' ' AS FLLR_1, ' ' AS FLLR_2, 'Y' AS ATRBN_IND, ' ' AS NOT_ATRBD_RSN_CD, 
      ' ' AS HOST_PLAN_CRPRT_PLAN_CD, ' ' AS HOME_PLAN_CRPRT_PLAN_CD, PA.PG_NM AS ATRBN_PROV_PGM_NM, 
      PA.PLAN_ST_CD, PA.PA_ATRBN_EFCTV_DT, PA.PA_ATRBN_TRMNTN_DT, PA.VBP_PI_PGM_ID 
      FROM SIT_ATRBN_FNL_INT_2 PA 
      LEFT OUTER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOME_PLAN_CD_XWALK_INBND BOT 
      ON PA.PLAN_ST_CD=BOT.PLAN_ST_CD WHERE RNK1=1""")

    result.persist()

    val rc = result.count()

    if (rc > 0) {
      result.createOrReplaceTempView("SIT_ATRBN_FNL_INT")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from SIT_ATRBN_FNL_INT")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_ATRBN_FNL_INT")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from SIT_ATRBN_FNL_INT ")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Join with PI_BCBSA_PGM_PG_VBP table to get VBP_ID. Generate final SIT table for Minus queries -036") {

    val id = Array("036")
    val name = Array("Test case : Join with PI_BCBSA_PGM_PG_VBP table to get VBP_ID. Generate final SIT table for Minus queries- 036 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(s"""SELECT * FROM (select distinct MMI_ID, CNSSTNT_MBR_ID, its_sbscrbr_id, MBR_ID, BHI_HOME_PLAN_ID AS BHI_HOME_PLAN_ID, BHI_HOST_PLAN_ID, ATRBD_PROV_ID, ATRBD_PROV_NPI, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_ORG_NM, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD, ATRBN_PRD_BGN_DT, ATRBN_PRD_END_DT, COALESCE(BDTC_VBP_ID,' ') AS VBP_ID, ATRBD_PROV_TAX_ID, PE_ID, MBR_SL_PCP_IND, FLLR_1, FLLR_2, ATRBN_IND, NOT_ATRBD_RSN_CD, HOST_PLAN_CRPRT_PLAN_CD, HOME_PLAN_CRPRT_PLAN_CD, ATRBN_PROV_PGM_NM, PA_ATRBN_EFCTV_DT, PA_ATRBN_TRMNTN_DT, row_number() over (partition by MBR_ID ,BHI_HOME_PLAN_ID , ATRBN_PRD_BGN_DT, PE_ID ORDER BY BDTC_VBP_ID DESC) AS rnk2 FROM SIT_ATRBN_FNL_INT PA LEFT OUTER JOIN (SELECT DISTINCT PG_ID,PI_PGM_ID,BDTC_VBP_ID, PGM_VBP_TERM_DT, pgm_vbp_efctv_dt FROM ${dbname}_pcandw1ph_nogbd_r000_in.PI_BCBSA_PGM_PG_VBP) K  on K.PI_PGM_ID=PA.VBP_PI_PGM_ID and K.PG_ID=PA.PE_ID WHERE substring(ATRBN_PRD_BGN_DT,1,7) >= substring(K.pgm_vbp_efctv_dt,1,7) AND substring(ATRBN_PRD_BGN_DT,1,7) <= substring(K.PGM_VBP_TERM_DT,1,7)) B WHERE RNK2=1""")

    result.persist()

    val rc = result.count()

    if (rc > 0) {
      result.createOrReplaceTempView("SIT_ATRBN_FNL")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT * FROM (select distinct MMI_ID, CNSSTNT_MBR_ID, its_sbscrbr_id, MBR_ID, BHI_HOME_PLAN_ID AS BHI_HOME_PLAN_ID, BHI_HOST_PLAN_ID, ATRBD_PROV_ID, ATRBD_PROV_NPI, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_ORG_NM, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD, ATRBN_PRD_BGN_DT, ATRBN_PRD_END_DT, COALESCE(BDTC_VBP_ID,' ') AS VBP_ID, ATRBD_PROV_TAX_ID, PE_ID, MBR_SL_PCP_IND, FLLR_1, FLLR_2, ATRBN_IND, NOT_ATRBD_RSN_CD, HOST_PLAN_CRPRT_PLAN_CD, HOME_PLAN_CRPRT_PLAN_CD, ATRBN_PROV_PGM_NM, PA_ATRBN_EFCTV_DT, PA_ATRBN_TRMNTN_DT, row_number() over (partition by MBR_ID ,BHI_HOME_PLAN_ID , ATRBN_PRD_BGN_DT, PE_ID ORDER BY BDTC_VBP_ID DESC) AS rnk2 FROM SIT_ATRBN_FNL_INT PA LEFT OUTER JOIN (SELECT DISTINCT PG_ID,PI_PGM_ID,BDTC_VBP_ID, PGM_VBP_TERM_DT, pgm_vbp_efctv_dt FROM ${dbname}_pcandw1ph_nogbd_r000_in.PI_BCBSA_PGM_PG_VBP) K  on K.PI_PGM_ID=PA.VBP_PI_PGM_ID and K.PG_ID=PA.PE_ID WHERE substring(ATRBN_PRD_BGN_DT,1,7) >= substring(K.pgm_vbp_efctv_dt,1,7) AND substring(ATRBN_PRD_BGN_DT,1,7) <= substring(K.PGM_VBP_TERM_DT,1,7)) B WHERE RNK2=1")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_ATRBN_FNL")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT * FROM (select distinct MMI_ID, CNSSTNT_MBR_ID, its_sbscrbr_id, MBR_ID, BHI_HOME_PLAN_ID AS BHI_HOME_PLAN_ID, BHI_HOST_PLAN_ID, ATRBD_PROV_ID, ATRBD_PROV_NPI, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_ORG_NM, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD, ATRBN_PRD_BGN_DT, ATRBN_PRD_END_DT, COALESCE(BDTC_VBP_ID,' ') AS VBP_ID, ATRBD_PROV_TAX_ID, PE_ID, MBR_SL_PCP_IND, FLLR_1, FLLR_2, ATRBN_IND, NOT_ATRBD_RSN_CD, HOST_PLAN_CRPRT_PLAN_CD, HOME_PLAN_CRPRT_PLAN_CD, ATRBN_PROV_PGM_NM, PA_ATRBN_EFCTV_DT, PA_ATRBN_TRMNTN_DT, row_number() over (partition by MBR_ID ,BHI_HOME_PLAN_ID , ATRBN_PRD_BGN_DT, PE_ID ORDER BY BDTC_VBP_ID DESC) AS rnk2 FROM SIT_ATRBN_FNL_INT PA LEFT OUTER JOIN (SELECT DISTINCT PG_ID,PI_PGM_ID,BDTC_VBP_ID, PGM_VBP_TERM_DT, pgm_vbp_efctv_dt FROM ${dbname}_pcandw1ph_nogbd_r000_in.PI_BCBSA_PGM_PG_VBP) K  on K.PI_PGM_ID=PA.VBP_PI_PGM_ID and K.PG_ID=PA.PE_ID WHERE substring(ATRBN_PRD_BGN_DT,1,7) >= substring(K.pgm_vbp_efctv_dt,1,7) AND substring(ATRBN_PRD_BGN_DT,1,7) <= substring(K.PGM_VBP_TERM_DT,1,7)) B WHERE RNK2=1 ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 2)
    }
  }  

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Minus query -1 (key columns) - 037") {

    val id = Array("037")
    val name = Array("Test case : Minus query -1 (key columns) - 037 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

  //  val llk = spark.sql(f"""select distinct(load_log_key),load_dt from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn order by load_dt desc limit 1""")

  //  val df1 = llk.select($"load_log_key").rdd.first()(0)

    val result1 = spark.sql(s"""select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY=${df1}""")
    
    println("select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY='${load_log_key}'")

    val result2 = spark.sql(s"""select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT from SIT_ATRBN_FNL""")

    val result = result1.except(result2)

    result.persist()

    val rc = result.count()

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY=${df1} minus select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT from SIT_ATRBN_FNL")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY=${df1} minus select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT from SIT_ATRBN_FNL ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 2)
    } 
  }

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Minus query -2 (Provider columns)- 038") {

    val id = Array("038")
    val name = Array("Test case : Minus query -2 (Provider columns) - 038 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result1 = spark.sql(s"""select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBD_PROV_ID, ATRBD_PROV_NPI, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_ORG_NM, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD,ATRBD_PROV_TAX_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' 
      union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBD_PROV_ID, ATRBD_PROV_NPI, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_ORG_NM, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD,ATRBD_PROV_TAX_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY=${df1}""")

    val result2 = spark.sql(s"""select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBD_PROV_ID, ATRBD_PROV_NPI, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_ORG_NM, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD,ATRBD_PROV_TAX_ID  from SIT_ATRBN_FNL""")

    val result = result1.except(result2)

    result.persist()

    val rc = result.count()

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBD_PROV_ID, ATRBD_PROV_NPI, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_ORG_NM, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD,ATRBD_PROV_TAX_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBD_PROV_ID, ATRBD_PROV_NPI, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_ORG_NM, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD,ATRBD_PROV_TAX_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY=${df1} minus select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBD_PROV_ID, ATRBD_PROV_NPI, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_ORG_NM, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD,ATRBD_PROV_TAX_ID  from SIT_ATRBN_FNL")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBD_PROV_ID, ATRBD_PROV_NPI, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_ORG_NM, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD,ATRBD_PROV_TAX_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBD_PROV_ID, ATRBD_PROV_NPI, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_ORG_NM, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD,ATRBD_PROV_TAX_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY=${df1} minus select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBD_PROV_ID, ATRBD_PROV_NPI, ATRBD_PROV_FRST_NM, ATRBD_PROV_LAST_NM, ATRBD_PROV_ORG_NM, ATRBD_PROV_STR_ADRS_1_TXT, ATRBD_PROV_STR_ADRS_2_TXT, ATRBD_PROV_CITY_NM, ATRBD_PROV_ST_CD, ATRBD_PROV_ZIP_CD,ATRBD_PROV_TAX_ID  from SIT_ATRBN_FNL ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
 
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Minus query -3 (Member fields) - 039") {

    val id = Array("039")
    val name = Array("Test case : Minus query -3 (Member fields) - 039 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

  //  val llk = spark.sql(s"""select distinct(load_log_key),load_dt from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn order by load_dt desc limit 1""")

  //  val df1 = llk.select($"load_log_key").rdd.first()(0)

    val result1 = spark.sql(s"""select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBN_PRD_END_DT,its_sbscrbr_id, MBR_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBN_PRD_END_DT,its_sbscrbr_id, MBR_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY=${df1}""")
    
    println("select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBN_PRD_END_DT,its_sbscrbr_id, MBR_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBN_PRD_END_DT,its_sbscrbr_id, MBR_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY= + df1")

    val result2 = spark.sql(s"""select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBN_PRD_END_DT,its_sbscrbr_id, MBR_ID from ${dbname}_pcandw1ph_nogbd_r000_bk.SIT_ATRBN_FNL""")

    val result = result1.except(result2)

    result.persist()

    val rc = result.count()

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBN_PRD_END_DT,its_sbscrbr_id, MBR_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBN_PRD_END_DT,its_sbscrbr_id, MBR_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY=${df1} minus select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBN_PRD_END_DT,its_sbscrbr_id, MBR_ID from ${dbname}_pcandw1ph_nogbd_r000_bk.SIT_ATRBN_FNL")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBN_PRD_END_DT,its_sbscrbr_id, MBR_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBN_PRD_END_DT,its_sbscrbr_id, MBR_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY=${df1} minus select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ATRBN_PRD_END_DT,its_sbscrbr_id, MBR_ID from ${dbname}_pcandw1ph_nogbd_r000_bk.SIT_ATRBN_FNL ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Minus query -4 (PG fields) - 040") {

    val id = Array("040")
    val name = Array("Test case : Minus query -4 (PG fields) - 040 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

 //   val llk = spark.sql("""select distinct(load_log_key),load_dt from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn order by load_dt desc limit 1""")

 //   val df1 = llk.select($"load_log_key").rdd.first()(0)

    val result1 = spark.sql(s"""select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,PE_ID,ATRBN_PROV_PGM_NM,VBP_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,PE_ID,ATRBN_PROV_PGM_NM,VBP_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY=${df1}""")

    val result2 = spark.sql(s"""select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,PE_ID,ATRBN_PROV_PGM_NM,VBP_ID from SIT_ATRBN_FNL""")

    val result = result1.except(result2)

    result.persist()

    val rc = result.count()

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,PE_ID,ATRBN_PROV_PGM_NM,VBP_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,PE_ID,ATRBN_PROV_PGM_NM,VBP_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY=${df1} minus select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,PE_ID,ATRBN_PROV_PGM_NM,VBP_ID from SIT_ATRBN_FNL")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,PE_ID,ATRBN_PROV_PGM_NM,VBP_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn WHERE PE_ID='${pg_id}' union all select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,PE_ID,ATRBN_PROV_PGM_NM,VBP_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE PE_ID='${pg_id}' AND LOAD_LOG_KEY=${df1} minus select distinct CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,PE_ID,ATRBN_PROV_PGM_NM,VBP_ID from SIT_ATRBN_FNL ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Minus query -5 (Return 0 records) - 041") {

    val id = Array("041")
    val name = Array("Test case : Minus query -5 (Return 0 records) - 041 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)
    
  //  val llk = spark.sql("""select distinct(load_log_key),load_dt from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn order by load_dt desc limit 1""")

  //  val df1 = llk.select($"load_log_key").rdd.first()(0)

    val result3 = spark.sql(s"""select PE_ID, COUNT(distinct CNSSTNT_MBR_ID) from (select distinct CNSSTNT_MBR_ID,PE_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn 
      union select distinct CNSSTNT_MBR_ID,PE_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE LOAD_LOG_KEY=${df1}) A group by PE_ID""")

    val data1 = spark.sql(s"""select DISTINCT PA.MCID, XWALK.MBR_KEY AS XWALK_MBR_KEY, PA.PG_ID, 
      PA.PI_PGM_ID AS VBP_PI_PGM_ID,
      CAST(from_unixtime(unix_timestamp(CAST('$startdateFnl' AS String), 'yyyy-MM-dd')) AS TIMESTAMP) AS ATRBN_PRD_BGN_DT,
      CAST(from_unixtime(unix_timestamp(CAST('$enddateFnl' AS String), 'yyyy-MM-dd')) AS TIMESTAMP)  AS ATRBN_PRD_END_DT
      from ${dbname}_pcandw1ph_nogbd_r000_in.PI_ATRBN_MCID PA 
      INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_XWALK XWALK ON PA.MCID=XWALK.cnsstnt_mbr_id 
      inner join ${dbname}_pcandw1ph_nogbd_r000_in.pi_pgm pgm on PA.pi_pgm_id=pgm.pi_pgm_id 
      INNER join ${dbname}_pcandw1ph_nogbd_r000_in.EP_ALT_SRC_ID_ALTID a on PA.IP_NPI=a.EP_ALTID_VAL_TXT 
      AND A.EP_ALTID_TYPE_CD  IN ('8014','33','8015') AND A.RCRD_STTS_CD <> 'DEL' 
      and A.SRC_SYS_SOR_CD NOT IN ('GBD') AND A.EP_SOR_CD='EPDS V2' 
      WHERE PA.RCRD_STTS_CD<>'DEL' AND PA.VRSN_CLOS_DT='8888-12-31' AND PA.ATRBN_EFCTV_DT<='${enddateFnl}' 
      AND PA.ATRBN_TRMNTN_DT >=CURRENT_DATE 
      AND PA.ATRBN_EFCTV_DT<>PA.ATRBN_TRMNTN_DT AND PA.atrbn_efctv_dt<=XWALK.cvrg_end_dt 
      and PA.atrbn_trmntn_dt>=XWALK.cvrg_bgn_dt AND PGM.PGM_TYPE_CD IN ('8000','8001','8004','8005','8024') 
      AND PGM.PI_PGM_ID  NOT LIKE 'OA%%'""")

    data1.persist
    println("The 1st df count is " + data1.count.toInt)
    data1.createOrReplaceTempView("SIT_ATRBN_ALL")

    val data2 = spark.sql(s"""SELECT DISTINCT A.mbr_key, A.mbr_prod_enrlmnt_efctv_dt, 
      A.mbr_prod_enrlmnt_trmntn_dt from ${dbname}_pcandw1ph_nogbd_r000_wh.all_mbr A 
      LEFT SEMI JOIN SIT_ATRBN_ALL B ON A.MBR_KEY=B.XWALK_MBR_KEY""")

    data2.persist
    println("The 2nd df count is " + data2.count.toInt)
    data2.createOrReplaceTempView("ALL_MBR_SIT")

    val result4 = spark.sql(s"""SELECT DISTINCT A.PG_ID, COUNT(DISTINCT A.MCID) FROM SIT_ATRBN_ALL A 
      INNER JOIN ALL_MBR_SIT B ON B.MBR_KEY=A.XWALK_MBR_KEY 
      LEFT OUTER JOIN (SELECT DISTINCT PG_ID,PI_PGM_ID,BDTC_VBP_ID, PGM_VBP_TERM_DT, pgm_vbp_efctv_dt 
      FROM ${dbname}_pcandw1ph_nogbd_r000_in.PI_BCBSA_PGM_PG_VBP) K on K.PI_PGM_ID=A.VBP_PI_PGM_ID 
      and K.PG_ID=A.PG_ID where substring(ATRBN_PRD_BGN_DT,1,7) >= substring(K.pgm_vbp_efctv_dt,1,7) 
      AND substring(ATRBN_PRD_BGN_DT,1,7) <= substring(K.PGM_VBP_TERM_DT,1,7) GROUP BY A.PG_ID""")

    val result = result3.except(result4)
    result.persist()

    val rc = result.count()
    data1.unpersist
    data2.unpersist

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select PE_ID, COUNT(distinct CNSSTNT_MBR_ID) from (select distinct CNSSTNT_MBR_ID,PE_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn union select distinct CNSSTNT_MBR_ID,PE_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE LOAD_LOG_KEY=${df1}) A group by PE_ID minus SELECT DISTINCT A.PG_ID, COUNT(DISTINCT A.MCID) FROM SIT_ATRBN_ALL A INNER JOIN ALL_MBR_SIT B ON B.MBR_KEY=A.XWALK_MBR_KEY LEFT OUTER JOIN (SELECT DISTINCT PG_ID,PI_PGM_ID,BDTC_VBP_ID, PGM_VBP_TERM_DT, pgm_vbp_efctv_dt FROM ${dbname}_pcandw1ph_nogbd_r000_in.PI_BCBSA_PGM_PG_VBP) K on K.PI_PGM_ID=A.VBP_PI_PGM_ID and K.PG_ID=A.PG_ID where substring(ATRBN_PRD_BGN_DT,1,7) >= substring(K.pgm_vbp_efctv_dt,1,7) AND substring(ATRBN_PRD_BGN_DT,1,7) <= substring(K.PGM_VBP_TERM_DT,1,7) GROUP BY A.PG_ID")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select PE_ID, COUNT(distinct CNSSTNT_MBR_ID) from (select distinct CNSSTNT_MBR_ID,PE_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn union select distinct CNSSTNT_MBR_ID,PE_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_err WHERE LOAD_LOG_KEY=${df1}) A group by PE_ID minus SELECT DISTINCT A.PG_ID, COUNT(DISTINCT A.MCID) FROM SIT_ATRBN_ALL A INNER JOIN ALL_MBR_SIT B ON B.MBR_KEY=A.XWALK_MBR_KEY LEFT OUTER JOIN (SELECT DISTINCT PG_ID,PI_PGM_ID,BDTC_VBP_ID, PGM_VBP_TERM_DT, pgm_vbp_efctv_dt FROM ${dbname}_pcandw1ph_nogbd_r000_in.PI_BCBSA_PGM_PG_VBP) K on K.PI_PGM_ID=A.VBP_PI_PGM_ID and K.PG_ID=A.PG_ID where substring(ATRBN_PRD_BGN_DT,1,7) >= substring(K.pgm_vbp_efctv_dt,1,7) AND substring(ATRBN_PRD_BGN_DT,1,7) <= substring(K.PGM_VBP_TERM_DT,1,7) GROUP BY A.PG_ID ")

 sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
 
      assert(1 == 2)
    }
  }


  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Duplicate check (Return 0 records) - 042") {

    val id = Array("042")
    val name = Array("Test case : Duplicate check (Return 0 records) - 042 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(s"""select CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ITS_SBSCRBR_ID, count(1) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn GROUP BY CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ITS_SBSCRBR_ID HAVING COUNT(1)>1 limit 10""")

    val rc = result.count()

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ITS_SBSCRBR_ID, count(1) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn GROUP BY CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ITS_SBSCRBR_ID HAVING COUNT(1)>1 limit 10")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ITS_SBSCRBR_ID, count(1) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn GROUP BY CNSSTNT_MBR_ID,BHI_HOME_PLAN_ID,BHI_HOST_PLAN_ID,ATRBN_PRD_BGN_DT,ITS_SBSCRBR_ID HAVING COUNT(1)>1 limit 10 ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 2)
    }
  }	

  //--------------------------------------------------------------------------

  test("LCL_ATRBN - Default columns - 043") {

    val id = Array("043")
    val name = Array("Test case : Default columns - 043 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(s"""select distinct mmi_id,  mbr_sl_pcp_ind, fillr_1,fillr_2, atrbn_ind,not_atrbd_rsn_cd, host_plan_crprt_plan_cd,home_plan_crprt_plan_cd from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn""")

    val rc = result.count()

    if (rc == 1) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mmi_id,  mbr_sl_pcp_ind, fillr_1,fillr_2, atrbn_ind,not_atrbd_rsn_cd, host_plan_crprt_plan_cd,home_plan_crprt_plan_cd from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mmi_id,  mbr_sl_pcp_ind, fillr_1,fillr_2, atrbn_ind,not_atrbd_rsn_cd, host_plan_crprt_plan_cd,home_plan_crprt_plan_cd from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn ")

sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/LCLAtrbn/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"

      assert(1 == 2)
    }
  }		

}