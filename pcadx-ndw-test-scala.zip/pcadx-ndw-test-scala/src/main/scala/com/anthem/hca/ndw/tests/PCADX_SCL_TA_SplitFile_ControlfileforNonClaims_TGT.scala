
package com.anthem.hca.ndw.tests

import java.io.File
import org.scalatest.FunSuite
import org.apache.spark.sql.SparkSession
import scala.io.Source
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.DataFrame
import java.text.SimpleDateFormat
import java.util.Calendar
import org.apache.spark.deploy.SparkHadoopUtil
import org.apache.hadoop.fs.{ FileSystem, Path, LocatedFileStatus, RemoteIterator }
import java.net.URI

object PCADX_SCL_TA_SplitFile_ControlfileforNonClaims_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_SplitFile_ControlfileforNonClaims_TGT(args(0), args(1), args(2))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_SplitFile_ControlfileforNonClaims_TGT(filePath: String, extractName: String, env: String) extends FunSuite {

  val spark = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()

  /*def getListOfFiles(dir: File, extensions: List[String]): List[File] = {
    dir.listFiles.filter(_.isFile).toList.filter { file =>
      extensions.exists(file.getName.endsWith(_))
    }
  }

  val okFileExtensions = List("ctl")
  val files = getListOfFiles(new File("" + name + ""), okFileExtensions)
*/
  //To get the HDFS configuration setup
  import spark.implicits._
  import spark.sql
  val sc = spark.sparkContext
  val hconf = SparkHadoopUtil.get.newConfiguration(sc.getConf)
  val hdfs1 = FileSystem.get(hconf)
  //To access the HDFS path by declaring filePath variable
  val iterList = hdfs1.listFiles(new Path(filePath), false)
  //To keep all hdfs files into list
  var list: List[String] = List()
  while (iterList.hasNext) {
    list = list :+ iterList.next.getPath.toString
  }
  val listFiles = list.filter(_.endsWith("ctl"))
  listFiles.foreach(t => {
    val name = t
    // .filter( vec => vec(1).contains("A1200"))
    //name.contains("A1200")
    val DATETIME_FORMAT1 = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss")
    val DATETIME1 = DATETIME_FORMAT1.format(Calendar.getInstance().getTime())

    var process_Name = ""
    if (extractName.equals("ACCOUNT_REPORTING_REF")) {
      process_Name = "Account_Reporting"
    } else if (extractName.equals("STD_PRODUCT_CLIENT_CONTRACT")) {
      process_Name = "Product_Client_Contract"
    } else if (extractName.equals("STD_PRODUCT")) {
      process_Name = "Product"
    } else if (extractName.equals("STD_ALPHA_PREFIX_REF")) {
      process_Name = "Alpha_Prefix"
    } else if (extractName.equals("STD_NET_CAT_FAC_REF")) {
      process_Name = "Net_Cat_Fac_Ref"
    } else if (extractName.equals("STD_NET_CAT_PROF_REF")) {
      process_Name = "Net_Cat_Prof_Ref"
    } else if (extractName.equals("STD_TRACEABILITY_REF")) {
      process_Name = "Traceability"
    } else if (extractName.equals("STD_MEMBER")) {
      process_Name = "Member"
    } else if (extractName.equals("STD_MEMBER_DEMOGRAPHIC")) {
      process_Name = "Member_Demographic"
    }

    if (name.contains("G1") || name.contains("G3")) {
      test("Check total record count is 5 or not for the file of " + name + "") {

        import spark.implicits._
        import spark.sql
        val sc = spark.sparkContext
        sc.setLogLevel("ERROR")

        val id = Array("001")
        val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
        val test_Name = Array("Testcase Name : Check total record count is 5 or not for the file of " + name + "")
        val query = Array("""Test Query : select count(*) from control_file""")
        val outPut = Array("SQL Query Output : ")
        val p = Array("PASS")
        val statusP = Array("Testcase Status : PASSED")
        val f = Array("FAIL")
        val statusF = Array("Testcase Status : FAILED")
        var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
        var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

        // val te="home_plan_id,extract_name,min_clm_processed_dt,max_clm_processed_dt,sbmsn_dt,rcrd_count,tot_sub_amt,tot_noncov_amt,tot_alwd_amt,tot_paid_amt,tot_cob_tpl_amt,tot_coinsur_amt,tot_copay_amt,tot_deduct_amt,tot_ff_srvc_eq_amt"

        val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
        //val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id","extract_name","min_clm_processed_dt","max_clm_processed_dt","sbmsn_dt","rcrd_count","tot_sub_amt","tot_noncov_amt","tot_alwd_amt","tot_paid_amt","tot_cob_tpl_amt","tot_coinsur_amt","tot_copay_amt","tot_deduct_amt","tot_ff_srvc_eq_amt")

        // fixed.show(false)

        fixed.createOrReplaceTempView("control_file")
        spark.sql("""select * from control_file""")
        val result = spark.sql("""select count(*) from control_file""")
        val a = result.rdd

        if (result.first.getLong(0) == 5) {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 1)
        } else {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 2)
        }

      }
    } else if (name.contains("G4")) {
      test("Check total record count is 3 or not for the file of " + name + "") {

        import spark.implicits._
        import spark.sql
        val sc = spark.sparkContext
        sc.setLogLevel("ERROR")

        val id = Array("001")
        val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
        val test_Name = Array("Testcase Name : Check total record count is 3 or not for the file of " + name + "")
        val query = Array("""Test Query : select count(*) from control_file""")
        val outPut = Array("SQL Query Output : ")
        val p = Array("PASS")
        val statusP = Array("Testcase Status : PASSED")
        val f = Array("FAIL")
        val statusF = Array("Testcase Status : FAILED")
        var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
        var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

        // val te="home_plan_id,extract_name,min_clm_processed_dt,max_clm_processed_dt,sbmsn_dt,rcrd_count,tot_sub_amt,tot_noncov_amt,tot_alwd_amt,tot_paid_amt,tot_cob_tpl_amt,tot_coinsur_amt,tot_copay_amt,tot_deduct_amt,tot_ff_srvc_eq_amt"

        val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
        //val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id","extract_name","min_clm_processed_dt","max_clm_processed_dt","sbmsn_dt","rcrd_count","tot_sub_amt","tot_noncov_amt","tot_alwd_amt","tot_paid_amt","tot_cob_tpl_amt","tot_coinsur_amt","tot_copay_amt","tot_deduct_amt","tot_ff_srvc_eq_amt")

        // fixed.show(false)

        fixed.createOrReplaceTempView("control_file")
        spark.sql("""select * from control_file""")
        val result = spark.sql("""select count(*) from control_file""")
        val a = result.rdd

        if (result.first.getLong(0) == 3) {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 1)
        } else {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 2)
        }

      }
    } else {
      test("Check total record count is 1 or not for the file of " + name + "") {

        import spark.implicits._
        import spark.sql
        val sc = spark.sparkContext
        sc.setLogLevel("ERROR")

        val id = Array("001")
        val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
        val test_Name = Array("Testcase Name : Check total record count is 1 or not for the file of " + name + "")
        val query = Array("""Test Query : select count(*) from control_file""")
        val outPut = Array("SQL Query Output : ")
        val p = Array("PASS")
        val statusP = Array("Testcase Status : PASSED")
        val f = Array("FAIL")
        val statusF = Array("Testcase Status : FAILED")
        var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
        var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

        // val te="home_plan_id,extract_name,min_clm_processed_dt,max_clm_processed_dt,sbmsn_dt,rcrd_count,tot_sub_amt,tot_noncov_amt,tot_alwd_amt,tot_paid_amt,tot_cob_tpl_amt,tot_coinsur_amt,tot_copay_amt,tot_deduct_amt,tot_ff_srvc_eq_amt"

        val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
        //val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id","extract_name","min_clm_processed_dt","max_clm_processed_dt","sbmsn_dt","rcrd_count","tot_sub_amt","tot_noncov_amt","tot_alwd_amt","tot_paid_amt","tot_cob_tpl_amt","tot_coinsur_amt","tot_copay_amt","tot_deduct_amt","tot_ff_srvc_eq_amt")

        // fixed.show(false)

        fixed.createOrReplaceTempView("control_file")
        spark.sql("""select * from control_file""")
        val result = spark.sql("""select count(*) from control_file""")
        val a = result.rdd

        if (result.first.getLong(0) == 1) {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 1)
        } else {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 2)
        }

      }
    }

    test("Check bhi_home_plan_id has NULL/Special Characters/Double Quotes or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("002")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check bhi_home_plan_id has NULL/Special Characters/Double Quotes or not for the file of " + name + "")
      val query = Array("""Test Query : select home_plan_id from control_file where home_plan_id rlike '[^0-9]'""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result1 = spark.sql("""select home_plan_id from control_file where home_plan_id rlike '[^0-9]'""")
      val a = result1.rdd

      if (result1.count > 0) {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      }

    }

    test("Check extract_name is correct or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("003")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check extract_name is correct or not for the file of " + name + "")
      val query = Array("""Test Query : select extract_name from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result = spark.sql("""select distinct extract_name from control_file""")
      val a = result.rdd

      if (result.first.getString(0).trim.equals(extractName)) {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }

    }

    test("Check extract_name has NULL/Special Characters/Double Quotes or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("004")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check extract_name has NULL/Special Characters/Double Quotes or not for the file of " + name + "")
      val query = Array("""Test Query : select extract_name from control_file where trim(extract_name) rlike '[^A-Z_]'""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result1 = spark.sql("""select extract_name from control_file where trim(extract_name) rlike '[^A-Z_]'""")
      val a = result1.rdd

      if (result1.count > 0) {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      }

    }

    test("Check extract_name is left justified, with trailing bytes filled with spaces or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("005")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check extract_name is left justified, with trailing bytes filled with spaces or not for the file of " + name + "")
      val query = Array("""Test Query : select extract_name from control_file where substr(extract_name,3,1) rlike '[^A-Z]' and substr(extract_name,32,1) not like ''""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result1 = spark.sql("""select extract_name from control_file where substr(extract_name,3,1) rlike '[^A-Z]' and substr(extract_name,32,1) not like ''""")
      val a = result1.rdd
      if (result1.count > 0) {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      }

    }

    test("Check min_clm_processed_dt column is in YYYYMMDD format or not fo rthe file of " + name + "") {
      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("006")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check min_clm_processed_dt column is in YYYYMMDD format or not fo rthe file of " + name + "")
      val query = Array("""Test Query : select distinct min_clm_processed_dt from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      val invalidFormat = udf((s: String) => FormatChecker.invalidFormat(s))
      val result1 = spark.sql("""select distinct min_clm_processed_dt from control_file""")
      val a = result1.rdd

      if (fixed.where(invalidFormat($"min_clm_processed_dt")).count() == 0) {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }

    }
    test("Check max_clm_processed_dt column is in YYYYMMDD format or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("007")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check max_clm_processed_dt column is in YYYYMMDD format or not for the file of " + name + "")
      val query = Array("""Test Query : select distinct max_clm_processed_dt from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      val invalidFormat = udf((s: String) => FormatChecker.invalidFormat(s))
      val result1 = spark.sql("""select distinct max_clm_processed_dt from control_file""")
      val a = result1.rdd

      if (fixed.where(invalidFormat($"max_clm_processed_dt")).count() == 0) {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }

    }
    test("Check sbmsn_dt column is in YYYYMMDD format or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("008")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check sbmsn_dt column is in YYYYMMDD format or not for the file of " + name + "")
      val query = Array("""Test Query : select distinct sbmsn_dt from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      val invalidFormat = udf((s: String) => FormatChecker.invalidFormat(s))
      val result1 = spark.sql("""select distinct sbmsn_dt from control_file""")
      val a = result1.rdd

      if (fixed.where(invalidFormat($"sbmsn_dt")).count() == 0) {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }

    }

    test("Check rcrd_count column has NULL/commas/Decimals or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("009")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check rcrd_count column has NULL/commas/Decimals or not for the file of " + name + "")
      val query = Array("""Test Query : select rcrd_count from control_file where rcrd_count rlike '[^0-9]'""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result1 = spark.sql("""select rcrd_count from control_file where rcrd_count rlike '[^0-9]'""")
      val a = result1.rdd
      if (result1.count > 0) {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      }

    }

    test("Check rcrd_count column is right justified with leading bytes zero filled or not for the file of " + name + "") {
      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("010")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check rcrd_count column is right justified with leading bytes zero filled or not for the file of " + name + "")
      val query = Array("""Test Query : select rcrd_count from control_file where substr(rcrd_count,57,1) rlike '[^0]' and substr(rcrd_count,66,1) rlike '[^1-9]'""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result1 = spark.sql("""select rcrd_count from control_file where substr(rcrd_count,57,1) rlike '[^0]' and substr(rcrd_count,66,1) rlike '[^1-9]'""")
      val a = result1.rdd
      if (result1.count > 0) {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      }

    }

    test("Check tot_sub_amt column has +00000000000000 or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("011")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check tot_sub_amt column has +00000000000000 or not for the file of " + name + "")
      val query = Array("""Test Query : select distinct tot_sub_amt from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result = spark.sql("""select distinct tot_sub_amt from control_file""")
      val a = result.rdd
      if (result.first.getString(0) == "+00000000000000") {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }
    }

    test("Check tot_noncov_amt column has +00000000000000 or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("012")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check tot_noncov_amt column has +00000000000000 or not for the file of " + name + "")
      val query = Array("""Test Query : select distinct tot_noncov_amt from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result = spark.sql("""select distinct tot_noncov_amt from control_file""")
      val a = result.rdd
      if (result.first.getString(0) == "+00000000000000") {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }
    }

    test("Check tot_alwd_amt column has +00000000000000 or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("013")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check tot_alwd_amt column has +00000000000000 or not for the file of " + name + "")
      val query = Array("""Test Query : select distinct tot_alwd_amt from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result = spark.sql("""select distinct tot_alwd_amt from control_file""")
      val a = result.rdd
      if (result.first.getString(0) == "+00000000000000") {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }
    }
    test("Check tot_paid_amt column has +00000000000000 or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("014")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check tot_paid_amt column has +00000000000000 or not for the file of " + name + "")
      val query = Array("""Test Query : select distinct tot_paid_amt from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result = spark.sql("""select distinct tot_paid_amt from control_file""")
      val a = result.rdd
      if (result.first.getString(0) == "+00000000000000") {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }
    }

    test("Check tot_cob_tpl_amt column has +00000000000000 or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("015")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check tot_cob_tpl_amt column has +00000000000000 or not for the file of " + name + "")
      val query = Array("""Test Query : select distinct tot_cob_tpl_amt from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result = spark.sql("""select distinct tot_cob_tpl_amt from control_file""")
      val a = result.rdd
      if (result.first.getString(0) == "+00000000000000") {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }
    }

    test("Check tot_coinsur_amt column has +00000000000000 or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("016")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check tot_coinsur_amt column has +00000000000000 or not for the file of " + name + "")
      val query = Array("""Test Query : select distinct tot_coinsur_amt from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result = spark.sql("""select distinct tot_coinsur_amt from control_file""")
      val a = result.rdd
      if (result.first.getString(0) == "+00000000000000") {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }
    }
    test("Check tot_copay_amt column has +00000000000000 or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("017")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check tot_copay_amt column has +00000000000000 or not for the file of " + name + "")
      val query = Array("""Test Query : select distinct tot_copay_amt from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result = spark.sql("""select distinct tot_copay_amt from control_file""")
      val a = result.rdd
      if (result.first.getString(0) == "+00000000000000") {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }
    }

    test("Check tot_deduct_amt column has +00000000000000 or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("018")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check tot_deduct_amt column has +00000000000000 or not for the file of " + name + "")
      val query = Array("""Test Query : select distinct tot_deduct_amt from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result = spark.sql("""select distinct tot_deduct_amt from control_file""")
      val a = result.rdd
      if (result.first.getString(0) == "+00000000000000") {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }
    }
    test("Check tot_ff_srvc_eq_amt column has +00000000000000 or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("019")
      val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check tot_ff_srvc_eq_amt column has +00000000000000 or not for the file of " + name + "")
      val query = Array("""Test Query : select distinct tot_ff_srvc_eq_amt from control_file""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
      fixed.createOrReplaceTempView("control_file")
      spark.sql("""select * from control_file""")
      val result = spark.sql("""select distinct tot_ff_srvc_eq_amt from control_file""")
      val a = result.rdd
      if (result.first.getString(0) == "+00000000000000") {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }
    }

    if (name.contains("G1") || name.contains("G2") || name.contains("G3") || name.contains("G4")) {
      test("Check home plan id's of group id are populated correctly or not for the file of " + name + "") {

        import spark.implicits._
        import spark.sql
        val sc = spark.sparkContext
        sc.setLogLevel("ERROR")

        val id = Array("020")
        val tcId = Array("Testcase Id : ControlFile_" + process_Name + "_" + id(0) + "")
        val test_Name = Array("Testcase Name : Check home plan id's of group id are populated correctly or not for the file of " + name + "")
        val query = Array("""Test Query : select distinct home_plan_id from control_file""")
        val outPut = Array("SQL Query Output : ")
        val p = Array("PASS")
        val statusP = Array("Testcase Status : PASSED")
        val f = Array("FAIL")
        val statusF = Array("Testcase Status : FAILED")
        var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
        var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

        val fixed = spark.read.text(name).map { x => FixedWidthFile.getRow(x.getString(0)) }.toDF("home_plan_id", "extract_name", "min_clm_processed_dt", "max_clm_processed_dt", "sbmsn_dt", "rcrd_count", "tot_sub_amt", "tot_noncov_amt", "tot_alwd_amt", "tot_paid_amt", "tot_cob_tpl_amt", "tot_coinsur_amt", "tot_copay_amt", "tot_deduct_amt", "tot_ff_srvc_eq_amt")
        fixed.createOrReplaceTempView("control_file")
        spark.sql("""select * from control_file""")
        val result1 = spark.sql("""select distinct home_plan_id from control_file""").rdd.map(_.mkString("|"))
        //val result2 = spark.sql("""select distinct home_plan_id from control_file""")
        if (name.contains("G1")) {
          var rdd1 = spark.sparkContext.parallelize(List("051", "748", "266", "458", "102")).toDF("home_plan_id")
          rdd1.createOrReplaceTempView("dframe")
        } else if (name.contains("G2")) {
          var rdd1 = spark.sparkContext.parallelize(List("040")).toDF("home_plan_id")
          rdd1.createOrReplaceTempView("dframe")
        } else if (name.contains("G3")) {
          var rdd1 = spark.sparkContext.parallelize(List("062", "182", "271", "254", "425")).toDF("home_plan_id")
          rdd1.createOrReplaceTempView("dframe")
        } else if (name.contains("G4")) {
          var rdd1 = spark.sparkContext.parallelize(List("131", "161", "330")).toDF("home_plan_id")
          rdd1.createOrReplaceTempView("dframe")
        }

        val result2 = spark.sql("select home_plan_id from dframe").rdd.map(_.mkString("|"))

        val ctl = result1.subtract(result2).map(_.concat("|ControlFile"))
        val exrt = result2.subtract(result1).map(_.concat("|ExpectedList"))
        val a = ctl.union(exrt).sortBy(x => x, true, 1)

        if (ctl.count != 0 || exrt.count != 0) {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 2)
        } else {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/ControlFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 1)
        }

      }
    }

  })
}