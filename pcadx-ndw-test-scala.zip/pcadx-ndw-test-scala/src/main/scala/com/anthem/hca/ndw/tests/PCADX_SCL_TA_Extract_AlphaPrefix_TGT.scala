package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import org.apache.spark.sql._
import java.util.Calendar
import java.util.Date
import java.text.SimpleDateFormat


object PCADX_SCL_TA_Extract_AlphaPrefix_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_AlphaPrefix_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_Extract_AlphaPrefix_TGT(dbname : String, env: String) extends FunSuite  {
  
     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
  
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Extract"
      val prcss = "AlphaPrefix"
  
  
  
  test("AlphaPrefix -Validate One record for each BHI Home Plan ID and Alpha Prefix - 001 ") {
     
      val id = Array("001")
      val name = Array("Test case : Validate One record for each BHI Home Plan ID and Alpha Prefix")
     
      val result = sqlContext.sql("""select bhi_home_plan_id ,bcbsa_prfx_cd,count(*) as count from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC 
      group by bhi_home_plan_id ,bcbsa_prfx_cd""")
      result.createOrReplaceTempView("resultDF")
    
     val invalid = sqlContext.sql("""select * from resultDF where count > 1 """)
    
     if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id ,bcbsa_prfx_cd,count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC group by bhi_home_plan_id ,bcbsa_prfx_cd) where count > 1")
      val data = Array("'BHI HPID','BCBSA_PRFX_CD','COUNT'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
     } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id ,bcbsa_prfx_cd,count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC group by bhi_home_plan_id ,bcbsa_prfx_cd")
      val data = Array("'BHI HPID','BCBSA_PRFX_CD','COUNT'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
      
    }

  }

 //===========================================
 
  test("AlphaPrefix -Validate that all the records have the correct [BHI Home Plan ID] as per Anthem - 002 ") {

    val id = Array("002")
    val name = Array("Test case : Validate that all the records have the correct [BHI Home Plan ID] as per Anthem")
     
  
    val result = sqlContext.sql("""select bhi_home_plan_id,bcbsa_prfx_cd,err_id,exclsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC where
    bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748')  limit 10""")
     
           
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748')  limit 10")
      val data = Array("'BHI HPID','BCBSA_PRFX_CD','ERR_ID','EXCLSN_ID'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748')  limit 10")
      val data = Array("'BHI HPID','BCBSA_PRFX_CD','ERR_ID','EXCLSN_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  
   //===========================================
  
    test("AlphaPrefix -Validate if AlphaPrefix field has default value of 999 - 003") {
    
      val id = Array("003")
      val name = Array("Test case : Validate if AlphaPrefix field has default value of 999")
     
      
    val result = sqlContext.sql("""select * from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC a
      where a.bcbsa_prfx_cd = '999' limit 10 """)
      
    if (result.count < 1) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC a where a.bcbsa_prfx_cd = '999' limit 10")
      val data = Array("'Column has no data with default value 999'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC a where a.bcbsa_prfx_cd = '999' limit 10")
      val data = Array("'Column has data with default value 999'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  
   //===========================================
   
  
  test("AlphaPrefix -Validate that BHI Home Plan ID is not NULL or contains blank spaces - 004 ") {
    
    val id = Array("004")
    val name = Array("Test case : Validate that BHI Home Plan ID is not NULL or contains blank spaces")
     
    
    val result = sqlContext.sql("""select bhi_home_plan_id,bcbsa_prfx_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC
        where length(trim(regexp_replace(coalesce(bhi_home_plan_id, "")," ", "")))=0  limit 10""")

            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0  limit 10")
      
      val data = Array("'BHI HPID','BCBSA_PRFX_CD'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0  limit 10")
      
      val data = Array("'BHI HPID','BCBSA_PRFX_CD' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

 
  //=============================================================
  
   
  test("AlphaPrefix -Validate that AlphaPrefix Field is not NULL or contains blank spaces - 005 ") {
    
    val id = Array("005")
    val name = Array("Test case : Validate that AlphaPrefix Field is not NULL or contains blank spaces")
     
    
    val result = sqlContext.sql("""select bhi_home_plan_id,bcbsa_prfx_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC
        where length(trim(regexp_replace(coalesce(bcbsa_prfx_cd, "")," ", "")))=0  limit 10""")

           
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC where length(trim(regexp_replace(coalesce(bcbsa_prfx_cd, ''),' ', '')))=0  limit 10")
      
      val data = Array("'BHI HPID','BCBSA_PRFX_CD'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC where length(trim(regexp_replace(coalesce(bcbsa_prfx_cd, ''),' ', '')))=0  limit 10")
      
      val data = Array("'BHI HPID','BCBSA_PRFX_CD' : No Invalid Values Found")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

 
  //=============================================================
  
  test("AlphaPrefix -Validate that AlphaPrefix Description is not NULL or contains blank spaces - 006 ") {
    
    val id = Array("006")
    val name = Array("Test case : Validate that AlphaPrefix Description is not NULL or contains blank spaces")
     
    
    val result = sqlContext.sql("""select bhi_home_plan_id,bcbsa_prfx_cd,bcbsa_prfx_desc from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC
        where length(trim(regexp_replace(coalesce(bcbsa_prfx_desc, "")," ", "")))=0  limit 10""")

       
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd,bcbsa_prfx_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC where length(trim(regexp_replace(coalesce(bcbsa_prfx_desc, ''),' ', '')))=0  limit 10")
      
      val data = Array("'BHI HPID','BCBSA_PRFX_CD','BCBSA_PRFX_DESC'")
      
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd,bcbsa_prfx_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC where length(trim(regexp_replace(coalesce(bcbsa_prfx_desc, ''),' ', '')))=0  limit 10")
      
      val data = Array("'BHI HPID','BCBSA_PRFX_CD','BCBSA_PRFX_DESC' : No Invalid Values Found")
      
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //=============================================================
  
  test("AlphaPrefix -Validate if BHI Home Plan ID does not contains any special character - 007 ") {
    
    val id = Array("007")
    val name = Array("Test case : Validate if BHI Home Plan ID does not contains any special character")
     
    
    val result = sqlContext.sql("""select bhi_home_plan_id,bcbsa_prfx_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC a
      where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%' limit 10""")

          
    if (result.count > 0) {
     val a = result.limit(10).rdd
     val status = Array("FAILED")
     val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC a where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%' limit 10")
      
     val data = Array("'BHI HPID','BCBSA_PRFX_CD'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC a where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%' limit 10")
      
      val data = Array("'BHI HPID','BCBSA_PRFX_CD' : No Invalid Values Found")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  //=============================================================
  
  test("AlphaPrefix -Validate if AlphaPrefix Field does not contains any special character - 008 ") {
    
    val id = Array("008")
    val name = Array("Test case : Validate if AlphaPrefix Field does not contains any special character")
     
    
    val result = sqlContext.sql("""select bhi_home_plan_id,bcbsa_prfx_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC a
      where a.bcbsa_prfx_cd  LIKE '%[^A-z0-9]%' limit 10""")

    
      
    if (result.count > 0) {
     val a = result.limit(10).rdd
     val status = Array("FAILED")
     val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC a where a.bcbsa_prfx_cd  LIKE '%[^A-z0-9]%' limit 10")

     val data = Array("'BHI HPID','BCBSA_PRFX_CD'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
     val a = result.limit(10).rdd
     val status = Array("SUCCESS")
     val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC a where a.bcbsa_prfx_cd  LIKE '%[^A-z0-9]%' limit 10")

     val data = Array("'BHI HPID','BCBSA_PRFX_CD' : No Invalid Values Found")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  //=============================================================
  
  test("AlphaPrefix -Validate if AlphaPrefix Description does not contains any special character - 009") {
   
    val id = Array("009")
    val name = Array("Test case : Validate if AlphaPrefix Description does not contains any special character")
     
    
    val result = sqlContext.sql("""select bhi_home_plan_id,bcbsa_prfx_cd,bcbsa_prfx_desc from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC a
      where a.bcbsa_prfx_desc  LIKE '%[^a-Z0-9]%'  limit 10""")
    
    
    
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd,bcbsa_prfx_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC a where a.bcbsa_prfx_desc  LIKE '%[^a-Z0-9]%'  limit 10")

      val data = Array("'BHI HPID','BCBSA_PRFX_CD','BCBSA_PRFX_DESC'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,bcbsa_prfx_cd,bcbsa_prfx_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFX_RFRNC a where a.bcbsa_prfx_desc  LIKE '%[^a-Z0-9]%'  limit 10")

      val data = Array("'BHI HPID','BCBSA_PRFX_CD','BCBSA_PRFX_DESC' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  //=============================================================
  
  test("AlphaPrefix - Validate that there are 14 BHI Home Plan ID  - 010") {
    
    val id = Array("010")
     val name = Array("Test case : Validate that there are 14 BHI Home Plan ID ")
     
    val result = sqlContext.sql(""" select count(distinct bhi_home_plan_id) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_PRFX_RFRNC """)
    
        
    if (result.collectAsList.toString.contains("14")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_PRFX_RFRNC ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_PRFX_RFRNC ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
  
  
  test("AlphaPrefix - Validate that all the alpha prefix codes present in PCC are there in Alpha Prefix Extract  - 011") {
    
    val id = Array("011")
     val name = Array("Test case : Validate that all the alpha prefix codes present in PCC are there in Alpha Prefix Extract ")
     
    val result = sqlContext.sql(""" select * from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_prfx_rfrnc PRFX left outer join """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_prod_clnt_cntrct PCC on trim(PRFX.bcbsa_prfx_cd)=trim(PCC.prfx_cd) where PCC.prfx_cd is NULL """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_prfx_rfrnc PRFX left outer join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_prod_clnt_cntrct PCC on trim(PRFX.bcbsa_prfx_cd)=trim(PCC.prfx_cd) where PCC.prfx_cd is NULL ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_prfx_rfrnc PRFX left outer join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_prod_clnt_cntrct PCC on trim(PRFX.bcbsa_prfx_cd)=trim(PCC.prfx_cd) where PCC.prfx_cd is NULL ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
  
  test("AlphaPrefix - Validate that all the alpha prefix descriptions  present in BOT table are there in Alpha Prefix Extract  - 012") {
    
    val id = Array("012")
     val name = Array("Test case : Validate that all the alpha prefix descriptions  present in BOT table are there in Alpha Prefix Extract ")
     
    val result = sqlContext.sql(""" select * 
                  from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_prfx_rfrnc PRFX 
                  left outer join """+dbname+"""_PCANDW1PH_nogbd_r000_in.bot_bcbsa_prfx_inbnd BOT
                  on trim(PRFX.bcbsa_prfx_desc)=trim(BOT.acct_nm)
                  where BOT.acct_nm is NULL and
                  PRFX.bcbsa_prfx_desc not in ('Assgnd - name not avail', 'Default') """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_prfx_rfrnc PRFX left outer join '''+dbname+'''_PCANDW1PH_nogbd_r000_in.bot_bcbsa_prfx_inbnd BOT on trim(PRFX.bcbsa_prfx_desc)=trim(BOT.acct_nm) where BOT.acct_nm is NULL and PRFX.bcbsa_prfx_desc not in ('Assgnd - name not avail', 'Default') ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_prfx_rfrnc PRFX left outer join '''+dbname+'''_PCANDW1PH_nogbd_r000_in.bot_bcbsa_prfx_inbnd BOT on trim(PRFX.bcbsa_prfx_desc)=trim(BOT.acct_nm) where BOT.acct_nm is NULL and PRFX.bcbsa_prfx_desc not in ('Assgnd - name not avail', 'Default') ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
 
  
   test("AlphaPrefix - Validate that for a given Alpha Prefix Id, if there are more than one description, then only that Alpha Description with the latest Date is considered - 013") {
   
     val id = Array("013")
     val name = Array("Test case : Validate that all the alpha prefix descriptions  present in BOT table are there in Alpha Prefix Extract ")
     
    val result = sqlContext.sql(""" Select bhi_home_plan_id,bcbsa_prfx_cd,bcbsa_prfx_desc 
                                  from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_prfx_rfrnc PRFX
                                  left outer join 
                                  (SELECT  prfx_cd, acct_nm, efctv_strt_dt, efctv_end_dt,
                                  RANK() OVER (PARTITION BY prfx_cd ORDER BY efctv_strt_dt DESC, efctv_end_dt DESC, acct_nm desc) as Rank 
                                  from """+dbname+"""_pcandw1ph_nogbd_r000_in.bot_bcbsa_prfx_inbnd ) BOT
                                  on trim(PRFX.bcbsa_prfx_cd)=trim(BOT.prfx_cd)
                                  where BOT.Rank = 1 and
                                  trim(PRFX.bcbsa_prfx_desc)<>trim(BOT.acct_nm) and
                                  BOT.prfx_cd is not NULL and
                                  PRFX.bcbsa_prfx_desc not in ('Assgnd - name not avail', 'Default') """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  Select * from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_prfx_rfrnc PRFX left outer join (SELECT  prfx_cd, acct_nm, efctv_strt_dt, efctv_end_dt, RANK() OVER (PARTITION BY prfx_cd ORDER BY efctv_strt_dt DESC, efctv_end_dt DESC, acct_nm desc) as Rank from '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_prfx_inbnd ) BOT on trim(PRFX.bcbsa_prfx_cd)=trim(BOT.prfx_cd) where BOT.Rank = 1 and trim(PRFX.bcbsa_prfx_desc)<>trim(BOT.acct_nm) and BOT.prfx_cd is not NULL and PRFX.bcbsa_prfx_desc not in ('Assgnd - name not avail', 'Default') ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  Select * from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_prfx_rfrnc PRFX left outer join (SELECT  prfx_cd, acct_nm, efctv_strt_dt, efctv_end_dt, RANK() OVER (PARTITION BY prfx_cd ORDER BY efctv_strt_dt DESC, efctv_end_dt DESC, acct_nm desc) as Rank from '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_prfx_inbnd ) BOT on trim(PRFX.bcbsa_prfx_cd)=trim(BOT.prfx_cd) where BOT.Rank = 1 and trim(PRFX.bcbsa_prfx_desc)<>trim(BOT.acct_nm) and BOT.prfx_cd is not NULL and PRFX.bcbsa_prfx_desc not in ('Assgnd - name not avail', 'Default') ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //==========================================
 
  /* 
   test("AlphaPrefix - Validate that for a given Alpha Prefix Id, if there are more than one description, then only that Alpha Description with the latest Date is considered - 005") {
   
     val id = Array("005")
     val name = Array("Test case :  Validate that for a given Alpha Prefix Id, if there are more than one description, then only that Alpha Description with the latest Date is considered ")
     
     
    val result = sqlContext.sql("""Select count(*) as counts from (SELECT  prfx_cd, acct_nm, efctv_strt_dt, efctv_end_dt,RANK() OVER (PARTITION BY prfx_cd ORDER BY  efctv_strt_dt DESC, efctv_end_dt DESC) as Rank 
                  from """+dbname+"""_pcandw1ph_nogbd_r000_in.bot_bcbsa_prfx_inbnd ) A where A.Rank = 1 """)
    
    val result1 = sqlContext.sql("""Select COUNT(DISTINCT (bcbsa_prfx_cd)) as counts from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prfx_rfrnc""")
    
    if (result.col("counts") == result1.col("counts")) {
      val a = result.limit(10).rdd
      val b = result1.rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : Select count(*) as counts from (SELECT  prfx_cd, acct_nm, efctv_strt_dt, efctv_end_dt,RANK() OVER (PARTITION BY prfx_cd ORDER BY  efctv_strt_dt DESC, efctv_end_dt DESC) as Rank from '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_prfx_inbnd ) A where A.Rank = 1")
      val query2 = Array("Test Query : Select COUNT(DISTINCT (bcbsa_prfx_cd)) as counts from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfx_rfrnc")
      
      val data = Array("'Count of 2 queries are equal'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_" + currdate) +"_.dat"
      assert(1==1)
      
    } else {
      val a = result.limit(10).rdd
      val b = result1.rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : Select count(*) as counts from (SELECT  prfx_cd, acct_nm, efctv_strt_dt, efctv_end_dt,RANK() OVER (PARTITION BY prfx_cd ORDER BY  efctv_strt_dt DESC, efctv_end_dt DESC) as Rank from '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_prfx_inbnd ) A where A.Rank = 1")
      val query2 = Array("Test Query : Select COUNT(DISTINCT (bcbsa_prfx_cd)) as counts from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfx_rfrnc")
      
      val data = Array("'Count of 2 queries are not equal'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/AlphaPrefix/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
   
  test("AlphaPrefix - Validate Source and Target table - 001") {
     
     val id = Array("001")
     val name = Array("Test case : Validate Source and Target table")
     

    ExcelTableValidation.tableCompare("select trim(bhi_home_plan_id),trim(prfx_cd),trim(acct_nm) from "+dbname+"_pcandw1ph_nogbd_r000_in.bot_bcbsa_prfx_inbnd",
        "select trim(bhi_home_plan_id),trim(bcbsa_prfx_cd),trim(bcbsa_prfx_desc ) from "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfx_rfrnc", 
       "bcbsa_prfx_rfrnc","bhi_home_plan_id,bcbsa_prfx_cd,bcbsa_prfx_desc",sc,f"$id",f"$name",f"$env")

    assert(1==1)
    
  } */
  
  
  
  
  
   
}