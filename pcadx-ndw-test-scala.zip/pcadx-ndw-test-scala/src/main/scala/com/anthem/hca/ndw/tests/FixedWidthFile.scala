package com.anthem.hca.ndw.tests

import org.apache.spark.sql.types._
import org.apache.spark.sql.Row
import scala.util.{Try, Failure}

object FixedWidthFile {

  val schemaString = "home_plan_id,extract_name,min_clm_processed_dt,max_clm_processed_dt,sbmsn_dt,rcrd_count,tot_sub_amt,tot_noncov_amt,tot_alwd_amt,tot_paid_amt,tot_cob_tpl_amt,tot_coinsur_amt,tot_copay_amt,tot_deduct_amt,tot_ff_srvc_eq_amt"
  val fields = schemaString.split(",").map(fieldName => StructField(fieldName, StringType, nullable = true))
  val schema = StructType(fields)
//val fields1 = schemaString.split(",").map(x => x.toCharArray())
//schemaString.split(",").map(x => x.toCharArray())
  def getRow(x: String): (String,String,String,String,String,String,String,String,String,String,String,String,String,String,String) = {
    /*val columnArray = new Array[String](15)
    columnArray(0) = x.substring(0, 3)
    columnArray(1) = x.substring(3, 33)
    columnArray(2) = x.substring(33, 41)
    columnArray(3) = x.substring(41, 49)
    columnArray(4) = x.substring(49, 57)
    columnArray(5) = x.substring(57, 67)
    columnArray(6) = x.substring(67, 82)
    columnArray(7) = x.substring(82, 97)
    columnArray(8) = x.substring(97, 112)
    columnArray(9) = x.substring(112, 127)
    columnArray(10) = x.substring(127, 142)
    columnArray(11) = x.substring(142, 157)
    columnArray(12) = x.substring(157, 172)
    columnArray(13) = x.substring(172, 187)
    columnArray(14) = x.substring(187, 202)
    //Row.fromSeq(columnArray)
    columnArray*/ 
    
  
  val a = (x.substring(0, 3),x.substring(3, 33),x.substring(33, 41),x.substring(41, 49),x.substring(49, 57),
      x.substring(57, 67),x.substring(67, 82),x.substring(82, 97),x.substring(97, 112),x.substring(112, 127),
    x.substring(127, 142),x.substring(142, 157),x.substring(157, 172),x.substring(172, 187),x.substring(187, 202))  
 a  
}
}

object FormatChecker extends java.io.Serializable {
  val fmt = org.joda.time.format.DateTimeFormat forPattern "yyyyMMdd"
  def invalidFormat(s: String) = Try(fmt parseDateTime s) match {
    case Failure(_) => true
    case _ => false
  }
}
