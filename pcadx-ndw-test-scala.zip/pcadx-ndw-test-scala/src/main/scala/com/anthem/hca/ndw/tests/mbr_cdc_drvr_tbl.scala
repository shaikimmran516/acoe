package com.anthem.hca.ndw.tests

import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import org.apache.spark.sql._
import java.util.Calendar
import java.util.Date
import java.text.SimpleDateFormat

object mbr_cdc_drvr_tbl {

  def main(args: Array[String]) {

    (new mbr_cdc_drvr_tbl(args(0), args(1), args(2))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class mbr_cdc_drvr_tbl(dbname : String, mbrHisTbl : String, mbrDemoHisTbl : String) extends FunSuite  {
  
     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
  
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val spark = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import spark.implicits._
      import spark.sql

    spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode", "INFER_ONLY")
    spark.conf.set("spark.sql.crossJoin.enabled", "true")

    
 //MEMBER bcbsa_mbrshp_bsln0803

  val mbr_new = spark.sql(""" select distinct WRK.mbr_id, "New" as status, "Mbr" as extrct_nm 
    from """+dbname+"""_PCANDW1PH_nogbd_r000_wk.WORK_BCBSA_MBRSHP WRK 
    left outer join """+dbname+"""_pcandw1ph_nogbd_r000_ou."""+mbrHisTbl+""" HIST 
    on trim(WRK.RCRD_HASH_PK_ID)=trim(HIST.RCRD_HASH_PK_ID) where HIST.RCRD_HASH_PK_ID is NULL """)

  val mbr_cdc = spark.sql(""" select distinct WRK.mbr_id, "Changed" as status, "Mbr" as extrct_nm 
   from """+dbname+"""_PCANDW1PH_nogbd_r000_wk.WORK_BCBSA_MBRSHP WRK 
   left outer join """+dbname+"""_pcandw1ph_nogbd_r000_ou."""+mbrHisTbl+""" HIST 
   on trim(WRK.RCRD_HASH_PK_ID)=trim(HIST.RCRD_HASH_PK_ID) 
   where HIST.RCRD_HASH_PK_ID is not NULL and HIST.RCRD_HASH_NPK_ID<>WRK.RCRD_HASH_NPK_ID """)

//MEMBER DEMOGRAPHIC BCBSA_MBRSHP_DMGRPHC_hist0829

  val mbr_dem_new = spark.sql(""" select distinct WRK.cnsstnt_mbr_id, "New" as status, "Mbr_Dem" as extrct_nm 
    from """+dbname+"""_PCANDW1PH_nogbd_r000_wk.WORK_BCBSA_MBRSHP_DMGRPHC WRK 
    left outer join """+dbname+"""_pcandw1ph_nogbd_r000_ou."""+mbrDemoHisTbl+""" HIST 
    on trim(WRK.RCRD_HASH_PK_ID)=trim(HIST.RCRD_HASH_PK_ID) where HIST.RCRD_HASH_PK_ID is NULL """)

  val mbr_dem_cdc = spark.sql(""" select distinct WRK.cnsstnt_mbr_id, "Changed" as status, "Mbr_Dem" as extrct_nm 
    from """+dbname+"""_PCANDW1PH_nogbd_r000_wk.WORK_BCBSA_MBRSHP_DMGRPHC WRK 
    left outer join """+dbname+"""_pcandw1ph_nogbd_r000_ou."""+mbrDemoHisTbl+""" HIST 
    on trim(WRK.RCRD_HASH_PK_ID)=trim(HIST.RCRD_HASH_PK_ID) 
    where HIST.RCRD_HASH_PK_ID is not NULL and HIST.RCRD_HASH_NPK_ID<>WRK.RCRD_HASH_NPK_ID """)

val result = mbr_new.union(mbr_cdc).union(mbr_dem_new).union(mbr_dem_cdc).distinct()
result.write.mode("overwrite").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.audt_ta_cdc_mbr_id ")



   
}