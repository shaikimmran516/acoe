package com.anthem.hca.ndw.utils

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession

import org.apache.spark.sql.SparkSession
import java.io.File
import org.apache.spark.sql.DataFrame
import java.text.SimpleDateFormat
import org.apache.spark.sql.SaveMode
import java.util.Calendar
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel
import java.util.Date
import java.text.SimpleDateFormat
import org.apache.log4j.Logger



object PCADX_SCL_TA_Utilities {



/*
val dbname: String = "dv"//args(0)
val TEST_LOG_LCTN_TXT: String = "/data/01/ts/app/ve2/pca/ndw1/phi/no_gbd/r000/logs/ta/L2/FinacialBalacing/"//args(1)
val TEST_LOG_FILE_NM: String="PCADX_TA_L2_FinancialBalancing"
val SUBJ_AREA_NM: String="CLM"
val PRCS_NM: String="L2-Financial Balancing"
*/


def ReportOutput(spark: SparkSession,dbname: String, repinput: DataFrame ): DataFrame = {
import spark.implicits._
val repcol=repinput.drop("sql").columns
val sql=repinput.select("sql").collect().map(_(0)).mkString
val size=repcol.size
var convertdata = List[String]()
repcol.foreach(i => {convertdata =  f"""'$i',nvl(cast($i as decimal(38,2)),0)""" :: convertdata})
val columns=convertdata.mkString(",")
val report= repinput.select(expr(f"""stack($size,$columns) as (B,C)""")).withColumn("sql",lit(sql))
val l2rulesmeta=spark.sql("select * from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_RULE")
val repou=l2rulesmeta.join(report,trim(report.col("B"))===trim(l2rulesmeta.col("RULE_CLMN_NM")),"inner").select(report("sql"),l2rulesmeta("RULE_DESC"),report("C") as "ACT_PERCT",report("C"),l2rulesmeta("RULE_THRSHLD"),l2rulesmeta("RULE_CMPRSN")).withColumn("TEST_CASE_STTS_TXT",when((l2rulesmeta("RULE_THRSHLD")>report("C") && l2rulesmeta("RULE_CMPRSN").equalTo(">")) or (l2rulesmeta("RULE_THRSHLD")<report("C") && l2rulesmeta("RULE_CMPRSN").equalTo("<")) , "PASS").otherwise("FAIL") ).drop("RULE_THRSHLD").drop ("RULE_CMPRSN").drop("C")
repou
}

def TestIDGen(spark: SparkSession, repou: DataFrame ): DataFrame = {

val repTestId=repou.withColumn("testId",lpad(row_number().over(Window.orderBy("RULE_DESC")),3,"0"))
repTestId

}

def output(spark: SparkSession, repTestId: DataFrame,SUBJ_AREA_NM: String,PRCS_NM: String, home_plan_id: String): DataFrame = {
val now = Calendar.getInstance().getTime()
val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
val EXECTN_DT = formatter1.format(new Date())
val errorOut=repTestId.select("testId","RULE_DESC","TEST_CASE_STTS_TXT","ACT_PERCT","sql").withColumn("SUBJ_AREA_NM" ,lit(SUBJ_AREA_NM)).withColumn("PRCS_NM",lit(PRCS_NM)).withColumn("home_plan_id",lit(home_plan_id)).withColumn("EXECTN_DT",lit(EXECTN_DT)).select("SUBJ_AREA_NM","PRCS_NM","testId","RULE_DESC","home_plan_id","TEST_CASE_STTS_TXT","ACT_PERCT","sql","EXECTN_DT")

//val sqlout=repTestId.select("testId","sql").withColumn("SUBJ_AREA_NM" ,lit(SUBJ_AREA_NM)).withColumn("PRCS_NM",lit(PRCS_NM)).withColumn("EXECTN_DT",lit(EXECTN_DT)).select("SUBJ_AREA_NM","PRCS_NM","testId","sql","EXECTN_DT")
errorOut
}

val log=Logger.getLogger(getClass.getName)
  val DATE_TIME_FORMAT = "YYYYMMDD"
  
  def validateDf(col: String): Boolean = try {
       java.time.LocalDateTime.parse(col, java.time.format.DateTimeFormatter.ofPattern(DATE_TIME_FORMAT))
 
        true
      } catch {
         case ex: java.time.format.DateTimeParseException => {
         // Handle exception if you want
        false
      }
    }

  def DfRowCount(df: DataFrame): Long = {
    var count: Long = df.count()
    return count
  }

  def BalanceCheck(sourcecount: Long, targetcount: Long): Long = {
    var varcount: Long = 0

    if (sourcecount == targetcount) {
      varcount = sourcecount - targetcount
    } else {
      varcount = sourcecount - targetcount
    }

    return varcount
  }

  /*def getHiveContext(appName: String): SparkSession = {

    val sparkConf = new SparkConf().setAppName(appName)
    val sc = new SparkContext(sparkConf)
    val spark = new org.apache.spark.sql.hive.HiveContext(sc)
    return spark
  }*/

  def getCurrentTime(): String = {
    val DATETIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val LOG_DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())
    LOG_DATETIME
  }

  /*
   * 
   * Adds the PK HASH and NON PK HASH columns
   * 
   */
  def create256BitHash(spark: SparkSession, sourceDf: DataFrame, primaryKeyList: List[String]): DataFrame = {

    val primaryKeys = primaryKeyList.map(x => f"""nvl($x,"")""").mkString(",")

    val nonPrimaryKeyList = (sourceDf.columns) diff primaryKeyList

    val nonPrimaryKeys = nonPrimaryKeyList.map(x => f"""nvl($x,"")""").mkString(",")

    val returnDf = sourceDf.withColumn("RCRD_HASH_PK_ID", expr(f"""md5(concat($primaryKeys))""")).
      withColumn("RCRD_HASH_NPK_ID", expr(f"""md5(concat($nonPrimaryKeys))"""))

    returnDf
  }

  def auditBalancingInsert(spark: SparkSession, sourceDf: DataFrame, tarType: String, tarTbl: String, tarDb: String, audBlncTbl: String, audDb: String, srcType: String, srcName: String, loadLogKey: String): Long = {
    import spark.implicits._

    val audtBlncId: String = loadLogKey.reverse
    val currTimeStamp = getCurrentTime()
    val sourceCnt = sourceDf.count()
    val tarCount = spark.table(f"""$tarDb.$tarTbl""").count()
    val cntrl_nm=""
    val src_dlr_amt=0.00
    val trgt_dlr_amt=0.00
    val vrnc_dlr_amt= src_dlr_amt - trgt_dlr_amt

    val variance = tarCount - sourceCnt
    
    val auditbaldata = spark.sql(f"""select '$audtBlncId' as AUDT_BLNCNG_ID,'$loadLogKey' as LOAD_LOG_KEY,'' as extrct_type_cd,'$srcType' as SRC_TYPE_CD,'$srcName' as src_nm,
                                                 '$tarTbl' as trgt_nm,'$cntrl_nm' as cntrl_nm,'$sourceCnt' as src_cnt,'$tarCount' as trgt_cnt,'$variance' as vrnc_cnt,'$src_dlr_amt' as src_dlr_amt,
                                                 '$trgt_dlr_amt' as trgt_dlr_amt,'$vrnc_dlr_amt' as vrnc_dlr_amt,'$currTimeStamp' as evnt_dtm""")

    //auditbaldata.write.mode("append").saveAsTable(f"""$audDb.$audBlncTbl""")
    
    auditbaldata.write.mode("append").insertInto(f"""$audDb.$audBlncTbl""")

    return variance
  }

  /*
   * 
   * Returns 
   * 
   */
  def error303Check(spark: SparkSession, inDf: DataFrame, colList: List[String]): List[DataFrame] = {
    import spark.implicits._
    var blankCheck = ""
    var selStmnt = ""
    inDf.createOrReplaceTempView("incoming_data")

    for (z <- colList) {
      blankCheck = f"""$blankCheck OR $z is null OR length(trim($z))=0"""
      selStmnt = f"""$selStmnt , case when $z is NULL or length(trim($z))=0 THEN "$z" END"""
    }
    //val blankCheckQuery = "select * ,array("+selStmnt.drop(3)+") as err_col_arr from incoming_data where " + (blankCheck.drop(3))

    val error303Rec = inDf.filter(blankCheck.drop(3)).withColumn("err_col_arr", expr("array(" + selStmnt.drop(3) + ")"))

    val audErrDf = error303Rec.select($"RCRD_HASH_PK_ID" as "ERR_ID", $"err_col_arr").withColumn("CLMN_NM", explode($"err_col_arr")).filter("""CLMN_NM is not null""").drop("err_col_arr").distinct

    val finalError303Df = error303Rec.drop("err_col_arr")
    val audErr303Df = audErrDf.withColumn("ERR_CD", lit("303"))

    List(finalError303Df, audErr303Df)
  }

  def error407Check(spark: SparkSession, inDf: DataFrame, colList: List[String]): List[DataFrame] = {
    import spark.implicits._
    var blankCheck = ""
    var selStmnt = ""
    inDf.createOrReplaceTempView("incoming_data")

    for (z <- colList) {
      blankCheck = blankCheck + " OR " + z + " like '% %'"
      selStmnt = selStmnt + " , case when " + z + " like '% %' THEN " + z + " END"
    }
    //val blankCheckQuery = "select * ,array("+selStmnt.drop(3)+") as err_col_arr from incoming_data where " + (blankCheck.drop(3))

    val error407Rec = inDf.filter(blankCheck.drop(3)).withColumn("err_col_arr", expr("array(" + selStmnt.drop(2) + ")"))

    val audErrDf = error407Rec.select($"RCRD_HASH_PK_ID" as "ERR_ID", $"err_col_arr").withColumn("CLMN_NM", explode($"err_col_arr")).filter("""CLMN_NM is not null""").drop("err_col_arr").distinct

    val finalError407Df = error407Rec.drop("err_col_arr")
    val audErr407Df = audErrDf.withColumn("ERR_CD", lit("407"))

    List(finalError407Df, audErr407Df)
  }

  /*
   * 
   * 
   * @Param : inDf -> Input Dataset
   * @Param : colLstChkDtls -> Input List of Map (col to check) -> [(Db Name of look up table),(Look Up Table Name)]
   * 
   * @return : List of DataFrames. 1st Df is the extract error Df and the second is the audit error Df
   */
  def error306Check(spark: SparkSession, inDf: DataFrame, colLstChkDtls: List[Map[String, (String, String)]]): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    var queryTxt = List[String]()
    for (z <- colLstChkDtls) {
      z.foreach(i => {

        val colNm = i._1.toString()
        val lookUpDb = i._2._1
        val lookUpTbl = i._2._2

        val itSql = f"""select distinct a.*,"$colNm" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on(trim(a.$colNm)=trim(b.$colNm)) where b.$colNm is null"""
        queryTxt = itSql :: queryTxt
      })

    }

    val finalQueryText = queryTxt.mkString(" Union All ")
    val Error306Df = spark.sql(finalQueryText)

    val audErr306Df = Error306Df.select($"RCRD_HASH_PK_ID" as "ERR_ID", $"CLMN_NM").withColumn("ERR_CD", lit("306")).distinct

    val finalError306Rec = Error306Df.drop("CLMN_NM").distinct
    List(finalError306Rec, audErr306Df)
  }

  def error306CheckColLevel(spark: SparkSession, inDf: DataFrame, colLstChkDtls: List[Map[String, (String, String, String)]], flag: Int): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    var queryTxt = List[String]()

    if (flag == 1) {

      for (z <- colLstChkDtls) {
        z.foreach(i => {

          val colNm = i._1.toString()
          val lookUpDb = i._2._1
          val lookUpTbl = i._2._2
          val lookUpColName = i._2._3

          val itSql = f"""select distinct a.*,"$colNm" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on(trim(a.$colNm)=trim(b.$lookUpColName)) where b.$lookUpColName is null"""
          queryTxt = itSql :: queryTxt
        })

      }

    } else if (flag == 2) {

      for (z <- colLstChkDtls) {
        z.foreach(i => {

          val colNm = i._1.toString().split(',')
          val col1 = colNm(0)
          val col2 = colNm(1)
          val lookUpDb = i._2._1
          val lookUpTbl = i._2._2
          val lookUpColNames = i._2._3.split(",")
          val lookUpColName1 = lookUpColNames(0)
          val lookUpColName2 = lookUpColNames(1)

          val itSql = f"""select distinct a.*,"$col2" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on (trim(a.$col1)=trim(b.$lookUpColName1)) and (trim(a.$col2)=trim(b.$lookUpColName2)) where b.$lookUpColName1 is null and b.$lookUpColName2 is null"""

          //val itSql = f"""select distinct a.*,"$colNm" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on(trim(a.$colNm)=trim(b.$colNm)) where b.$colNm is null"""
          queryTxt = itSql :: queryTxt
        })

      }

    } else if (flag == 3) {

      for (z <- colLstChkDtls) {
        z.foreach(i => {

          val colNm = i._1.toString().split(',')
          val col1 = colNm(0)
          val col2 = colNm(1)
          val col3 = colNm(2)
          val lookUpDb = i._2._1
          val lookUpTbl = i._2._2
          val lookUpColNames = i._2._3.split(",")
          val lookUpColName1 = lookUpColNames(0)
          val lookUpColName2 = lookUpColNames(1)
          val lookUpColName3 = lookUpColNames(2)

          val itSql = f"""select distinct a.*,"$col2" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on (trim(a.$col1)=trim(b.$lookUpColName1)) and (trim(a.$col2)=trim(b.$lookUpColName2)) and (trim(a.$col3)=trim(b.$lookUpColName3)) where b.$lookUpColName1 is null and b.$lookUpColName2 is null and b.$lookUpColName3 is null"""

          //val itSql = f"""select distinct a.*,"$colNm" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on(trim(a.$colNm)=trim(b.$colNm)) where b.$colNm is null"""
          queryTxt = itSql :: queryTxt
        })

      }

    } else if (flag == 4) {
      for (z <- colLstChkDtls) {
        z.foreach(i => {

          val colNm = i._1.toString().split(',')
          val col1 = colNm(0)
          val col2 = colNm(1)
          val col3 = colNm(2)
          val col4 = colNm(3)
          val lookUpDb = i._2._1
          val lookUpTbl = i._2._2
          val lookUpColName = i._2._3

          val itSql = f"""select distinct a.*,"$col2" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on (trim(a.$col1)=trim(b.$lookUpColName)) and (trim(a.$col2)=trim(b.$lookUpColName)) and (trim(a.$col3)=trim(b.$lookUpColName)) and (trim(a.$col4)=trim(b.$lookUpColName)) where b.$lookUpColName is null and b.$lookUpColName is null and b.$lookUpColName is null and b.$lookUpColName is null"""

          //val itSql = f"""select distinct a.*,"$colNm" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on(trim(a.$colNm)=trim(b.$colNm)) where b.$colNm is null"""
          queryTxt = itSql :: queryTxt
        })

      }

    } else if (flag == 5) {
      for (z <- colLstChkDtls) {
        z.foreach(i => {

          val colNm = i._1.toString().split(',')
          val col1 = colNm(0)
          val col2 = colNm(1)
          val col3 = colNm(2)
          val col4 = colNm(3)
          val col5 = colNm(4)
          val lookUpDb = i._2._1
          val lookUpTbl = i._2._2
          val lookUpColNames = i._2._3.split(",")
          val lookUpColName1 = lookUpColNames(0)
          val lookUpColName2 = lookUpColNames(1)
          val lookUpColName3 = lookUpColNames(2)
          val lookUpColName4 = lookUpColNames(3)
          val lookUpColName5 = lookUpColNames(4)

          val itSql = f"""select distinct a.*,"$col2" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on (trim(a.$col1)=trim(b.$lookUpColName1)) and (trim(a.$col2)=trim(b.$lookUpColName2)) and (trim(a.$col3)=trim(b.$lookUpColName3)) and (trim(a.$col4)=trim(b.$lookUpColName4)) and (trim(a.$col5)=trim(b.$lookUpColName5)) where b.$lookUpColName1 is null and b.$lookUpColName2 is null and b.$lookUpColName3 is null and b.$lookUpColName4 is null and b.$lookUpColName5 is null"""

          //val itSql = f"""select distinct a.*,"$colNm" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on(trim(a.$colNm)=trim(b.$colNm)) where b.$colNm is null"""
          queryTxt = itSql :: queryTxt
        })

      }

    }

    val finalQueryText = queryTxt.mkString(" Union All ")
    val Error306Df = spark.sql(finalQueryText)

    val audErr306Df = Error306Df.select($"RCRD_HASH_PK_ID" as "ERR_ID", $"CLMN_NM").withColumn("ERR_CD", lit("306")).distinct

    val finalError306Rec = Error306Df.drop("CLMN_NM").distinct

    List(finalError306Rec, audErr306Df)
  }

  /*
   * 
   * Member Demogrphic 409 for Member State Code
   */
  def error409MemDemoCheck(spark: SparkSession, inDf: DataFrame, colLstChkDtls: List[Map[String, (String,String,String)]]): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    var queryTxt = List[String]()

    //val audErr409Df = inDf
    //val finalError409Rec = inDf
    for (z <- colLstChkDtls) {
      z.foreach(i => {

        val colNm = i._1.toString()
        val lookUpDb = i._2._1
        val lookUpTbl = i._2._2
        val lookUpColName = i._2._3

        val itSql = f"""select distinct a.*,"$colNm" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on(trim(a.$colNm)=trim(b.$lookUpColName)) where b.$lookUpColName is null and a.$colNm LIKE '' """
        queryTxt = itSql :: queryTxt
      })

    }

    val finalQueryText = queryTxt.mkString(" Union All ")
    val Error409Df = spark.sql(finalQueryText)

    val audErr409Df = Error409Df.select($"RCRD_HASH_PK_ID" as "ERR_ID", $"CLMN_NM").withColumn("ERR_CD", lit("409")).distinct

    val finalError409Rec = Error409Df.drop("CLMN_NM").distinct

    List(finalError409Rec, audErr409Df)
  }

  /*
   *  USAGE: error409Check(spark, totalDataSet, err409ChkDtls,flagnumber())
   * 
   */
  def error409Check(spark: SparkSession, inDf: DataFrame, colLstChkDtls: List[Map[String, (String, String,String)]], flag: Int): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    var queryTxt = List[String]()

    //val audErr409Df = inDf
    //val finalError409Rec = inDf

    if (flag == 1) {

      for (z <- colLstChkDtls) {
        z.foreach(i => {

          val colNm = i._1.toString()
          val lookUpDb = i._2._1
          val lookUpTbl = i._2._2
          val lookUpColName = i._2._3
          

          val itSql = f"""select distinct a.*,"$colNm" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on(trim(a.$colNm)=trim(b.$lookUpColName)) where b.$lookUpColName is null"""
          queryTxt = itSql :: queryTxt
        })

      }
      
      //val finalQueryText = queryTxt.mkString(" Union All ")
      //val Error409Df = spark.sql(finalQueryText)

      //val audErr409Df = Error409Df.select($"RCRD_HASH_PK_ID" as "ERR_ID", $"CLMN_NM").withColumn("ERR_CD", lit("409")).distinct

      //val finalError409Rec = Error409Df.drop("CLMN_NM").distinct

    } else if (flag == 2) {

      for (z <- colLstChkDtls) {
        z.foreach(i => {

          val colNm = i._1.toString().split(',')
          val col1 = colNm(0)
          val col2 = colNm(1)
          val lookUpDb = i._2._1
          val lookUpTbl = i._2._2
          val lookUpColNames = i._2._3.split(',')
          val lookUColName1 = lookUpColNames(0)
          val lookUpColName2 = lookUpColNames(1)

          val itSql = f"""select distinct a.*,"$col2" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on (trim(a.$col1)=trim(b.$lookUColName1)) and (trim(a.$col2)=trim(b.$lookUpColName2)) where b.$lookUColName1 is null and b.$lookUpColName2 is null"""

          //val itSql = f"""select distinct a.*,"$colNm" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on(trim(a.$colNm)=trim(b.$colNm)) where b.$colNm is null"""
          queryTxt = itSql :: queryTxt
        })

      }

      //val finalQueryText = queryTxt.mkString(" Union All ")
      //val Error409Df = spark.sql(finalQueryText)
      //val audErr409Df = Error409Df.select($"RCRD_HASH_PK_ID" as "ERR_ID", $"CLMN_NM").withColumn("ERR_CD", lit("409")).distinct
      //val finalError409Rec = Error409Df.distinct

    } else if (flag == 3) {

      for (z <- colLstChkDtls) {
        z.foreach(i => {

          val colNm = i._1.toString().split(',')
          val col1 = colNm(0)
          val col2 = colNm(1)
          val col3 = colNm(2)
          val lookUpDb = i._2._1
          val lookUpTbl = i._2._2
          val lookUpColNames = i._2._3.split(',')
          val lookUpColName1 = lookUpColNames(0)
          val lookUpColName2 = lookUpColNames(1)
          val lookUpColName3 = lookUpColNames (2)
          
          val itSql = f"""select distinct a.* from incoming_data a left outer join $lookUpDb.$lookUpTbl b on (trim(a.$col1)=trim(b.$lookUpColName1)) and (trim(a.$col2)=trim(b.$lookUpColName2)) and (trim(a.$col3)=trim(b.$lookUpColName3)) where b.$lookUpColName1 is null and b.$lookUpColName2 is null and b.$lookUpColName3 is null"""

          //val itSql = f"""select distinct a.*,"$colNm" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on(trim(a.$colNm)=trim(b.$colNm)) where b.$colNm is null"""
          queryTxt = itSql :: queryTxt
        })
      }

      //val finalQueryText = queryTxt.mkString(" Union All ")
      //val Error409Df = spark.sql(finalQueryText)
      //val audErr409Df = Error409Df.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit("")).withColumn("ERR_CD", lit("409")).distinct
      //val finalError409Rec = Error409Df.distinct

    }

    val finalQueryText = queryTxt.mkString(" Union All ")
    val Error409Df = spark.sql(finalQueryText)
    val audErr409Df = Error409Df.select($"RCRD_HASH_PK_ID" as "ERR_ID", $"CLMN_NM").withColumn("ERR_CD", lit("409")).distinct
    val finalError409Rec = Error409Df.drop("CLMN_NM").distinct
    List(finalError409Rec, audErr409Df)
  }

  /*
   * 409 implementation 2
   * 
   * this is a row level check, which checks for the presence of combination of columns in parent table in specified ref table.
   * 
   * 
   */

  def error409Check_2(spark: SparkSession, inDf: DataFrame, colLstChkDtls: List[Map[String, (String, String)]]): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    var queryTxt = List[String]()

    for (z <- colLstChkDtls) {
      z.foreach(i => {

        val colNm = i._1.toString().split(',')
        val col1 = colNm(0)
        val col2 = colNm(1)
        val lookUpDb = i._2._1
        val lookUpTbl = i._2._2

        val itSql = f"""select distinct a.* from incoming_data a left outer join $lookUpDb.$lookUpTbl b on (trim(a.$col1)=trim(b.$col1)) and (trim(a.$col2)=trim(b.$col2)) where b.$col1 is null and b.$col2 is null"""

        //val itSql = f"""select distinct a.*,"$colNm" as CLMN_NM from incoming_data a left outer join $lookUpDb.$lookUpTbl b on(trim(a.$colNm)=trim(b.$colNm)) where b.$colNm is null"""
        queryTxt = itSql :: queryTxt
      })

    }

    val finalQueryText = queryTxt.mkString(" Union All ")
    val Error409Df = spark.sql(finalQueryText)
    val audErr409Df = Error409Df.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit("")).withColumn("ERR_CD", lit("409")).distinct
    val finalError409Rec = Error409Df.distinct
    List(finalError409Rec, audErr409Df)

  }

  def error801Check(spark: SparkSession, inDf: DataFrame, tColList: List[String], pColList: List[String], idColList: List[String]): List[DataFrame] = {
    import spark.implicits._
    var blankCheck = ""
    inDf.createOrReplaceTempView("incoming_data")
    var queryTxt = List[String]()
    for (x <- tColList) {

      blankCheck = f"""$blankCheck OR rlike($x,'\\[\\"\\]') """
    }

    val blackCheckQueryT = "select * from incoming_data where " + blankCheck.drop(3)

    queryTxt = blackCheckQueryT :: queryTxt
    blankCheck = ""
    for (y <- pColList) {
      blankCheck = blankCheck + " OR rlike(" + y + ",'\\[-!#%&+,./:\\;<=>@`{|}~\\\"()*_^?\\\\[\\\\]\\'\\$\\]')"

    }

    val blackCheckQueryP = "select * from incoming_data where " + blankCheck.drop(3)

    queryTxt = blackCheckQueryP :: queryTxt

    blankCheck = ""

    for (y <- idColList) {
      blankCheck = blankCheck + " OR rlike(" + y + ",'\\[-!#%&+,./:\\;<=>@`{|}~\\\"()*_^?\\\\[\\\\]\\'\\$\\]')"

    }

    val blackCheckQueryID = "select * from incoming_data where " + blankCheck.drop(3)

    queryTxt = blackCheckQueryID :: queryTxt

    val finalQueryText = queryTxt.mkString(" Union All ")
    val Error801Df = spark.sql(finalQueryText)

    val audErr801Df = Error801Df.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit("")).withColumn("ERR_CD", lit("801")).distinct

    val finalError801Rec = Error801Df.distinct
    List(finalError801Rec, audErr801Df)
  }

  /*
   * 
   * 
   * Error check 410 for National Account Indicator 
   * 
   */
  def errorCheck410(spark: SparkSession, inDf: DataFrame, targetColname: String, primaryColList: List[String], lookupString: String): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    val primaryColString = primaryColList.mkString(",")
    val indCheckDf = f"""select a.* from incoming_data a where $targetColname not in (" + lookupString + ")"""
    val indCheckDfFinal = spark.sql(indCheckDf)
    val audErr501Df = indCheckDfFinal.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(targetColname)).withColumn("ERR_CD", lit("410")).distinct
    List(indCheckDfFinal, audErr501Df)

  }
  
  def errorCheck310(spark : SparkSession, inDf : DataFrame, colToCheck: String) : List[DataFrame] = {  
    List()
    
  }

  
  /* 
  * Error check 307 for metal enrollment indicator --
  */
  
  def errorCheck307(spark: SparkSession, inDf: DataFrame, targetColList: List[String], primaryColList: List[String]): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    val primaryColString = primaryColList.mkString(",")
    val targetColName = targetColList(0)
    val whereCondition = {
      if (targetColList.size == 1)
        f"$targetColName not in ('Y','N') "
      else
        " ACCT_ID = 'INDIVIDUAL' AND CNTRCT_TYPE_CD != 'INDIVIDUAL' "
    }
    val indCheckDf = f"""select a.* from incoming_data a where $whereCondition"""
    val indCheckDfFinal = spark.sql(indCheckDf)
    val audErr501Df = indCheckDfFinal.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(targetColList.mkString(","))).withColumn("ERR_CD", lit("307")).distinct
    List(indCheckDfFinal, audErr501Df)

  }

  /*
  * 
  * Error check 423 for transitional_health_plan_indicator
  * 
  */
  def errorCheck423(spark: SparkSession, inDf: DataFrame, targetColname: String, primaryColList: List[String], lookupString: String): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    val primaryColString = primaryColList.mkString(",")
    val indCheckDf = f"""select a.* from incoming_data a where $targetColname not in (" + lookupString + ")"""
    val indCheckDfFinal = spark.sql(indCheckDf)
    val audErr423Df = indCheckDfFinal.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(targetColname)).withColumn("ERR_CD", lit("423")).distinct
    List(indCheckDfFinal, audErr423Df)
  }

  /*
   * 
   * Error Function 308 - Birthdate > 125 years  
   * 
   */
  def errorCheck308(spark: SparkSession, inDf: DataFrame, colNameDOB: String, NoOfYears: Int): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data") //YYYYMMDD
    val indCheckDf = f"""select a.* from incoming_data a 
     where from_unixtime(unix_timestamp($colNameDOB ,'yyyyMMdd'), 'yyyy-MM-dd') <  ADD_MONTHS(CURRENT_TIMESTAMP,-$NoOfYears*12)"""
    val indCheckDfFinal = spark.sql(indCheckDf)
    val audErr308Df = indCheckDfFinal.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colNameDOB)).withColumn("ERR_CD", lit("308")).distinct
    List(indCheckDfFinal, audErr308Df)
  }

  /*
   * 
   * 
   * Error Check 501 - for Duplicate Check
   * 
   * 
   */
  def duplicate501Check(spark: SparkSession, inDf: DataFrame, primaryColList: List[String]): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    val primaryColString = primaryColList.mkString(",")
    val dupDfStr = f"""select a.*,count(1)over(partition by $primaryColString) as cnt  from incoming_data a"""
    val dupDf = spark.sql(dupDfStr).filter("""cnt>1""").drop("cnt")
    val dupError501Df = dupDf
    val audErr501Df = dupError501Df.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit("")).withColumn("ERR_CD", lit("501")).distinct
    List(dupError501Df, audErr501Df)
  }

  def error309Check(spark: SparkSession, inDf: DataFrame, colToCheck: String): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    val datechk = colToCheck + "> current_date()"
    val datechkquery = f"""select * from incoming_data where """ + datechk
    val error309Rec = spark.sql(datechkquery)
    val audErr309Df = error309Rec.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colToCheck)).withColumn("ERR_CD", lit("309")).distinct
    List(error309Rec, audErr309Df)
  }
  
  //Error check 309
    def error309CheckValidDate(spark: SparkSession, inDf: DataFrame, colToCheck: String): List[DataFrame] = {
      
       import spark.implicits._
       
       inDf.createOrReplaceTempView("incoming_data")
       val datechk= colToCheck+ "> current_date() OR "+validateDf(colToCheck) +"= true"
       val datechkquery="select * from incoming_data where " + datechk
       val Error309Df = spark.sql(datechkquery)
       val audErr309Df = Error309Df.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colToCheck)).withColumn("ERR_CD", lit("309")).       distinct
       //val finalError309Rec = Error309Df.drop("CLMN_NM")
       
       List(Error309Df, audErr309Df)
       
    }
      def error309DateCompareCheck(spark: SparkSession, inDf: DataFrame, colToCheck: String,colToCompare: String): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    val datechk = colToCheck + "< " + colToCompare
    val datechkquery = f"""select * from incoming_data where """ + datechk
    val error309Rec = spark.sql(datechkquery)
    val audErr309Df = error309Rec.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colToCheck)).withColumn("ERR_CD", lit("309")).distinct
    List(error309Rec, audErr309Df)
  }
    /*
     * 
     * Check VAlid Date For Member DemoGraphic
     */
     def error308ValidDateMemDemo(spark: SparkSession, inDf: DataFrame, colToCheck: String): List[DataFrame] = {
      
       import spark.implicits._
       
       inDf.createOrReplaceTempView("incoming_data")
       val datechk= colToCheck+ "> current_date() OR "+validateDf(colToCheck) +"= true"
       val datechkquery="select * from incoming_data where " + datechk
       val Error308Df = spark.sql(datechkquery)
       val audErr308Df = Error308Df.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colToCheck)).withColumn("ERR_CD", lit("308")).distinct
       //val finalError309Rec = Error309Df.drop("CLMN_NM")       
       List(Error308Df, audErr308Df)
       
    }

  /*
  def error303Check(spark: SparkSession, inDf: DataFrame, colList: List[String]): List[DataFrame] = {

    var blankCheck = ""
    inDf.createOrReplaceTempView("incoming_data")

    for (z <- colList) {
      blankCheck = blankCheck + "OR " + z + " is null OR length(trim(" + z + "))=0 "
    }
    val blankCheckQuery = "select * from incoming_data where " + (blankCheck.drop(2))
    // log.info("blankCheckQuery:- " + blankCheckQuery)
    val error303Rec = spark.sql(blankCheckQuery)

    val extractDf = inDf.except(error303Rec)
    val finalError303Rec = error303Rec.withColumn("ERR_CD", lit("303"))

    List(extractDf, finalError303Rec)

  }

  def error306Check(spark: SparkSession, inDf: DataFrame, colToCheck: String, lookUpTbl: String, lookUpDb: String): List[DataFrame] = {
    inDf.createOrReplaceTempView("incoming_data")
    val queryTxt = f"""select distinct a.* from incoming_data a inner join $lookUpDb.$lookUpTbl b on(trim(a.$colToCheck)=trim(b.$colToCheck))"""
    val validRec = spark.sql(queryTxt)
    val finalError306Rec = (inDf.except(validRec)).withColumn("ERR_CD", lit("306"))

    List(validRec, finalError306Rec)
  }

  def duplicate501Check(spark: SparkSession, inDf: DataFrame, primaryColList: List[String]): List[DataFrame] = {
    inDf.createOrReplaceTempView("incoming_data")
    val primaryColString = primaryColList.mkString(",")
    val dupDfStr = f"""select a.*,count(1)over(partition by $primaryColString) as cnt  from incoming_data a"""
    val dupDf = spark.sql(dupDfStr).filter("""cnt>1""").drop("cnt")
    val validDf = inDf.except(dupDf)
    val dupError501Df = dupDf.withColumn("ERR_CD", lit("501"))
    List(validDf, dupError501Df)
  } */

  def show(inDf: DataFrame) {
    inDf.show(500, false)
  }

  def error307Check(spark: SparkSession, inDf: DataFrame, colList: List[String], lookupString: String): List[DataFrame] = {
    import spark.implicits._
    var lookupCheck = ""
    inDf.createOrReplaceTempView("incoming_data")

    for (z <- colList) {
      lookupCheck = lookupCheck + "OR " + z + " not in (" + lookupString + ") "
    }
    val lookupCheckQuery = "select * from incoming_data where " + (lookupCheck.drop(2))
    // log.info("blankCheckQuery:- " + blankCheckQuery)
    val error307Rec = spark.sql(lookupCheckQuery)

    //val extractDf = inDf.except(error307Rec)
    val finalError307Rec = error307Rec.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colList.mkString(","))).withColumn("ERR_CD", lit("307")).distinct

    List(error307Rec, finalError307Rec)

  }

  
  def error306MemberDemoCheck(spark: SparkSession, inDf: DataFrame, colList: List[String], lookupString: String): List[DataFrame] = {
    import spark.implicits._
    var lookupCheck = ""
    inDf.createOrReplaceTempView("incoming_data")

    for (z <- colList) {
      lookupCheck = lookupCheck + "OR " + z + " not in (" + lookupString + ") "
    }
    val lookupCheckQuery = "select * from incoming_data where " + (lookupCheck.drop(2))
    // log.info("blankCheckQuery:- " + blankCheckQuery)
    val error306Rec = spark.sql(lookupCheckQuery)

   // val extractDf = inDf.except(error306Rec)
    val finalError306Rec = error306Rec.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colList.mkString(","))).withColumn("ERR_CD", lit("306")).distinct

    List(error306Rec, finalError306Rec)

  }
  
  /*
   * 
   * Error Check 305 for Demographic Void Indicator
   */
  
  def error305MemberDemoCheck(spark: SparkSession, inDf: DataFrame, colList: List[String], lookupString: String): List[DataFrame] = {
    import spark.implicits._
    var lookupCheck = ""
    inDf.createOrReplaceTempView("incoming_data")

    for (z <- colList) {
      lookupCheck = lookupCheck + "OR " + z + " not in (" + lookupString + ") "
    }
    val lookupCheckQuery = "select * from incoming_data where " + (lookupCheck.drop(2))
    // log.info("blankCheckQuery:- " + blankCheckQuery)
    val error305Rec = spark.sql(lookupCheckQuery)

    //val extractDf = inDf.except(error305Rec)
    val finalError305Rec = error305Rec.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colList.mkString(","))).withColumn("ERR_CD", lit("305")).distinct

    List(error305Rec, finalError305Rec)

  }
  
  
    /*
   * 
   * Error Check 305 for CategoryOfService -POS-CDE
   */
  
  def error305CategoryOfService(spark: SparkSession, inDf: DataFrame, CTGRY_OF_SRVC_CD: String): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")

    var cosDf= inDf
  //  val list = List("IP PROF", "OP PROF", "IP OTH-ER", "OP OTH-ER", "PHARM")
  //  val fnlCosDf = cosDf.withColumn("CTGRY_OF_SRVC_CD", trim(upper($"CTGRY_OF_SRVC_CD"))).filter((!$"CTGRY_OF_SRVC_CD") isin (list: _*))
    val fnlCosDf = cosDf.filter(col("CTGRY_OF_SRVC_CD").notEqual("IP PROF") || col("CTGRY_OF_SRVC_CD").notEqual("OP PROF") || col("CTGRY_OF_SRVC_CD").notEqual("IP OTHER") || col("CTGRY_OF_SRVC_CD").notEqual("OP OTHER") || col("CTGRY_OF_SRVC_CD").notEqual("VOID"))

    //val extractDf = inDf.except(error305Rec)
    val finalError305Rec = fnlCosDf.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(CTGRY_OF_SRVC_CD)).withColumn("ERR_CD", lit("305")).distinct

    List(fnlCosDf, finalError305Rec)

  }
  
  
  def fixedwidthoutput(spark: SparkSession, wh_db: String, src_db: String, extract_name: String, tbl_name: String, flat_file_location: String, audDqChkTblNm: String) = {
    import spark.implicits._
    val flat_file_name = flat_file_location.toLowerCase + "/" + extract_name.toLowerCase + "_fw"
    val srcTblDf=spark.table(f"""$src_db.$tbl_name""")
    val clnTblDf=cleanSpclChars(spark,srcTblDf)
    clnTblDf.createOrReplaceTempView("cleaned_src_tbl")
    // Creating case statements for formatting data.
    val convert_query = spark.sql("""select case when FLD_DATA_TYPE='DATE' then concat("date_format(", FLD_NM,",'yyyyMMdd')" , FLD_NM) when FLD_DATA_TYPE='CHAR' then concat("case when ", FLD_NM," is null then REPEAT(' ','",FLD_LGTH,"') else rpad(upper(regexp_replace(",FLD_NM,",'\\\"','')),",FLD_LGTH,",' ') end as ", FLD_NM) when FLD_DATA_TYPE='NUMERIC' then concat("Case when ",FLD_NM," is null then case when  INSTR('",FLD_LGTH,"','S')=0 then REPEAT(0,'",FLD_LGTH,"') else CONCAT('+',REPEAT(0,SUBSTR('",FLD_LGTH,"',INSTR('",FLD_LGTH,"','(')+1,INSTR('",FLD_LGTH,"',')')-INSTR('",FLD_LGTH,"','(')-1)-1)) end else case when  INSTR('",FLD_LGTH,"','S')=0 then lpad(regexp_replace(",FLD_NM,",'[.,]',''),'",FLD_LGTH,"','0')  else CONCAT('+',lpad(regexp_replace(",FLD_NM,",'[.,]',''),SUBSTR('",FLD_LGTH,"',INSTR('",FLD_LGTH,"','(')+1,INSTR('",FLD_LGTH,"',')')-INSTR('",FLD_LGTH,"','(')-1)-1,0)) end  end as ", FLD_NM) end    as query,FLD_ORDR as col_num from """ + wh_db + "." + audDqChkTblNm + " where lower(PRCS_NM)=" + "'" + extract_name.toLowerCase() + "'").createOrReplaceTempView("convert_query")
  // log.info(f"convert_query:- $convert_query")
       // Collecting all case statements in a single row.
    var collect_query = "select " + spark.sql("select collect_list(query) from convert_query ").first.getAs[List[String]](0).mkString(",") + " from  cleaned_src_tbl"
   // log.info(f"collect_query:- $collect_query")
       spark.sql(collect_query).createOrReplaceTempView("collect_query")
    //logic for fetching ordered output.
    val column_list = spark.sql("""select FLD_NM from """ + wh_db + "." + audDqChkTblNm + " where lower(PRCS_NM)=" + "'" + extract_name.toLowerCase() + "' order by cast(FLD_ORDR as int)").collect
    var final_query = "select "
    column_list.foreach(x => final_query = final_query + x.mkString("") + ",")
    final_query = final_query.substring(0, final_query.length - 1) + " from collect_query"
    //saving file in hdfs location 
  // log.info(f"final_query:- $final_query")
   spark.sql(final_query).repartition(1).map(x => x.mkString("")).toJavaRDD.saveAsTextFile(flat_file_name)   //saveAsTextFile(flat_file_name)
  }
  
  /*
   * 
   * Remove special charachters from all columns of a dataframe
   */
   def cleanSpclChars(spark: SparkSession,inDf:DataFrame): DataFrame ={
    import spark.implicits._
    var tmpDf=inDf
    for(col <- inDf.columns){ 
      tmpDf=tmpDf.withColumn(col,expr(f"TRIM(REGEXP_REPLACE($col, '\\\\P{ASCII}', ''))"))
      
    }
    tmpDf
   }

  /*
   * Error check 411
   */

  def error411Check(spark: SparkSession, inDf: DataFrame, endDate: String, beginDate: String, colNameToPopulate: String): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    val datechk = f"$endDate < $beginDate"
    val datechkquery = "select * from incoming_data where " + datechk
    val error411Rec = spark.sql(datechkquery)
    val audErr411Df = error411Rec.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colNameToPopulate)).withColumn("ERR_CD", lit("411")).distinct

    List(error411Rec, audErr411Df)
  }  
  /*
   * Error check 308 for MemberDemographic
   */

  def error315MemDemoGraphicCheck(spark: SparkSession, inDf: DataFrame, endDate: String, beginDate: String, colNameToPopulate: String): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    val datechk = f"$endDate < $beginDate"
    val datechkquery = "select * from incoming_data where " + datechk
    val error315Rec = spark.sql(datechkquery)
    val audErr315Df = error315Rec.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colNameToPopulate)).withColumn("ERR_CD", lit("315")).distinct

    List(error315Rec, audErr315Df)
  }  
  //Error check A201 SRC_GRP_NBR
    def errorA201Check(spark: SparkSession, inDf: DataFrame, colList: List[String] ): List[DataFrame] = {
      
       import spark.implicits._
      
       inDf.createOrReplaceTempView("incoming_data")
       var lenchk = ""

       for (z <- colList) {
           lenchk = lenchk + " OR length(trim(" + z + ")) > 14 "
       }
       val lenchkquery="select * from incoming_data where " + lenchk.drop(3)
       val Error201Df = spark.sql(lenchkquery)
      // val audErr201Df = Error201Df.select($"RCRD_HASH_PK_ID" as "ERR_ID", $"CLMN_NM").withColumn("ERR_CD", lit("A201"))
       val audErr201Df = Error201Df.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colList.mkString(","))).withColumn("ERR_CD", lit("A201")).distinct
       val finalError201Rec = Error201Df.drop("CLMN_NM")
       
       List(finalError201Rec, audErr201Df)
       
    }
  def error305AlphabetCheck(spark: SparkSession, inDf: DataFrame, colList: List[String]): List[DataFrame] = {
    import spark.implicits._
    val colLists = colList.mkString
    //val alphaCheckDF = inDf.filter(!inDf(colLists).substr(0,3).like("^[a-zA-Z]*$"))
    var alphaCheckDF = inDf
    
    colList.foreach(column => {
      alphaCheckDF = alphaCheckDF.where(f"trim(substr($column,0,3)) !='999' and trim(substr($column,0,3))  rlike '[^a-zA-Z]' ")

    })

    val audErr305Df = alphaCheckDF.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colList.mkString(","))).withColumn("ERR_CD", lit("305")).distinct
    val finalError305Rec = alphaCheckDF.drop("CLMN_NM")
    List(finalError305Rec, audErr305Df)
  }
  
  /*
   * 
   * Error code 310 for PhoneNumeber Check
   */
  
  def error310PhoneNumberCheck(spark: SparkSession, inDf: DataFrame, colNM: String): List[DataFrame] = {
    import spark.implicits._
    var phNumberCheckDf= inDf
    val pattern = ""
     phNumberCheckDf = phNumberCheckDf.where(f"length(trim($colNM)) <> 10 and trim($colNM) rlike '[^0-9]'")
   

    val audErr310Df = phNumberCheckDf.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colNM)).withColumn("ERR_CD", lit("310")).distinct
    val finalError310Rec = phNumberCheckDf.drop("CLMN_NM")
    List(finalError310Rec, audErr310Df)
  }

  /*
   * 
   * Error Check 310 for ZipCodePlus 4
   */
  
  def error310ZipCodePlus4Check(spark: SparkSession, inDf: DataFrame, colList: List[String]): List[DataFrame] = {
    import spark.implicits._
    val colLists = colList.mkString
    //val alphaCheckDF = inDf.filter(!inDf(colLists).substr(0,3).like("^[a-zA-Z]*$"))
    var alphaCheckDF = inDf
    
    colList.foreach(column => {
      alphaCheckDF = alphaCheckDF.where(f"($column) rlike '[^0-9]'")

    })

    val audErr310Df = alphaCheckDF.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colList.mkString(","))).withColumn("ERR_CD", lit("310")).distinct
    val finalError305Rec = alphaCheckDF.drop("CLMN_NM")
    List(finalError305Rec, audErr310Df)
  }
   
 def OverlapA301Check(spark: SparkSession, inDf: DataFrame, segCol: String, begDtCol: String,endDtCol:String): List[DataFrame] = {
                import spark.implicits._    
                inDf.createOrReplaceTempView("incoming_data")
                val selStmnt= f"""select *, case when DATEDIFF(""" +begDtCol+""", LAG(""" +endDtCol+""",1) OVER (PARTITION BY """ +segCol+""" ORDER BY """ +begDtCol+""")) <=0 then "Y" else "N" end as errind from incoming_data"""
                spark.sql(selStmnt).createOrReplaceTempView("overlapRecords")     
                val validRecords=spark.sql("select * from overlapRecords where errind ='N'")
                val errA301Rec1= spark.sql("select * from overlapRecords where errind ='Y'")
                val errA301Rec= errA301Rec1.drop($"errind")
                val audErr309Df = errA301Rec.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(begDtCol)).withColumn("ERR_CD", lit("A301")).distinct
        val finalError310Rec = errA301Rec.drop("CLMN_NM")      
                List(errA301Rec,audErr309Df)
}  
   /*
   * 
   * Error code 312 for Number range check
   */
  
  def error312Check(spark: SparkSession, inDf: DataFrame, colLstChkDtls: List[Map[String, (String, Integer)]]): List[DataFrame] = {
    import spark.implicits._
    inDf.createOrReplaceTempView("incoming_data")
    var queryTxt = List[String]()

    for (z <- colLstChkDtls) {
      z.foreach(i => {

        val colNm = i._1
        val comparisionType = i._2._1 // <= or >=
        val comparisionVal = i._2._2

        val itSql = f"""select distinct a.* from incoming_data a where trim(a.$colNm) $comparisionType $comparisionVal """
        queryTxt = itSql :: queryTxt
      })

    }

    val finalQueryText = queryTxt.mkString(" Union All ")
    val Error312Df = spark.sql(finalQueryText)
    val audErr312Df = Error312Df.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit("")).withColumn("ERR_CD", lit("312")).distinct
    val finalError312Rec = Error312Df.distinct
    List(finalError312Rec, audErr312Df)

  }  
    /*
   * 
   * Error code 311 for Decimal Check
   */ 
  def error311Check(spark: SparkSession, inDf: DataFrame, colList: List[String]): List[DataFrame] = {
    import spark.implicits._
    val colLists = colList.mkString
    var decimalCheckDf= inDf

   colList.foreach(column => {
   // decimalCheckDf = decimalCheckDf.where(f"(((abs($column)*100) - CONVERT(INT,(abs($column)*100))) <> 0)")
    decimalCheckDf = decimalCheckDf.where(f"(((abs($column)*100) - CAST((abs($column)*100) as INT)) <> 0)")
   })

    val audErr311Df = decimalCheckDf.select($"RCRD_HASH_PK_ID" as "ERR_ID").withColumn("CLMN_NM", lit(colList.mkString(","))).withColumn("ERR_CD", lit("311")).distinct
    val finalError311Rec = decimalCheckDf.drop("CLMN_NM")
    List(finalError311Rec, audErr311Df)
  }

 def overlapIteration(spark: SparkSession, inDf: DataFrame ,itrreq: Int, itrdone: Int): DataFrame = {
    import spark.implicits._
if (itrreq==itrdone){inDf}
else {
    
var itrcurrent=itrdone+1
    inDf.createOrReplaceTempView("inDf")
val overlapdataset1=  spark.sql(""" select distinct BHI_HOME_PLAN_ID,home_plan_prod_id,mbr_id,cnsstnt_mbr_id,src_sys_cd,mbr_brth_dt,mbr_curnt_prmry_zip_cd,mbr_curnt_cntry_cd,mbr_curnt_cnty_cd,mbr_gndr_cd,mbr_cnfdntlty_cd,acct_id,grp_id,subgrp_id,cvrg_bgn_dt,cvrg_end_dt,mbr_rltnshp_cd,sbscrbr_home_plan_prod_id,sbscrbr_id,enrlmnt_elgblty_stts_cd,mbr_mdcl_cob_cd, mbr_phrmcy_cob_cd,ddctbl_ctgry_cd,mh_cd_enrlmnt_bnft_cd,phrmcy_bnft_ind,mh_cd_bnft_ind,mdcl_bnft_ind,hosp_bnft_ind,fclty_bnfts_bhi_ntwk_ctgry_cd,prfsnl_bnfts_bhi_ntwk_ctgry_cd,fclty_bnfts_plan_ntwk_ctgry_cd,prfsnl_bnfts_plan_ntwk_ctgry_cd,phrmcy_crv_out_sbmsn_ind,phrmcy_bnft_tiers_nbr_txt,bnft_pkg_id,gov_sbsdy_ind,csr_type_cd,qhp_id,nlo_acct_type_cd,nlo_plan_type_cd,case when datediff(CVRG_END_DT, LEAD(CVRG_BGN_DT, 1) OVER (PARTITION BY BHI_HOME_PLAN_ID, MBR_ID ORDER BY CVRG_END_DT,CVRG_BGN_DT,home_plan_prod_id,src_sys_cd,mbr_brth_dt,mbr_curnt_prmry_zip_cd,mbr_curnt_cntry_cd,mbr_curnt_cnty_cd,mbr_gndr_cd,mbr_cnfdntlty_cd,acct_id,grp_id,subgrp_id,mbr_rltnshp_cd,sbscrbr_home_plan_prod_id,sbscrbr_id,enrlmnt_elgblty_stts_cd,mbr_mdcl_cob_cd, mbr_phrmcy_cob_cd,ddctbl_ctgry_cd,mh_cd_enrlmnt_bnft_cd,phrmcy_bnft_ind,mh_cd_bnft_ind,mdcl_bnft_ind,hosp_bnft_ind,fclty_bnfts_bhi_ntwk_ctgry_cd,prfsnl_bnfts_bhi_ntwk_ctgry_cd,fclty_bnfts_plan_ntwk_ctgry_cd,prfsnl_bnfts_plan_ntwk_ctgry_cd,phrmcy_crv_out_sbmsn_ind,phrmcy_bnft_tiers_nbr_txt,bnft_pkg_id,gov_sbsdy_ind,csr_type_cd,qhp_id,nlo_acct_type_cd,nlo_plan_type_cd )) >=0 then date_sub(LEAD(CVRG_BGN_DT, 1) OVER (PARTITION BY BHI_HOME_PLAN_ID, MBR_ID ORDER BY CVRG_END_DT ,CVRG_BGN_DT,home_plan_prod_id,src_sys_cd,mbr_brth_dt,mbr_curnt_prmry_zip_cd,mbr_curnt_cntry_cd,mbr_curnt_cnty_cd,mbr_gndr_cd,mbr_cnfdntlty_cd,acct_id,grp_id,subgrp_id,mbr_rltnshp_cd,sbscrbr_home_plan_prod_id,sbscrbr_id,enrlmnt_elgblty_stts_cd,mbr_mdcl_cob_cd, mbr_phrmcy_cob_cd,ddctbl_ctgry_cd,mh_cd_enrlmnt_bnft_cd,phrmcy_bnft_ind,mh_cd_bnft_ind,mdcl_bnft_ind,hosp_bnft_ind,fclty_bnfts_bhi_ntwk_ctgry_cd,prfsnl_bnfts_bhi_ntwk_ctgry_cd,fclty_bnfts_plan_ntwk_ctgry_cd,prfsnl_bnfts_plan_ntwk_ctgry_cd,phrmcy_crv_out_sbmsn_ind,phrmcy_bnft_tiers_nbr_txt,bnft_pkg_id,gov_sbsdy_ind,csr_type_cd,qhp_id,nlo_acct_type_cd,nlo_plan_type_cd ),1) else CVRG_END_DT end as CVRG_END_DT_overlap  from inDf""")

overlapdataset1.createOrReplaceTempView("overlapdataset1")

val initDataset = spark.sql(""" select distinct BHI_HOME_PLAN_ID,home_plan_prod_id,mbr_id,cnsstnt_mbr_id,src_sys_cd,mbr_brth_dt,mbr_curnt_prmry_zip_cd,mbr_curnt_cntry_cd,mbr_curnt_cnty_cd,mbr_gndr_cd,mbr_cnfdntlty_cd,acct_id,grp_id,subgrp_id,cvrg_bgn_dt,CVRG_END_DT_overlap as cvrg_end_dt,mbr_rltnshp_cd,sbscrbr_home_plan_prod_id,sbscrbr_id,enrlmnt_elgblty_stts_cd,mbr_mdcl_cob_cd,mbr_phrmcy_cob_cd,ddctbl_ctgry_cd,mh_cd_enrlmnt_bnft_cd,phrmcy_bnft_ind,mh_cd_bnft_ind,mdcl_bnft_ind,hosp_bnft_ind,fclty_bnfts_bhi_ntwk_ctgry_cd,prfsnl_bnfts_bhi_ntwk_ctgry_cd,fclty_bnfts_plan_ntwk_ctgry_cd,prfsnl_bnfts_plan_ntwk_ctgry_cd,phrmcy_crv_out_sbmsn_ind,phrmcy_bnft_tiers_nbr_txt,bnft_pkg_id,gov_sbsdy_ind,csr_type_cd,qhp_id,nlo_acct_type_cd,nlo_plan_type_cd from overlapdataset1 where datediff(CVRG_END_DT_overlap,CVRG_BGN_DT)>0""")
overlapIteration(spark,initDataset ,itrreq,itrcurrent)

}
}


 def overlapIterationmemdemo(spark: SparkSession, inDf: DataFrame ,itrreq: Int, itrdone: Int): DataFrame = {
    import spark.implicits._
if (itrreq==itrdone){inDf}
else {
    
var itrcurrent=itrdone+1
    inDf.createOrReplaceTempView("inDf")
val overlapdataset1=  spark.sql(""" select distinct bhi_home_plan_id,cnsstnt_mbr_id,mbr_prfx_txt,mbr_last_nm,mbr_frst_nm,mbr_mid_init_nm,mbr_sfx_txt,mbr_prmry_str_adrs_1_txt,mbr_prmry_str_adrs_2_txt,mbr_prmry_city_nm,mbr_prmry_st_cd,mbr_prmry_zip_cd,mbr_prmry_zip_plus4_cd,mbr_prmry_phone_nbr,mbr_prmry_email_adrs_txt,mbr_scndry_str_adrs_1_txt,mbr_scndry_str_adrs_2_txt,mbr_scndry_city_nm,mbr_scndry_st_cd,mbr_scndry_zip_cd,mbr_scndry_zip_plus4_cd,host_plan_ovrd_cd,mbr_parn_cd,its_sbscrbr_id,mmi_id,host_plan_cd,dmgrphc_void_ind,dmgrphc_mbr_cnfdntlty_cd,efctv_dt,exprtn_dt,ooa_mbr_cd,case when datediff(exprtn_dt, LEAD(efctv_dt, 1) OVER (PARTITION BY BHI_HOME_PLAN_ID, cnsstnt_mbr_id,dmgrphc_void_ind ORDER BY exprtn_dt,efctv_dt,mbr_prfx_txt,mbr_last_nm,mbr_frst_nm,mbr_mid_init_nm,mbr_sfx_txt,mbr_prmry_str_adrs_1_txt,mbr_prmry_str_adrs_2_txt,mbr_prmry_city_nm,mbr_prmry_st_cd,mbr_prmry_zip_cd,mbr_prmry_zip_plus4_cd,mbr_prmry_phone_nbr,mbr_prmry_email_adrs_txt,mbr_scndry_str_adrs_1_txt,mbr_scndry_str_adrs_2_txt,mbr_scndry_city_nm,mbr_scndry_st_cd,mbr_scndry_zip_cd,mbr_scndry_zip_plus4_cd,host_plan_ovrd_cd,mbr_parn_cd,its_sbscrbr_id,mmi_id,host_plan_cd,dmgrphc_mbr_cnfdntlty_cd,ooa_mbr_cd )) >=0 then date_sub(LEAD(efctv_dt, 1) OVER (PARTITION BY BHI_HOME_PLAN_ID, cnsstnt_mbr_id,dmgrphc_void_ind ORDER BY exprtn_dt,efctv_dt,mbr_prfx_txt,mbr_last_nm,mbr_frst_nm,mbr_mid_init_nm,mbr_sfx_txt,mbr_prmry_str_adrs_1_txt,mbr_prmry_str_adrs_2_txt,mbr_prmry_city_nm,mbr_prmry_st_cd,mbr_prmry_zip_cd,mbr_prmry_zip_plus4_cd,mbr_prmry_phone_nbr,mbr_prmry_email_adrs_txt,mbr_scndry_str_adrs_1_txt,mbr_scndry_str_adrs_2_txt,mbr_scndry_city_nm,mbr_scndry_st_cd,mbr_scndry_zip_cd,mbr_scndry_zip_plus4_cd,host_plan_ovrd_cd,mbr_parn_cd,its_sbscrbr_id,mmi_id,host_plan_cd,dmgrphc_mbr_cnfdntlty_cd,ooa_mbr_cd ),1) else exprtn_dt end as CVRG_END_DT_overlap  from inDf""")

overlapdataset1.createOrReplaceTempView("overlapdataset1")

val initDataset = spark.sql(""" select distinct bhi_home_plan_id,cnsstnt_mbr_id,mbr_prfx_txt,mbr_last_nm,mbr_frst_nm,mbr_mid_init_nm,mbr_sfx_txt,mbr_prmry_str_adrs_1_txt,mbr_prmry_str_adrs_2_txt,mbr_prmry_city_nm,mbr_prmry_st_cd,mbr_prmry_zip_cd,mbr_prmry_zip_plus4_cd,mbr_prmry_phone_nbr,mbr_prmry_email_adrs_txt,mbr_scndry_str_adrs_1_txt,mbr_scndry_str_adrs_2_txt,mbr_scndry_city_nm,mbr_scndry_st_cd,mbr_scndry_zip_cd,mbr_scndry_zip_plus4_cd,host_plan_ovrd_cd,mbr_parn_cd,its_sbscrbr_id,mmi_id,host_plan_cd,dmgrphc_void_ind,dmgrphc_mbr_cnfdntlty_cd,efctv_dt,CVRG_END_DT_overlap as exprtn_dt,ooa_mbr_cd from overlapdataset1 where datediff(CVRG_END_DT_overlap,efctv_dt)>0""")
overlapIterationmemdemo(spark,initDataset ,itrreq,itrcurrent)

}
}





}
  
  

