package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Error_Traceability_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Error_Traceability_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_Error_Traceability_TGT(dbname : String, env: String) extends FunSuite  { //with RDDComparisons with SharedSparkContext

     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())

     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Error"
      val prcss = "Traceability"
  
  test("Traceability Error-Check Error code when bhi_home_plan_id column has spaces - 001") {

      val id = Array("001")
       val name = Array("Test case : Check Error code when bhi_home_plan_id column has spaces")
     
    val result = sqlContext.sql("""select DISTINCT a.err_cd,b.err_id,b.bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, "")," ", "")))=0""")
    
     result.createOrReplaceTempView("resultdf")
     val validCode = sqlContext.sql("""select distinct err_cd from resultdf  where err_cd == '303' """)
     val invalidCode = sqlContext.sql("""select * from resultdf where err_cd != '303' """)
   
       
    if (validCode.count == 0 || (validCode.collectAsList.toString.contains("303") && validCode.count() == 1 && invalidCode.count() == 0)) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select DISTINCT a.err_cd,b.err_id,b.bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0 and a.err_cd == '303'")
      val data = Array("'ErrorCode' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==1)
    } else {
      val a = invalidCode.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select * from (select DISTINCT a.err_cd,b.err_id,b.bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0) where err_cd != '303' ")
      val data = Array("'ErrorCode','Error_Id','BHI_Home_Plan_Id'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
    
  }
  
   //=============================================================

  test("Traceability Error-Check Error code when sor_cd column has spaces - 002") {

    val id = Array("002")
    val name = Array("Test case : Check Error code when sor_cd column has spaces")
    
    val result = sqlContext.sql("""select DISTINCT a.err_cd,b.err_id,b.sor_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.sor_cd, "")," ", "")))=0""")

     result.createOrReplaceTempView("resultdf")
     val validCode = sqlContext.sql("""select distinct err_cd from resultdf  where err_cd == '303' """)
     val invalidCode = sqlContext.sql("""select * from resultdf where err_cd != '303' """)
   
    if (validCode.count == 0 || (validCode.collectAsList.toString.contains("303") && validCode.count() == 1 && invalidCode.count() == 0)) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select DISTINCT a.err_cd,b.err_id,b.sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sor_cd, ''),' ', '')))=0 and a.err_cd =='303'")
      val data = Array(" 'ErrorCode': No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==1)
    } else {
      val a = invalidCode.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select DISTINCT a.err_cd,b.err_id,b.sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sor_cd, ''),' ', '')))=0) where err_cd != '303'  ")
      val data = Array("'ErrorCode','Error_Id','Sor_Cd'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }

  }

  //=============================================================

  test("Traceability Error-Check bhi_home_plan_id column values not located in reference table - 003") {

    val id = Array("003")
    val name = Array("Test case : Check bhi_home_plan_id column values not located in reference table")
    
    val result = sqlContext.sql("""select distinct a.bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_trcblty_rfrnc_err' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306' """)

    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') """)
   
     val r = result.except(result1)
     
    if (r.count > 0) {
      val a = r.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct a.bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='bcbsa_trcblty_rfrnc_err' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306' and a.bhi_home_plan_id not in (select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') )")
      val data = Array("'bhi_home_plan_id'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct a.bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='bcbsa_trcblty_rfrnc_err' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306' and a.bhi_home_plan_id not in (select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') )")
      val data = Array("bhi_home_plan_id : No Invalid Record Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==1)
    }

  }

  //=============================================================

  test("Traceability Error-Check Error code when Traceability Description column sor_desc has Special characters - 004") {

    val id = Array("004")
    val name = Array("Test case : Check Error code when Traceability Description column sor_desc has Special characters")
    

    val result = sqlContext.sql("""select DISTINCT a.err_cd,b.err_id,b.sor_desc from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
"""+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
where length(trim(regexp_replace(coalesce(b.sor_desc, "")," ", "")))=0 or sor_desc like '%"%' or 
sor_desc like '%-%'  or  sor_desc like '%!%'  or  sor_desc like '%#%'
or  sor_desc like '%\%%'  or  sor_desc like '%&%'  or  sor_desc like '%+%'
or  sor_desc like '%,%'  or  sor_desc like '%.%'  or  sor_desc like '%/%'
or  sor_desc like '%:%'  or  sor_desc like '%;%'  or sor_desc like '%<%'
or  sor_desc like '%=%'  or  sor_desc like '%>%'  or  sor_desc like '%@%'
or  sor_desc like '%`%'  or  sor_desc like '%{%'  or  sor_desc like '%|%'
or  sor_desc like '%}%'  or  sor_desc like '%~%'  or  sor_desc like '%"%'
or  sor_desc like '%(%'  or sor_desc like '%)%'  or  sor_desc like '%*%'
or  sor_desc like '%\\%'  or  sor_desc like '%\_%'  or  sor_desc like '%\^%'
or  sor_desc like '%\?%'  or  sor_desc like '%\[%'  or  sor_desc like '%\]%'
or  sor_desc like '%\'%'""")


     result.createOrReplaceTempView("resultdf")
     val validCode = sqlContext.sql("""select distinct err_cd from resultdf  where err_cd == '801' """)
     val invalidCode = sqlContext.sql("""select * from resultdf where err_cd != '801' """)
   
    if ((validCode.count == 0 && invalidCode.count == 0)|| (validCode.collectAsList.toString.contains("801") && validCode.count() == 1 && invalidCode.count() == 0)) {
      val a = validCode.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct err_cd from (select DISTINCT a.err_cd,b.err_id,b.sor_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sor_desc, ''),' ', '')))=0 or sor_desc like '%[^A-z0-9]%') where err_cd == '801'")
      val data = Array("'ErrorCode' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==1)
    } else {
      val a = invalidCode.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select DISTINCT a.err_cd,b.err_id,b.sor_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sor_desc, ''),' ', '')))=0 or sor_desc like '%[^A-z0-9]%') where err_cd != '801' ")
      val data = Array("'ErrorCode','err_id','sor_desc'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
}
