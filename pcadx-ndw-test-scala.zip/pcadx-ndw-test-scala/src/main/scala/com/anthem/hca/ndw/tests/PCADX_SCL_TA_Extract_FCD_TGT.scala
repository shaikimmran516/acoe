package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Extract_FCD_TGT {
 
  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_FCD_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}


 class PCADX_SCL_TA_Extract_FCD_TGT(dbname : String, env: String) extends FunSuite  {

     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
     
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Extract"
      val prcss = "FacilityClaimDetail"
   
test("ClaimFacilityDetailExtract -Validated NULL or blank spaces checks for all Columns - 001") {
    
    val id = Array("001")
    val name = Array("Test case : Validated NULL or blank spaces checks for all Columns")
    
          
    val col_name = Array("bhi_home_plan_id",
	"clm_id",
	"clm_line_nbr",
	"trcblty_fld_cd",
	"adjstmnt_sqnc_nbr",
	"bnft_paymnt_stts_cd",
	"clm_paymnt_stts_cd",
	"prmry_non_cvrd_rsn_cd",
	"non_cvrd_rsn_cd_2",
	"non_cvrd_rsn_cd_3",
	"non_cvrd_rsn_cd_4",
	"reimbmnt_type_cd",
	"rvnu_cd",
	"totl_units_nbr",
	"srvc_post_dt",
	"srvc_from_dt",
	"sbmtd_amt",
	"non_cvrd_amt",
	"alwd_amt",
	"paymnt_amt",
	"cob_tpl_amt",
	"coinsrn_amt",
	"cpay_amt",
	"ddctbl_amt")

    val i = 0;

    for( i <- 0 to 10){
    val k = col_name(i)
	  val result = sqlContext.sql(f"""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, $k from """+dbname+f"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where length(trim(regexp_replace(coalesce($k, "")," ", "")))=0 """)
     
	if (result.count > 0) {
	   println(f" $k -- Failed")
      val a = result.limit(10).rdd
      /*val status = Array("FAILED")
      val header = sc.parallelize(Array(f"'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','$k'"), 1)
      header.union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_k_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      */
    } else {
      println(f" $k -- Success")
    }
     
    }
 }
    
  //===========================================

test("ClaimFacilityDetailExtract -Validated Special Character checks for key Columns - 002") {
    val id = Array("002")
    val name = Array("Test case : Validated Special Character checks for key Column")
    

    
    val col_name = Array("bhi_home_plan_id",
    "clm_id",
    "clm_line_nbr",
    "trcblty_fld_cd")

    val i = 0;

    for( i <- 0 to 3){
    val k = col_name(i)
	  val result = sqlContext.sql(f"""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+f"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where $k RLIKE '[^A-z0-9]' """)
      
	  if (result.count > 0) {
      println(f" $k -- Failed")
      
      
    } else {
      println(f" $k -- Success")
    }
     
    }
 }
 
  //===========================================
 
  test("ClaimFacilityDetailExtract -Validated Double Quote Character checks for other Columns - 003") {
    val id = Array("003")
    val name = Array("Test case : Validated Double Quote Character checks for other Columns")
   
    
    val col_name = Array("adjstmnt_sqnc_nbr",
"cpt_hcpcs_cd",
"proc_mdfr_cd",
"bnft_paymnt_stts_cd",
"clm_paymnt_stts_cd",
"prmry_non_cvrd_rsn_cd",
"non_cvrd_rsn_cd_2",
"non_cvrd_rsn_cd_3",
"non_cvrd_rsn_cd_4",
"reimbmnt_type_cd",
"rvnu_cd",
"totl_units_nbr",
"srvc_post_dt",
"srvc_from_dt",
"sbmtd_amt",
"non_cvrd_amt",
"alwd_amt",
"paymnt_amt",
"cob_tpl_amt",
"coinsrn_amt",
"cpay_amt",
"ddctbl_amt")

    val i = 0;

    for( i <- 0 to 58){
    val k = col_name(i)
	  val result = sqlContext.sql(f"""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, $k from """+dbname+f"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where $k RLIKE '"' """)
      
	  if (result.count > 0) {
	    println(f" $k -- Failed")
    
      
    } else {
      println(f" $k -- Success")
      
    }
     
    }
 }
 
  //===========================================
 
  test("ClaimFacilityDetailExtract -Validate One record for each BHI Home Plan ID,Claim ID, Claim Line Number & Traceability - 004") {
    
    val id = Array("004")
    val name = Array("Test case : Validate One record for each BHI Home Plan ID,Claim ID, Claim Line Number & Traceability")
    
    

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, count(*) as count from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl group by bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd""")
    result.createOrReplaceTempView("resultDF")
    
    val invalid = sqlContext.sql("""select * from resultDF where count > 1 """)
    
    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl group by bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd) where count > 1")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','COUNT'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl group by bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','COUNT' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    }

  }

  //===========================================
  
   test("ClaimFacilityDetailExtract -Validate that all the records have the correct [BHI Home Plan ID] as per Anthem - 005") {
    val id = Array("005")
    val name = Array("Test case : Validate that all the records have the correct [BHI Home Plan ID] as per Anthem")
    
    

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where
    bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') """)
     
        
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') ")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','ERR_ID','EXCLSN_ID'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') ")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','ERR_ID','EXCLSN_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    }

  }

  //===========================================Changes need to be done in future
 
 test("ClaimFacilityDetailExtract -Validate that Claim Line Number should not be less than 000 or greater than 999 - 006") {
    val id = Array("006")
    val name = Array("Test case : Validate that Claim Line Number should not be less than 000 or greater than 999")
    
    

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where
    clm_line_nbr < 000 OR clm_line_nbr > 999  """)
     
        
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where clm_line_nbr < 000 OR clm_line_nbr > 999 ")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','ERR_ID','EXCLSN_ID'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where clm_line_nbr < 000 OR clm_line_nbr > 999 ")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','ERR_ID','EXCLSN_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    }

  }

  //===========================================
 
 test("ClaimFacilityDetailExtract -Validate that BHI Home Plan ID + Traceability is present in Traceability Table - 007") {
    val id = Array("007")
    val name = Array("Test case : Validate that BHI Home Plan ID + Traceability is present in Traceability Table")
    
    

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(trcblty_fld_cd))) as CONCAT_TGT from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(trcblty_fld_cd))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc)")
      val data = Array("'Home_Plan_Id + Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(trcblty_fld_cd))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc)")
      val data = Array("'Home_Plan_Id + Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
 
 test("ClaimFacilityDetailExtract -Validate that Benefit Payment Status Code is present in Reference table - 008") {
    val id = Array("008")
    val name = Array("Test case : Validate that Benefit Payment Status Code is present in Reference table")
    
    

    val result1 = sqlContext.sql("""select distinct (trim(bnft_paymnt_stts_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(bnft_paymnt_stts_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(bnft_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where err_id = '0' and exclsn_ind = 0 and trim(bnft_paymnt_stts_cd) not in (select distinct (trim(bnft_pymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bnft_pymnt_stts_cd_inbnd)")
      val data = Array("'Benefit Payment Status Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(bnft_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where err_id = '0' and exclsn_ind = 0 and trim(bnft_paymnt_stts_cd) not in (select distinct (trim(bnft_pymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bnft_pymnt_stts_cd_inbnd)")
      val data = Array("'Benefit Payment Status Code'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
 
 test("ClaimFacilityDetailExtract - Validate that Benefit Payment Status Code has Valid Values - 009") {
    val id = Array("009")
    val name = Array("Test case : Validate that Benefit Payment Status Code has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct bnft_paymnt_stts_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where bnft_paymnt_stts_cd NOT IN ('Y','N','O')  """)

            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct bnft_paymnt_stts_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where bnft_paymnt_stts_cd NOT IN ('Y','N','O')")
      val data = Array("'Benefit Payment Status_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct bnft_paymnt_stts_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where bnft_paymnt_stts_cd NOT IN ('Y','N','O')")
      val data = Array("'Invalid Benefit Payment Status_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
 
  test("ClaimFacilityDetailExtract -Validate that Claim Payment Status Code is present in Reference table - 010") {
    val id = Array("010")
    val name = Array("Test case : Validate that Claim Payment Status Code is present in Reference table")
    
    

    val result1 = sqlContext.sql("""select distinct (trim(clm_paymnt_stts_cd )) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_clm_paymnt_stts_inbnd   """)

    val result2 = sqlContext.sql("""select distinct clm_paymnt_stts_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct clm_paymnt_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where err_id = '0' and exclsn_ind = 0 and clm_paymnt_stts_cd not in (select distinct (trim(clm_pymnt_stts_cd )) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_clm_pymnt_stts_inbnd)")
      val data = Array("'Claim Payment Status Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct clm_paymnt_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where err_id = '0' and exclsn_ind = 0 and clm_paymnt_stts_cd not in (select distinct (trim(clm_pymnt_stts_cd )) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_clm_pymnt_stts_inbnd)")
      val data = Array("'Invalid Claim Payment Status Code'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
  
 test("ClaimFacilityDetailExtract -Validate that Claim Payment Status Code has Valid Values - 011") {
    val id = Array("011")
    val name = Array("Test case : Validate that Claim Payment Status Code has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct clm_paymnt_stts_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where clm_paymnt_stts_cd NOT IN ('D','P')  """)

            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct clm_paymnt_stts_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where clm_paymnt_stts_cd NOT IN ('D','P')")
      val data = Array("'Claim Payment Status_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct clm_paymnt_stts_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where clm_paymnt_stts_cd NOT IN ('D','P')")
      val data = Array("'Invalid Claim Payment Status_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
 
 test("ClaimFacilityDetailExtract -Validate that Non-Covered Reason Code - Primary is present in Reference table - 012") {
    val id = Array("012")
    val name = Array("Test case : Validate that Non-Covered Reason Code - Primary is present in Reference table")
    
    

    val result1 = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd   """)

    val result2 = sqlContext.sql("""select distinct prmry_non_cvrd_rsn_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where prmry_non_cvrd_rsn_cd rlike '[^0-9]' """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where prmry_non_cvrd_rsn_cd rlike '[^0-9]' and prmry_non_cvrd_rsn_cd not in (select distinct (trim(non_cvrd_rsn_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd)")
      val data = Array("'Non-Covered Reason Code - Primary' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where prmry_non_cvrd_rsn_cd rlike '[^0-9]' and prmry_non_cvrd_rsn_cd not in (select distinct (trim(non_cvrd_rsn_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd)")
      val data = Array("'Invalid Non-Covered Reason Code - Primary'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
 
  //===========================================
 
 test("ClaimFacilityDetailExtract -Validate that Non-Covered Reason Code 2 is present in Reference table - 013") {
    val id = Array("013")
    val name = Array("Test case : Validate that Non-Covered Reason Code 2 is present in Reference table")
    
    

    val result1 = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd """)

    val result2 = sqlContext.sql("""select distinct non_cvrd_rsn_cd_2 from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_2 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where err_id = '0' and exclsn_ind = 0 and non_cvrd_rsn_cd_2 not in (select distinct (trim(non_cvrd_rsn_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd)")
      val data = Array("'Non-Covered Reason Code 2' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_2 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where err_id = '0' and exclsn_ind = 0 and non_cvrd_rsn_cd_2 not in (select distinct (trim(non_cvrd_rsn_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd)")
      val data = Array("'Invalid Non-Covered Reason Code 2'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
 
  //===========================================
 
  test("ClaimFacilityDetailExtract -Validate that Non-Covered Reason Code 3 is present in Reference table - 014") {
    val id = Array("014")
    val name = Array("Test case : Validate that Non-Covered Reason Code 3 is present in Reference table")
    
    

    val result1 = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd """)

    val result2 = sqlContext.sql("""select distinct non_cvrd_rsn_cd_3 from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_3 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where err_id = '0' and exclsn_ind = 0 and non_cvrd_rsn_cd_3 not in (select distinct (trim(non_cvrd_rsn_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd)")
      val data = Array("'Non-Covered Reason Code 3' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_3 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where err_id = '0' and exclsn_ind = 0 and non_cvrd_rsn_cd_3 not in (select distinct (trim(non_cvrd_rsn_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd)")
      val data = Array("'Invalid Non-Covered Reason Code 3'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
 
  //===========================================
 
  test("ClaimFacilityDetailExtract -Validate that Non-Covered Reason Code 4 is present in Reference table - 015") {
    val id = Array("015")
    val name = Array("Test case : Validate that Non-Covered Reason Code 4 is present in Reference table")
    
    

    val result1 = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd """)

    val result2 = sqlContext.sql("""select distinct non_cvrd_rsn_cd_4 from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_4 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where err_id = '0' and exclsn_ind = 0 and non_cvrd_rsn_cd_4 not in (select distinct (trim(non_cvrd_rsn_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd)")
      val data = Array("'Non-Covered Reason Code 4' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_4 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where err_id = '0' and exclsn_ind = 0 and non_cvrd_rsn_cd_4 not in (select distinct (trim(non_cvrd_rsn_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd)")
      val data = Array("'Invalid Non-Covered Reason Code 4'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
 
 test("ClaimFacilityDetailExtract -Validate that the BHI Home Plan ID + Traceability Field + Claim ID combination must be present in the Facility Header table - 016") {
    val id = Array("016")
    val name = Array("Test case :Validate that the BHI Home Plan ID + Traceability Field + Claim ID combination must be present in the Facility Header table")
    
    

    val result = sqlContext.sql(""" select bhi_home_plan_id, clm_id, trcblty_fld_cd
from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl DTL
left outer join """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR
on trim(DTL.bhi_home_plan_id)=trim(HDR.bhi_home_plan_id) and
trim(DTL.clm_id)=trim(HDR.clm_id) and
trim(DTL.trcblty_fld_cd)=trim(HDR.trcblty_fld_cd)
where HDR.clm_id is NULL
 """)

    //check condition
        
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl DTL left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR on trim(DTL.bhi_home_plan_id)=trim(HDR.bhi_home_plan_id) and trim(DTL.clm_id)=trim(HDR.clm_id) and trim(DTL.trcblty_fld_cd)=trim(HDR.trcblty_fld_cd) where HDR.clm_id is NULL")
      val data = Array("' BHI Home Plan ID , Claim , Traceability Field' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl DTL left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hd HDR on trim(DTL.bhi_home_plan_id)=trim(HDR.bhi_home_plan_id) and trim(DTL.clm_id)=trim(HDR.clm_id) and trim(DTL.trcblty_fld_cd)=trim(HDR.trcblty_fld_cd) where HDR.clm_id is NULL")
      val data = Array("' BHI Home Plan ID , Claim , Traceability Field' :  Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  
  
  //===========================================
    
  test("ClaimFacilityDetailExtract -Validate that Non-Covered Reason Code 2 has Valid Values - 017") {
    val id = Array("017")
    val name = Array("Test case : Validate that Non-Covered Reason Code 2 has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct non_cvrd_rsn_cd_2, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where non_cvrd_rsn_cd_2 NOT IN ('00')  """)

            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_2, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where non_cvrd_rsn_cd_2 NOT IN ('00')")
      val data = Array("'Non-Covered Reason Code 2','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_2, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where non_cvrd_rsn_cd_2 NOT IN ('00')")
      val data = Array("'Invalid Non-Covered Reason Code 2','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
  
  test("ClaimFacilityDetailExtract -Validate that Non-Covered Reason Code 3 has Valid Values - 018") {
    val id = Array("018")
    val name = Array("Test case : Validate that Non-Covered Reason Code 3 has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct non_cvrd_rsn_cd_3, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where non_cvrd_rsn_cd_2 NOT IN ('00')  """)

            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_3, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where non_cvrd_rsn_cd_2 NOT IN ('00')")
      val data = Array("'Non-Covered Reason Code 3','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_3, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where non_cvrd_rsn_cd_2 NOT IN ('00')")
      val data = Array("'Invalid Non-Covered Reason Code 3','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
  
   test("ClaimFacilityDetailExtract -Validate that Non-Covered Reason Code 4 has Valid Values - 019") {
    val id = Array("019")
    val name = Array("Test case : Validate that Non-Covered Reason Code 4 has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct non_cvrd_rsn_cd_4, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where non_cvrd_rsn_cd_2 NOT IN ('00')  """)

            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_4, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where non_cvrd_rsn_cd_2 NOT IN ('00')")
      val data = Array("'Non-Covered Reason Code 4','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_4, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where non_cvrd_rsn_cd_2 NOT IN ('00')")
      val data = Array("'Invalid Non-Covered Reason Code 4','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
    test("ClaimFacilityDetailExtract -Validate that Service Post date has Valid Values - 020") {
    val id = Array("020")
    val name = Array("Test case : Validate that Service Post date has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct srvc_post_dt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where date(srvc_post_dt) <> '0001-01-01'  """)

            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct srvc_post_dt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where date(srvc_post_dt) <> '0001-01-01'")
      val data = Array("'Service Post date','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct srvc_post_dt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  where date(srvc_post_dt) <> '0001-01-01'")
      val data = Array("'Invalid Service Post date','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
    
   test("ClaimFacilityDetailExtract -Validate that if COB TPL Amt > 0 then Primary Non-Covered Reason Code is 00 - 021") {
    val id = Array("021")
    val name = Array("Test case : Validate that if COB TPL Amt > 0 then Primary Non-Covered Reason Code is 00")
 
    val result = sqlContext.sql(""" select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,prmry_non_cvrd_rsn_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL 
      where cob_tpl_amt>0 and prmry_non_cvrd_rsn_cd<>'00' """)
      
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL  where cob_tpl_amt>0 and prmry_non_cvrd_rsn_cd<>'00'")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','COB_Tpl_Amt','Prmry_Non_Cvrd_Rsn_CD' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL  where cob_tpl_amt>0 and prmry_non_cvrd_rsn_cd<>'00'")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','COB_Tpl_Amt','Prmry_Non_Cvrd_Rsn_CD'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimFacilityDetailExtract -Validate that if COB TPL Amt > 0 then Primary Non-Covered Amount is 00 - 022") {
    val id = Array("022")
    val name = Array("Test case : Validate that if COB TPL Amt > 0 then Primary Non-Covered Amount is 00")
 
    val result = sqlContext.sql(""" select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,non_cvrd_amt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL 
      where cob_tpl_amt>0 and non_cvrd_amt<>'0'  """)
      
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,non_cvrd_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL  where cob_tpl_amt>0 and non_cvrd_amt<>'0'")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','COB_Tpl_Amt','Non_Cvrd_Amt' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
       val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,non_cvrd_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL  where cob_tpl_amt>0 and non_cvrd_amt<>'0'")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','COB_Tpl_Amt','Non_Cvrd_Amt'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimFacilityDetailExtract -Validate that the only  Non-Covered Reason Code is 00 and 40 when cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0 - 023") {
    val id = Array("023")
    val name = Array("Test case : Validate that the only Non-Covered Reason Code is 00 and 40 when cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0")
 
    val result = sqlContext.sql(""" select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,prmry_non_cvrd_rsn_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL 
      where cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0 and prmry_non_cvrd_rsn_cd not in ('00','40') """)
      
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL  where cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0 and prmry_non_cvrd_rsn_cd not in ('00','40')")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','COB_Tpl_Amt','Prmry_Non_Cvrd_Rsn_CD' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL  where cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0 and prmry_non_cvrd_rsn_cd not in ('00','40')")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','COB_Tpl_Amt','Prmry_Non_Cvrd_Rsn_CD'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimFacilityDetailExtract -Valdate that if Non-Covered Reason Code is 00 the Non-Covered Amount is 00 when cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0 - 024") {
    val id = Array("024")
    val name = Array("Test case : Valdate that if Non-Covered Reason Code is 00 the Non-Covered Amount is 00 when cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0 ")
 
    val result = sqlContext.sql(""" select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,prmry_non_cvrd_rsn_cd,non_cvrd_amt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL 
      where cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0 and prmry_non_cvrd_rsn_cd = '00' and non_cvrd_amt<>0 """)
      
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,prmry_non_cvrd_rsn_cd,non_cvrd_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL  where cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0 and prmry_non_cvrd_rsn_cd = '00' and non_cvrd_amt<>0")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','COB_Tpl_Amt','Prmry_Non_Cvrd_Rsn_CD','Non_Cvrd_Amt' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,prmry_non_cvrd_rsn_cd,non_cvrd_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL  where cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0 and prmry_non_cvrd_rsn_cd = '00' and non_cvrd_amt<>0")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','COB_Tpl_Amt','Prmry_Non_Cvrd_Rsn_CD','Non_Cvrd_Amt'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimFacilityDetailExtract -Validate that if Non-Covered Reason Code is 70 then Non-Covered amount is 00 when  cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)=0 - 025") {
    val id = Array("025")
    val name = Array("Test case : Validate that if Non-Covered Reason Code is 70 then Non-Covered amount is 00 when  cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)=0")
 
    val result = sqlContext.sql(""" select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,prmry_non_cvrd_rsn_cd,non_cvrd_amt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL 
      where cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)=0 and prmry_non_cvrd_rsn_cd ='70' and non_cvrd_amt<>0 """)
      
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,prmry_non_cvrd_rsn_cd,non_cvrd_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL  where cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)=0 and prmry_non_cvrd_rsn_cd ='70' and non_cvrd_amt<>0 ")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','COB_Tpl_Amt','Prmry_Non_Cvrd_Rsn_CD','Non_Cvrd_Amt' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr,cob_tpl_amt,prmry_non_cvrd_rsn_cd,non_cvrd_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_DTL  where cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)=0 and prmry_non_cvrd_rsn_cd ='70' and non_cvrd_amt<>0 ")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','COB_Tpl_Amt','Prmry_Non_Cvrd_Rsn_CD','Non_Cvrd_Amt'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================

  
  test("ClaimFacilityDetailExtract -No Denied lined should have apportioned amounts - 026") {
    val id = Array("026")
    val name = Array("Test case : No Denied lined should have apportioned amounts")
 
    val result1 = sqlContext.sql(""" select * from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_dtl_stg where cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0 
and prmry_non_cvrd_rsn_cd not in ('00','40') and clm_paymnt_stts_cd='D' """)

    val result2 = sqlContext.sql(""" select distinct FCDS.bhi_home_plan_id, FCDS.clm_line_nbr, FCDS.trcblty_fld_cd, FCDS.clm_adjstmnt_key,
FCDS.clm_paymnt_stts_cd,FCDS.prmry_non_cvrd_rsn_cd, FCDS.sbmtd_amt, FCDS.non_cvrd_amt, FCDS.alwd_amt,
FCDS.paymnt_amt, FCDS.cob_tpl_amt, FCDS.coinsrn_amt, FCDS.cpay_amt, FCDS.ddctbl_amt,
OUTPAT.billd_chrg_amt, OUTPAT.non_cvrd_amt, OUTPAT.alwd_amt, OUTPAT.paid_amt, OUTPAT.cob_svngs_amt, 
OUTPAT.coinsrn_amt, OUTPAT.cpay_amt, OUTPAT.ddctbl_amt
from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_dtl_stg FCDS
inner join """+dbname+"""_pcandw1ph_nogbd_r000_wh.all_clm_outpat_fclty OUTPAT
ON
FCDS.clm_adjstmnt_key=OUTPAT.clm_adjstmnt_key and
FCDS.clm_line_nbr=OUTPAT.clm_line_nbr and
FCDS.trcblty_fld_cd=OUTPAT.clm_sor_cd
where FCDS.cob_tpl_amt<=0 and 
(FCDS.paymnt_amt+FCDS.coinsrn_amt+FCDS.cpay_amt+FCDS.ddctbl_amt)>0 and
FCDS.prmry_non_cvrd_rsn_cd not in ('00','40') and
FCDS.clm_paymnt_stts_cd='D' """)
      
    if (result1.count == 0 && result2.count == 0) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      
      val query1 = Array("Test Query1 :  select * from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_dtl_stg where cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0 and prmry_non_cvrd_rsn_cd not in ('00','40') and clm_paymnt_stts_cd='D'")

      val query2 = Array("Test Query2 : select distinct FCDS.bhi_home_plan_id, FCDS.clm_line_nbr, FCDS.trcblty_fld_cd, FCDS.clm_adjstmnt_key,FCDS.clm_paymnt_stts_cd,FCDS.prmry_non_cvrd_rsn_cd, FCDS.sbmtd_amt, FCDS.non_cvrd_amt, FCDS.alwd_amt, FCDS.paymnt_amt, FCDS.cob_tpl_amt, FCDS.coinsrn_amt, FCDS.cpay_amt, FCDS.ddctbl_amt, OUTPAT.billd_chrg_amt, OUTPAT.non_cvrd_amt, OUTPAT.alwd_amt, OUTPAT.paid_amt, OUTPAT.cob_svngs_amt, OUTPAT.coinsrn_amt, OUTPAT.cpay_amt, OUTPAT.ddctbl_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_dtl_stg FCDS inner join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.all_clm_outpat_fclty OUTPAT ON FCDS.clm_adjstmnt_key=OUTPAT.clmadj_key and FCDS.clm_line_nbr=OUTPAT.clm_line_nbr and FCDS.trcblty_fld_cd=OUTPAT.clm_sor_cd where FCDS.cob_tpl_amt<=0 and (FCDS.paymnt_amt+FCDS.coinsrn_amt+FCDS.cpay_amt+FCDS.ddctbl_amt)>0 and FCDS.prmry_non_cvrd_rsn_cd not in ('00','40') and FCDS.clm_paymnt_stts_cd='D' ")

      val data = Array(" Count of both the queries are Matching")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      
      val query1 = Array("Test Query1 :  select * from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_dtl_stg where cob_tpl_amt<=0 and (paymnt_amt+coinsrn_amt+cpay_amt+ddctbl_amt)>0 and prmry_non_cvrd_rsn_cd not in ('00','40') and clm_paymnt_stts_cd='D'")

      val query2 = Array("Test Query2 : select distinct FCDS.bhi_home_plan_id, FCDS.clm_line_nbr, FCDS.trcblty_fld_cd, FCDS.clm_adjstmnt_key,FCDS.clm_paymnt_stts_cd,FCDS.prmry_non_cvrd_rsn_cd, FCDS.sbmtd_amt, FCDS.non_cvrd_amt, FCDS.alwd_amt, FCDS.paymnt_amt, FCDS.cob_tpl_amt, FCDS.coinsrn_amt, FCDS.cpay_amt, FCDS.ddctbl_amt, OUTPAT.billd_chrg_amt, OUTPAT.non_cvrd_amt, OUTPAT.alwd_amt, OUTPAT.paid_amt, OUTPAT.cob_svngs_amt, OUTPAT.coinsrn_amt, OUTPAT.cpay_amt, OUTPAT.ddctbl_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_dtl_stg FCDS inner join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.all_clm_outpat_fclty OUTPAT ON FCDS.clm_adjstmnt_key=OUTPAT.clmadj_key and FCDS.clm_line_nbr=OUTPAT.clm_line_nbr and FCDS.trcblty_fld_cd=OUTPAT.clm_sor_cd where FCDS.cob_tpl_amt<=0 and (FCDS.paymnt_amt+FCDS.coinsrn_amt+FCDS.cpay_amt+FCDS.ddctbl_amt)>0 and FCDS.prmry_non_cvrd_rsn_cd not in ('00','40') and FCDS.clm_paymnt_stts_cd='D' ")

      val data = Array(" Count of both the queries are not Matching")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
  
  test("ClaimFacilityDetailExtract -Amounts comparison between FCH and FCD - 027") {
    val id = Array("027")
    val name = Array("Test case : Amounts comparison between FCH and FCD")
 
    val result1 = sqlContext.sql(""" select bhi_home_plan_id, (SUM (SBMTD_AMT)) AS BILLD_CHRG_AMT ,(SUM (NON_CVRD_AMT)) AS NON_CVRD_AMT ,          
    (SUM (ALWD_AMT)) AS ALWD_AMT ,(SUM (PAYMNT_AMT)) AS PAID_AMT ,(SUM (COB_TPL_AMT)) AS COB_SVNGS_AMT ,
    (SUM (COINSRN_AMT)) AS COINSRN_AMT ,(SUM (CPAY_AMT)) AS CPAY_AMT ,(SUM (DDCTBL_AMT)) AS DDCTBL_AMT          
     FROM """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr 
    group by bhi_home_plan_id
    order by bhi_home_plan_id """).createOrReplaceTempView("result1DF")

    val result2 = sqlContext.sql(""" select bhi_home_plan_id, (SUM (SBMTD_AMT)) AS BILLD_CHRG_AMT ,(SUM (NON_CVRD_AMT)) AS NON_CVRD_AMT ,          
    (SUM (ALWD_AMT)) AS ALWD_AMT ,(SUM (PAYMNT_AMT)) AS PAID_AMT ,(SUM (COB_TPL_AMT)) AS COB_SVNGS_AMT ,
    (SUM (COINSRN_AMT)) AS COINSRN_AMT ,(SUM (CPAY_AMT)) AS CPAY_AMT ,(SUM (DDCTBL_AMT)) AS DDCTBL_AMT          
     FROM """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl 
    group by bhi_home_plan_id
    order by bhi_home_plan_id """).createOrReplaceTempView("result2DF")

    val result = sqlContext.sql(""" select * from result1DF r1 join result2DF r2 on r1.bhi_home_plan_id = r2.bhi_home_plan_id where r1.BILLD_CHRG_AMT <> r2.BILLD_CHRG_AMT or r1.NON_CVRD_AMT <> r2.NON_CVRD_AMT or r1.ALWD_AMT <> r2.ALWD_AMT or r1.PAID_AMT <> r2.PAID_AMT 
      or r1.COB_SVNGS_AMT <> r2.COB_SVNGS_AMT or r1.COINSRN_AMT <> r2.COINSRN_AMT or r1.CPAY_AMT <> r2.CPAY_AMT or r1.DDCTBL_AMT <> r2.DDCTBL_AMT""")
      
    if (result.count == 0) {
      val a = result.rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select * from result1DF r1 join result2DF r2 on r1.bhi_home_plan_id = r2.bhi_home_plan_id where  r1.BILLD_CHRG_AMT <> r2.BILLD_CHRG_AMT or r1.NON_CVRD_AMT <> r2.NON_CVRD_AMT or r1.ALWD_AMT <> r2.ALWD_AMT or r1.PAID_AMT <> r2.PAID_AMT  or r1.COB_SVNGS_AMT <> r2.COB_SVNGS_AMT or r1.COINSRN_AMT <> r2.COINSRN_AMT or r1.CPAY_AMT <> r2.CPAY_AMT or r1.DDCTBL_AMT <> r2.DDCTBL_AMT")
      val data = Array("'bhi_home_plan_id','BILLD_CHRG_AMT','NON_CVRD_AMT','ALWD_AMT',' PAID_AMT','COB_SVNGS_AMT','COINSRN_AMT','CPAY_AMT','DDCTBL_AMT' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select * from result1DF r1 join result2DF r2 on r1.bhi_home_plan_id = r2.bhi_home_plan_id where  r1.BILLD_CHRG_AMT <> r2.BILLD_CHRG_AMT or r1.NON_CVRD_AMT <> r2.NON_CVRD_AMT or r1.ALWD_AMT <> r2.ALWD_AMT or r1.PAID_AMT <> r2.PAID_AMT  or r1.COB_SVNGS_AMT <> r2.COB_SVNGS_AMT or r1.COINSRN_AMT <> r2.COINSRN_AMT or r1.CPAY_AMT <> r2.CPAY_AMT or r1.DDCTBL_AMT <> r2.DDCTBL_AMT")
      val data = Array("'bhi_home_plan_id','BILLD_CHRG_AMT','NON_CVRD_AMT','ALWD_AMT',' PAID_AMT','COB_SVNGS_AMT','COINSRN_AMT','CPAY_AMT','DDCTBL_AMT'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1 == 2)
    }
  }
  
  //===========================================
  
   test("ClaimFacilityDetailExtract -Validate that no FEP claims present in Extract - 028") {
    val id = Array("028")
    val name = Array("Test case : Validate that no FEP claims present in Extract")
 
    val result1 = sqlContext.sql(""" select distinct stg.bhi_home_plan_id,stg.clm_id,c.mbr_key,stg.clm_adjstmnt_key,c.src_grp_nbr,coa.mbu_cf_cd from 
"""+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_dtl_stg stg inner join """+dbname+"""_pcandw1ph_nogbd_r000_in.clm c 
on c.clm_adjstmnt_key= stg.clm_adjstmnt_key inner join """+dbname+"""_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa coa 
on c.mbr_key= coa.mbr_key where c.src_grp_nbr='FEP' """)

    val result2 = sqlContext.sql(""" select TRCBLTY_FLD_CD,COUNT(*) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl GROUP BY TRCBLTY_FLD_CD 
having TRCBLTY_FLD_CD in ("888","896") """)
      
    if (result1.count == 0 && result2.count == 0) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query1 :  select distinct stg.bhi_home_plan_id,stg.clm_id,c.mbr_key,stg.clm_adjstmnt_key,c.src_grp_nbr,coa.mbu_cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_dtl_stg stg inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm c on c.clm_adjstmnt_key= stg.clm_adjstmnt_key inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa coa on c.mbr_key= coa.mbr_key where c.src_grp_nbr='FEP'")
      val query2 = Array("Test Query2 :  select TRCBLTY_FLD_CD,COUNT(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl GROUP BY TRCBLTY_FLD_CD having TRCBLTY_FLD_CD in ('888','896')")
      val data = Array(" Count of both the queries are Matching")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query1 :  select distinct stg.bhi_home_plan_id,stg.clm_id,c.mbr_key,stg.clm_adjstmnt_key,c.src_grp_nbr,coa.mbu_cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_dtl_stg stg inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm c on c.clm_adjstmnt_key= stg.clm_adjstmnt_key inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa coa on c.mbr_key= coa.mbr_key where c.src_grp_nbr='FEP'")
      val query2 = Array("Test Query2 :  select TRCBLTY_FLD_CD,COUNT(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl GROUP BY TRCBLTY_FLD_CD having TRCBLTY_FLD_CD in ('888','896')")
      val data = Array(" Count of both the queries are not Matching")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimFacilityDetailExtract - Validate that there are 14 BHI Home Plan ID  - 029") {
    
    val id = Array("029")
     val name = Array("Test case : Validate that there are 14 BHI Home Plan ID ")
     
    val result = sqlContext.sql(""" select count(distinct bhi_home_plan_id) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)
    
        
    if (result.collectAsList.toString.contains("14")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_fclty_clm_dtl ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_fclty_clm_dtl ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
 /*
 test("ClaimFacilityDetailExtract -Validate that Claim ID column is populated  as per specified field format - 16") {
    val id = Array("016")
    val name = Array("Test case : Validate that Claim ID column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select distinct concat(trim(a.clm_nbr),trim(b.mcid)) from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm a  
      inner join """+dbname+"""_pcandw1ph_nogbd_r000_in.pi_mcid_mbr_key_xwalk_all b  
        on a.mbr_key = b.mbr_key and a.mbrshp_sor_cd = b.mbrshp_sor_cd 
        INNER JOIN """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM_MAX_RVSN CMR  ON a.clm_adjstmnt_key=CMR.CLM_ADJSTMNT_KEY """)

    val result2 = sqlContext.sql("""select distinct (trim(clm_id)) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(clm_id)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl and trim(clm_id) not in (select distinct concat(trim(a.clm_nbr),trim(b.mcid)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm a inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.pi_mcid_mbr_key_xwalk_all b on a.mbr_key = b.mbr_key and a.mbrshp_sor_cd = b.mbrshp_sor_cd)")
      val data = Array("'Claim_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(clm_id)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where trim(clm_id) not in (select distinct concat(trim(a.clm_nbr),trim(b.mcid)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm a inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.pi_mcid_mbr_key_xwalk_all b on a.mbr_key = b.mbr_key and a.mbrshp_sor_cd = b.mbrshp_sor_cd)")
      val data = Array("'Invalid Claim_ID'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
 
 test("ClaimFacilityDetailExtract -Validate that Traceability Field column is populated  as per specified field format - 17") {
    val id = Array("017")
    val name = Array("Test case : Validate that Traceability Field column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select distinct (trim(a.clm_sor_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm a 
      INNER JOIN """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM_MAX_RVSN CMR  ON a.clm_adjstmnt_key=CMR.CLM_ADJSTMNT_KEY """)

    val result2 = sqlContext.sql("""select distinct (trim(trcblty_fld_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(trcblty_fld_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where trim(trcblty_fld_cd) not in (select distinct (trim(a.clm_sor_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm a)")
      val data = Array("'Traceability Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(trcblty_fld_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where trim(trcblty_fld_cd) not in (select distinct (trim(a.clm_sor_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm a)")
      val data = Array("'Invalid Traceability Code'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
 
 test("ClaimFacilityDetailExtract -Validate that Adjustment Sequence Number column is populated  as per specified field format - 19") {
    val id = Array("019")
    val name = Array("Test case : Validate that Adjustment Sequence Number column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select distinct CAST(date_format(to_date(a.ADJDCTN_DT, 'yyyy-MM-dd'),'yyyyMMdd') AS INT) AS ADJSTMNT_SQNC_NBR from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm a 
      INNER JOIN """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM_MAX_RVSN CMR  ON a.clm_adjstmnt_key=CMR.CLM_ADJSTMNT_KEY """)

    val result2 = sqlContext.sql("""select distinct adjstmnt_sqnc_nbr from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct adjstmnt_sqnc_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where adjstmnt_sqnc_nbr not in (select distinct CAST(date_format(to_date(a.ADJDCTN_DT, 'yyyy-MM-dd'),'yyyyMMdd') AS INT) AS ADJSTMNT_SQNC_NBR from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm a  INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM_MAX_RVSN CMR  ON a.clm_adjstmnt_key=CMR.CLM_ADJSTMNT_KEY)")
      val data = Array("'Adjustment Sequence Number' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct adjstmnt_sqnc_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where adjstmnt_sqnc_nbr not in (select distinct CAST(date_format(to_date(a.ADJDCTN_DT, 'yyyy-MM-dd'),'yyyyMMdd') AS INT) AS ADJSTMNT_SQNC_NBR from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm a  INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM_MAX_RVSN CMR  ON a.clm_adjstmnt_key=CMR.CLM_ADJSTMNT_KEY)")
      val data = Array("'Invalid Adjustment Sequence Number'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
 
  test("ClaimFacilityDetailExtract -Validate that Claim Payment Status column is populated  as per specified field format - 20") {
    val id = Array("020")
    val name = Array("Test case : Validate that Claim Payment Status column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select distinct a.adjdctn_stts_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm a INNER JOIN """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM_MAX_RVSN CMR  ON a.clm_adjstmnt_key=CMR.CLM_ADJSTMNT_KEY """)

    val result2 = sqlContext.sql("""select distinct clm_paymnt_stts_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct clm_paymnt_stts_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where clm_paymnt_stts_cd not in (select distinct adjdctn_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm)")
      val data = Array("'Claim Payment Status ' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct clm_paymnt_stts_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where clm_paymnt_stts_cd not in (select distinct adjdctn_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm)")
      val data = Array("'Invalid Claim Payment Status '")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //=========================================== 
  
   test("ClaimFacilityDetailExtract -Validate that Total Units column is populated  as per specified field format - 21") {
    val id = Array("021")
    val name = Array("Test case : Validate that Total Units column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select distinct billd_srvc_unit_cnt from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line""")

    val result2 = sqlContext.sql("""select distinct totl_units_nbr from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct totl_units_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where totl_units_nbr not in (select distinct billd_srvc_unit_cnt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Total Units' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct totl_units_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where totl_units_nbr not in (select distinct billd_srvc_unit_cnt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Invalid Total Units'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
   
    test("ClaimFacilityDetailExtract -Validate that Service From Date column is populated  as per specified field format - 22") {
    val id = Array("022")
    val name = Array("Test case : Validate that Service From Date column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select distinct clm_line_srvc_strt_dt from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line""")

    val result2 = sqlContext.sql("""select distinct srvc_from_dt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct srvc_from_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where srvc_from_dt not in (select distinct clm_line_srvc_strt_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Service From Date' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct srvc_from_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where srvc_from_dt not in (select distinct clm_line_srvc_strt_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Invalid Service From Date'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
    
    test("ClaimFacilityDetailExtract -Validate that Service Post Date column is populated  as per specified field format - 23") {
    val id = Array("023")
    val name = Array("Test case : Validate that Service Post Date column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select distinct clm_line_srvc_end_dt from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line""")

    val result2 = sqlContext.sql("""select distinct srvc_post_dt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct srvc_post_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where srvc_post_dt not in (select distinct clm_line_srvc_end_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Service Post Date' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct srvc_post_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where srvc_post_dt not in (select distinct clm_line_srvc_end_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Invalid Service Post Date'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
    
    test("ClaimFacilityDetailExtract -Validate that Submitted Amount column is populated  as per specified field format - 24") {
    val id = Array("024")
    val name = Array("Test case : Validate that Submitted Amount column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select billd_chrg_amt from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line""")

    val result2 = sqlContext.sql("""select sbmtd_amt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select sbmtd_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where sbmtd_amt not in (select billd_chrg_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Submitted Amount' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select sbmtd_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where sbmtd_amt not in (select billd_chrg_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Invalid Submitted Amount'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
    
    test("ClaimFacilityDetailExtract -Validate that Allowed Amount column is populated  as per specified field format  - 25") {
    val id = Array("025")
    val name = Array("Test case : Validate that Allowed Amount column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select  alwd_amt from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line""")

    val result2 = sqlContext.sql("""select  alwd_amt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  alwd_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where alwd_amt not in (select  alwd_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Allowed Amount' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  alwd_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where alwd_amt not in (select  alwd_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Invalid Allowed Amount'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
    
    test("ClaimFacilityDetailExtract -Validate that Payment Amount column is populated  as per specified field format  - 26") {
    val id = Array("026")
    val name = Array("Test case : Validate that Payment Amount column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select paid_amt from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line""")

    val result2 = sqlContext.sql("""select paymnt_amt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select paymnt_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where paymnt_amt not in (select paid_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Payment Amount' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select paymnt_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where paymnt_amt not in (select paid_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Invalid Payment Amount'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
  
  //===========================================
    
    test("ClaimFacilityDetailExtract -Validate that COB / TPL Amount column is populated  as per specified field format - 27") {
    val id = Array("027")
    val name = Array("Test case : Validate that COB / TPL Amount column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select cob_svngs_amt from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line""")

    val result2 = sqlContext.sql("""select cob_tpl_amt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select cob_tpl_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where cob_tpl_amt not in (select cob_svngs_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'COB / TPL Amount' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select cob_tpl_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where cob_tpl_amt not in (select cob_svngs_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Invalid COB / TPL Amount'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
  
  //===========================================
    
    test("ClaimFacilityDetailExtract -Validate that COB / TPL Amount column is populated  as per specified field format - 28") {
    val id = Array("028")
    val name = Array("Test case : Validate that COB / TPL Amount column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select cob_svngs_amt from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line""")

    val result2 = sqlContext.sql("""select cob_tpl_amt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select cob_tpl_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where cob_tpl_amt not in (select cob_svngs_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'COB / TPL Amount' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select cob_tpl_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where cob_tpl_amt not in (select cob_svngs_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Invalid COB / TPL Amount'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
    
    test("ClaimFacilityDetailExtract -Validate that Coinsurance column is populated  as per specified field format - 29") {
    val id = Array("029")
    val name = Array("Test case : Validate that Coinsurance column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select coinsrn_amt from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line""")

    val result2 = sqlContext.sql("""select coinsrn_amt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select coinsrn_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where coinsrn_amt not in (select coinsrn_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Coinsurance Amount' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select coinsrn_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where coinsrn_amt not in (select coinsrn_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Invalid Coinsurance Amount'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
    
    test("ClaimFacilityDetailExtract -Validate that Copay column is populated  as per specified field format - 30") {
    val id = Array("030")
    val name = Array("Test case : Validate that Copay column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select cpay_amt from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line""")

    val result2 = sqlContext.sql("""select cpay_amt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select cpay_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where cpay_amt not in (select cpay_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Copay Amount' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select cpay_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where cpay_amt not in (select cpay_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line)")
      val data = Array("'Invalid Copay Amount'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
    
    test("ClaimFacilityDetailExtract -Validate that Deductible column is populated  as per specified field format  - 31") {
    val id = Array("031")
    val name = Array("Test case : Validate that Deductible column is populated  as per specified field format")
    
    

    val result1 = sqlContext.sql("""select ddctbl_amt from """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line""")

    val result2 = sqlContext.sql("""select ddctbl_amt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select ddctbl_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where ddctbl_amt not in (select ddctbl_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line) ")
      val data = Array("'Deductible Amount' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select ddctbl_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where ddctbl_amt not in (select ddctbl_amt from '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line) ")
      val data = Array("'Invalid Deductible Amount'")
     assert(1==1)
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }*/
   
 }
 