package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import java.util.Date
import java.text.SimpleDateFormat


object PCADX_SCL_TA_Extract_Traceability_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_Traceability_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_Extract_Traceability_TGT(dbname : String, env: String) extends FunSuite {

     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
  
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
  
      val subj = "Extract"
      val prcss = "Traceability"
      
  
   
  test("Traceability -Validate One record for each BHI Home Plan ID and Traceability field - 001") {
     
     val id = Array("001")
     val name = Array("Test case : Validate One record for each BHI Home Plan ID and Traceability field")
      
    val result = sqlContext.sql("""select bhi_home_plan_id ,sor_cd,count(*) as count from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc group by bhi_home_plan_id ,sor_cd""")
    result.createOrReplaceTempView("resultDF")
    
    val invalid = sqlContext.sql("""select * from resultDF where count > 1 """)
    
    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id ,sor_cd,count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc group by bhi_home_plan_id ,sor_cd) where count > 1  ")
      val data = Array("'BHI HPID','SOR_CD','COUNT'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from (select bhi_home_plan_id ,sor_cd,count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc group by bhi_home_plan_id ,sor_cd) where count > 1  ")
      val data = Array("'BHI HPID','SOR_CD','COUNT' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  
  test("Traceability -Validate that all the records have the correct [BHI Home Plan ID] as per Anthem - 002") {
    
    val id = Array("002")
     val name = Array("Test case : Validate that all the records have the correct [BHI Home Plan ID] as per Anthem ")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,sor_cd,err_id,exclsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc where
    bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748')  """)
     
     
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') ")
      val data = Array("'BHI HPID','SOR_CD','ERR_ID','EXCLSN_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') ")
      val data = Array("'BHI HPID','SOR_CD','ERR_ID','EXCLSN_ID' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================

  test("Traceability -Validate that BHI Home Plan ID is not NULL or contains blank spaces - 003") {
    
    val id = Array("003")
     val name = Array("Test case : Validate that BHI Home Plan ID is not NULL or contains blank spaces")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,sor_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc
        where length(trim(regexp_replace(coalesce(bhi_home_plan_id, "")," ", "")))=0  """)
   
        
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','SOR_CD'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','SOR_CD' : No Invalid Record Found")
      
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  //===========================================

  test("Traceability -Validate that Traceability field is not NULL or contains blank spaces - 004") {
    
    val id = Array("004")
     val name = Array("Test case : Validate that Traceability field is not NULL or contains blank spaces")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,sor_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc
        where length(trim(regexp_replace(coalesce(sor_cd, "")," ", "")))=0 """)
        
           
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc where length(trim(regexp_replace(coalesce(sor_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','SOR_CD'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc where length(trim(regexp_replace(coalesce(sor_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','SOR_CD' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  //===========================================
  
  test("Traceability -Validate that Traceability Description is not NULL or contains blank spaces - 005 ") {
     
    val id = Array("005")
     val name = Array("Test case : Validate that Traceability Description is not NULL or contains blank spaces")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,sor_cd,sor_desc from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc
        where length(trim(regexp_replace(coalesce(sor_desc, "")," ", "")))=0 and err_id ='0' and exclsn_ind = 0""")
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd,sor_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc where length(trim(regexp_replace(coalesce(sor_desc, ''),' ', '')))=0 and err_id ='0' and exclsn_ind = 0")
      val data = Array("'BHI HPID','SOR_CD','SOR_DESC'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd,sor_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc where length(trim(regexp_replace(coalesce(sor_desc, ''),' ', '')))=0 and err_id ='0' and exclsn_ind = 0")
      val data = Array("'BHI HPID','SOR_CD','SOR_DESC' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  //===========================================
  
  test("Traceability -Validate if BHI Home Plan ID does not contains any special character - 006 ") {
    
    val id = Array("006")
     val name = Array("Test case : Validate if BHI Home Plan ID does not contains any special character")
     
    val result = sqlContext.sql("""select  bhi_home_plan_id,sor_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc a where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%'""")
   
    if (result.count > 0) {
     val a = result.limit(10).rdd
     val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc a where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%'")
     val data = Array("'BHI HPID','SOR_CD'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc a where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','SOR_CD' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  //===========================================
  
  test("Traceability -Validate if Traceability field does not contains any special character - 007 ") {
     
    val id = Array("007")
     val name = Array("Test case : Validate if Traceability field does not contains any special character")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,sor_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc a
      where a.sor_cd  LIKE '%[^A-z0-9]%'""")
    
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc a where a.sor_cd  LIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','SOR_CD'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc a where a.sor_cd  LIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','SOR_CD' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  //===========================================
  
  test("Traceability -Validate if Traceability Description does not contains any special character - 008 ") {
    
    val id = Array("008")
     val name = Array("Test case : Validate if Traceability Description does not contains any special character")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,sor_cd,sor_desc from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc a
      where a.sor_desc  LIKE '%[^A-z0-9]%' and err_id ='0' and exclsn_ind = 0""")
      
    
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd,sor_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc a where a.sor_desc  LIKE '%[^A-z0-9]%' and err_id ='0' and exclsn_ind = 0")
      val data = Array("'BHI HPID','SOR_CD','SOR_DESC'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd,sor_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc a where a.sor_desc  LIKE '%[^A-z0-9]%' and err_id ='0' and exclsn_ind = 0")
      val data = Array("'BHI HPID','SOR_CD','SOR_DESC' : No Invalid Record Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }

  //=========================================== 
 
   test("Traceability - Validate that equal number of records exists for each [BHI Home Plan ID] as it’s a cross join - 009 ") {
    
     val id = Array("009")
     val name = Array("Test case : Validate that equal number of records exists for each [BHI Home Plan ID] as it’s a cross join ")
     
    val result = sqlContext.sql("""select bhi_home_plan_id, count(*) as CountOfEachId from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc
    group by bhi_home_plan_id""")
    
    result.createOrReplaceTempView("resultDF")
    val check = sqlContext.sql(""" select distinct CountOfEachId from resultDF """)
      
    
    if (check.count > 1) {
      val a = check.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select distinct CountOfEachId from (select bhi_home_plan_id, count(*) as CountOfEachId from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc group by bhi_home_plan_id)")
      val data = Array("'DistinctValues-Record/Count_of Each_BHI_HomePlan_Id'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select distinct CountOfEachId from (select bhi_home_plan_id, count(*) as CountOfEachId from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc group by bhi_home_plan_id)")
      val data = Array("'DistinctValues-Record/Count_of Each_BHI_HomePlan_Id'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    }
  }
   
   //===========================================
   
   test("Traceability - Validate that there are 14 BHI Home Plan ID  - 010 ") {
    
    val id = Array("010")
     val name = Array("Test case : Validate that there are 14 BHI Home Plan ID ")
     
    val result = sqlContext.sql(""" select count(distinct bhi_home_plan_id) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_trcblty_rfrnc """)
    
        
    if (result.collectAsList.toString.contains("14")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_trcblty_rfrnc ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_trcblty_rfrnc ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Traceability/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
   
   /*
   test("Traceability - Validate Source and Target table - 001") {
  
     val id = Array("NCEAP002")
     val name = Array("Test case : Validate Source and Target table")

    ExcelTableValidation.tableCompare("select trim(distinct bot_bcbsa_cmpny_cf_xwalk_inbnd.home_plan_cd), trim(sor_cd.sor_cd), trim(sor_cd.sor_desc) from """+dbname+"""_pcandw1ph_nogbd_r000_in.bot_bcbsa_cmpny_cf_xwalk_inbnd join """+dbname+"""_pcandw1ph_nogbd_r000_wh.sor_cd ", 
       "select trim(bhi_home_plan_id) , trim(sor_cd), trim(sor_desc) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc",
       "bcbsa_trcblty_rfrnc","bhi_home_plan_id, sor_cd, sor_desc",sc)

    //assert(1 == 1)
    
  } */

   


}