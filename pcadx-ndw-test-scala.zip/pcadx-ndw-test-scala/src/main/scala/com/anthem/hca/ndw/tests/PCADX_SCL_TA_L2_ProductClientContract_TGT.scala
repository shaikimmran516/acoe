package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession

import org.apache.spark.sql.SparkSession
import java.io.File
import org.apache.spark.sql.DataFrame
import com.anthem.hca.ndw.utils.PCADX_SCL_TA_Utilities._
import java.text.SimpleDateFormat
import org.apache.spark.sql.SaveMode
import java.util.Calendar
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel
import java.util.Date
import java.text.SimpleDateFormat



object PCADX_SCL_TA_L2_ProductClientContract_TGT {



def main(args: Array[String]) {



val dbname: String = args(0)
val SUBJ_AREA_NM: String=args(1)
val PRCS_NM: String=args(2)


val appName = "Datapipe from L2 cases for PCC" // we will make this generic going forward

val warehouseLocation = new File("/user/hive/warehouse").getAbsolutePath
val options = Map("path" -> "/user/hive/warehouse")

val spark = SparkSession
.builder()
.appName(appName)
.config("spark.sql.warehouse.dir", warehouseLocation)
.enableHiveSupport()
.getOrCreate()

spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode","INFER_ONLY")
spark.conf.set("spark.sql.crossJoin.enabled","true")

import spark.implicits._
val home_plan_id =spark.sql("select distinct bhi_home_plan_id from "+dbname+"_pcandw1ph_nogbd_r000_wh.bot_bcbsa_plan_sbmsn")
val  home_plan=home_plan_id.select("bhi_home_plan_id").collect().map(_(0)).toList

val totalDataSet=spark.sql("select * from "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct")
val error303CheckDfList: List[DataFrame] = error303Check(spark, totalDataSet, List( "SIC_CD", "MBR_ENRLMNT_IND"))
val error303Df = error303CheckDfList(1)

val err306ChkDtls = List(Map("SIC_CD" -> (dbname+"_pcandw1ph_nogbd_r000_in", "RFRNC_BCBSA_INDSTRY_GRPG_SIC_CD_INBND", "indstry_grpg_sic_cd")))
val error306CheckDfList = error306CheckColLevel(spark, totalDataSet, err306ChkDtls, 1)
val error306Df = error306CheckDfList(1)
val error307CheckDfListn1 = errorCheck307(spark, totalDataSet, List("MBR_ENRLMNT_IND"), List("BHI_HOME_PLAN_ID", "Home_Plan_Prod_ID", "ACCT_ID", "GRP_ID", "SUBGRP_ID"))
val error307Dfn1 = error307CheckDfListn1(1)
val error=error303Df.union(error306Df).union(error307Dfn1).distinct.createOrReplaceTempView("pcc")


spark.sql("select ME.*,b.bhi_home_plan_id FROM pcc ME  join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct b on  ME.err_id=b.err_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Error")

spark.sql("select count(*) CNT ,b.bhi_home_plan_id FROM (select distinct err_id from pcc) ME  join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct b on  ME.err_id=b.err_id group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("TotalError")

spark.sql("SELECT count(*) as CNT,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Total")

spark.sql(" select SUM(CASE WHEN SEL.grp_id ='INDIVIDUAL' THEN  SEL.CNT ELSE 0 END) AS A,  SUM(CASE WHEN SEL.sic_cd IN ('99','9999') THEN  SEL.CNT ELSE 0 END) AS B,  SUM(CASE WHEN SEL.mbr_enrlmnt_ind='N' THEN  SEL.CNT ELSE 0 END) AS C,bhi_home_plan_id   FROM  (  SELECT 1 AS CNT, grp_id, sic_cd, mbr_enrlmnt_ind,bhi_home_plan_id FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  WHERE      (grp_id ='INDIVIDUAL' OR sic_cd IN ('99','9999') OR mbr_enrlmnt_ind='N')   ) SEL group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("PCCDetails")



// Rule 1-4
home_plan.foreach(bhi_home_plan_id => {

val sqlbshow=" select a.CNT*100/(b.CNT) as PRODClntContract12  FROM  (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err FH where   bhi_home_plan_id='"+bhi_home_plan_id +"'   ) a join (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b    "

val sqlb=" select a.CNT*100/(b.CNT) as PRODClntContract12  FROM  (  SELECT  CNT  FROM TotalError FH where   bhi_home_plan_id='"+bhi_home_plan_id +"'   ) a join (  SELECT  CNT  FROM Total FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b    "


var b=spark.sql(sqlb).withColumn("sql",lit(sqlbshow))


//Rule 5


val sqlashow = "select PRODClntContractEntrolInd15*100/Total_CNT as PRODClntContractEntrolInd15,PRODClntContractSic13*100/Total_CNT as PRODClntContractSic13 from  (select  SUM(CASE WHEN lower(clmn_nm)='mbr_enrlmnt_ind' THEN 1 ELSE 0 END) AS PRODClntContractEntrolInd15,  SUM(CASE WHEN lower(clmn_nm)='sic_cd' THEN 1 ELSE 0 END) AS PRODClntContractSic13 from pcc a join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct b on  a.err_id=b.err_id where  lower(clmn_nm) in  ('mbr_enrlmnt_ind', 'sic_cd')  and  bhi_home_plan_id='"+bhi_home_plan_id +"') SEL  cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct FH where    bhi_home_plan_id='"+bhi_home_plan_id +"') total"

val sqla = "select PRODClntContractEntrolInd15*100/Total_CNT as PRODClntContractEntrolInd15,PRODClntContractSic13*100/Total_CNT as PRODClntContractSic13 from  (select  SUM(CASE WHEN lower(clmn_nm)='mbr_enrlmnt_ind' THEN 1 ELSE 0 END) AS PRODClntContractEntrolInd15,  SUM(CASE WHEN lower(clmn_nm)='sic_cd' THEN 1 ELSE 0 END) AS PRODClntContractSic13 from Error where  lower(clmn_nm) in  ('mbr_enrlmnt_ind', 'sic_cd')  and  bhi_home_plan_id='"+bhi_home_plan_id +"') SEL  cross join (SELECT CNT as Total_CNT  FROM Total FH where    bhi_home_plan_id='"+bhi_home_plan_id +"') total"

var a=spark.sql(sqla).withColumn("sql",lit(sqlashow))



//Rule 6-9

val sqlcshow = "SELECT 1 as dummy, (B-A)*100/Total_CNT as PRODClntContractSic14,  C*100/Total_CNT as PRODClntContractEnrolInd16 from ( select SUM(CASE WHEN SEL.grp_id ='INDIVIDUAL' THEN  SEL.CNT ELSE 0 END) AS A,  SUM(CASE WHEN SEL.sic_cd IN ('99','9999') THEN  SEL.CNT ELSE 0 END) AS B,  SUM(CASE WHEN SEL.mbr_enrlmnt_ind='N' THEN  SEL.CNT ELSE 0 END) AS C   FROM  (  SELECT 1 AS CNT, grp_id, sic_cd, mbr_enrlmnt_ind FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  WHERE    bhi_home_plan_id='"+bhi_home_plan_id +"' and  (grp_id ='INDIVIDUAL' OR sic_cd IN ('99','9999') OR mbr_enrlmnt_ind='N')   ) SEL )a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total "

val sqlc = "SELECT 1 as dummy, (B-A)*100/Total_CNT as PRODClntContractSic14,  C*100/Total_CNT as PRODClntContractEnrolInd16 from ( select * from PCCDetails where bhi_home_plan_id='"+bhi_home_plan_id +"' ) a cross join (SELECT CNT as Total_CNT  FROM Total FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total "

val c=spark.sql(sqlc).withColumn("sql",lit(sqlcshow))






val e=output(spark, TestIDGen(spark,ReportOutput(spark,dbname,a).union(ReportOutput(spark,dbname,b)).union(ReportOutput(spark,dbname,c))),SUBJ_AREA_NM,PRCS_NM, bhi_home_plan_id.toString())

e.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_RSLT")
//e(1).write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_SQL")


})



}



}