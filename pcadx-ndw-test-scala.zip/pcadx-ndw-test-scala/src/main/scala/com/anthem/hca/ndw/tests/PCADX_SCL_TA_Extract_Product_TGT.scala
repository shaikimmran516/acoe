package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import java.util.Date
import java.text.SimpleDateFormat

object PCADX_SCL_TA_Extract_Product_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_Product_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}


class PCADX_SCL_TA_Extract_Product_TGT(dbname : String, env: String) extends FunSuite {

     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
  
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql

      val subj = "Extract"
      val prcss = "Product"
  
  
   
  
  test("ProductExtract -Validate One record for each BHI Home Plan ID and Home Product ID- 001") {
    
      val id = Array("001")
      val name = Array("Test case : Validate One record for each BHI Home Plan ID and Home Product ID")
     
     
    val result = sqlContext.sql("""select bhi_home_plan_id ,home_plan_prod_id,count(*) as count from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod group by bhi_home_plan_id,home_plan_prod_id""")
    result.createOrReplaceTempView("resultDF")
    
    val invalid = sqlContext.sql("""select * from resultDF where count > 1 """)
    
    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id ,home_plan_prod_id,count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod group by bhi_home_plan_id,home_plan_prod_id) where count > 1")
      val data = Array("'BHI HPID','PRODUCT_ID','COUNT'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id ,home_plan_prod_id,count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod group by bhi_home_plan_id,home_plan_prod_id")
      val data = Array("'BHI HPID','PRODUCT_ID','COUNT'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    }

  }

  //===========================================
  
  
  test("ProductExtract -Validate that all the records have the correct [BHI Home Plan ID] as per Anthem - 002") {
    
    val id = Array("002")
    val name = Array("Test case : Validate that all the records have the correct [BHI Home Plan ID] as per Anthem")
     
      
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,err_id,exclsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod where
    bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748')  """)
    
    //val result1 = sqlContext.sql("""""")
     
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') ")
      val data = Array("'BHI HPID','PRODUCT_ID','ERR_ID','EXCLSN_ID'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') ")
      val data = Array("'BHI HPID','PRODUCT_ID','ERR_ID','EXCLSN_ID' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
  
   test("ProductExtract -Check Product Category values not located in reference table - 003") {

     val id = Array("003")
      val name = Array("Test case : Check Product Category values not located in reference table")
     
   
    val result1 = sqlContext.sql("""select distinct bhi_prod_catgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod """)

    val result2 = sqlContext.sql("""select distinct bhi_prod_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_prod_ctgry_inbnd""")

    val result = result1.except(result2)
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct bhi_prod_catgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where err_id = '0' and exclsn_ind = 0  and bhi_prod_catgry_cd not in (select distinct bhi_prod_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_prod_ctgry_inbnd) ")
      val data = Array("'Invalid PRODUCT_CATEGORY'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
     val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct bhi_prod_catgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where err_id = '0' and exclsn_ind = 0  and bhi_prod_catgry_cd not in (select distinct bhi_prod_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_prod_ctgry_inbnd) ")
      val data = Array("'PRODUCT_CATEGORY' : No Invalid values Found")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
   
   //===========================================
  

  test("ProductExtract -Validate that BHI Home Plan ID is not NULL or contains blank spaces  - 004") {
    
    val id = Array("004")
      val name = Array("Test case : Validate that BHI Home Plan ID is not NULL or contains blank spaces")
     
         val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod
        where length(trim(regexp_replace(coalesce(bhi_home_plan_id, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }  
  
  //===========================================

  test("ProductExtract -Validate that HomePlan ProductID field is not NULL or contains blank spaces  - 005") {
    
    val id = Array("005")
      val name = Array("Test case : Validate that HomePlan ProductID field is not NULL or contains blank spaces")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod
        where length(trim(regexp_replace(coalesce(home_plan_prod_id, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where length(trim(regexp_replace(coalesce(home_plan_prod_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
        val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where length(trim(regexp_replace(coalesce(home_plan_prod_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }  
  
  //===========================================
  
 
  test("ProductExtract -Validate that BHI ProductCategory field is not NULL or contains blank spaces - 006") {
  
    val id = Array("006")
    val name = Array("Test case : Validate that BHI ProductCategory field is not NULL or contains blank spaces")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,bhi_prod_catgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod
        where length(trim(regexp_replace(coalesce(bhi_prod_catgry_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,bhi_prod_catgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where length(trim(regexp_replace(coalesce(bhi_prod_catgry_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID','PRODUCT_CATEGORY'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
        val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,bhi_prod_catgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where length(trim(regexp_replace(coalesce(bhi_prod_catgry_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID','PRODUCT_CATEGORY' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    
  }
    
  //===========================================
  
  test("ProductExtract -Validate that Traceability field is not NULL or contains blank spaces- 007") {
    
    val id = Array("007")
      val name = Array("Test case : Validate that Traceability field is not NULL or contains blank spaces")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,sor_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod
        where length(trim(regexp_replace(coalesce(sor_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where length(trim(regexp_replace(coalesce(sor_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID','TRACEABILITY' ")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where length(trim(regexp_replace(coalesce(sor_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID','TRACEABILITY' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  //===========================================

  test("ProductExtract -Validate that  BHI Home Plan ID does not contain Special Characters - 008") {
    
    val id = Array("008")
      val name = Array("Test case : Validate that  BHI Home Plan ID does not contain Special Characters")
         
    val result1 = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a
      where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%'""")
    
            
    if (result1.count > 0) {
      val a = result1.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%' ")
      val data = Array("'BHI HPID','PRODUCT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%' ")
      val data = Array("'BHI HPID','PRODUCT_ID' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  
  
  //===========================================
  
  test("ProductExtract -Validate that HomePlan ProductID field does not contain Special Characters - 009") {
    
    val id = Array("009")
      val name = Array("Test case : Validate that HomePlan ProductID field does not contain Special Characters")
     
    val result1 = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a
      where a.home_plan_prod_id  LIKE '%[^A-z0-9]%' limit 10""")
    
            
    if (result1.count > 0) {
      val a = result1.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a where a.home_plan_prod_id  LIKE '%[^A-z0-9]%' limit 10")
      val data = Array("'BHI HPID','PRODUCT_ID'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a where a.home_plan_prod_id  LIKE '%[^A-z0-9]%' limit 10")
      val data = Array("'BHI HPID','PRODUCT_ID' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
  
  test("ProductExtract -Validate that HomePlan ProductName field does not contain DoubleQuotes SpecialChar - 010") {
    
    val id = Array("010")
      val name = Array("Test case : Validate that HomePlan ProductName field does not contain DoubleQuotes SpecialChar")
             
    val result1 = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,home_plan_prod_nm from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a
      where a.home_plan_prod_nm  LIKE '%"%' limit 10""")
    
        
    if (result1.count > 0) {
      val a = result1.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : elect bhi_home_plan_id,home_plan_prod_id,home_plan_prod_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a where a.home_plan_prod_nm  LIKE '%<double quote>%' limit 10")
      val data = Array("'BHI HPID','PRODUCT_ID','PRODUCT_NAME'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : elect bhi_home_plan_id,home_plan_prod_id,home_plan_prod_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a where a.home_plan_prod_nm  LIKE '%<double quote>%' limit 10")
      val data = Array("'BHI HPID','PRODUCT_ID','PRODUCT_NAME' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   
   //===========================================

  test("ProductExtract -Validate that BHI ProductCategory field does not contain DoubleQuotes SpecialChar - 011") {
    
    val id = Array("011")
      val name = Array("Test case : Validate that BHI ProductCategory field does not contain DoubleQuotes SpecialChar")
     
    val result1 = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,bhi_prod_catgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a
      where a.bhi_prod_catgry_cd  LIKE '%"%' limit 10""")
    
        
    if (result1.count > 0) {
      val a = result1.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,bhi_prod_catgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a where a.bhi_prod_catgry_cd  LIKE '%<double quote>%' limit 10 ")
      val data = Array("'BHI HPID','PRODUCT_ID','PRODUCT_CATEGORY'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,bhi_prod_catgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a where a.bhi_prod_catgry_cd  LIKE '%<double quote>%' limit 10 ")
      val data = Array("'BHI HPID','PRODUCT_ID','PRODUCT_CATEGORY' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  

   //===========================================
  
  test("ProductExtract -Validate that Traceability field does not contain Special Characters - 012") {
    
    val id = Array("012")
      val name = Array("Test case : Validate that Traceability field does not contain Special Characters")
     
    val result1 = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,sor_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a
      where a.sor_cd  like '%[^A-z0-9]%' limit 10""")
    
            
    if (result1.count > 0) {
      val a = result1.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a where a.sor_cd  like '%[^A-z0-9]%' limit 10")
      val data = Array("'BHI HPID','PRODUCT_ID','TRACEABILITY'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a where a.sor_cd  like '%[^A-z0-9]%' limit 10")
      val data = Array("'BHI HPID','PRODUCT_ID','TRACEABILITY' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  
  //===========================================
  
  test("ProductExtract - Validate that Home Plan Product ID column is populated  as per specified field format - 013") {
   
    val id = Array("013")
      val name = Array("Test case : Validate that Home Plan Product ID column is populated  as per specified field format")
     
    val result1 = sqlContext.sql(""" select distinct prod_cf_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa""")
    val result2 = sqlContext.sql(""" select distinct home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod """)
        
    val result = result2.except(result1)
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where home_plan_prod_id not in (select distinct prod_cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa)")
      val data = Array("'Invalid PRODUCT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where home_plan_prod_id not in (select distinct prod_cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa)")
      val data = Array("'PRODUCT_ID' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that Home Plan Product Name column is populated  as per specified field format - 014") {
    
    val id = Array("014")
      val name = Array("Test case : Validate that Home Plan Product Name column is populated  as per specified field format")
     
    val result1 = sqlContext.sql(""" select distinct gl_cf_desc from """+dbname+"""_pcandw1ph_nogbd_r000_in.gl_cf_hrzntl_hrchy """)
    
    val result2 = sqlContext.sql(""" select distinct home_plan_prod_nm from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod """)
        
    val result = result2.except(result1)
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct home_plan_prod_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where err_id = '0' and exclsn_ind = 0 and home_plan_prod_nm not in (select distinct gl_cf_type_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_hrzntl_hrchy) ")
      val data = Array("'Invalid HomePlan_ProductName'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct home_plan_prod_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where err_id = '0' and exclsn_ind = 0 and home_plan_prod_nm not in (select distinct gl_cf_type_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_hrzntl_hrchy) ")
      val data = Array("'HomePlan_ProductName' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that NDW Product Category column is populated  as per specified field format - 015") {
   
    val id = Array("015")
      val name = Array("Test case : Validate that NDW Product Category column is populated  as per specified field format")
     
    val result1 = sqlContext.sql(""" select distinct hlth_prod_srvc_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.prod """)
    val result2 = sqlContext.sql(""" select distinct bhi_prod_catgry_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod where err_id = '0' and exclsn_ind = 0""")
        
    val result = result2.except(result1)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct bhi_prod_catgry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where err_id = '0' and exclsn_ind = 0 and bhi_prod_catgry_cd not in (select distinct hlth_prod_srvc_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.prod)")
      val data = Array("'Invalid Product_Category'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct bhi_prod_catgry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where err_id = '0' and exclsn_ind = 0 and bhi_prod_catgry_cd not in (select distinct hlth_prod_srvc_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.prod)")
      val data = Array("'Product_Category' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that Traceability Field is populated appropriately in the extract table - 016") {
   
    val id = Array("016")
      val name = Array("Test case : Validate that Traceability Field is populated appropriately in the extract table")
     
    val result1 = sqlContext.sql(""" select distinct sor_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc """)
    val result2 = sqlContext.sql(""" select distinct sor_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod where err_id = '0' and exclsn_ind = 0""")
        
    val result = result2.except(result1)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct sor_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where err_id = '0' and exclsn_ind = 0 and sor_cd not in (select distinct prod_sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.prod)")
      val data = Array("'Invalid Traceability'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct sor_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where err_id = '0' and exclsn_ind = 0 and sor_cd not in (select distinct prod_sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.prod)")
      val data = Array("'Traceability' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that the Product extract includes Blue Plan products - 017") {
    
    val id = Array("017")
      val name = Array("Test case : Validate that the Product extract includes Blue Plan products")
     
    val result = sqlContext.sql(""" select a.* from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join 
      (select distinct cf_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_type_desc =  'BRANDSTATE' and gl_lvl_desc LIKE 'BLUE%') b 
      where a.mbu_cf_cd  = b.cf_cd""")

                
    if (result.count < 1) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_type_desc =  'BRANDSTATE' and gl_lvl_desc LIKE 'BLUE%') b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Product extracts does not contain Blue Plan Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_type_desc =  'BRANDSTATE' and gl_lvl_desc LIKE 'BLUE%') b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Blue Plan Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that the Product extract includes Commercial Products - 018") {
    
    val id = Array("018")
      val name = Array("Test case : Validate that the Product extract includes Commercial Products")
     
    val result = sqlContext.sql(""" select a.* from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join 
      (select distinct cf_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc ='COMMERCIAL BUSINESS' or gl_lvl_desc = 'COMMERCIAL BUSINESS' and gl_cf_type_desc =  'OPERATING_UNIT' ) b 
      where a.mbu_cf_cd  = b.cf_cd""")

            
    if (result.count < 1) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc ='COMMERCIAL BUSINESS' or gl_lvl_desc = 'COMMERCIAL BUSINESS' and gl_cf_type_desc =  'OPERATING_UNIT' ) b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Product extracts does not contain Commercial Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc ='COMMERCIAL BUSINESS' or gl_lvl_desc = 'COMMERCIAL BUSINESS' and gl_cf_type_desc =  'OPERATING_UNIT' ) b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Commercial Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that the Product extract includes Pharmacy PPO product in Product Name - 019") {
    
    val id = Array("019")
    val name = Array("Test case : Validate that the Product extract includes Pharmacy PPO product in Product Name")
        
    val result = sqlContext.sql(""" select distinct home_plan_prod_nm from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_PROD where home_plan_prod_nm like '%PHARMACY PPO%' limit 10""")
    
            
    if (result.count < 1) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct home_plan_prod_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_PROD where home_plan_prod_nm like '%PHARMACY PPO%' limit 10")
      val data = Array("'Product extracts does not contain Pharmacy PPO Product in Product name Field'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
     val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct home_plan_prod_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_PROD where home_plan_prod_nm like '%PHARMACY PPO%' limit 10")
      val data = Array("'Pharmacy PPO Product'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that the Product extract includes PPO product Code in Product Category - 020") {
    
    val id = Array("020")
      val name = Array("Test case : Validate that the Product extract includes PPO product Code in Product Category")
     
    val result = sqlContext.sql(""" select distinct bhi_prod_catgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod  where bhi_prod_catgry_cd  = 'PPO' limit 10""")
    
            
    if (result.count < 1) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct bhi_prod_catgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod  where bhi_prod_catgry_cd  = 'PPO' limit 10")
      val data = Array("'Product extracts does not contain PPO Product Code in Product Category Field'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
     val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct bhi_prod_catgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod  where bhi_prod_catgry_cd  = 'PPO' limit 10")
      val data = Array("'PPO Product Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Vaidate that Product Extract does not contain any data for Federal Employee Program (FEP) - 021") {
    
    val id = Array("021")
      val name = Array("Test case : Vaidate that Product Extract does not contain any data for Federal Employee Program (FEP)")
     
   val result = sqlContext.sql(""" select a.* from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join 
      (select distinct mbu_cf_cbe_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.gl_cf_mbu_cbe_vrtcl_hrchy where gl_cf_desc like '%FEP CBE%' or gl_lvl_desc like '%FEP CBE%') b 
      where a.mbu_cf_cd  = b.mbu_cf_cbe_cd""")

            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct mbu_cf_cbe_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_mbu_cbe_vrtcl_hrchy where gl_cf_desc like '%FEP CBE%' or gl_lvl_desc like '%FEP CBE%') b  where a.mbu_cf_cd  = b.mbu_cf_cbe_cd")
      val data = Array("'Product Extract Contains FEP data")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
     val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct mbu_cf_cbe_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_mbu_cbe_vrtcl_hrchy where gl_cf_desc like '%FEP CBE%' or gl_lvl_desc like '%FEP CBE%') b  where a.mbu_cf_cd  = b.mbu_cf_cbe_cd")
      val data = Array("'Product Extract does not Contains FEP data")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that Product Extract does not contain any worker's comp products - 022") {
   
    val id = Array("022")
      val name = Array("Test case : Validate that Product Extract does not contain any worker's comp products")
     
   val result = sqlContext.sql(""" select a.* from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join 
      (select distinct cf_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%WORKERS%' or gl_lvl_desc like '%WORKERS%' and gl_cf_type_desc =  'CBE' ) b 
      where a.mbu_cf_cd  = b.cf_cd""")
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%WORKERS%' or gl_lvl_desc like '%WORKERS%' and gl_cf_type_desc =  'CBE' ) b  where a.mbu_cf_cd  = b.cf_cd ")
      val data = Array("'Product Extract  Contains Worker's Comp Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
     val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%WORKERS%' or gl_lvl_desc like '%WORKERS%' and gl_cf_type_desc =  'CBE' ) b  where a.mbu_cf_cd  = b.cf_cd ")
      val data = Array("'Product Extract does not Contains Worker's Comp Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that Product Extract does not contain any NEHP products - 023") {
    
    val id = Array("023")
      val name = Array("Test case : Validate that Product Extract does not contain any NEHP products")
     
    val result = sqlContext.sql(""" select a.* from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join 
      (select distinct cf_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%NEHP%' or gl_lvl_desc like '%NEHP%' and gl_cf_type_desc =  'PRODUCT' ) b 
      where a.mbu_cf_cd  = b.cf_cd""")
   
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%NEHP%' or gl_lvl_desc like '%NEHP%' and gl_cf_type_desc =  'PRODUCT' ) b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Product Extract Contains NEHP Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
     val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%NEHP%' or gl_lvl_desc like '%NEHP%' and gl_cf_type_desc =  'PRODUCT' ) b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Product Extract doe not Contains NEHP Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that Product Extract does not contain any  Fedral program products - 024") {
    
    val id = Array("024")
      val name = Array("Test case : Validate that Product Extract does not contain any  Fedral program products")
     
     val result = sqlContext.sql(""" select a.* from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join 
      (select distinct cf_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%TRICARE%' or gl_lvl_desc Like '%TRICARE%' and gl_cf_type_desc in ('CBE','OPERATING_UNIT') ) b 
      where a.mbu_cf_cd  = b.cf_cd""")
   
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%TRICARE%' or gl_lvl_desc Like '%TRICARE%' and gl_cf_type_desc in ('CBE','OPERATING_UNIT') ) b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Product Extract Contains Fedral Program Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%TRICARE%' or gl_lvl_desc Like '%TRICARE%' and gl_cf_type_desc in ('CBE','OPERATING_UNIT') ) b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Product Extract does not Contains Fedral Program Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that Product Extract does not contain any  Unicare products  - 025") {
    
    val id = Array("025")
      val name = Array("Test case : Validate that Product Extract does not contain any  Unicare products")
        
    val result = sqlContext.sql(""" select a.* from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join 
      (select distinct cf_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%UNICARE%' or gl_lvl_desc Like '%UNICARE%' and gl_cf_type_desc  = 'OPERATING_UNIT' ) b 
      where a.mbu_cf_cd  = b.cf_cd""")
          
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%UNICARE%' or gl_lvl_desc Like '%UNICARE%' and gl_cf_type_desc  = 'OPERATING_UNIT' ) b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Product Extract Contains Unicare Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%UNICARE%' or gl_lvl_desc Like '%UNICARE%' and gl_cf_type_desc  = 'OPERATING_UNIT' ) b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Product Extract does not Contains Unicare Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that Product Extract does not contain any  Healthlink products  - 026") {
    
    val id = Array("026")
      val name = Array("Test case : Validate that Product Extract does not contain any  Healthlink products")
     
     val result = sqlContext.sql(""" select a.* from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join 
      (select distinct cf_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where  gl_lvl_desc = 'HEALTHLINK CBE') b 
      where a.mbu_cf_cd  = b.cf_cd""")
               
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where  gl_lvl_desc = 'HEALTHLINK CBE') b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Product Extract Contains HealthLink Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.* from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where  gl_lvl_desc = 'HEALTHLINK CBE') b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Product Extract does not Contains HealthLink Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that Product Extract does not contain any medicare products for which they are primary or secondary. This includes Medicare Cost, Medicare Advantage, Medicare Supplemental - 027") {
    
    val id = Array("027")
      val name = Array("Test case : Validate that Product Extract does not contain any medicare products for which they are primary or secondary. This includes Medicare Cost, Medicare Advantage, Medicare Supplemental")
     
    val result = sqlContext.sql(""" Select * from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod where home_plan_prod_id  IN('MFFSR','MHLCM','MHLMA','MHLOA','MHMSN','MPLMA','MPPMA',
      'PFFSR','PHMSN','PMDFF','PMDGZ','PMDHL','PMDPL','PMDPP','PMDSN','PPPMA','PWDGZ','PWDHL','PWDPL') """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : Select * from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where home_plan_prod_id  IN('MFFSR','MHLCM','MHLMA','MHLOA','MHMSN','MPLMA','MPPMA','PFFSR','PHMSN','PMDFF','PMDGZ','PMDHL','PMDPL','PMDPP','PMDSN','PPPMA','PWDGZ','PWDHL','PWDPL')")
      val data = Array("'Product Extract Contains Medicare Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : Select * from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where home_plan_prod_id  IN('MFFSR','MHLCM','MHLMA','MHLOA','MHMSN','MPLMA','MPPMA','PFFSR','PHMSN','PMDFF','PMDGZ','PMDHL','PMDPL','PMDPP','PMDSN','PPPMA','PWDGZ','PWDHL','PWDPL')")
      val data = Array("'Product Extract doe not Contains Medicare Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that Product Extract shall not contain any Medicaid Programs for which they are primary or secondary - 028") {
   
    val id = Array("028")
      val name = Array("Test case : Validate that Product Extract shall not contain any Medicaid Programs for which they are primary or secondary")
     
    val result = sqlContext.sql(""" select a.* from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join 
      (select distinct cf_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%MEDICAID%' or gl_lvl_desc Like '%MEDICAID%' and gl_cf_type_desc  = 'PRODUCT') b 
      where a.mbu_cf_cd  = b.cf_cd""")
      
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select a.* from '''+dbname+''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%MEDICAID%' or gl_lvl_desc Like '%MEDICAID%' and gl_cf_type_desc  = 'PRODUCT') b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Product Extract Contains Medicaid Program Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
   } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.* from '''+dbname+''_pcandw1ph_nogbd_r000_ou.bcbsa_prod a inner join (select distinct cf_cd from '''+dbname+''_pcandw1ph_nogbd_r000_in.gl_cf_vrtcl_hrchy where gl_cf_desc like '%MEDICAID%' or gl_lvl_desc Like '%MEDICAID%' and gl_cf_type_desc  = 'PRODUCT') b  where a.mbu_cf_cd  = b.cf_cd")
      val data = Array("'Product Extract does not Contains Medicaid Program Products'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
   //===========================================
  
  test("ProductExtract - Validate that there are 14 BHI Home Plan ID  - 029 ") {
    
    val id = Array("029")
     val name = Array("Test case : Validate that there are 14 BHI Home Plan ID ")
     
    val result = sqlContext.sql(""" select count(distinct bhi_home_plan_id) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod """)
    
        
    if (result.collectAsList.toString.contains("14")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Product/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
  
  /*
   test("ProductExtract - Validate Source and Target table - 001") {
  
   val id = Array("NCEPD001")
   val name = Array("Test case : Validate Source and Target table")
     
    ExcelTableValidation.tableCompare("select trim(a.bhi_home_plan_id), trim(b.prod_cf_cd),  trim(b.prod_cf_desc), trim(c.hlth_prod_srvc_type_cd ), trim(c.prod_sor_cd ) from ts_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_home_plan_cd_xwalk_inbnd a  inner join ts_pcandw1ph_nogbd_r000_wh.all_mbr b on trim(a.mbu_cf_cd) = trim(b.mbu_cf_cd)  and trim(a.cmpny_chrt_fld_cd) = trim(b.cmpny_cf_cd) inner join ts_pcandw1ph_nogbd_r000_wh.all_prod c on trim(b.prod_ofrg_key) = trim(c.prod_ofrg_key)", 
       "select trim(bhi_home_plan_id) , trim(home_plan_prod_id), trim(home_plan_prod_nm), trim(bhi_prod_catgry_cd ), trim(sor_cd) from ts_pcandw1ph_nogbd_r000_ou.bcbsa_prod",
       "bcbsa_prod","bhi_home_plan_id, home_plan_prod_id, home_plan_prod_nm, bhi_prod_catgry_cd, sor_cd",sc)

    //assert(1 == 1)
    
  } */
  
  //===========================================
  
   
}