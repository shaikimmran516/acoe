package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Extract_Pharmacy_TGT {
 
  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_Pharmacy_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}


 class PCADX_SCL_TA_Extract_Pharmacy_TGT(dbname : String, env: String) extends FunSuite {
   
     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
     
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Extract"
      val prcss = "Pharmacy"
   
   test("ClaimPharmacyExtract -Validated NULL or blank spaces checks for all Columns - 001") {
    val id = Array("001")
    val name = Array("Test case : Validated NULL or blank spaces checks for all Columns")
    
    
    
    val col_name = Array("bhi_home_plan_id",
    "clm_id",
    "trcblty_fld_cd",
    "adjstmnt_sqnc_nbr",
    "host_plan_id",
    "home_plan_prod_id",
    "acct_cd",
    "grp_cd",
    "subgrp_cd",
    "mbr_id",
    "clm_mbr_cntry_cd")

  val i = 0;

  for( i <- 0 to 10){
  val k = col_name(i)
	val result = sqlContext.sql(f"""select bhi_home_plan_id, clm_id, trcblty_fld_cd, $k from """+dbname+f"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where length(trim(regexp_replace(coalesce($k, "")," ", "")))=0 """)
     
	if (result.count > 0) {
      println(f" $k -- Failed")
    } else {
      println(f" $k -- Success")
    }
     
    }
 }
    
  //===========================================
 
   test("ClaimPharmacyExtract -Validated Special Character checks for key Columns - 002") {
    val id = Array("002")
    val name = Array("Test case : Validated Special Character checks for key Columns")
    
    val col_name = Array("bhi_home_plan_id",
    "clm_id",
    "clm_line_nbr",
    "trcblty_fld_cd")

    val i = 0;

    for( i <- 0 to 3){
    val k = col_name(i)
	  val result = sqlContext.sql(f"""select bhi_home_plan_id, clm_id, trcblty_fld_cd from """+dbname+f"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where $k RLIKE '[^A-z0-9]' """)
      
	  if (result.count > 0) {
     println(f" $k -- Failed")
    } else {
       println(f" $k -- Success")
    }
     
    }
 }
 
  //===========================================
   
    test("ClaimPharmacyExtract -Validated Double QuoteCharacter checks for other Columns - 003") {
    val id = Array("003") 
    val name = Array("Test case : Validated Double Quote Character checks for other Columns")
    
    val col_name = Array("adjstmnt_sqnc_nbr",
"host_plan_id",
"home_plan_prod_id",
"acct_cd",
"grp_cd",
"subgrp_cd",
"mbr_id",
"clm_mbr_zip_cd",
"clm_mbr_cntry_cd",
"billg_prov_id",
"npi_billg_prov_id",
"billg_prov_spclty_cd",
"pcp_prov_id",
"npi_pcp_prov_id",
"rndrg_prov_id",
"npi_rndrg_prov_id",
"rndrg_prov_spclty_cd",
"rndrg_prov_type_cd",
"prscrbg_prov_id",
"npi_prscrbg_prov_id",
"bsis_of_reimbmnt_dtrmntn_cd",
"bnft_paymnt_stts_cd",
"phrmcy_crv_out_sbmsn_ind",
"ctgry_of_srvc_cd",
"clm_paymnt_stts_cd",
"cmpnd_cd",
"daw_cd",
"days_sply_nbr",
"dspnsg_stts_cd",
"frmlry_ind",
"plan_spclty_drgind",
"prmry_non_cvrd_rsn_cd",
"othr_cvrg_cd",
"phrmcy_bnfts_mngr_cd",
"plos_cd",
"prod_srvc_id",
"qty_dspnsd_nbr",
"sbmsn_type_cd",
"adjdctd_dt",
"clm_paid_dt",
"srvc_dt",
"alwd_amt",
"non_cvrd_amt",
"paymnt_amt",
"sbmtd_amt",
"aplyd_periodic_ddctbl_amt",
"atrbd_prod_slctn_amt",
"atrbd_sales_tax_amt",
"cpay_coinsrn_amt",
"awp_sbmtd_amt",
"dspnsg_fee_paid_amt",
"flat_sales_tax_paid_amt",
"incntv_paid_amt",
"ingred_cost_paid_amt",
"othr_amt_paid_amt",
"rcgnzd_othr_payor_amt",
"pat_pay_amt",
"pctag_sales_tax_paid_amt",
"totl_paid_amt")

  val i = 0;

  for( i <- 0 to 58){
  val k = col_name(i)
	val result = sqlContext.sql(f"""select bhi_home_plan_id, clm_id, trcblty_fld_cd, $k from """+dbname+f"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where $k RLIKE '"' """)
      
	if (result.count > 0) {
     println(f" $k -- Failed")
    } else {
      println(f" $k -- Success")
    }
     
    }
 }
 
  //===========================================
    
  test("ClaimPharmacyExtract -Validate that all the records have the correct [BHI Home Plan ID] as per Anthem - 004") {
    val id = Array("004")
    val name = Array("Test case : Validate that all the records have the correct [BHI Home Plan ID] as per Anthem")

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, trcblty_fld_cd, err_id, exclsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where
    bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') """)
     
        
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') ")
      val data = Array("'BHI HPID','Claim_ID','Traceability','ERR_ID','EXCLSN_ID")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
      
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') ")
      val data = Array("'BHI HPID','Claim_ID','Traceability','ERR_ID','EXCLSN_ID : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    }

  }

  //===========================================
  
   test("ClaimPharmacyExtract -Validate One record for each BHI Home Plan ID, Claim ID, Claim Line Number & Traceability - 005") {
    
    val id = Array("005")
    val name = Array("Test case : Validate One record for each BHI Home Plan ID, Claim ID, Claim Line Number & Traceability")

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, count(*) as count from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm group by bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd""")
    result.createOrReplaceTempView("resultDF")
    
    val invalid = sqlContext.sql("""select * from resultDF where count > 1 """)
    
    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm group by bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd) where count > 1 ")
      val data = Array("'BHI HPID','Claim_ID','Claim Line Number','Traceability','COUNT'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
      } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm group by bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd")
      val data = Array("'BHI HPID','Claim_ID','Claim Line Number','Traceability','COUNT' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    }

  }

  //===========================================
  
   test("ClaimPharmacyExtract -Validate that Claim Line Number should not be less than 000 or greater than 999 - 006") {
    val id = Array("006")
    val name = Array("Test case : Validate that Claim Line Number should not be less than 000 or greater than 999")

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where
    clm_line_nbr < 000 OR clm_line_nbr > 999  """)
     
        
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where clm_line_nbr < 000 OR clm_line_nbr > 999 ")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','ERR_ID','EXCLSN_ID'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where clm_line_nbr < 000 OR clm_line_nbr > 999 ")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','ERR_ID','EXCLSN_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  //===========================================
   
   test("ClaimPharmacyExtract -Validate that BHI Home Plan ID + Traceability is present in Traceability Table - 007") {
    val id = Array("007")
    val name = Array("Test case : Validate that BHI Home Plan ID + Traceability is present in Traceability Table ")

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(trcblty_fld_cd))) as CONCAT_TGT from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(trcblty_fld_cd))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc)")
      val data = Array("'Home_Plan_Id + Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(trcblty_fld_cd))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc)")
      val data = Array("'Home_Plan_Id + Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
  
   test("ClaimPharmacyExtract -Validate that Host Plan ID is present in Reference table - 008") {
    val id = Array("008")
    val name = Array("Test case : Validate that Host Plan ID is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(host_plan_id_cd )) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_host_plan_id_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(host_plan_id))  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(host_plan_id))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and trim(host_plan_id) not in (select distinct (trim(host_plan_id_cd )) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_host_plan_id_inbnd )")
      val data = Array("'Host_Plan_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(host_plan_id))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and trim(host_plan_id) not in (select distinct (trim(host_plan_id_cd )) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_host_plan_id_inbnd )")
      val data = Array("'Invalid Host_Plan_ID'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimPharmacyExtract -Validate that BHI Home Plan ID + Home Plan Product ID is present in Product Table - 009") {
    val id = Array("009")
    val name = Array("Test case : Validate that BHI Home Plan ID + Home Plan Product ID is present in Product Table")

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_SRC from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_TGT from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimPharmacyExtract -Validate that BHI Home Plan ID + Home Plan Product ID + Account ID + Group + SubGroup is present in PCC Table - 010") {
    val id = Array("010")
    val name = Array("Test case : Validate that BHI Home Plan ID + Home Plan Product ID + Account ID + Group + SubGroup is present in PCC Table")

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_id) ,  trim(grp_id) ,  trim(subgrp_id))) as CONCAT_SRC from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_cd) ,  trim(grp_cd) ,  trim(subgrp_cd))) as CONCAT_TGT from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_cd) ,  trim(grp_cd) ,  trim(subgrp_cd))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_id) ,  trim(grp_id) ,  trim(subgrp_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID + Account + Group + SubGroup' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_cd) ,  trim(grp_cd) ,  trim(subgrp_cd))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_id) ,  trim(grp_id) ,  trim(subgrp_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID + Account + Group + SubGroup'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
  test("ClaimPharmacyExtract -Validate SubGroup='NOSUB' if Group='NOGRP' - 011") {
    val id = Array("011")
    val name = Array("Test case : Validate SubGroup='NOSUB' if Group='NOGRP'")

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, subgrp_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where grp_cd='NOGRP' and subgrp_cd!='NOSUB'""")
     
      
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, subgrp_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where grp_cd='NOGRP' and subgrp_cd!='NOSUB'")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','SUB_GROUP'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, subgrp_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where grp_cd='NOGRP' and subgrp_cd!='NOSUB'")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','SUB_GROUP' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    }
    
 }
  
  //===========================================
  
   test("ClaimPharmacyExtract -Validate that BHI Home Plan ID + Home Plan Product ID + Member ID is present in Member Table - 012") {
    val id = Array("012")
    val name = Array("Test case : Validate that BHI Home Plan ID + Home Plan Product ID + Member ID is present in Member Table")
    
    

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id))) as CONCAT_SRC from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id ))) as CONCAT_TGT from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID + Member ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID + Member ID'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimPharmacyExtract -Validate that Member Zip Code is present in Reference table - 013") {
    val id = Array("013")
    val name = Array("Test case : Validate that Member Zip Code is present in Reference table")
    
    

    val result1 = sqlContext.sql("""select distinct (trim(zip_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(clm_mbr_zip_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm """)

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(clm_mbr_zip_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and trim(clm_mbr_zip_cd) not in (select distinct (trim(zip_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd)")
      val data = Array("'Member_Zip_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(clm_mbr_zip_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and trim(clm_mbr_zip_cd) not in (select distinct (trim(zip_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd)")
      val data = Array("'Invalid Member_Zip_Code'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //=========================================== 
  
    test("ClaimPharmacyExtract -Validate that Member Country Code is present in Reference table - 014") {
    val id = Array("014")
    val name = Array("Test case : Validate that Member Country Code is present in Reference table")
    
    

    val result1 = sqlContext.sql("""select distinct (trim(cntry_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(clm_mbr_cntry_cd))  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and clm_mbr_cntry_cd not in ('UN')""")

        
    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(clm_mbr_cntry_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and trim(clm_mbr_cntry_cd) not in (select distinct (trim(cntry_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd)")
      val data = Array("'Member_Country_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(clm_mbr_cntry_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where err_id = '0' and exclsn_ind = 0 and trim(clm_mbr_cntry_cd) not in (select distinct (trim(cntry_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd)")
      val data = Array("'Invalid Member_Country_Code'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
    
    
   test("ClaimPharmacyExtract -Check Billing Provider Specialty Code column has Default/Valid Value - 015") {
    val id = Array("015")
    val name = Array("Test case : Check Billing Provider Specialty Code column has Default/Valid Value")
 
    val result = sqlContext.sql("""select distinct billg_prov_spclty_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(billg_prov_spclty_cd) NOT IN ('A5')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct billg_prov_spclty_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(billg_prov_spclty_cd) NOT IN ('A5')")
      val data = Array("'Billing_Provider_Specialty_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct billg_prov_spclty_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(billg_prov_spclty_cd) NOT IN ('A5')")
      val data = Array("'Invalid Billing_Provider_Specialty_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
   
   test("ClaimPharmacyExtract -Check Rendering Provider Specialty Code column has Default/Valid Value - 016") {
    val id = Array("016")
    val name = Array("Test case : Check Rendering Provider Specialty Code column has Default/Valid Value")
   
    val result = sqlContext.sql("""select distinct rndrg_prov_spclty_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(rndrg_prov_spclty_cd) NOT IN ('A5')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct rndrg_prov_spclty_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(rndrg_prov_spclty_cd) NOT IN ('A5')")
      val data = Array("'Rendering_Provider_Specialty','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct rndrg_prov_spclty_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(rndrg_prov_spclty_cd) NOT IN ('A5')")
      val data = Array("'Invalid Rendering_Provider_Specialty','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
   
   test("ClaimPharmacyExtract -Check Rendering Provider Type Code column has Default/Valid Value - 017") {

    val name = Array("Test case : Check Rendering Provider Type Code column has Default/Valid Value")
    val id = Array("017")
    

    
    val result = sqlContext.sql("""select distinct rndrg_prov_type_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(rndrg_prov_type_cd) NOT IN ('RX')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct rndrg_prov_type_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(rndrg_prov_type_cd) NOT IN ('RX')")
      val data = Array("'Rendering_Provider_Type_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct rndrg_prov_type_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(rndrg_prov_type_cd) NOT IN ('RX')")
      val data = Array("'Invalid Rendering_Provider_Type_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
   
   test("ClaimPharmacyExtract -Validate that Benefit Payment Status Code has Valid Values - 018") {
    val id = Array("018")
    val name = Array("Test case : Validate that Benefit Payment Status Code has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct bnft_paymnt_stts_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where bnft_paymnt_stts_cd NOT IN ('Y','N','O')  """)

            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct bnft_paymnt_stts_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where bnft_paymnt_stts_cd NOT IN ('Y','N','O')")
      val data = Array("'Benefit Payment Status_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct bnft_paymnt_stts_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where bnft_paymnt_stts_cd NOT IN ('Y','N','O')")
      val data = Array("'Invalid Benefit Payment Status_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimPharmacyExtract -Validate that Pharmacy Carve Out Submission Indicator Code has Valid Values - 019") {
    val id = Array("019")
    val name = Array("Test case : Validate that Pharmacy Carve Out Submission Indicator Code has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct phrmcy_crv_out_sbmsn_ind, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where phrmcy_crv_out_sbmsn_ind NOT IN ('Y','N')  """)

            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct phrmcy_crv_out_sbmsn_ind, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where phrmcy_crv_out_sbmsn_ind NOT IN ('Y','N')")
      val data = Array("'Pharmacy_CarveOut_Submission_Indicator_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct phrmcy_crv_out_sbmsn_ind, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where phrmcy_crv_out_sbmsn_ind NOT IN ('Y','N')")
      val data = Array("'Invalid Pharmacy_CarveOut_Submission_Indicator_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimPharmacyExtract -Validate that Category of Service Column has Valid Values - 020") {
    val id = Array("020")
    val name = Array("Test case : Validate that Category of Service Column has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct ctgry_of_srvc_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(ctgry_of_srvc_cd) NOT IN ('PHARM','VOID')  """)

            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct ctgry_of_srvc_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(ctgry_of_srvc_cd) NOT IN ('PHARM','VOID')")
      val data = Array("'Category_of_Service_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct ctgry_of_srvc_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(ctgry_of_srvc_cd) NOT IN ('PHARM','VOID')")
      val data = Array("'Invalid Category_of_Service_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimPharmacyExtract -Validate that Formulary Indicator Code has Valid Values - 021") {
    val id = Array("021")
    val name = Array("Test case : Validate that Formulary Indicator Code has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct frmlry_ind, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(frmlry_ind) NOT IN ('Y','N')  """)

            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct frmlry_ind, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(frmlry_ind) NOT IN ('Y','N')")
      val data = Array("'Formulary_Indicator_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct frmlry_ind, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(frmlry_ind) NOT IN ('Y','N')")
      val data = Array("'Invalid Formulary_Indicator_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
    test("ClaimPharmacyExtract -Validate that Plan Specialty Drug Indicator Code has Valid Values - 022") {
    val id = Array("022")
    val name = Array("Test case : Validate that Plan Specialty Drug Indicator Code has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct plan_spclty_drgind, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(plan_spclty_drgind) NOT IN ('Y','N')  """)

            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct plan_spclty_drgind, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(plan_spclty_drgind) NOT IN ('Y','N') ")
      val data = Array("'Plan_Specialty_Drug_Indicator_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct plan_spclty_drgind, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(plan_spclty_drgind) NOT IN ('Y','N') ")
      val data = Array("'Invalid Plan_Specialty_Drug_Indicator_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
    
    test("ClaimPharmacyExtract -Validate that Place of Servicer Code has Valid Values - 023") {
    val id = Array("023")
    val name = Array("Test case : Validate that Place of Servicer Code has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct plos_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(plos_cd) NOT IN ('01')  """)

            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct plos_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(plos_cd) NOT IN ('01')")
      val data = Array("'Place_of_Service_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct plos_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where trim(plos_cd) NOT IN ('01')")
      val data = Array("'Invalid Place_of_Service_Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
  test("ClaimPharmacyExtract -Validate that Submission Type Code has default Values - 024") {
    val id = Array("024")
    val name = Array("Test case : Validate that Submission Type Code has default Values")
    
    

    val result = sqlContext.sql(""" select distinct sbmsn_type_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where sbmsn_type_cd not in ('UN','PA','EL','SC','WB') """)
            
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct sbmsn_type_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where sbmsn_type_cd not in ('UN','PA','EL','SC','WB')")
      val data = Array("'Submission type Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct sbmsn_type_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where sbmsn_type_cd not in ('UN','PA','EL','SC','WB')")
      val data = Array("'Invalid Submission type Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================  
   
  test("ClaimPharmacyExtract -Validate that file should have Claims data for only members that are in the Membership extract - 025") {
    val id = Array("025")
    val name = Array("Test case : Validate that file should have Claims data for only members that are in the Membership extract")
    
    

    val result1 = sqlContext.sql("""select distinct mbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm""")
    val result2 = sqlContext.sql("""select distinct mbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp""")
    val result = result1.except(result2)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where mbr_id not in (select distinct mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'Member Id values not present in Membership extract' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where mbr_id not in (select distinct mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'Invalid Member Id values not present in Membership extract'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
  
   test("ClaimPharmacyExtract -Validate that Claim Payment Status Code has Valid Values - 026") {
    val id = Array("026")
    val name = Array("Test case : Validate that Claim Payment Status Code has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct clm_paymnt_stts_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where clm_paymnt_stts_cd NOT IN ('P')""")
 
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct clm_paymnt_stts_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where clm_paymnt_stts_cd NOT IN ('P')")
      val data = Array("'Claim Payment Status Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct clm_paymnt_stts_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm  where clm_paymnt_stts_cd NOT IN ('P')")
      val data = Array("'Invalid Claim Payment Status Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
  
   test("ClaimPharmacyExtract -Validate that Compound Code has Valid Values - 027") {
    val id = Array("027")
    val name = Array("Test case : Validate that Compound Code has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct cmpnd_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where cmpnd_cd NOT IN ('0','1','2')""")
 
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct cmpnd_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where cmpnd_cd NOT IN ('0','1','2')")
      val data = Array("'Compound Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct cmpnd_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where cmpnd_cd NOT IN ('0','1','2')")
      val data = Array("'Invalid Compound Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimPharmacyExtract -Validate that Non-Covered Reason Code - Primary has Valid Values - 028") {
    val id = Array("028")
    val name = Array("Test case : Validate that Non-Covered Reason Code - Primary has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct prmry_non_cvrd_rsn_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where prmry_non_cvrd_rsn_cd NOT IN ('00','10')""")
 
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct prmry_non_cvrd_rsn_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where prmry_non_cvrd_rsn_cd NOT IN ('00','10')")
      val data = Array("'Non-Covered Reason Code - Primary','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct prmry_non_cvrd_rsn_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where prmry_non_cvrd_rsn_cd NOT IN ('00','10')")
      val data = Array("'Invalid Non-Covered Reason Code - Primary','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimPharmacyExtract -Validate that PBM Code has Valid Values - 029") {
    val id = Array("029")
    val name = Array("Test case : Validate that PBM Code has Valid Values")
    
    

    val result = sqlContext.sql("""select distinct phrmcy_bnfts_mngr_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where phrmcy_bnfts_mngr_cd NOT IN ('04','99','03')""")
 
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct phrmcy_bnfts_mngr_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where phrmcy_bnfts_mngr_cd NOT IN ('04','99','03')")
      val data = Array("'PBM Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct phrmcy_bnfts_mngr_cd, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where phrmcy_bnfts_mngr_cd NOT IN ('04','99','03')")
      val data = Array("'Invalid PBM Code','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimPharmacyExtract -Validate that no FEP claims present in Extract - 030") {
    val id = Array("030")
    val name = Array("Test case : Validate that no FEP claims present in Extract")
    
    val result1 = sqlContext.sql(""" select  distinct stg.bhi_home_plan_id,stg.home_plan_prod_id,stg.mbr_id,stg.mbr_key,stg.clmadj_key,c.src_grp_nbr,coa.mbu_cf_cd 
      from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg stg inner join """+dbname+"""_pcandw1ph_nogbd_r000_in.clm  c on 
        c.clm_adjstmnt_key= stg.clmadj_key inner join """+dbname+"""_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa coa on c.mbr_key= coa.mbr_key where c.src_grp_nbr='FEP' """)
    
    val result2 = sqlContext.sql(""" select TRCBLTY_FLD_CD,COUNT(*) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm GROUP BY TRCBLTY_FLD_CD having TRCBLTY_FLD_CD 
in ("888","896") """)

          
    if (result1.count == 0 && result2.count == 0) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query1 :  select  distinct stg.bhi_home_plan_id,stg.home_plan_prod_id,stg.mbr_id,stg.mbr_key,stg.clmadj_key,c.src_grp_nbr,coa.mbu_cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg stg inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm  c on c.clm_adjstmnt_key= stg.clmadj_key inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa coa on c.mbr_key= coa.mbr_key where c.src_grp_nbr='FEP'")
      val query2 = Array("Test Query2 :  select TRCBLTY_FLD_CD,COUNT(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm GROUP BY TRCBLTY_FLD_CD having TRCBLTY_FLD_CD in ('888','896')")
      val data = Array(" Count of both the queries are Matching")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query1 :  select  distinct stg.bhi_home_plan_id,stg.home_plan_prod_id,stg.mbr_id,stg.mbr_key,stg.clmadj_key,c.src_grp_nbr,coa.mbu_cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg stg inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm  c on c.clm_adjstmnt_key= stg.clmadj_key inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa coa on c.mbr_key= coa.mbr_key where c.src_grp_nbr='FEP'")
      val query2 = Array("Test Query2 :  select TRCBLTY_FLD_CD,COUNT(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm GROUP BY TRCBLTY_FLD_CD having TRCBLTY_FLD_CD in ('888','896')")
      val data = Array(" Count of both the queries are not Matching")
     
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("ClaimPharmacyExtract - Pharmacy global filter check service rendering type - 031") {
    val id = Array("031")
    val name = Array("Test case : Pharmacy global filter check service rendering type ")
    
    
    val result = sqlContext.sql(""" select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM """+dbname+"""_PCANDW1PH_nogbd_r000_sg.BCBSA_PHRMCY_CLM_stg  E 
INNER JOIN """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.SRVC_RNDRG_TYPE_CD NOT IN ('PHMCY') """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.BCBSA_PHRMCY_CLM_stg  E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.SRVC_RNDRG_TYPE_CD NOT IN ('PHMCY')")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.BCBSA_PHRMCY_CLM_stg  E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.SRVC_RNDRG_TYPE_CD NOT IN ('PHMCY')")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
   
   test("ClaimPharmacyExtract - Pharmacy global filter check adjudication status code - 032") {
    val id = Array("032")
    val name = Array("Test case : Pharmacy global filter check adjudication status code ")
    
    
    val result = sqlContext.sql(""" select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM """+dbname+"""_PCANDW1PH_nogbd_r000_sg.BCBSA_PHRMCY_CLM_stg  E 
INNER JOIN """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND  C.ADJDCTN_STTS_CD  IN (01) """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.BCBSA_PHRMCY_CLM_stg  E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND  C.ADJDCTN_STTS_CD  IN (01)")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.BCBSA_PHRMCY_CLM_stg  E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND  C.ADJDCTN_STTS_CD  IN (01)")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
   
   test("ClaimPharmacyExtract - Validate that there are 14 BHI Home Plan ID  - 033") {
    
    val id = Array("033")
     val name = Array("Test case : Validate that there are 14 BHI Home Plan ID ")
     
    val result = sqlContext.sql(""" select count(distinct bhi_home_plan_id) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_PHRMCY_CLM """)
    
        
    if (result.collectAsList.toString.contains("14")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PHRMCY_CLM ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PHRMCY_CLM ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================Done
   
   test("ClaimPharmacyExtract -  Basis of Reimbursement - 034") {
    
    val id = Array("034")
     val name = Array("Test case : Basis of Reimbursement ")
     
    val result = sqlContext.sql(""" select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, 
      PHRMCY.bsis_of_reimbmnt_dtrmntn_cd, CLM.bsis_cost_dtrmn_cd, INB.bsis_cost_dtrmn_cd from 
      """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on 
      trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) and 
      trim(PHRMCY.bsis_of_reimbmnt_dtrmntn_cd)=trim(CLM.bsis_cost_dtrmn_cd) left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.bot_bcbsa_bsis_cost_dtrmn_cd_xwalk_inbnd INB 
      on trim(CLM.bsis_cost_dtrmn_cd)=trim(INB.bsis_cost_dtrmn_cd) where (CLM.bsis_cost_dtrmn_cd is NULL or INB.bsis_cost_dtrmn_cd is NULL) and trim(CLM.cdh_rcrd_stts_cd)="ACT" limit 10 """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.bsis_of_reimbmnt_dtrmntn_cd, CLM.bsis_cost_dtrmn_cd, INB.bsis_cost_dtrmn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) and trim(PHRMCY.bsis_of_reimbmnt_dtrmntn_cd)=trim(CLM.bsis_cost_dtrmn_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_bsis_cost_dtrmn_cd_xwalk_inbnd INB on trim(CLM.bsis_cost_dtrmn_cd)=trim(INB.bsis_cost_dtrmn_cd) where (CLM.bsis_cost_dtrmn_cd is NULL or INB.bsis_cost_dtrmn_cd is NULL) and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10  ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.bsis_of_reimbmnt_dtrmntn_cd', 'CLM.bsis_cost_dtrmn_cd', 'INB.bsis_cost_dtrmn_cd' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.bsis_of_reimbmnt_dtrmntn_cd, CLM.bsis_cost_dtrmn_cd, INB.bsis_cost_dtrmn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) and trim(PHRMCY.bsis_of_reimbmnt_dtrmntn_cd)=trim(CLM.bsis_cost_dtrmn_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_bsis_cost_dtrmn_cd_xwalk_inbnd INB on trim(CLM.bsis_cost_dtrmn_cd)=trim(INB.bsis_cost_dtrmn_cd) where (CLM.bsis_cost_dtrmn_cd is NULL or INB.bsis_cost_dtrmn_cd is NULL) and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10  ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.bsis_of_reimbmnt_dtrmntn_cd', 'CLM.bsis_cost_dtrmn_cd', 'INB.bsis_cost_dtrmn_cd' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
   
   test("ClaimPharmacyExtract - Benefit Payment Status Code  - 035") {
    
    val id = Array("035")
     val name = Array("Test case : Benefit Payment Status Code ")
     
    val result1 = sqlContext.sql(""" select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.bnft_paymnt_stts_cd, CLM.clm_line_nbr, CLM.INN_CD from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.INN_CD) = "IN" and trim(PHRMCY.bnft_paymnt_stts_cd)<>"Y" and trim(CLM.clm_line_nbr)=trim(concat("0",PHRMCY.clm_line_nbr)) and trim(CLM.cdh_rcrd_stts_cd)="ACT" limit 10 """)
    
    val result2 = sqlContext.sql(""" select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.bnft_paymnt_stts_cd, CLM.clm_line_nbr, CLM.INN_CD from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.INN_CD) = "OUT" and trim(PHRMCY.bnft_paymnt_stts_cd)<>"N" and trim(CLM.clm_line_nbr)=trim(concat("0",PHRMCY.clm_line_nbr)) and trim(CLM.cdh_rcrd_stts_cd)="ACT" limit 10 """)
        
    if (result1.count == 0 && result2.count == 0) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.bnft_paymnt_stts_cd, CLM.clm_line_nbr, CLM.INN_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.INN_CD) = 'IN' and trim(PHRMCY.bnft_paymnt_stts_cd)<>'Y' and trim(CLM.clm_line_nbr)=trim(concat('0',PHRMCY.clm_line_nbr)) and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10 ")
      val query2 = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.bnft_paymnt_stts_cd, CLM.clm_line_nbr, CLM.INN_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.INN_CD) = 'OUT' and trim(PHRMCY.bnft_paymnt_stts_cd)<>'N' and trim(CLM.clm_line_nbr)=trim(concat('0',PHRMCY.clm_line_nbr)) and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10 ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.bnft_paymnt_stts_cd', 'CLM.clm_line_nbr', 'CLM.INN_CD' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(sc.parallelize(query2,1)).union(sc.parallelize(data,1)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.bnft_paymnt_stts_cd, CLM.clm_line_nbr, CLM.INN_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.INN_CD) = 'IN' and trim(PHRMCY.bnft_paymnt_stts_cd)<>'Y' and trim(CLM.clm_line_nbr)=trim(concat('0',PHRMCY.clm_line_nbr)) and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10 ")
      val query2 = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.bnft_paymnt_stts_cd, CLM.clm_line_nbr, CLM.INN_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.INN_CD) = 'OUT' and trim(PHRMCY.bnft_paymnt_stts_cd)<>'N' and trim(CLM.clm_line_nbr)=trim(concat('0',PHRMCY.clm_line_nbr)) and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10 ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.bnft_paymnt_stts_cd', 'CLM.clm_line_nbr', 'CLM.INN_CD' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(sc.parallelize(query2,1)).union(sc.parallelize(data,1)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
   
   test("ClaimPharmacyExtract - Claim Payment Status  - 036") {
    
    val id = Array("036")
     val name = Array("Test case : Claim Payment Status ")
     
    val result = sqlContext.sql(""" select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.clm_paymnt_stts_cd,
       CLM.ADJDCTN_STTS_CD from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join 
       """+dbname+"""_pcandw1ph_nogbd_r000_in.clm CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) 
       where trim(CLM.ADJDCTN_STTS_CD) = '01' and trim(PHRMCY.clm_paymnt_stts_cd)<>"P" and trim(CLM.cdh_rcrd_stts_cd)="ACT" limit 10 """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.clm_paymnt_stts_cd, CLM.ADJDCTN_STTS_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.ADJDCTN_STTS_CD) = '01' and trim(PHRMCY.clm_paymnt_stts_cd)<>'P' and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10  ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.clm_paymnt_stts_cd', 'CLM.ADJDCTN_STTS_CD' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.clm_paymnt_stts_cd, CLM.ADJDCTN_STTS_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.ADJDCTN_STTS_CD) = '01' and trim(PHRMCY.clm_paymnt_stts_cd)<>'P' and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10  ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.clm_paymnt_stts_cd', 'CLM.ADJDCTN_STTS_CD' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
   
   test("ClaimPharmacyExtract - Compound Code  - 037") {
    
    val id = Array("037")
     val name = Array("Test case : Compound Code ")
     
    val result1 = sqlContext.sql(""" select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.cmpnd_cd, CLM.CMPND_CD from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.CMPND_CD="1" and PHRMCY.cmpnd_cd<>"1" and trim(CLM.cdh_rcrd_stts_cd)="ACT" limit 10 """)
    val result2 = sqlContext.sql(""" select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.cmpnd_cd, CLM.CMPND_CD from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.CMPND_CD="2" and PHRMCY.cmpnd_cd<>"2" and trim(CLM.cdh_rcrd_stts_cd)="ACT" limit 10 """)
        
    if (result1.count == 0 && result2.count == 0) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.cmpnd_cd, CLM.CMPND_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.CMPND_CD='1' and PHRMCY.cmpnd_cd<>'1' and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10  ")
      val query2 = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.cmpnd_cd, CLM.CMPND_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.CMPND_CD='2' and PHRMCY.cmpnd_cd<>'2' and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10 ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.cmpnd_cd', 'CLM.CMPND_CD' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(sc.parallelize(query2,1)).union(sc.parallelize(data,1)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.cmpnd_cd, CLM.CMPND_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.CMPND_CD='1' and PHRMCY.cmpnd_cd<>'1' and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10  ")
      val query2 = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.cmpnd_cd, CLM.CMPND_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.CMPND_CD='2' and PHRMCY.cmpnd_cd<>'2' and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10 ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.cmpnd_cd', 'CLM.CMPND_CD' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(sc.parallelize(query2,1)).union(sc.parallelize(data,1)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
   
   test("ClaimPharmacyExtract - Dispensing Status - 038") {
    
    val id = Array("038")
     val name = Array("Test case : Dispensing Status ")
     
    val result1 = sqlContext.sql(""" select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.DSPNSG_STTS_CD, CLM.DSPNSG_STTS_CD from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.DSPNSG_STTS_CD ="C" and PHRMCY.DSPNSG_STTS_CD <>"C" and trim(CLM.cdh_rcrd_stts_cd)="ACT" limit 10 """)
    val result2 = sqlContext.sql(""" select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.DSPNSG_STTS_CD, CLM.DSPNSG_STTS_CD from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.DSPNSG_STTS_CD ="P" and PHRMCY.DSPNSG_STTS_CD <>"P" and trim(CLM.cdh_rcrd_stts_cd)="ACT" limit 10 """)
        
    if (result1.count == 0 && result2.count == 0) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.DSPNSG_STTS_CD, CLM.DSPNSG_STTS_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.DSPNSG_STTS_CD ='C' and PHRMCY.DSPNSG_STTS_CD <>'C' and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10 ")
      val query2 = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.DSPNSG_STTS_CD, CLM.DSPNSG_STTS_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.DSPNSG_STTS_CD ='P' and PHRMCY.DSPNSG_STTS_CD <>'P' and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10 ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.DSPNSG_STTS_CD', 'CLM.DSPNSG_STTS_CD' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(sc.parallelize(query2,1)).union(sc.parallelize(data,1)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.DSPNSG_STTS_CD, CLM.DSPNSG_STTS_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.DSPNSG_STTS_CD ='C' and PHRMCY.DSPNSG_STTS_CD <>'C' and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10 ")
      val query2 = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.DSPNSG_STTS_CD, CLM.DSPNSG_STTS_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.DSPNSG_STTS_CD ='P' and PHRMCY.DSPNSG_STTS_CD <>'P' and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10 ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.DSPNSG_STTS_CD', 'CLM.DSPNSG_STTS_CD' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(sc.parallelize(query2,1)).union(sc.parallelize(data,1)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
   
   test("ClaimPharmacyExtract -  Formulary Indicator - 039") {
    
    val id = Array("039")
     val name = Array("Test case : Formulary Indicator ")
     
    val result = sqlContext.sql(""" select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.frmlry_ind, 
      CLM.FRMLRY_CD from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM 
      on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where 
      CLM.FRMLRY_CD = 'FRMLY' and PHRMCY.frmlry_ind <>"Y" and trim(CLM.cdh_rcrd_stts_cd)="ACT" limit 10 """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.frmlry_ind, CLM.FRMLRY_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.FRMLRY_CD = 'FRMLY' and PHRMCY.frmlry_ind <>'Y' and trim(CLM.cdh_rcrd_stts_cd)='ACT limit 10 ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.frmlry_ind', 'CLM.FRMLRY_CD' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.frmlry_ind, CLM.FRMLRY_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.FRMLRY_CD = 'FRMLY' and PHRMCY.frmlry_ind <>'Y' and trim(CLM.cdh_rcrd_stts_cd)='ACT limit 10  ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.frmlry_ind', 'CLM.FRMLRY_CD' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
   
   test("ClaimPharmacyExtract - Plan Specialty Drug Indicator - 040") {
    
    val id = Array("040")
     val name = Array("Test case : Plan Specialty Drug Indicator ")
     
    val result = sqlContext.sql(""" select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.plan_spclty_drgind,
       CLM.SPCLTY_DRUG_CD from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM 
       on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where 
       CLM.SPCLTY_DRUG_CD = 'Y' and PHRMCY.plan_spclty_drgind <>"Y" and trim(CLM.cdh_rcrd_stts_cd)="ACT" limit 10 """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.plan_spclty_drgind, CLM.SPCLTY_DRUG_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.SPCLTY_DRUG_CD = 'Y' and PHRMCY.plan_spclty_drgind <>'Y' and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10 ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.plan_spclty_drgind', 'CLM.SPCLTY_DRUG_CD' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.plan_spclty_drgind, CLM.SPCLTY_DRUG_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.SPCLTY_DRUG_CD = 'Y' and PHRMCY.plan_spclty_drgind <>'Y' and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10  ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.plan_spclty_drgind', 'CLM.SPCLTY_DRUG_CD' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
   
   test("ClaimPharmacyExtract - Non-Covered Reason Code - 041") {
    
    val id = Array("041")
     val name = Array("Test case : Non-Covered Reason Code ")
     
    val result1 = sqlContext.sql(""" select NON_CVRD_AMT, prmry_non_cvrd_rsn_cd, *  from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg where NON_CVRD_AMT > 0 and prmry_non_cvrd_rsn_cd<>"10" limit 10 """)
    val result2 = sqlContext.sql(""" select NON_CVRD_AMT, prmry_non_cvrd_rsn_cd, *  from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg where NON_CVRD_AMT = 0 and prmry_non_cvrd_rsn_cd<>"00" limit 10 """)
        
    if (result1.count == 0 && result2.count == 0) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query :  select NON_CVRD_AMT, prmry_non_cvrd_rsn_cd, *  from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg where NON_CVRD_AMT > 0 and prmry_non_cvrd_rsn_cd<>'10' limit 10 ")
      val query2 = Array("Test Query :  select NON_CVRD_AMT, prmry_non_cvrd_rsn_cd, *  from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg where NON_CVRD_AMT = 0 and prmry_non_cvrd_rsn_cd<>'00' limit 10 ")
      val data = Array("'NON_CVRD_AMT', 'prmry_non_cvrd_rsn_cd', '*' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(sc.parallelize(query2,1)).union(sc.parallelize(data,1)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query :  select NON_CVRD_AMT, prmry_non_cvrd_rsn_cd, *  from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg where NON_CVRD_AMT > 0 and prmry_non_cvrd_rsn_cd<>'10' limit 10 ")
      val query2 = Array("Test Query :  select NON_CVRD_AMT, prmry_non_cvrd_rsn_cd, *  from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg where NON_CVRD_AMT = 0 and prmry_non_cvrd_rsn_cd<>'00' limit 10 ")
      val data = Array("'NON_CVRD_AMT', 'prmry_non_cvrd_rsn_cd', '*' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(sc.parallelize(query2,1)).union(sc.parallelize(data,1)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
   
   test("ClaimPharmacyExtract - Other Coverage Code - 042") {
    
    val id = Array("042")
     val name = Array("Test case : Other Coverage Code ")
     
    val result = sqlContext.sql(""" select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.OTHR_CVRG_CD, 
      CLM.OTHR_CVRG_CD from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on 
      trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where 
      trim(CLM.OTHR_CVRG_CD) = 'UNK' and length(trim(PHRMCY.OTHR_CVRG_CD)) <>0 and trim(CLM.cdh_rcrd_stts_cd)="ACT" limit 10 """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.OTHR_CVRG_CD, CLM.OTHR_CVRG_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.OTHR_CVRG_CD) = 'UNK' and length(trim(PHRMCY.OTHR_CVRG_CD)) <>0 and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10 ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.OTHR_CVRG_CD', 'CLM.OTHR_CVRG_CD' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select PHRMCY.clmadj_key, PHRMCY.clm_line_nbr, PHRMCY.trcblty_fld_cd, PHRMCY.OTHR_CVRG_CD, CLM.OTHR_CVRG_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg PHRMCY left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.phrmcy_clm_line CLM on trim(PHRMCY.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(PHRMCY.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.OTHR_CVRG_CD) = 'UNK' and length(trim(PHRMCY.OTHR_CVRG_CD)) <>0 and trim(CLM.cdh_rcrd_stts_cd)='ACT' limit 10  ")
      val data = Array("'PHRMCY.clmadj_key', 'PHRMCY.clm_line_nbr', 'PHRMCY.trcblty_fld_cd', 'PHRMCY.OTHR_CVRG_CD', 'CLM.OTHR_CVRG_CD' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
   
   
   test("ClaimPharmacyExtract - Product / Service ID  - 043") {
    
    val id = Array("043")
     val name = Array("Test case : Product / Service ID  ")
     
    val result = sqlContext.sql(""" select cmpnd_cd, prod_srvc_id, *  from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg where 
      cmpnd_cd = "2" and prod_srvc_id not like "%99999%" limit 10 """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select cmpnd_cd, prod_srvc_id, *  from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg where cmpnd_cd = '2' and prod_srvc_id not like '%99999%' limit 10  ")
      val data = Array("'cmpnd_cd', 'prod_srvc_id', '*' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select cmpnd_cd, prod_srvc_id, *  from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_phrmcy_clm_stg where cmpnd_cd = '2' and prod_srvc_id not like '%99999%' limit 10  ")
      val data = Array("'cmpnd_cd', 'prod_srvc_id', '*' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
   
 
  test("ClaimPharmacyExtract - Referential integrity with member for Zipcode & Country Code combination  - 044") {
    
    val id = Array("044")
     val name = Array("Test case : Referential integrity with member for Zipcode & Country Code combination  ")
     
    val result = sqlContext.sql(""" select *
              from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm clm
              left outer join """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp mbr
              on trim(clm.clm_mbr_zip_cd)=trim(mbr.mbr_curnt_prmry_zip_cd) and
              trim(clm.mbr_id)=trim(mbr.mbr_id) and
              trim(clm.clm_mbr_cntry_cd)=trim(mbr.mbr_curnt_cntry_cd)
              where mbr.mbr_curnt_prmry_zip_cd is NULL
              limit 20 """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm clm left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp mbr on trim(clm.clm_mbr_zip_cd)=trim(mbr.mbr_curnt_prmry_zip_cd) and trim(clm.mbr_id)=trim(mbr.mbr_id) and trim(clm.clm_mbr_cntry_cd)=trim(mbr.mbr_curnt_cntry_cd) where mbr.mbr_curnt_prmry_zip_cd is NULL  ")
      val data = Array("'*' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm clm left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp mbr on trim(clm.clm_mbr_zip_cd)=trim(mbr.mbr_curnt_prmry_zip_cd) and trim(clm.mbr_id)=trim(mbr.mbr_id) and trim(clm.clm_mbr_cntry_cd)=trim(mbr.mbr_curnt_cntry_cd) where mbr.mbr_curnt_prmry_zip_cd is NULL  ")
      val data = Array("'*' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================   

  test("ClaimPharmacyExtract - validating the Medicare group 195331 exclusion  - 045") {
    
    val id = Array("045")
     val name = Array("Test case : validating the Medicare group 195331 exclusion  ")
     
    val result = sqlContext.sql(""" select  bhi_home_plan_id,clm_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where grp_cd='195331' limit 10 """)
    
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,clm_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where grp_cd='195331' limit 10 ")
      val data = Array("'*' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,clm_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm where grp_cd='195331' limit 10  ")
      val data = Array("'*' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Pharmacy/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
   
   
 }