package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession

import org.apache.spark.sql.SparkSession
import java.io.File
import org.apache.spark.sql.DataFrame
import com.anthem.hca.ndw.utils.PCADX_SCL_TA_Utilities._
import java.text.SimpleDateFormat
import org.apache.spark.sql.SaveMode
import java.util.Calendar
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel
import java.util.Date
import java.text.SimpleDateFormat



object PCADX_SCL_TA_L2_AccountReporting_TGT {


  
def main(args: Array[String]) {
  


val dbname: String = args(0)
val SUBJ_AREA_NM: String=args(1)
val PRCS_NM: String=args(2)


val appName = "Datapipe from L2 cases for Product" // we will make this generic going forward

val warehouseLocation = new File("/user/hive/warehouse").getAbsolutePath
val options = Map("path" -> "/user/hive/warehouse")

val spark = SparkSession
.builder()
.appName(appName)
.config("spark.sql.warehouse.dir", warehouseLocation)
.enableHiveSupport()
.getOrCreate()

spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode","INFER_ONLY")
spark.conf.set("spark.sql.crossJoin.enabled","true")

import spark.implicits._
val home_plan_id =spark.sql("select distinct bhi_home_plan_id from "+dbname+"_pcandw1ph_nogbd_r000_wh.bot_bcbsa_plan_sbmsn")
val  home_plan=home_plan_id.select("bhi_home_plan_id").collect().map(_(0)).toList
spark.sql("SELECT count(*) as CNT,bhi_home_plan_id   FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg FH group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Total")
spark.sql("SELECT count(*)  as CNT,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg_err FH group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Error")

// Rule 1-4
home_plan.foreach(bhi_home_plan_id => {

val sqlbshow=" select a.CNT*100/(b.CNT) as AcctRep  FROM  (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg_err FH where  bhi_home_plan_id='"+bhi_home_plan_id +"' ) a join (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b    "

val sqlb=" select a.CNT*100/(b.CNT) as AcctRep  FROM  (  SELECT  CNT  FROM Error FH where  bhi_home_plan_id='"+bhi_home_plan_id +"' ) a join (  SELECT  CNT  FROM Total FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b    "

var b=spark.sql(sqlb).withColumn("sql",lit(sqlbshow))

var e=output(spark, TestIDGen(spark,ReportOutput(spark,dbname,b)),SUBJ_AREA_NM,PRCS_NM, bhi_home_plan_id.toString())


e.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_RSLT")
//e(1).write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_SQL")


})



}
  
  

}