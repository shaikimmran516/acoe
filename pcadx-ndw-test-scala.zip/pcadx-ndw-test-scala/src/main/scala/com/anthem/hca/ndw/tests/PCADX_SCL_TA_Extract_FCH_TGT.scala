package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Extract_FCH_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_FCH_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_Extract_FCH_TGT(dbname: String, env: String) extends FunSuite {

  val now = Calendar.getInstance().getTime()
  val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
  val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
  val currdate = formatter.format(new Date())
  val currdate1 = formatter1.format(new Date())

  val sc = SparkContext.getOrCreate()
  sc.setLogLevel("ERROR")
  val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()

  import sqlContext.implicits._
  import sqlContext.sql

  val subj = "Extract"
  val prcss = "FacilityClaimHeader"

  test("ClaimFacilityHeaderExtract -Validated NULL or blank spaces checks for all Columns") {

    val id = Array("001")
    val name = Array("Test case : Validated NULL or blank spaces checks for all Columns")

    val col_name = Array(
      "bhi_home_plan_id",
      "clm_id",
      "trcblty_fld_cd",
      "adjstmnt_sqnc_nbr",
      "host_plan_id",
      "home_plan_prod_id",
      "acct_nbr",
      "grp_nm",
      "subgrp_nm",
      "mbr_id",
      "clm_mbr_cntry_cd",
      "atndg_prov_id",
      "atndg_prov_spclty_cd",
      "atndg_prov_zip_cd",
      "atndg_prov_cntry_cd",
      "billg_prov_id",
      "billg_prov_spclty_cd",
      "billg_prov_cntry_cd",
      "pcp_id",
      "pcp_prov_spclty_cd",
      "pcp_prov_cntry_cd",
      "rndrg_prov_id",
      "rndrg_prov_spclty_cd",
      "rndrg_prov_cntry_cd",
      "rndrg_prov_type_cd",
      "prncpal_icd9_diag_cd",
      "prncpal_proc_dt",
      "scndry_proc_dt_1",
      "scndry_proc_dt_2",
      "scndry_proc_dt_3",
      "scndry_proc_dt_4",
      "scndry_proc_dt_5",
      "bnft_paymnt_stts_cd",
      "bill_stts_cd",
      "brth_wt_cd",
      "srvc_ctgry_cd",
      "clm_paymnt_stts_cd",
      "clm_type_cd",
      "dschrg_stts_cd",
      "its_clm_ind",
      "non_cvrd_rsn_cd_1",
      "non_cvrd_rsn_cd_2",
      "non_cvrd_rsn_cd_3",
      "non_cvrd_rsn_cd_4",
      "plos_cd",
      "reimbmnt_type_cd",
      "sbmsn_type_cd",
      "adjdctd_dt",
      "clm_entr_dt",
      "clm_paid_dt",
      "clm_rcvd_dt",
      "frst_srvc_dt",
      "last_srvc_dt",
      "stmnt_from_dt",
      "stmnt_thru_dt",
      "cvrd_days_for_paymnt_nbr",
      "non_cvrd_days_for_paymnt_nbr",
      "sbmtd_amt",
      "non_cvrd_amt",
      "alwd_amt",
      "paymnt_amt",
      "cob_tpl_amt",
      "coinsrn_amt",
      "cpay_amt",
      "ddctbl_amt",
      "npi_atndg_prov_id",
      "npi_billg_prov_id",
      "npi_pcp_prov_id",
      "npi_rndrg_prov_id",
      "non_cntrctd_hhrmls_ngttn_ind",
      "billg_prov_cntrctg_stts_ind",
      "rndrg_prov_cntrctg_stts_ind",
      "sccf_id",
      "scndry_icd10_proc_dt_6",
      "scndry_icd10_proc_dt_7",
      "scndry_icd10_proc_dt_8",
      "scndry_icd10_proc_dt_9",
      "scndry_icd10_proc_dt_10",
      "scndry_icd10_proc_dt_11",
      "scndry_icd10_proc_dt_12",
      "scndry_icd10_proc_dt_13",
      "scndry_icd10_proc_dt_14",
      "scndry_icd10_proc_dt_15",
      "scndry_icd10_proc_dt_16",
      "scndry_icd10_proc_dt_17",
      "scndry_icd10_proc_dt_18",
      "scndry_icd10_proc_dt_19",
      "scndry_icd10_proc_dt_20",
      "scndry_icd10_proc_dt_21",
      "scndry_icd10_proc_dt_22",
      "scndry_icd10_proc_dt_23",
      "scndry_icd10_proc_dt_24")

    val i = 0;

    for (i <- 0 to 91) {
      val k = col_name(i)
      val result = sqlContext.sql(f"""select bhi_home_plan_id, clm_id, trcblty_fld_cd, $k from """ + dbname + f"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where length(trim(regexp_replace(coalesce($k, "")," ", "")))=0 """)

      if (result.count > 0) {
        println(f" $k -- Failed")
      } else {
        println(f" $k -- Success")
      }

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validated Special Character checks for key Columns") {
    val id = Array("002")
    val name = Array("Test case :Validated Special Character checks for key Columns")

    val col_name = Array(
      "bhi_home_plan_id",
      "clm_id",
      "trcblty_fld_cd")

    val i = 0;

    for (i <- 0 to 2) {
      val k = col_name(i)
      val result = sqlContext.sql(f"""select bhi_home_plan_id, clm_id, trcblty_fld_cd from """ + dbname + f"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where $k RLIKE '[^A-z0-9]' """)

      if (result.count > 0) {
        println(f" $k -- Failed")
      } else {
        println(f" $k -- Success")
      }

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validated Double Quote Character checks for other Columns") {
    val id = Array("003")
    val name = Array("Test case : Validated Double Quote Character checks for other Columns")

    val col_name = Array(
      "adjstmnt_sqnc_nbr",
      "host_plan_id",
      "home_plan_prod_id",
      "acct_nbr",
      "grp_nm",
      "subgrp_nm",
      "mbr_id",
      "clm_mbr_zip_cd",
      "clm_mbr_cntry_cd",
      "atndg_prov_id",
      "atndg_prov_spclty_cd",
      "atndg_prov_zip_cd",
      "atndg_prov_cntry_cd",
      "billg_prov_id",
      "billg_prov_spclty_cd",
      "billg_prov_zip_cd",
      "billg_prov_cntry_cd",
      "billg_prov_tax_id",
      "billg_prov_medcr_id",
      "billg_prov_last_nm",
      "billg_prov_frst_nm",
      "billg_prov_ntwk_id",
      "pcp_id",
      "pcp_prov_spclty_cd",
      "pcp_prov_zip_cd",
      "pcp_prov_cntry_cd",
      "rndrg_prov_id",
      "rndrg_prov_spclty_cd",
      "rndrg_prov_zip_cd",
      "rndrg_prov_cntry_cd",
      "rndrg_prov_type_cd",
      "rndrg_prov_medcr_id",
      "rndrg_prov_last_nm",
      "rndrg_prov_frst_nm",
      "rndrg_prov_ntwk_id",
      "admtg_diag_cd",
      "prncpal_icd9_diag_cd",
      "scndry_icd9_diag_cd_1",
      "scndry_icd9_diag_cd_2",
      "scndry_icd9_diag_cd_3",
      "scndry_icd9_diag_cd_4",
      "scndry_icd9_diag_cd_5",
      "scndry_icd9_diag_cd_6",
      "scndry_icd9_diag_cd_7",
      "scndry_icd9_diag_cd_8",
      "scndry_icd9_diag_cd_9",
      "scndry_icd9_diag_cd_10",
      "prncpal_proc_cd",
      "prncpal_proc_dt",
      "scndry_proc_cd_1",
      "scndry_proc_dt_1",
      "scndry_proc_cd_2",
      "scndry_proc_dt_2",
      "scndry_proc_cd_3",
      "scndry_proc_dt_3",
      "scndry_proc_cd_4",
      "scndry_proc_dt_4",
      "scndry_proc_cd_5",
      "scndry_proc_dt_5",
      "admt_src_cd",
      "admt_type_cd",
      "authrzn_id",
      "bnft_paymnt_stts_cd",
      "bill_stts_cd",
      "brth_wt_cd",
      "srvc_ctgry_cd",
      "clms_sys_drg_cd",
      "clms_sys_drg_mdc_cd",
      "clms_sys_ap_drg_cd",
      "clms_sys_ap_drg_mjr_dgnstc_category_code",
      "clm_paymnt_stts_cd",
      "clm_type_cd",
      "dschrg_stts_cd",
      "its_clm_ind",
      "non_cvrd_rsn_cd_1",
      "non_cvrd_rsn_cd_2",
      "non_cvrd_rsn_cd_3",
      "non_cvrd_rsn_cd_4",
      "plos_cd",
      "reimbmnt_type_cd",
      "sbmsn_type_cd",
      "type_of_bill_cd",
      "adjdctd_dt",
      "clm_entr_dt",
      "clm_paid_dt",
      "clm_rcvd_dt",
      "frst_srvc_dt",
      "last_srvc_dt",
      "stmnt_from_dt",
      "stmnt_thru_dt",
      "cvrd_days_for_paymnt_nbr",
      "non_cvrd_days_for_paymnt_nbr",
      "sbmtd_amt",
      "non_cvrd_amt",
      "alwd_amt",
      "paymnt_amt",
      "cob_tpl_amt",
      "coinsrn_amt",
      "cpay_amt",
      "ddctbl_amt",
      "npi_atndg_prov_id",
      "npi_billg_prov_id",
      "npi_pcp_prov_id",
      "npi_rndrg_prov_id",
      "non_cntrctd_hhrmls_ngttn_ind",
      "billg_prov_cntrctg_stts_ind",
      "rndrg_prov_cntrctg_stts_ind",
      "sccf_id",
      "icd10_admsn_diag_cd",
      "prncpal_icd10_diag_cd",
      "scndry_icd10_diag_cd_1",
      "scndry_icd10_diag_cd_2",
      "scndry_icd10_diag_cd_3",
      "scndry_icd10_diag_cd_4",
      "scndry_icd10_diag_cd_5",
      "scndry_icd10_diag_cd_6",
      "scndry_icd10_diag_cd_7",
      "scndry_icd10_diag_cd_8",
      "scndry_icd10_diag_cd_9",
      "scndry_icd10_diag_cd_10",
      "prncpal_icd10_proc_cd",
      "scndry_icd10_proc_cd_1",
      "scndry_icd10_proc_cd_2",
      "scndry_icd10_proc_cd_3",
      "scndry_icd10_proc_cd_4",
      "scndry_icd10_proc_cd_5",
      "scndry_icd10_diag_cd_11",
      "scndry_icd10_diag_cd_12",
      "scndry_icd10_diag_cd_13",
      "scndry_icd10_diag_cd_14",
      "scndry_icd10_diag_cd_15",
      "scndry_icd10_diag_cd_16",
      "scndry_icd10_diag_cd_17",
      "scndry_icd10_diag_cd_18",
      "scndry_icd10_diag_cd_19",
      "scndry_icd10_diag_cd_20",
      "scndry_icd10_diag_cd_21",
      "scndry_icd10_diag_cd_22",
      "scndry_icd10_diag_cd_23",
      "scndry_icd10_diag_cd_24",
      "scndry_icd10_proc_cd_6",
      "scndry_icd10_proc_dt_6",
      "scndry_icd10_proc_cd_7",
      "scndry_icd10_proc_dt_7",
      "scndry_icd10_proc_cd_8",
      "scndry_icd10_proc_dt_8",
      "scndry_icd10_proc_cd_9",
      "scndry_icd10_proc_dt_9",
      "scndry_icd10_proc_cd_10",
      "scndry_icd10_proc_dt_10",
      "scndry_icd10_proc_cd_11",
      "scndry_icd10_proc_dt_11",
      "scndry_icd10_proc_cd_12",
      "scndry_icd10_proc_dt_12",
      "scndry_icd10_proc_cd_13",
      "scndry_icd10_proc_dt_13",
      "scndry_icd10_proc_cd_14",
      "scndry_icd10_proc_dt_14",
      "scndry_icd10_proc_cd_15",
      "scndry_icd10_proc_dt_15",
      "scndry_icd10_proc_cd_16",
      "scndry_icd10_proc_dt_16",
      "scndry_icd10_proc_cd_17",
      "scndry_icd10_proc_dt_17",
      "scndry_icd10_proc_cd_18",
      "scndry_icd10_proc_dt_18",
      "scndry_icd10_proc_cd_19",
      "scndry_icd10_proc_dt_19",
      "scndry_icd10_proc_cd_20",
      "scndry_icd10_proc_dt_20",
      "scndry_icd10_proc_cd_21",
      "scndry_icd10_proc_dt_21",
      "scndry_icd10_proc_cd_22",
      "scndry_icd10_proc_dt_22",
      "scndry_icd10_proc_cd_23",
      "scndry_icd10_proc_dt_23",
      "scndry_icd10_proc_cd_24",
      "scndry_icd10_proc_dt_24",
      "prncpal_diag_poa_cd",
      "diag_poa_cd_1",
      "diag_poa_cd_2",
      "diag_poa_cd_3",
      "diag_poa_cd_4",
      "diag_poa_cd_5",
      "diag_poa_cd_6",
      "diag_poa_cd_7",
      "diag_poa_cd_8",
      "diag_poa_cd_9",
      "diag_poa_cd_10",
      "diag_poa_cd_11",
      "diag_poa_cd_12",
      "diag_poa_cd_13",
      "diag_poa_cd_14",
      "diag_poa_cd_15",
      "diag_poa_cd_16",
      "diag_poa_cd_17",
      "diag_poa_cd_18",
      "diag_poa_cd_19",
      "diag_poa_cd_20",
      "diag_poa_cd_21",
      "diag_poa_cd_22",
      "diag_poa_cd_23",
      "diag_poa_cd_24",
      "extrnl_coi_cd_1",
      "extrnl_coi_cd_2",
      "extrnl_coi_cd_3",
      "extrnl_coi_cd_4",
      "extrnl_coi_cd_5",
      "extrnl_coi_cd_6",
      "extrnl_coi_cd_7",
      "extrnl_coi_cd_8",
      "extrnl_coi_cd_9",
      "extrnl_coi_cd_10",
      "extrnl_coi_cd_11",
      "extrnl_coi_cd_12",
      "prfv_cd_1",
      "prfv_cd_2",
      "prfv_cd_3")

    val i = 0;

    for (i <- 0 to 217) {
      val k = col_name(i)
      val result = sqlContext.sql(f"""select bhi_home_plan_id, clm_id, trcblty_fld_cd, $k from """ + dbname + f"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where $k RLIKE '"' """)

      if (result.count > 0) {
        println(f" $k -- Failed")
      } else {
        println(f" $k -- Success")
      }

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate if the FCH  extract table is loaded - 001") {
    val id = Array("001")
    val name = Array("Test case : Validate if the FCH  extract table is loaded - 001")

    val result = sqlContext.sql(f"""Select count(*) as cnt from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_HDR """)

    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : Select count(*) from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_HDR")
      val data = Array("'cnt'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : Select count(*) from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_HDR")
      val data = Array("'cnt' : Data is present")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    }
  }

  test("ClaimFacilityHeaderExtract -Validate if the FCH  extract table is loaded - 002") {
    val id = Array("002")
    val name = Array("Test case : Validate if the FCH  extract table is loaded - 002")

    val result = sqlContext.sql(f"""select BHI_HOME_PLAN_ID, count(*) as cnt                                       
from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_HDR                                                
group by BHI_HOME_PLAN_ID                                  
order by BHI_HOME_PLAN_ID 
LIMIT 15""")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : select BHI_HOME_PLAN_ID, count(*) as cnt from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_HDR group by BHI_HOME_PLAN_ID order by BHI_HOME_PLAN_ID LIMIT 15")
      val data = Array("'BHI_HOME_PLAN_ID' : Data is present")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)

  }
  
  test("ClaimFacilityHeaderExtract -Validate if the FCH extract table has a valid home plan id - 003") {
    val id = Array("003")
    val name = Array("Test case : Validate if the FCH extract table has a valid home plan id - 003")

    val result = sqlContext.sql(f"""Select BHI_HOME_PLAN_ID from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_HDR where bhi_home_plan_id not in 
      ('051','102','182','254','271','458','748','062','131','161','266','330','425','040') """)

    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : Select BHI_HOME_PLAN_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_HDR where bhi_home_plan_id not in ('051','102','182','254','271','458','748','062','131','161','266','330','425','040')")
      val data = Array("'BHI_HOME_PLAN_ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : Select BHI_HOME_PLAN_ID from ${dbname}_pcandw1ph_nogbd_r000_ou.BCBSA_FCLTY_CLM_HDR where bhi_home_plan_id not in ('051','102','182','254','271','458','748','062','131','161','266','330','425','040')")
      val data = Array("'BHI_HOME_PLAN_ID' : Data is present")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    }
  }

  test("ClaimFacilityHeaderExtract -Validate that all the records have the correct [BHI Home Plan ID] as per Anthem - 004") {
    val id = Array("004")
    val name = Array("Test case : Validate that all the records have the correct [BHI Home Plan ID] as per Anthem")

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, trcblty_fld_cd, err_id, exclsn_ind from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where
    bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') """)

    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') ")
      val data = Array("'BHI HPID','Claim_ID','Traceability','ERR_ID','EXCLSN_ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') ")
      val data = Array("'BHI HPID','Claim_ID','Traceability','ERR_ID','EXCLSN_ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    }

  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate One record for each BHI Home Plan ID, Claim ID & Traceability - 005") {

    val id = Array("005")
    val name = Array("Test case : Validate One record for each BHI Home Plan ID, Claim ID & Traceability")

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, trcblty_fld_cd, count(*) as count from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr group by bhi_home_plan_id, clm_id, trcblty_fld_cd""")
    result.createOrReplaceTempView("resultDF")

    val invalid = sqlContext.sql("""select * from resultDF where count > 1 """)

    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id, clm_id, trcblty_fld_cd, count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr group by bhi_home_plan_id, clm_id, trcblty_fld_cd) where count > 1")
      val data = Array("'BHI HPID','Claim_ID','Traceability','COUNT'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, trcblty_fld_cd, count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr group by bhi_home_plan_id, clm_id, trcblty_fld_cd")
      val data = Array("'BHI HPID','Claim_ID','Traceability','COUNT' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    }

  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that BHI Home Plan ID + Traceability is present in Traceability Table - 006") {
    val id = Array("006")
    val name = Array("Test case : Validate that BHI Home Plan ID + Traceability is present in Traceability Table")

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(trcblty_fld_cd))) as CONCAT_TGT from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(trcblty_fld_cd))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc)")
      val data = Array("'Home_Plan_Id + Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(trcblty_fld_cd))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc)")
      val data = Array("'Home_Plan_Id + Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Host Plan ID is present in Reference table - 007") {
    val id = Array("007")
    val name = Array("Test case : Validate that Host Plan ID is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(host_plan_id_cd )) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_host_plan_id_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(host_plan_id))  from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(host_plan_id))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(host_plan_id) not in (select distinct (trim(host_plan_id_cd )) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_host_plan_id_inbnd)")
      val data = Array("'Host_Plan_ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(host_plan_id))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(host_plan_id) not in (select distinct (trim(host_plan_id_cd )) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_host_plan_id_inbnd)")
      val data = Array("'Invalid Host_Plan_ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that BHI Home Plan ID + Home Plan Product ID is present in Product Table - 008") {
    val id = Array("008")
    val name = Array("Test case : Validate that BHI Home Plan ID + Home Plan Product ID is present in Product Table")

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_SRC from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prod  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_TGT from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that BHI Home Plan ID + Home Plan Product ID + Account ID + Group + SubGroup is present in PCC Table - 009") {
    val id = Array("009")
    val name = Array("Test case : Validate that BHI Home Plan ID + Home Plan Product ID + Account ID + Group + SubGroup is present in PCC Table")

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_id) ,  trim(grp_id) ,  trim(subgrp_id))) as CONCAT_SRC from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_nbr) ,  trim(grp_nm) ,  trim(subgrp_nm))) as CONCAT_TGT from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_nbr) ,  trim(grp_nm) ,  trim(subgrp_nm))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_id) ,  trim(grp_id) ,  trim(subgrp_id))) as CONCAT_SRC from '''+dbname+'''pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID + Account + Group + SubGroup' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_nbr) ,  trim(grp_nm) ,  trim(subgrp_nm))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_id) ,  trim(grp_id) ,  trim(subgrp_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID + Account + Group + SubGroup'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that BHI Home Plan ID + Home Plan Product ID + Member ID is present in Member Table - 010") {
    val id = Array("010")
    val name = Array("Test case : Validate that BHI Home Plan ID + Home Plan Product ID + Member ID is present in Member Table")

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id))) as CONCAT_SRC from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id ))) as CONCAT_TGT from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID + Member ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID + Member ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Member Zip Code is present in Reference table - 011") {
    val id = Array("011")
    val name = Array("Test case : Validate that Member Zip Code is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(zip_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(clm_mbr_zip_cd))  from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(clm_mbr_zip_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(clm_mbr_zip_cd) not in (select distinct (trim(zip_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd)")
      val data = Array("'Member_Zip_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(clm_mbr_zip_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(clm_mbr_zip_cd) not in (select distinct (trim(zip_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd)")
      val data = Array("'Member_Zip_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Member Country Code is present in Reference table - 012") {
    val id = Array("012")
    val name = Array("Test case : Validate that Member Country Code is present in Reference table ")

    val result1 = sqlContext.sql("""select distinct (trim(cntry_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(clm_mbr_cntry_cd))  from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where clm_mbr_cntry_cd not in ('UN')""")

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(clm_mbr_cntry_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(clm_mbr_cntry_cd) not in (select distinct (trim(cntry_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd)")
      val data = Array("'Member_Country_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(clm_mbr_cntry_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(clm_mbr_cntry_cd) not in (select distinct (trim(cntry_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd)")
      val data = Array("'Invalid Member_Country_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that ICD-9 Diagnosis Code - Principal is present in Diagnosis Reference table - 013") {
    val id = Array("013")
    val name = Array("Test case : Validate that ICD-9 Diagnosis Code - Principal is present in Diagnosis Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(diag_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_diag_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(prncpal_icd9_diag_cd))  from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(prncpal_icd9_diag_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(prncpal_icd9_diag_cd) not in (select distinct (trim(diag_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_diag_inbnd)")
      val data = Array("'ICD-9_Diagnosis_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(prncpal_icd9_diag_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(prncpal_icd9_diag_cd) not in (select distinct (trim(diag_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_diag_inbnd)")
      val data = Array("'Invalid ICD-9_Diagnosis_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  /*test("ClaimFacilityHeaderExtract -Validate that ICD-10 Diagnosis Code - Principal is present in Reference table - 014") {
    val id = Array("014")
    val name = Array("Test case : Validate that ICD-10 Diagnosis Code - Principal is present in Reference table")


    val result1 = sqlContext.sql("""select distinct (trim(icd10_diag_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_icd10_diag_inbnd where (trim(icd10_diag_cd)) not in ('UN', '') """)

    val result2 = sqlContext.sql("""select distinct (trim(prncpal_icd10_diag_cd))  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where  (trim(prncpal_icd10_diag_cd)) <> 'UN' """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(prncpal_icd10_diag_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where trim(prncpal_icd10_diag_cd) not in (select distinct (trim(icd10_diag_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_icd10_diag_inbnd)")
      val data = Array("'ICD-10_Diagnosis_Code' : No Invalid Values Found")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(prncpal_icd10_diag_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where trim(prncpal_icd10_diag_cd) not in (select distinct (trim(icd10_diag_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_icd10_diag_inbnd)")
      val data = Array("'Invalid ICD-10_Diagnosis_Code'")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }*/

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Benefit Payment Status Code has Valid Values - 014") {
    val id = Array("014")
    val name = Array("Test case : Validate that Benefit Payment Status Code has Valid Values")

    val result = sqlContext.sql("""select distinct bnft_paymnt_stts_cd, bhi_home_plan_id, clm_id,mbr_id, trcblty_fld_cd from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where bnft_paymnt_stts_cd NOT IN ('Y','N','O')  """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct bnft_paymnt_stts_cd, bhi_home_plan_id, clm_id,mbr_id, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where bnft_paymnt_stts_cd NOT IN ('Y','N','O')")
      val data = Array("'Benefit_Payment_Status_Code','BHI HPID','Claim_ID','MBR_ID','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct bnft_paymnt_stts_cd, bhi_home_plan_id, clm_id,mbr_id, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where bnft_paymnt_stts_cd NOT IN ('Y','N','O')")
      val data = Array("'Invalid Benefit_Payment_Status_Code','BHI HPID','Claim_ID','MBR_ID','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Benefit Payment Status Code is present in Reference table - 015") {
    val id = Array("015")
    val name = Array("Test case : Validate that Benefit Payment Status Code is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(bnft_paymnt_stts_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(bnft_paymnt_stts_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(bnft_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(bnft_paymnt_stts_cd) not in (select distinct (trim(bnft_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd)")
      val data = Array("'Benefit_Payment_Status_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(bnft_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(bnft_paymnt_stts_cd) not in (select distinct (trim(bnft_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd)")
      val data = Array("'Invalid Benefit_Payment_Status_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Category of Service Code has Valid Values - 016") {
    val id = Array("016")
    val name = Array("Test case :Validate that Category of Service Code has Valid Values")

    val result = sqlContext.sql("""select distinct srvc_ctgry_cd, bhi_home_plan_id, clm_id,mbr_id, trcblty_fld_cd from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where srvc_ctgry_cd NOT IN ('IP ACUTE','IP NON-ACUTE','OP FAC')   """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct srvc_ctgry_cd, bhi_home_plan_id, clm_id,mbr_id, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where srvc_ctgry_cd NOT IN ('IP ACUTE','IP NON-ACUTE','OP FAC') ")
      val data = Array("'Category_of_Service_Code','BHI HPID','Claim_ID','MBR_ID','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct srvc_ctgry_cd, bhi_home_plan_id, clm_id,mbr_id, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where srvc_ctgry_cd NOT IN ('IP ACUTE','IP NON-ACUTE','OP FAC') ")
      val data = Array("'Invalid Category_of_Service_Code','BHI HPID','Claim_ID','MBR_ID','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Category of Service Code is present in Reference table - 017") {
    val id = Array("017")
    val name = Array("Test case : Validate that Category of Service Code is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(ctgry_of_srvc_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_ctgry_of_srvc_inbnd    """)

    val result2 = sqlContext.sql("""select distinct (trim(srvc_ctgry_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(srvc_ctgry_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(srvc_ctgry_cd) not in (select distinct (trim(ctgry_of_srvc_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_ctgry_of_srvc_inbnd)")
      val data = Array("'Category_of_Service_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(srvc_ctgry_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(srvc_ctgry_cd) not in (select distinct (trim(ctgry_of_srvc_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_ctgry_of_srvc_inbnd)")
      val data = Array("'Invalid Category_of_Service_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Claim Payment Status Code is present in Reference table - 018") {
    val id = Array("018")
    val name = Array("Test case : Validate that Claim Payment Status Code is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(clm_paymnt_stts_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_clm_paymnt_stts_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(clm_paymnt_stts_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(clm_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(clm_paymnt_stts_cd) not in (select distinct (trim(clm_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_clm_paymnt_stts_inbnd)")
      val data = Array("'Claim_Payment_Status_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(clm_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(clm_paymnt_stts_cd) not in (select distinct (trim(clm_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_clm_paymnt_stts_inbnd)")
      val data = Array("'Invalid Claim_Payment_Status_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that ITS Claim Indicator Code has Valid Values - 019") {
    val id = Array("019")
    val name = Array("Test case : Validate that ITS Claim Indicator Code has Valid Values")

    val result = sqlContext.sql("""select distinct its_clm_ind, bhi_home_plan_id, clm_id,mbr_id, trcblty_fld_cd from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where its_clm_ind NOT IN ('Y','N') """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct its_clm_ind, bhi_home_plan_id, clm_id,mbr_id, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where its_clm_ind NOT IN ('Y','N')")
      val data = Array("'ITS_Claim_Indicator_Code','BHI HPID','Claim_ID','MBR ID','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct its_clm_ind, bhi_home_plan_id, clm_id,mbr_id, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where its_clm_ind NOT IN ('Y','N')")
      val data = Array("'Invalid ITS_Claim_Indicator_Code','BHI HPID','Claim_ID','MBR ID','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Validate that Place of Service Code is present in Reference table - 020") {
    val id = Array("020")
    val name = Array("Test case : Validate that Place of Service Code is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(place_of_srvc_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_place_of_srvc_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(plos_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(plos_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(plos_cd) not in (select distinct (trim(place_of_srvc_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_place_of_srvc_inbnd)")
      val data = Array("'Place of Service_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(plos_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where err_id = '0' and exclsn_ind = 0 and trim(plos_cd) not in (select distinct (trim(place_of_srvc_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_place_of_srvc_inbnd)")
      val data = Array("'Invalid Place of Service_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate Last Date of Service is greater or equal to First Date of Service - 021") {
    val id = Array("021")
    val name = Array("Test case : Validate Last Date of Service is greater or equal to First Date of Service")

    val result = sqlContext.sql("""select last_srvc_dt,frst_srvc_dt, bhi_home_plan_id, clm_id, trcblty_fld_cd from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where last_srvc_dt < frst_srvc_dt """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select last_srvc_dt,frst_srvc_dt, bhi_home_plan_id, clm_id, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where last_srvc_dt < frst_srvc_dt")
      val data = Array("'Last Service date','First Service date','BHI HPID','Claim_ID','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select last_srvc_dt,frst_srvc_dt, bhi_home_plan_id, clm_id, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where last_srvc_dt < frst_srvc_dt")
      val data = Array("'Invalid Last Service date','First Service date','BHI HPID','Claim_ID','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  /*test("ClaimFacilityHeaderExtract -Validate that Submitted Amount is equal to or less than '-0' - 023"){
    val id = Array("023")
    val name = Array("Test case : Validate that Submitted Amount is equal to or less than '-0'")


    val result = sqlContext.sql("""select sbmtd_amt, bhi_home_plan_id, clm_id, trcblty_fld_cd,err_id,exclsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where sbmtd_amt < 0.00  """)


    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select sbmtd_amt, bhi_home_plan_id, clm_id, trcblty_fld_cd,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where sbmtd_amt < 0.00 ")
      val data = Array("'Subitted_Amount','BHI HPID','Claim_ID','Traceability' : No Invalid Values Found")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select sbmtd_amt, bhi_home_plan_id, clm_id, trcblty_fld_cd,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where sbmtd_amt < 0.00 ")
      val data = Array("'Invalid Subitted_Amount','BHI HPID','Claim_ID','Traceability'")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }


  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Non-Covered Amount is equal to or less than '-0' - 024") {
    val id = Array("024")
    val name = Array("Test case : Validate that Non-Covered Amount is equal to or less than '-0' ")


    val result = sqlContext.sql("""select non_cvrd_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind
      from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where non_cvrd_amt < 0.00  """)


    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select non_cvrd_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where non_cvrd_amt < 0.00 ")
      val data = Array("'Non-Covered_Amount','BHI HPID','Claim_ID','Traceability' : No Invalid Values Found")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select non_cvrd_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where non_cvrd_amt < 0.00 ")
      val data = Array("'Invalid Non-Covered_Amount','BHI HPID','Claim_ID','Traceability'")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Allowed Amount is equal to or less than '-0' - 025") {
    val id = Array("025")
    val name = Array("Test case : Validate that Allowed Amount is equal to or less than '-0'")


    val result = sqlContext.sql("""select alwd_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where alwd_amt < 0.00  """)


    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select alwd_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where alwd_amt < 0.00  ")
      val data = Array("'Allowed_Amount','BHI HPID','Claim_ID','Traceability' : No Invalid Values Found")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select alwd_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where alwd_amt < 0.00  ")
      val data = Array("'Invalid Allowed_Amount','BHI HPID','Claim_ID','Traceability'")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Payment Amount is equal to or less than '-0' - 026") {
    val id = Array("026")
    val name = Array("Test case : Validate that Payment Amount is equal to or less than '-0'")


    val result = sqlContext.sql("""select paymnt_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where paymnt_amt < 0.00  """)


    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select paymnt_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where paymnt_amt < 0.00 ")
      val data = Array("'Payment_Amount','BHI HPID','Claim_ID','Traceability' : No Invalid Values Found")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select paymnt_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where paymnt_amt < 0.00 ")
      val data = Array("'Invalid Payment_Amount','BHI HPID','Claim_ID','Traceability'")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Coinsurance Amount is equal to or less than '-0' - 027") {
    val id = Array("027")
    val name = Array("Test case : Validate that Coinsurance Amount is equal to or less than '-0")


    val result = sqlContext.sql("""select coinsrn_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where coinsrn_amt < 0.00  """)


    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select coinsrn_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where coinsrn_amt < 0.00 ")
      val data = Array("'Coinsurance_Amount','BHI HPID','Claim_ID','Traceability : No Invalid Values Found")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select coinsrn_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where coinsrn_amt < 0.00 ")
      val data = Array("'Invalid Coinsurance_Amount','BHI HPID','Claim_ID','Traceability")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Copay Amount is equal to or less than '-0' - 028") {
    val id = Array("028")
    val name = Array("Test case : Validate that Copay Amount is equal to or less than '-0'")

    val result = sqlContext.sql("""select cpay_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where cpay_amt < 0.00  """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select cpay_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where cpay_amt < 0.00 ")
      val data = Array("'Copay_Amount','BHI HPID','Claim_ID','Traceability : No Invalid Values Found")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select cpay_amt, bhi_home_plan_id, clm_id,  trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where cpay_amt < 0.00 ")
      val data = Array("'Invalid Copay_Amount','BHI HPID','Claim_ID','Traceability")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that Deductible Amount is equal to or less than '-0' - 029") {
    val id = Array("029")
    val name = Array("Test case : Validate that Deductible Amount is equal to or less than '-0'")

    val result = sqlContext.sql("""select ddctbl_amt, bhi_home_plan_id, clm_id, trcblty_fld_cd,err_id,exclsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where ddctbl_amt < 0.00  """)


    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select ddctbl_amt, bhi_home_plan_id, clm_id, trcblty_fld_cd,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where ddctbl_amt < 0.00 ")
      val data = Array("'Deductible_Amount','BHI HPID','Claim_ID','Traceability' : No Invalid Values Found")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select ddctbl_amt, bhi_home_plan_id, clm_id, trcblty_fld_cd,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where ddctbl_amt < 0.00 ")
      val data = Array("'Invalid Deductible_Amount','BHI HPID','Claim_ID','Traceability'")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)

    }
  }*/

  //===========================================

  test("ClaimFacilityHeaderExtract -Check if any rendering provider id is default when billing provider id is populated - 022") {
    val id = Array("022")
    val name = Array("Test case : Check if any rendering provider id is default when billing provider id is populated")

    val result = sqlContext.sql(""" select fch.BHI_HOME_PLAN_ID,fch.clm_id,fch.mbr_id,fch.BILLG_PROV_ID,fch.BILLG_PROV_ZIP_CD,
      fch.RNDRG_PROV_ID,fch.RNDRG_PROV_ZIP_CD from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr fch
         where fch.BILLG_PROV_ID  not like '%99999999999%' and fch.RNDRG_PROV_ID like '%99999999999%'  """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select fch.BHI_HOME_PLAN_ID,fch.clm_id,fch.mbr_id,fch.BILLG_PROV_ID,fch.BILLG_PROV_ZIP_CD,fch.RNDRG_PROV_ID,fch.RNDRG_PROV_ZIP_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr fchwhere fch.BILLG_PROV_ID  not like '%99999999999%' and fch.RNDRG_PROV_ID like '%99999999999%'  ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','BILLG_PROV_ID','BILLG_PROV_ZIP_CD','RNDRG_PROV_ID','RNDRG_PROV_ZIP_CD' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select fch.BHI_HOME_PLAN_ID,fch.clm_id,fch.mbr_id,fch.BILLG_PROV_ID,fch.BILLG_PROV_ZIP_CD,fch.RNDRG_PROV_ID,fch.RNDRG_PROV_ZIP_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr fchwhere fch.BILLG_PROV_ID  not like '%99999999999%' and fch.RNDRG_PROV_ID like '%99999999999%'  ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','BILLG_PROV_ID','BILLG_PROV_ZIP_CD','RNDRG_PROV_ID','RNDRG_PROV_ZIP_CD'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Check if any Billing  provider id is default when Rendering  provider id is populated - 023") {
    val id = Array("023")
    val name = Array("Test case : Check if any Billing  provider id is default when Rendering  provider id is populated")

    val result = sqlContext.sql(""" select fch.BHI_HOME_PLAN_ID,fch.clm_id,fch.mbr_id,fch.BILLG_PROV_ID,fch.BILLG_PROV_ZIP_CD,
      fch.RNDRG_PROV_ID,fch.RNDRG_PROV_ZIP_CD from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr fch 
        where fch.BILLG_PROV_ID   like '%99999999999%' and fch.RNDRG_PROV_ID not like '%99999999999%' """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select fch.BHI_HOME_PLAN_ID,fch.clm_id,fch.mbr_id,fch.BILLG_PROV_ID,fch.BILLG_PROV_ZIP_CD, fch.RNDRG_PROV_ID,fch.RNDRG_PROV_ZIP_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr fch  where fch.BILLG_PROV_ID   like '%99999999999%' and fch.RNDRG_PROV_ID not like '%99999999999%'  ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','BILLG_PROV_ID','BILLG_PROV_ZIP_CD','RNDRG_PROV_ID','RNDRG_PROV_ZIP_CD' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select fch.BHI_HOME_PLAN_ID,fch.clm_id,fch.mbr_id,fch.BILLG_PROV_ID,fch.BILLG_PROV_ZIP_CD, fch.RNDRG_PROV_ID,fch.RNDRG_PROV_ZIP_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr fch  where fch.BILLG_PROV_ID   like '%99999999999%' and fch.RNDRG_PROV_ID not like '%99999999999%'  ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','BILLG_PROV_ID','BILLG_PROV_ZIP_CD','RNDRG_PROV_ID','RNDRG_PROV_ZIP_CD'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Claim Payment Status should have Only values D and P - 024") {
    val id = Array("024")
    val name = Array("Test case : Claim Payment Status should have Only values D and P")

    val result = sqlContext.sql(""" select bhi_home_plan_id,clm_id,mbr_id,CLM_PAYMNT_STTS_CD 
      from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where CLM_PAYMNT_STTS_CD not in ('D','P') """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id,CLM_PAYMNT_STTS_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where CLM_PAYMNT_STTS_CD not in ('D','P') ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','CLM_PAYMNT_STTS_CD' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id,CLM_PAYMNT_STTS_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where CLM_PAYMNT_STTS_CD not in ('D','P') ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','CLM_PAYMNT_STTS_CD'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Claim Type should have Only values 1,2, and 4 - 025") {
    val id = Array("025")
    val name = Array("Test case : Claim Type should have Only values 1,2, and 4 ")

    val result = sqlContext.sql(""" select bhi_home_plan_id,clm_id,mbr_id, CLM_TYPE_CD  
      from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where CLM_TYPE_CD  not in ('1','2','4') """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id, CLM_TYPE_CD  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where CLM_TYPE_CD  not in ('1','2','4') ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','CLM_TYPE_CD' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id, CLM_TYPE_CD  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where CLM_TYPE_CD  not in ('1','2','4') ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','CLM_TYPE_CD'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Admit Type Code should have Only values 1,2,3,4,5,9 or else SPACE - 026") {
    val id = Array("026")
    val name = Array("Test case : Admit Type Code should have Only values 1,2,3,4,5,9 or else SPACE")

    val result = sqlContext.sql(""" select bhi_home_plan_id,clm_id,mbr_id, ADMT_TYPE_CD from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr 
      where trim(ADMT_TYPE_CD) not in ('1','2','3','4','5','9','') """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id, ADMT_TYPE_CD  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where trim(ADMT_TYPE_CD) not in ('1','2','3','4','5','9','') ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','ADMT_TYPE_CD' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id, ADMT_TYPE_CD  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where trim(ADMT_TYPE_CD) not in ('1','2','3','4','5','9','') ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','ADMT_TYPE_CD'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Non-Contracted Hold Harmless Negotiations Indicator should have Only values could be I,X,N - 027") {
    val id = Array("027")
    val name = Array("Test case : Non-Contracted Hold Harmless Negotiations Indicator should have Only values could be I,X,N")

    val result = sqlContext.sql(""" select bhi_home_plan_id,clm_id,mbr_id, NON_CNTRCTD_HHRMLS_NGTTN_IND 
    from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where NON_CNTRCTD_HHRMLS_NGTTN_IND  not in ('I','X','N') """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id, NON_CNTRCTD_HHRMLS_NGTTN_IND from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where NON_CNTRCTD_HHRMLS_NGTTN_IND  not in ('I','X','N')  ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','NON_CNTRCTD_HHRMLS_NGTTN_IND' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id, NON_CNTRCTD_HHRMLS_NGTTN_IND from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where NON_CNTRCTD_HHRMLS_NGTTN_IND  not in ('I','X','N')  ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','NON_CNTRCTD_HHRMLS_NGTTN_IND'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Billing Provider Contracting Status Indicator- Expected values are (I,Y,C,P,N) - 028") {
    val id = Array("028")
    val name = Array("Test case : Billing Provider Contracting Status Indicator- Expected values are ('I','Y','N','C','P','O')")

    val result = sqlContext.sql(""" select bhi_home_plan_id,clm_id,mbr_id,BILLG_PROV_CNTRCTG_STTS_IND  
    from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where BILLG_PROV_CNTRCTG_STTS_IND  not in ('I','Y','N','C','P','O') """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select bhi_home_plan_id,clm_id,mbr_id,BILLG_PROV_CNTRCTG_STTS_IND from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where BILLG_PROV_CNTRCTG_STTS_IND  not in ('I','Y','N','C','P','O') ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','BILLG_PROV_CNTRCTG_STTS_IND' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select bhi_home_plan_id,clm_id,mbr_id,BILLG_PROV_CNTRCTG_STTS_IND from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where BILLG_PROV_CNTRCTG_STTS_IND  not in ('I','Y','N','C','P','O') ")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','BILLG_PROV_CNTRCTG_STTS_IND'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Rendering  Provider Contracting Status Indicator- Expected values are (I,Y,C,P,N) - 029") {
    val id = Array("029")
    val name = Array("Test case : Rendering  Provider Contracting Status Indicator- Expected values are (I,Y,C,P,N)")

    val result = sqlContext.sql(""" select bhi_home_plan_id,clm_id,mbr_id,RNDRG_PROV_CNTRCTG_STTS_IND  
    from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where RNDRG_PROV_CNTRCTG_STTS_IND  not in ('I','Y','N','C','P','O') """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id,RNDRG_PROV_CNTRCTG_STTS_IND  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where RNDRG_PROV_CNTRCTG_STTS_IND  not in ('I','Y','N','C','P','O')")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','RNDRG_PROV_CNTRCTG_STTS_IND' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id,RNDRG_PROV_CNTRCTG_STTS_IND  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where RNDRG_PROV_CNTRCTG_STTS_IND  not in ('I','Y','N','C','P','O')")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','RNDRG_PROV_CNTRCTG_STTS_IND'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Facility Header and Facility details refrential Integrity check- 030") {
    val id = Array("030")
    val name = Array("Test case : Facility Header and Facility details refrential Integrity check")

    val result = sqlContext.sql(""" select distinct FCD.bhi_home_plan_id, FCD.clm_id, FCD.trcblty_fld_cd 
    from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl FCD left outer join """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH 
    on trim(FCD.bhi_home_plan_id)=trim(FCH.bhi_home_plan_id) and trim(FCD.clm_id)=trim(FCH.clm_id) and 
    trim(FCD.trcblty_fld_cd)=trim(FCH.trcblty_fld_cd) where FCH.trcblty_fld_cd is NULL """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct FCD.bhi_home_plan_id, FCD.clm_id, FCD.trcblty_fld_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl FCD left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH  on trim(FCD.bhi_home_plan_id)=trim(FCH.bhi_home_plan_id) and trim(FCD.clm_id)=trim(FCH.clm_id) and  trim(FCD.trcblty_fld_cd)=trim(FCH.trcblty_fld_cd) where FCH.trcblty_fld_cd is NULL")
      val data = Array(" 'BHI HomePlan ID','Claim ID','Traceability Field Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct FCD.bhi_home_plan_id, FCD.clm_id, FCD.trcblty_fld_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl FCD left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH  on trim(FCD.bhi_home_plan_id)=trim(FCH.bhi_home_plan_id) and trim(FCD.clm_id)=trim(FCH.clm_id) and  trim(FCD.trcblty_fld_cd)=trim(FCH.trcblty_fld_cd) where FCH.trcblty_fld_cd is NULL")
      val data = Array("'BHI HomePlan ID','Claim ID','Traceability Field Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -FCH Non covered reason code check - 031") {
    val id = Array("031")
    val name = Array("Test case : FCH Non covered reason code check")

    val result = sqlContext.sql(""" select distinct fch.NON_CVRD_RSN_CD_1,fch.BHI_HOME_PLAN_ID,fch.CLM_ID 
    from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr fch where fch.non_cvrd_amt  > 0 and fch.NON_CVRD_RSN_CD_1 <> '98' """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct fch.NON_CVRD_RSN_CD_1,fch.BHI_HOME_PLAN_ID,fch.CLM_ID  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr fch where fch.non_cvrd_amt  > 0 and fch.NON_CVRD_RSN_CD_1 <> '98'")
      val data = Array("'Non-Covered Reason Code','BHI HomePlan ID','Claim ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct fch.NON_CVRD_RSN_CD_1,fch.BHI_HOME_PLAN_ID,fch.CLM_ID  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr fch where fch.non_cvrd_amt  > 0 and fch.NON_CVRD_RSN_CD_1 <> '98'")
      val data = Array("'Non-Covered Reason Code','BHI HomePlan ID','Claim ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Claims System DRG Code – Values in this fields should be part of reference table only - 032") {
    val id = Array("032")
    val name = Array("Test case : Claims System DRG Code – Values in this fields should be part of reference table only")

    val result = sqlContext.sql(""" select distinct * from
(select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, FCH.clms_sys_drg_cd
from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH
left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.fclty_clm CLM
on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and
trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd)
where trim(CLM.drg_type_cd)="MS-DRG" and
length(trim(CLM.DRG_CD))=3 and 
trim(CLM.DRG_CD)<>"UNK" and
length(trim(FCH.clms_sys_drg_cd))=0 and
length(trim(CLM.DRG_CD))<>0)driver
left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd INB
on concat('0',trim(driver.DRG_CD))=trim(INB.drg_cd)
where INB.drg_cd is not NULL """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select clms_sys_drg_cd,BHI_HOME_PLAN_ID,CLM_ID,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_drg_inbnd REF on FCH.clms_sys_drg_cd = REF.drg_cd where REF.drg_cd  is NULL and FCH.clms_sys_drg_cd<>'NA' and Length(trim(FCH.clms_sys_drg_cd))<>0")
      val data = Array("'Claims System DRG Code','BHI HomePlan ID','Claim ID','MBR ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select clms_sys_drg_cd,BHI_HOME_PLAN_ID,CLM_ID,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_drg_inbnd REF on FCH.clms_sys_drg_cd = REF.drg_cd where REF.drg_cd  is NULL and FCH.clms_sys_drg_cd<>'NA' and Length(trim(FCH.clms_sys_drg_cd))<>0")
      val data = Array("'Claims System DRG Code','BHI HomePlan ID','Claim ID','MBR ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Claims System DRG MDC Code - Values in this fields should be part of reference table only - 033") {
    val id = Array("033")
    val name = Array("Test case : Claims System DRG MDC Code - Values in this fields should be part of reference table only")

    val result = sqlContext.sql(""" select clms_sys_drg_mdc_cd,BHI_HOME_PLAN_ID,CLM_ID,mbr_id from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH 
    left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_drg_inbnd REF on FCH.clms_sys_drg_mdc_cd = REF.mjr_diag_ctgry_cd 
    where REF.mjr_diag_ctgry_cd is NULL and FCH.clms_sys_drg_mdc_cd <>"NA" and Length(trim(FCH.clms_sys_drg_mdc_cd))<>0 """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select clms_sys_drg_mdc_cd,BHI_HOME_PLAN_ID,CLM_ID,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH  left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_drg_inbnd REF on FCH.clms_sys_drg_mdc_cd = REF.mjr_diag_ctgry_cd  where REF.mjr_diag_ctgry_cd is NULL and FCH.clms_sys_drg_mdc_cd <>'NA' and Length(trim(FCH.clms_sys_drg_mdc_cd))<>0")
      val data = Array("'Claims System DRG MDC Code','BHI HomePlan ID','Claim ID','MBR ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select clms_sys_drg_mdc_cd,BHI_HOME_PLAN_ID,CLM_ID,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH  left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_drg_inbnd REF on FCH.clms_sys_drg_mdc_cd = REF.mjr_diag_ctgry_cd  where REF.mjr_diag_ctgry_cd is NULL and FCH.clms_sys_drg_mdc_cd <>'NA' and Length(trim(FCH.clms_sys_drg_mdc_cd))<>0")
      val data = Array("'Claims System DRG MDC Code','BHI HomePlan ID','Claim ID','MBR ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Claims System APDRG Code -Values in this fields should be part of reference table only - 034") {
    val id = Array("034")
    val name = Array("Test case : Claims System APDRG Code -Values in this fields should be part of reference table only")

    val result = sqlContext.sql(""" select distinct * from
(select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, FCH.clms_sys_ap_drg_cd
from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH
left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.fclty_clm CLM
on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and
trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd)
where trim(CLM.drg_type_cd)="AP" and
length(trim(CLM.DRG_CD))=3 and 
trim(CLM.DRG_CD)<>"UNK" and
length(trim(FCH.clms_sys_ap_drg_cd))=0 and
length(trim(CLM.DRG_CD))<>0)driver
left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd INB
on concat('0',trim(driver.DRG_CD))=trim(INB.drg_cd)
where INB.drg_cd is not NULL """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select clms_sys_ap_drg_cd,BHI_HOME_PLAN_ID,CLM_ID,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_drg_inbnd REF on FCH.clms_sys_ap_drg_cd = REF.drg_cd  where REF.drg_cd is NULL and FCH.clms_sys_ap_drg_cd <>'NA' and Length(trim(FCH.clms_sys_ap_drg_cd))<>0")
      val data = Array("'Claims System APDRG Code','BHI HomePlan ID','Claim ID','MBR ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select clms_sys_ap_drg_cd,BHI_HOME_PLAN_ID,CLM_ID,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_drg_inbnd REF on FCH.clms_sys_ap_drg_cd = REF.drg_cd  where REF.drg_cd is NULL and FCH.clms_sys_ap_drg_cd <>'NA' and Length(trim(FCH.clms_sys_ap_drg_cd))<>0")
      val data = Array("'Claims System APDRG Code','BHI HomePlan ID','Claim ID','MBR ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Claims System APDRG MDC Code - Values in this fields should be part of reference table only - 035") {
    val id = Array("035")
    val name = Array("Test case : Claims System APDRG MDC Code - Values in this fields should be part of reference table only")

    val result = sqlContext.sql(""" select clms_sys_ap_drg_mjr_dgnstc_category_code,BHI_HOME_PLAN_ID,CLM_ID,mbr_id from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH 
    left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_drg_inbnd REF on FCH.clms_sys_ap_drg_mjr_dgnstc_category_code = REF.mjr_diag_ctgry_cd 
    where REF.mjr_diag_ctgry_cd is NULL and FCH.clms_sys_ap_drg_mjr_dgnstc_category_code <>"NA" and 
    Length(trim(FCH.clms_sys_ap_drg_mjr_dgnstc_category_code))<>0 """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select clms_sys_ap_drg_mjr_dgnstc_category_code,BHI_HOME_PLAN_ID,CLM_ID,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_drg_inbnd REF on FCH.clms_sys_ap_drg_mjr_dgnstc_category_code = REF.mjr_diag_ctgry_cd  where REF.mjr_diag_ctgry_cd is NULL and FCH.clms_sys_ap_drg_mjr_dgnstc_category_code <>'NA' and  Length(trim(FCH.clms_sys_ap_drg_mjr_dgnstc_category_code))<>0")
      val data = Array("'Claims System APDRG MDC Code','BHI HomePlan ID','Claim ID','MBR ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select clms_sys_ap_drg_mjr_dgnstc_category_code,BHI_HOME_PLAN_ID,CLM_ID,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_drg_inbnd REF on FCH.clms_sys_ap_drg_mjr_dgnstc_category_code = REF.mjr_diag_ctgry_cd  where REF.mjr_diag_ctgry_cd is NULL and FCH.clms_sys_ap_drg_mjr_dgnstc_category_code <>'NA' and  Length(trim(FCH.clms_sys_ap_drg_mjr_dgnstc_category_code))<>0")
      val data = Array(" 'Claims System APDRG MDC Code','BHI HomePlan ID','Claim ID','MBR ID' ")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract -Validate that no FEP claims present in Extract - 036") {
    val id = Array("036")
    val name = Array("Test case : Validate that no FEP claims present in Extract")

    val result1 = sqlContext.sql(""" select  distinct stg.bhi_home_plan_id,stg.home_plan_prod_id,stg.mbr_id,stg.mbr_key,stg.clm_adjstmnt_key,c.src_grp_nbr,coa.mbu_cf_cd 
from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg stg inner join """ + dbname + """_pcandw1ph_nogbd_r000_in.clm  c 
on c.clm_adjstmnt_key= stg.clm_adjstmnt_key inner join """ + dbname + """_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa coa 
on c.mbr_key= coa.mbr_key where c.src_grp_nbr='FEP'""")

    val result2 = sqlContext.sql(""" select TRCBLTY_FLD_CD,COUNT(*) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr GROUP BY TRCBLTY_FLD_CD having TRCBLTY_FLD_CD 
in ("888","896")""")

    if (result1.count == 0 && result2.count == 0) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query1 :  select  distinct stg.bhi_home_plan_id,stg.home_plan_prod_id,stg.mbr_id,stg.mbr_key,stg.clm_adjstmnt_key,c.src_grp_nbr,coa.mbu_cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg stg inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm  c on c.clm_adjstmnt_key= stg.clm_adjstmnt_key inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa coa on c.mbr_key= coa.mbr_key where c.src_grp_nbr='FEP'")
      val query2 = Array("Test Query2 :  select TRCBLTY_FLD_CD,COUNT(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr GROUP BY TRCBLTY_FLD_CD having TRCBLTY_FLD_CD in ('888','896')")
      val data = Array(" Count of both the queries are Matching")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query1, 1)).union(sc.parallelize(query2, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query1 :  select  distinct stg.bhi_home_plan_id,stg.home_plan_prod_id,stg.mbr_id,stg.mbr_key,stg.clm_adjstmnt_key,c.src_grp_nbr,coa.mbu_cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg stg inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm  c on c.clm_adjstmnt_key= stg.clm_adjstmnt_key inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa coa on c.mbr_key= coa.mbr_key where c.src_grp_nbr='FEP'")
      val query2 = Array("Test Query2 :  select TRCBLTY_FLD_CD,COUNT(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr GROUP BY TRCBLTY_FLD_CD having TRCBLTY_FLD_CD in ('888','896')")
      val data = Array(" Count of both the queries are not Matching")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query1, 1)).union(sc.parallelize(query2, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)

    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - FCH global filter check service rendering type - 037") {
    val id = Array("037")
    val name = Array("Test case : FCH global filter check service rendering type ")

    val result = sqlContext.sql(""" select  E.CLM_ADJSTMNT_KEY,E.CLM_ID,E.MBR_ID FROM """ + dbname + """_PCANDW1PH_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg  E 
INNER JOIN """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM C ON E.CLM_ADJSTMNT_KEY= C.CLM_ADJSTMNT_KEY AND C.SRVC_RNDRG_TYPE_CD NOT IN('HOSP','FANCL') """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  E.CLM_ADJSTMNT_KEY,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg  E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.CLM_ADJSTMNT_KEY= C.CLM_ADJSTMNT_KEY AND C.SRVC_RNDRG_TYPE_CD NOT IN('HOSP','FANCL')")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  E.CLM_ADJSTMNT_KEY,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg  E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.CLM_ADJSTMNT_KEY= C.CLM_ADJSTMNT_KEY AND C.SRVC_RNDRG_TYPE_CD NOT IN('HOSP','FANCL')")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - FCH global filter check adjudication status code - 038") {
    val id = Array("038")
    val name = Array("Test case : FCH global filter check adjudication status code ")

    val result = sqlContext.sql(""" select  E.CLM_ADJSTMNT_KEY,E.CLM_ID,E.MBR_ID FROM """ + dbname + """_PCANDW1PH_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg  E 
INNER JOIN """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM C ON E.CLM_ADJSTMNT_KEY= C.CLM_ADJSTMNT_KEY   AND  C.ADJDCTN_STTS_CD  IN (03, 10) """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  E.CLM_ADJSTMNT_KEY,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg  E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.CLM_ADJSTMNT_KEY= C.CLM_ADJSTMNT_KEY   AND  C.ADJDCTN_STTS_CD  IN (03, 10)")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  E.CLM_ADJSTMNT_KEY,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg  E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.CLM_ADJSTMNT_KEY= C.CLM_ADJSTMNT_KEY   AND  C.ADJDCTN_STTS_CD  IN (03, 10)")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - FCH global filter check claims its host type - 039") {
    val id = Array("039")
    val name = Array("Test case : FCH global filter check claims its host type ")

    val result = sqlContext.sql(""" select  E.CLM_ADJSTMNT_KEY,E.CLM_ID,E.MBR_ID FROM """ + dbname + """_PCANDW1PH_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg  E 
INNER JOIN """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM C ON E.CLM_ADJSTMNT_KEY= C.CLM_ADJSTMNT_KEY AND C.CLM_ITS_HOST_CD  in ('HOST', 'JAACL') """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  E.CLM_ADJSTMNT_KEY,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg  E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.CLM_ADJSTMNT_KEY= C.CLM_ADJSTMNT_KEY AND C.CLM_ITS_HOST_CD  in ('HOST', 'JAACL')")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  E.CLM_ADJSTMNT_KEY,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg  E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.CLM_ADJSTMNT_KEY= C.CLM_ADJSTMNT_KEY AND C.CLM_ITS_HOST_CD  in ('HOST', 'JAACL')")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Check Category of service should be IP ACUTE - 040") {
    val id = Array("040")
    val name = Array("Test case : Check Category of service should be IP ACUTE ")

    val result = sqlContext.sql(""" select FCH.srvc_ctgry_cd from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH 
      left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and 
        trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.clm_adjstmnt_key is not NULL and 
        SUBSTR(trim(CLM.type_of_bill_cd), 2,2) in ('11', '12', '41' ,'42' ,'84') and UPPER(trim(FCH.srvc_ctgry_cd)) <> "IP ACUTE" """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select FCH.srvc_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.clm_adjstmnt_key is not NULL and  SUBSTR(trim(CLM.type_of_bill_cd), 2,2) in ('11', '12', '41' ,'42' ,'84') and UPPER(trim(FCH.srvc_ctgry_cd)) <> 'IP ACUTE'")
      val data = Array("'FCH.srvc_ctgry_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select FCH.srvc_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.clm_adjstmnt_key is not NULL and  SUBSTR(trim(CLM.type_of_bill_cd), 2,2) in ('11', '12', '41' ,'42' ,'84') and UPPER(trim(FCH.srvc_ctgry_cd)) <> 'IP ACUTE'")
      val data = Array("'FCH.srvc_ctgry_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Check Category of service should be IP NON-ACUTE - 041") {
    val id = Array("041")
    val name = Array("Test case : Check Category of service should be IP NON-ACUTE ")

    val result = sqlContext.sql(""" select FCH.srvc_ctgry_cd from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH 
      left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and 
        trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.clm_adjstmnt_key is not NULL and 
        SUBSTR(trim(CLM.type_of_bill_cd), 2,2) in ('15','16','17','18','21','22','25','26','27','28','45','46','47','48','51','52','55','56','57','58','61','62','65','66','67','68','81','82') and 
        UPPER(trim(FCH.srvc_ctgry_cd)) <> "IP NON-ACUTE" """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select FCH.srvc_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.clm_adjstmnt_key is not NULL and  SUBSTR(trim(CLM.type_of_bill_cd), 2,2) in ('15','16','17','18','21','22','25','26','27','28','45','46','47','48','51','52','55','56','57','58','61','62','65','66','67','68','81','82') and  UPPER(trim(FCH.srvc_ctgry_cd)) <> 'IP NON-ACUTE'")
      val data = Array("'FCH.srvc_ctgry_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select FCH.srvc_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.clm_adjstmnt_key is not NULL and  SUBSTR(trim(CLM.type_of_bill_cd), 2,2) in ('15','16','17','18','21','22','25','26','27','28','45','46','47','48','51','52','55','56','57','58','61','62','65','66','67','68','81','82') and  UPPER(trim(FCH.srvc_ctgry_cd)) <> 'IP NON-ACUTE'")
      val data = Array("'FCH.srvc_ctgry_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - ICD-9 & ICD-10 defaults validation - 042") {
    val id = Array("042")
    val name = Array("Test case : ICD-9 & ICD-10 defaults validation ")

    val result = sqlContext.sql(""" select * from (
select HDR.bhi_home_plan_id, HDR.clm_id, HDR.clm_adjstmnt_key, HDR.prncpal_icd9_diag_cd, HDR.prncpal_icd10_diag_cd, CLM.PRNCPL_DIAG_CD, DIAG.rptg_diag_cd 
from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg HDR
left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.clm CLM
on HDR.clm_adjstmnt_key=CLM.clm_adjstmnt_key and
trim(HDR.trcblty_fld_cd)=trim(CLM.clm_sor_cd)
left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.diag DIAG
on trim(CLM.PRNCPL_DIAG_CD)=trim(DIAG.diag_cd)
where DIAG.diag_cd is not NULL and
CLM.clm_adjstmnt_key is not NULL and
trim(HDR.prncpal_icd9_diag_cd) = "UN" and
(trim(HDR.prncpal_icd10_diag_cd) = "UN" or trim(HDR.prncpal_icd10_diag_cd) = "") and
CLM.ICD_VRSN_CD = '10' and
length(trim(CLM.PRNCPL_DIAG_CD))>0
)a """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from (select HDR.bhi_home_plan_id, HDR.clm_id, HDR.clm_adjstmnt_key, HDR.prncpal_icd9_diag_cd, HDR.prncpal_icd10_diag_cd, CLM.PRNCPL_DIAG_CD, DIAG.rptg_diag_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg HDR left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm CLM on HDR.clm_adjstmnt_key=CLM.clm_adjstmnt_key and trim(HDR.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.diag DIAG on trim(CLM.PRNCPL_DIAG_CD)=trim(DIAG.diag_cd) where DIAG.diag_cd is not NULL and CLM.clm_adjstmnt_key is not NULL and trim(HDR.prncpal_icd9_diag_cd) = 'UN' and (trim(HDR.prncpal_icd10_diag_cd) = 'UN' or trim(HDR.prncpal_icd10_diag_cd) = '') and CLM.ICD_VRSN_CD = '10' and length(trim(CLM.PRNCPL_DIAG_CD))>0)a")
      val data = Array(" : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select HDR.bhi_home_plan_id, HDR.clm_id, HDR.clm_adjstmnt_key, HDR.prncpal_icd9_diag_cd, HDR.prncpal_icd10_diag_cd, CLM.PRNCPL_DIAG_CD, DIAG.rptg_diag_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg HDR left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm CLM on HDR.clm_adjstmnt_key=CLM.clm_adjstmnt_key and trim(HDR.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.diag DIAG on trim(CLM.PRNCPL_DIAG_CD)=trim(DIAG.diag_cd) where DIAG.diag_cd is not NULL and CLM.clm_adjstmnt_key is not NULL and trim(HDR.prncpal_icd9_diag_cd) = 'UN' and (trim(HDR.prncpal_icd10_diag_cd) = 'UN' or trim(HDR.prncpal_icd10_diag_cd) = '') and CLM.ICD_VRSN_CD = '10' and length(trim(CLM.PRNCPL_DIAG_CD))>0)a")
      val data = Array("")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Validate the admt_src_cd transformation logic - 043") {
    val id = Array("043")
    val name = Array("Test case : Validate the admt_src_cd transformation logic ")

    val result = sqlContext.sql(""" select admt_src_cd from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr
       where admt_src_cd not in ("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "20", "21", "41", "42", "43", "44", "45", "46", "49", "A", "B", "C", "D", "E", "F") and length(trim(admt_src_cd))<>0 """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select admt_src_cd from '''+dbname'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where admt_src_cd not in ('00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '20', '21', '41', '42', '43', '44', '45', '46', '49', 'A', 'B', 'C', 'D', 'E', 'F') and length(trim(admt_src_cd))<>0")
      val data = Array("'admt_src_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select admt_src_cd from '''+dbname'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where admt_src_cd not in ('00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '20', '21', '41', '42', '43', '44', '45', '46', '49', 'A', 'B', 'C', 'D', 'E', 'F') and length(trim(admt_src_cd))<>0")
      val data = Array("'admt_src_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Validate the authorization id transformation logic - 044") {
    val id = Array("044")
    val name = Array("Test case : Validate the authorization id transformation logic ")

    val result = sqlContext.sql(""" select FCH.authrzn_id from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH 
      left outer join (select PA_NBR as au_id from """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM  where PA_NBR not in ('NA','N/A','') and PA_NBR not like '%UNK%' 
  union all select CLM_LINE_PA_NBR as au_id from """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM_LINE) CLM on trim(FCH.authrzn_id)=trim(CLM.au_id) where CLM.au_id is NULL """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select FCH.authrzn_id from '''+dbname'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH  left outer join (select PA_NBR as au_id from '''+dbname'''_pcandw1ph_nogbd_r000_in.CLM  where PA_NBR not in ('NA','N/A','') and PA_NBR not like '%UNK%'  union all select CLM_LINE_PA_NBR as au_id from '''+dbname'''_pcandw1ph_nogbd_r000_in.CLM_LINE) CLM on trim(FCH.authrzn_id)=trim(CLM.au_id) where CLM.au_id is NULL")
      val data = Array("'authrzn_id' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select FCH.authrzn_id from '''+dbname'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FCH  left outer join (select PA_NBR as au_id from '''+dbname'''_pcandw1ph_nogbd_r000_in.CLM  where PA_NBR not in ('NA','N/A','') and PA_NBR not like '%UNK%'  union all select CLM_LINE_PA_NBR as au_id from '''+dbname'''_pcandw1ph_nogbd_r000_in.CLM_LINE) CLM on trim(FCH.authrzn_id)=trim(CLM.au_id) where CLM.au_id is NULL")
      val data = Array("'authrzn_id'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Principal proc code 'NA' default validation - 045") {
    val id = Array("045")
    val name = Array("Test case : Principal proc code 'NA' default validation ")

    val result = sqlContext.sql(""" select distinct clm_id,mbr_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where clm_type_cd  not in ('1','2','4','UN') limit 10 """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct clm_id,mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where clm_type_cd  not in ('1','2','4','UN') limit 10")
      val data = Array("'clm_type_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct clm_id,mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where clm_type_cd  not in ('1','2','4','UN') limit 10")
      val data = Array("'clm_type_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Principal proc code spaces default validation - 046") {
    val id = Array("046")
    val name = Array("Test case : Principal proc code spaces default validation ")

    val result = sqlContext.sql(""" select distinct clm_id,mbr_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where srvc_ctgry_cd="IP ACUTE" AND clm_type_cd  not in ("1") limit 10""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct clm_id,mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where srvc_ctgry_cd='IP ACUTE' AND clm_type_cd  not in ('1') limit 10")
      val data = Array("'clm_type_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct clm_id,mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where srvc_ctgry_cd='IP ACUTE' AND clm_type_cd  not in ('1') limit 10")
      val data = Array("'clm_type_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Validate that the category of code and clm type are in sync - 047") {
    val id = Array("047")
    val name = Array("Test case : Validate that the category of code and clm type are in sync. ")

    val result = sqlContext.sql(""" select srvc_ctgry_cd, clm_type_cd from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr 
      where clm_type_cd="2" and srvc_ctgry_cd like "%IP%" """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select srvc_ctgry_cd, clm_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where clm_type_cd='2' and srvc_ctgry_cd like '%IP%'")
      val data = Array("'srvc_ctgry_cd', 'clm_type_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select srvc_ctgry_cd, clm_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  where clm_type_cd='2' and srvc_ctgry_cd like '%IP%'")
      val data = Array("'srvc_ctgry_cd', 'clm_type_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Submission type code field validation - 048") {
    val id = Array("048")
    val name = Array("Test case : Submission type code field validation  ")

    val result = sqlContext.sql(""" select FCH.sbmsn_type_cd from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH 
      left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and 
      trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM_FORM_TYPE_CD) not in ('PA', 'EL', 'SC', 'WB') and trim(FCH.sbmsn_type_cd)="NA" """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select FCH.sbmsn_type_cd from '''+dbname'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname'''_pcandw1ph_nogbd_r000_in.CLM CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and  trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM_FORM_TYPE_CD) not in ('PA', 'EL', 'SC', 'WB') and trim(FCH.sbmsn_type_cd)='NA'")
      val data = Array("'sbmsn_type_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select FCHsbmsn_type_cd from '''+dbname'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname'''_pcandw1ph_nogbd_r000_in.CLM CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and  trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM_FORM_TYPE_CD) not in ('PA', 'EL', 'SC', 'WB') and trim(FCH.sbmsn_type_cd)='NA'")
      val data = Array("'sbmsn_type_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Claim type code field validation, Scenario-1 - 049") {
    val id = Array("049")
    val name = Array("Test case : Claim type code field validation,Scenario-1 ")

    /*    val result = sqlContext.sql(""" select FCH.clm_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH
      left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM_LINE CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and
      trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.INPAT_CD = 'Y' and FCH.clm_type_cd=2 """)*/

    val result = sqlContext.sql(s"""Select distinct clm_id, clm_type_cd from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr WHERE clm_type_cd not in ('1','2','4')""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : Select distinct clm_id, clm_type_cd from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr WHERE clm_type_cd not in ('1','2','4')")
      val data = Array("'clm_type_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : Select distinct clm_id, clm_type_cd from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr WHERE clm_type_cd not in ('1','2','4')")
      val data = Array("'clm_type_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Claim type code field validation, Scenario-2 - 050") {
    val id = Array("050")
    val name = Array("Test case : Claim type code field validation,Scenario-2  ")

    /*    val result = sqlContext.sql(""" select FCH.clm_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH
      left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM_LINE CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and
      trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.INPAT_CD = 'Y' and FCH.clm_type_cd=2 """)*/

    val result = sqlContext.sql(s"""Select distinct clm_id, clm_type_cd from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr WHERE srvc_ctgry_cd ='IP ACUTE' 
      AND clm_type_cd not in ('1')""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : Select distinct clm_id, clm_type_cd from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr WHERE srvc_ctgry_cd ='IP ACUTE' AND clm_type_cd not in ('1')")
      val data = Array("'clm_type_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : Select distinct clm_id, clm_type_cd from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr WHERE srvc_ctgry_cd ='IP ACUTE' AND clm_type_cd not in ('1')")
      val data = Array("'clm_type_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Claim type code field validation, Scenario-3 - 051") {
    val id = Array("051")
    val name = Array("Test case : Claim type code field validation,Scenario-3")

    /*    val result = sqlContext.sql(""" select FCH.clm_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH
      left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM_LINE CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and
      trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.INPAT_CD = 'Y' and FCH.clm_type_cd=2 """)*/

    val result = sqlContext.sql(s"""Select distinct clm_id, clm_type_cd from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr WHERE srvc_ctgry_cd ='IP NON-ACUTE' 
      AND clm_type_cd not in ('1','4')""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : Select distinct clm_id, clm_type_cd from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr WHERE srvc_ctgry_cd ='IP NON-ACUTE' AND clm_type_cd not in ('1','4')")
      val data = Array("'clm_type_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : Select distinct clm_id, clm_type_cd from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr WHERE srvc_ctgry_cd ='IP NON-ACUTE' AND clm_type_cd not in ('1','4')")
      val data = Array("'clm_type_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Claim type code field validation, Scenario-4 - 052") {
    val id = Array("052")
    val name = Array("Test case : Claim type code field validation,Scenario-4")

    /*    val result = sqlContext.sql(""" select FCH.clm_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH
      left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM_LINE CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and
      trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.INPAT_CD = 'Y' and FCH.clm_type_cd=2 """)*/

    val result = sqlContext.sql(s"""select distinct FCH.CLM_ID,FCH.clm_type_cd from ${dbname}_pcandw1ph_nogbd_r000_OU.bcbsa_fclty_clm_hdr FCH
inner join ${dbname}_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH_STG
ON FCH.CLM_ID=FCH_STG.CLM_ID
INNER JOIN  ${dbname}_pcandw1ph_nogbd_r000_in.FCLTY_CLM FC on 
trim(FCH_STG.clm_adjstmnt_key)=trim(FC.clm_adjstmnt_key) 
where  FCH.srvc_ctgry_cd ='IP NON-ACUTE' AND FC.Type_Of_Bill_CD LIKE '01%' AND FCH.clm_type_cd<>'1'""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"""select distinct FCH.CLM_ID,FCH.clm_type_cd from ${dbname}_pcandw1ph_nogbd_r000_OU.bcbsa_fclty_clm_hdr FCH
inner join ${dbname}_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH_STG
ON FCH.CLM_ID=FCH_STG.CLM_ID
INNER JOIN  ${dbname}_pcandw1ph_nogbd_r000_in.FCLTY_CLM FC on 
trim(FCH_STG.clm_adjstmnt_key)=trim(FC.clm_adjstmnt_key) 
where  FCH.srvc_ctgry_cd ='IP NON-ACUTE' AND FC.Type_Of_Bill_CD LIKE '01%' AND FCH.clm_type_cd<>'1'""")
      val data = Array("'clm_type_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"""select distinct FCH.CLM_ID,FCH.clm_type_cd from ${dbname}_pcandw1ph_nogbd_r000_OU.bcbsa_fclty_clm_hdr FCH
inner join ${dbname}_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH_STG
ON FCH.CLM_ID=FCH_STG.CLM_ID
INNER JOIN  ${dbname}_pcandw1ph_nogbd_r000_in.FCLTY_CLM FC on 
trim(FCH_STG.clm_adjstmnt_key)=trim(FC.clm_adjstmnt_key) 
where  FCH.srvc_ctgry_cd ='IP NON-ACUTE' AND FC.Type_Of_Bill_CD LIKE '01%' AND FCH.clm_type_cd<>'1'""")
      val data = Array("'clm_type_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Claim type code field validation, Scenario-5 - 053") {
    val id = Array("053")
    val name = Array("Test case : Claim type code field validation,Scenario-5")

    /*    val result = sqlContext.sql(""" select FCH.clm_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH
      left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.CLM_LINE CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and
      trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where CLM.INPAT_CD = 'Y' and FCH.clm_type_cd=2 """)*/

    val result = sqlContext.sql(s"""Select distinct clm_id, clm_type_cd from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr WHERE srvc_ctgry_cd not in ('IP NON-ACUTE','IP ACUTE') 
      AND clm_type_cd<>'2'""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"""Select distinct clm_id, clm_type_cd from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr WHERE srvc_ctgry_cd not in ('IP NON-ACUTE','IP ACUTE') 
      AND clm_type_cd<>'2'""")
      val data = Array("'clm_type_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"""Select distinct clm_id, clm_type_cd from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr WHERE srvc_ctgry_cd not in ('IP NON-ACUTE','IP ACUTE') 
      AND clm_type_cd<>'2'""")
      val data = Array("'clm_type_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimFacilityHeaderExtract - Validate that there are 14 BHI Home Plan ID  - 054") {

    val id = Array("054")
    val name = Array("Test case : Validate that there are 14 BHI Home Plan ID ")

    val result = sqlContext.sql(""" select count(distinct bhi_home_plan_id) from """ + dbname + """_PCANDW1PH_nogbd_r000_ou.bcbsa_fclty_clm_hdr """)

    if (result.collectAsList.toString.contains("14")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_fclty_clm_hdr ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_fclty_clm_hdr ")
      val data = Array("'Count' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }
  //==========================================

  test("ClaimFacilityHeaderExtract - To check clms_sys_drg_cd default spaces are populated as per mapping (where length(drug code)=3 in source) - 055") {

    val id = Array("055")
    val name = Array("Test case : To check default spaces are populated as per mapping (where length(drug code)=3 in source) ")

    val result = sqlContext.sql(""" select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, 
      FCH.clms_sys_drg_cd, XWALK.drg_cd, XWALK.drg_long_desc from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer 
      join """ + dbname + """_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and 
      trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd XWALK 
      on concat("0",trim(CLM.DRG_CD))=trim(XWALK.drg_cd) where trim(CLM.drg_type_cd)="MS-DRG" and length(trim(CLM.DRG_CD))=3 and 
      trim(CLM.DRG_CD)<>"UNK" and length(trim(FCH.clms_sys_drg_cd))=0 and length(trim(CLM.DRG_CD))<>0 and CLM.clm_adjstmnt_key is 
      not NULL and CLM.cdh_rcrd_stts_cd="ACT" and XWALK.drg_cd is not NULL limit 10 """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD,FCH.clms_sys_drg_cd, XWALK.drg_cd, XWALK.drg_long_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd XWALK on concat('0',trim(CLM.DRG_CD))=trim(XWALK.drg_cd) where trim(CLM.drg_type_cd)='MS-DRG' and length(trim(CLM.DRG_CD))=3 and trim(CLM.DRG_CD)<>'UNK' and length(trim(FCH.clms_sys_drg_cd))=0 and length(trim(CLM.DRG_CD))<>0 and CLM.clm_adjstmnt_key is not NULL and CLM.cdh_rcrd_stts_cd='ACT' and XWALK.drg_cd is not NULL limit 10  ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_drg_cd', 'XWALK.drg_cd', 'XWALK.drg_long_desc' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD,FCH.clms_sys_drg_cd, XWALK.drg_cd, XWALK.drg_long_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd XWALK on concat('0',trim(CLM.DRG_CD))=trim(XWALK.drg_cd) where trim(CLM.drg_type_cd)='MS-DRG' and length(trim(CLM.DRG_CD))=3 and trim(CLM.DRG_CD)<>'UNK' and length(trim(FCH.clms_sys_drg_cd))=0 and length(trim(CLM.DRG_CD))<>0 and CLM.clm_adjstmnt_key is not NULL and CLM.cdh_rcrd_stts_cd='ACT' and XWALK.drg_cd is not NULL limit 10  ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_drg_cd', 'XWALK.drg_cd', 'XWALK.drg_long_desc' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - To check clms_sys_drg_cd default spaces are populated as per mapping (where length(drug code)<>3 in source) - 056") {

    val id = Array("056")
    val name = Array("Test case : To check default spaces are populated as per mapping (where length(drug code)<>3 in source) ")

    val result = sqlContext.sql(""" select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, 
      FCH.clms_sys_drg_cd, XWALK.drg_cd, XWALK.drg_long_desc from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer 
      join """ + dbname + """_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and 
      trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd XWALK 
      on trim(CLM.DRG_CD)=trim(XWALK.drg_cd) where trim(CLM.drg_type_cd)="MS-DRG" and length(trim(CLM.DRG_CD))<>3 and 
      length(trim(FCH.clms_sys_drg_cd))=0 and length(trim(CLM.DRG_CD))<>0 and CLM.clm_adjstmnt_key is not NULL and 
      CLM.cdh_rcrd_stts_cd="ACT" and XWALK.drg_cd is not NULL limit 10 """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, FCH.clms_sys_drg_cd, XWALK.drg_cd, XWALK.drg_long_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd XWALK on trim(CLM.DRG_CD)=trim(XWALK.drg_cd) where trim(CLM.drg_type_cd)='MS-DRG' and length(trim(CLM.DRG_CD))<>3 and length(trim(FCH.clms_sys_drg_cd))=0 and length(trim(CLM.DRG_CD))<>0 and CLM.clm_adjstmnt_key is not NULL and CLM.cdh_rcrd_stts_cd='ACT' and XWALK.drg_cd is not NULL limit 10  ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_drg_cd', 'XWALK.drg_cd', 'XWALK.drg_long_desc' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, FCH.clms_sys_drg_cd, XWALK.drg_cd, XWALK.drg_long_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd XWALK on trim(CLM.DRG_CD)=trim(XWALK.drg_cd) where trim(CLM.drg_type_cd)='MS-DRG' and length(trim(CLM.DRG_CD))<>3 and length(trim(FCH.clms_sys_drg_cd))=0 and length(trim(CLM.DRG_CD))<>0 and CLM.clm_adjstmnt_key is not NULL and CLM.cdh_rcrd_stts_cd='ACT' and XWALK.drg_cd is not NULL limit 10  ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_drg_cd', 'XWALK.drg_cd', 'XWALK.drg_long_desc' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - To check that the value of drug code is as per mapping logic - 057") {

    val id = Array("057")
    val name = Array("Test case : To check that the value of drug code is as per mapping logic ")

    val result = sqlContext.sql(""" select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, 
      FCH.clms_sys_drg_cd, REF.drg_cd from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join 
      """ + dbname + """_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and 
      trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) and substr(trim(FCH.clms_sys_drg_cd), 2)=trim(CLM.DRG_CD) left outer join 
      """ + dbname + """_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd REF on trim(FCH.clms_sys_drg_cd)=trim(REF.drg_cd) where 
      trim(CLM.drg_type_cd)="MS-DRG" and length(trim(CLM.DRG_CD))=3 and trim(CLM.DRG_CD)<>"UNK" and 
      length(trim(FCH.clms_sys_drg_cd))<>0 and (CLM.DRG_CD is NULL or REF.drg_cd is NULL) limit 10 """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, FCH.clms_sys_drg_cd, REF.drg_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and  trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) and substr(trim(FCH.clms_sys_drg_cd), 2)=trim(CLM.DRG_CD) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd REF on trim(FCH.clms_sys_drg_cd)=trim(REF.drg_cd) where trim(CLM.drg_type_cd)='MS-DRG' and length(trim(CLM.DRG_CD))=3 and trim(CLM.DRG_CD)<>'UNK' and length(trim(FCH.clms_sys_drg_cd))<>0 and (CLM.DRG_CD is NULL or REF.drg_cd is NULL) limit 10  ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_drg_cd', 'REF.drg_cd' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, FCH.clms_sys_drg_cd, REF.drg_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and  trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) and substr(trim(FCH.clms_sys_drg_cd), 2)=trim(CLM.DRG_CD) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd REF on trim(FCH.clms_sys_drg_cd)=trim(REF.drg_cd) where trim(CLM.drg_type_cd)='MS-DRG' and length(trim(CLM.DRG_CD))=3 and trim(CLM.DRG_CD)<>'UNK' and length(trim(FCH.clms_sys_drg_cd))<>0 and (CLM.DRG_CD is NULL or REF.drg_cd is NULL) limit 10  ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_drg_cd', 'REF.drg_cd' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - To check clms_sys_ap_drg_cd default spaces are populated as per mapping (where length(drug code)=3 in source) - 058") {

    val id = Array("058")
    val name = Array("Test case : To check default spaces are populated as per mapping (where length(drug code)=3 in source) ")

    val result = sqlContext.sql(""" select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, 
      FCH.clms_sys_ap_drg_cd, XWALK.drg_cd, XWALK.drg_long_desc from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH 
      left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and 
      trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd XWALK 
      on concat("0",trim(CLM.DRG_CD))=trim(XWALK.drg_cd) where trim(CLM.drg_type_cd)="AP" and length(trim(CLM.DRG_CD))=3 and 
      trim(CLM.DRG_CD)<>"UNK" and length(trim(FCH.clms_sys_ap_drg_cd))=0 and length(trim(CLM.DRG_CD))<>0 and CLM.clm_adjstmnt_key 
      is not NULL and CLM.cdh_rcrd_stts_cd="ACT" and XWALK.drg_cd is not NULL limit 10 """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, FCH.clms_sys_ap_drg_cd, XWALK.drg_cd, XWALK.drg_long_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd XWALK on concat('0',trim(CLM.DRG_CD))=trim(XWALK.drg_cd) where trim(CLM.drg_type_cd)='AP' and length(trim(CLM.DRG_CD))=3 and trim(CLM.DRG_CD)<>'UNK' and length(trim(FCH.clms_sys_ap_drg_cd))=0 and length(trim(CLM.DRG_CD))<>0 and CLM.clm_adjstmnt_key is not NULL and CLM.cdh_rcrd_stts_cd='ACT' and XWALK.drg_cd is not NULL limit 10  ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_ap_drg_cd', 'XWALK.drg_cd', 'XWALK.drg_long_desc' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, FCH.clms_sys_ap_drg_cd, XWALK.drg_cd, XWALK.drg_long_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd XWALK on concat('0',trim(CLM.DRG_CD))=trim(XWALK.drg_cd) where trim(CLM.drg_type_cd)='AP' and length(trim(CLM.DRG_CD))=3 and trim(CLM.DRG_CD)<>'UNK' and length(trim(FCH.clms_sys_ap_drg_cd))=0 and length(trim(CLM.DRG_CD))<>0 and CLM.clm_adjstmnt_key is not NULL and CLM.cdh_rcrd_stts_cd='ACT' and XWALK.drg_cd is not NULL limit 10  ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_ap_drg_cd', 'XWALK.drg_cd', 'XWALK.drg_long_desc' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - To check clms_sys_ap_drg_cd default spaces are populated as per mapping (where length(drug code)<>3 in source) - 059 ") {

    val id = Array("059")
    val name = Array("Test case : To check clms_sys_ap_drg_cd default spaces are populated as per mapping (where length(drug code)<>3 in source) ")

    val result = sqlContext.sql(""" select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, 
      FCH.clms_sys_ap_drg_cd, XWALK.drg_cd, XWALK.drg_long_desc from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left 
      outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and 
      trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd XWALK 
      on trim(CLM.DRG_CD)=trim(XWALK.drg_cd) where trim(CLM.drg_type_cd)="AP" and length(trim(CLM.DRG_CD))<>3 and 
      length(trim(FCH. clms_sys_ap_drg_cd))=0 and length(trim(CLM.DRG_CD))<>0 and CLM.clm_adjstmnt_key is not NULL and 
      CLM.cdh_rcrd_stts_cd="ACT" and XWALK.drg_cd is not NULL limit 10 """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, FCH.clms_sys_ap_drg_cd, XWALK.drg_cd, XWALK.drg_long_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd XWALK on trim(CLM.DRG_CD)=trim(XWALK.drg_cd) where trim(CLM.drg_type_cd)='AP' and length(trim(CLM.DRG_CD))<>3 and length(trim(FCH. clms_sys_ap_drg_cd))=0 and length(trim(CLM.DRG_CD))<>0 and CLM.clm_adjstmnt_key is not NULL and CLM.cdh_rcrd_stts_cd='ACT' and XWALK.drg_cd is not NULL limit 10 ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_ap_drg_cd', 'XWALK.drg_cd', 'XWALK.drg_long_desc' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, FCH.clms_sys_ap_drg_cd, XWALK.drg_cd, XWALK.drg_long_desc from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd XWALK on trim(CLM.DRG_CD)=trim(XWALK.drg_cd) where trim(CLM.drg_type_cd)='AP' and length(trim(CLM.DRG_CD))<>3 and length(trim(FCH. clms_sys_ap_drg_cd))=0 and length(trim(CLM.DRG_CD))<>0 and CLM.clm_adjstmnt_key is not NULL and CLM.cdh_rcrd_stts_cd='ACT' and XWALK.drg_cd is not NULL limit 10 ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_ap_drg_cd', 'XWALK.drg_cd', 'XWALK.drg_long_desc' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - To check that the value of AP drug code is as per mapping logic - 060") {

    val id = Array("060")
    val name = Array("Test case : To check that the value of AP drug code is as per mapping logic ")

    val result = sqlContext.sql(""" select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, 
      FCH.clms_sys_ap_drg_cd from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join 
      """ + dbname + """_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and 
      trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) and substr(trim(FCH.clms_sys_ap_drg_cd), 2)=trim(CLM.DRG_CD) left outer join 
      """ + dbname + """_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd REF on trim(FCH.clms_sys_ap_drg_cd)=trim(REF.drg_cd) where 
      trim(CLM.drg_type_cd)="AP" and length(trim(CLM.DRG_CD))=3 and trim(CLM.DRG_CD)<>"UNK" and 
      length(trim(FCH.clms_sys_ap_drg_cd))<>0 and (CLM.DRG_CD is NULL or REF.drg_cd is NULL) """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, FCH.clms_sys_ap_drg_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) and substr(trim(FCH.clms_sys_ap_drg_cd), 2)=trim(CLM.DRG_CD) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd REF on trim(FCH.clms_sys_ap_drg_cd)=trim(REF.drg_cd) where trim(CLM.drg_type_cd)='AP' and length(trim(CLM.DRG_CD))=3 and trim(CLM.DRG_CD)<>'UNK' and length(trim(FCH.clms_sys_ap_drg_cd))<>0 and (CLM.DRG_CD is NULL or REF.drg_cd is NULL) ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_ap_drg_cd' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select FCH.clm_adjstmnt_key, FCH.trcblty_fld_cd, CLM.drg_type_cd, CLM.DRG_CD, FCH.clms_sys_ap_drg_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg FCH left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.fclty_clm CLM on trim(FCH.clm_adjstmnt_key)=trim(CLM.clm_adjstmnt_key) and trim(FCH.trcblty_fld_cd)=trim(CLM.clm_sor_cd) and substr(trim(FCH.clms_sys_ap_drg_cd), 2)=trim(CLM.DRG_CD) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_drg_cd_xwalk_inbnd REF on trim(FCH.clms_sys_ap_drg_cd)=trim(REF.drg_cd) where trim(CLM.drg_type_cd)='AP' and length(trim(CLM.DRG_CD))=3 and trim(CLM.DRG_CD)<>'UNK' and length(trim(FCH.clms_sys_ap_drg_cd))<>0 and (CLM.DRG_CD is NULL or REF.drg_cd is NULL) ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_ap_drg_cd' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - To check that the PDR Logic is working as per the transformation - 061") {

    val id = Array("061")
    val name = Array("Test case : To check that the PDR Logic is working as per the transformation ")

    val result1 = sqlContext.sql(""" 
      select distinct A.clm_adjstmnt_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clm_adjstmnt_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  TRIM(A.BILLG_PROV_ID)= trim(ab.prov_nbr)
      and trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      """)

    val result2 = sqlContext.sql(""" 
      select distinct A.clm_adjstmnt_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clm_adjstmnt_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.npi_billg_prov_id)=trim(ab.prov_npi)
      and trim(A.billg_prov_tax_id)=trim(ab.fein_txt)
      and trim(A.billg_prov_zip_cd)=trim(ab.zip_cd)
      and trim(A.billg_prov_last_nm)=trim(ab.last_nm)
      """)

    val result3 = sqlContext.sql(""" 
      select distinct A.clm_adjstmnt_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clm_adjstmnt_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg EXT where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.npi_billg_prov_id)=trim(ab.prov_npi)
      and trim(A.billg_prov_tax_id)=trim(ab.fein_txt)
      and trim(A.billg_prov_zip_cd)=trim(ab.zip_cd)
      """)

    val result4 = sqlContext.sql(""" 
      select distinct A.clm_adjstmnt_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clm_adjstmnt_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.npi_billg_prov_id)=trim(ab.prov_npi)
      and trim(A.billg_prov_tax_id)=trim(ab.fein_txt)
      """)

    val result5 = sqlContext.sql(""" 
      select distinct A.clm_adjstmnt_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clm_adjstmnt_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.npi_billg_prov_id)=trim(ab.prov_npi)
      and trim(A.billg_prov_zip_cd)=trim(ab.zip_cd)
      and trim(A.billg_prov_last_nm)=trim(ab.last_nm)
      """)

    val result6 = sqlContext.sql(""" 
      select distinct A.clm_adjstmnt_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clm_adjstmnt_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.npi_billg_prov_id)=trim(ab.prov_npi)
      and trim(A.billg_prov_zip_cd)=trim(ab.zip_cd)
      """)

    val result7 = sqlContext.sql(""" 
      select distinct A.clm_adjstmnt_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clm_adjstmnt_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.npi_billg_prov_id)=trim(ab.prov_npi)
      """)

    val result8 = sqlContext.sql(""" 
      select distinct A.clm_adjstmnt_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clm_adjstmnt_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.billg_prov_tax_id)=trim(ab.fein_txt)
      and trim(A.billg_prov_zip_cd)=trim(ab.zip_cd)
      and trim(A.billg_prov_last_nm)=trim(ab.last_nm)
      """)

    val result9 = sqlContext.sql(""" 
      select distinct A.clm_adjstmnt_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clm_adjstmnt_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.billg_prov_tax_id)=trim(ab.fein_txt)
      and trim(A.billg_prov_zip_cd)=trim(ab.zip_cd)
      """)

    val result10 = sqlContext.sql(""" 
      select distinct A.clm_adjstmnt_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clm_adjstmnt_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.billg_prov_tax_id)=trim(ab.fein_txt)
      """)

    if (result1.count == 0 && result2.count == 0 && result3.count == 0 && result4.count == 0 && result5.count == 0 && result6.count == 0 && result7.count == 0 && result8.count == 0 && result9.count == 0 && result10.count == 0) {
      val a = result10.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  All scenarios for PDR Logic ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_ap_drg_cd' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result10.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  All scenarios for PDR Logic ")
      val data = Array("'FCH.clm_adjstmnt_key', 'FCH.trcblty_fld_cd', 'CLM.drg_type_cd', 'CLM.DRG_CD', 'FCH.clms_sys_ap_drg_cd' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  /*test("ClaimFacilityHeaderExtract - Validate that the category of code and clm type are in sync - 066") {

    val id = Array("062")
     val name = Array("Test case : Validate that the category of code and clm type are in sync ")

    val result1 = sqlContext.sql(""" select srvc_ctgry_cd, clm_type_cd, *
from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr
where clm_type_cd<>"1" and srvc_ctgry_cd="IP ACUTE"
limit 10 """)

    val result2 = sqlContext.sql(""" select srvc_ctgry_cd, clm_type_cd, *
from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr
where clm_type_cd="4" and srvc_ctgry_cd="IP NON-ACUTE"
limit 10
 """)

    val result3 = sqlContext.sql(""" select srvc_ctgry_cd, clm_type_cd, *
from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr
where clm_type_cd<>"1" and srvc_ctgry_cd="IP NON-ACUTE" and bill_stts_cd="1%"
limit 10 """)

    val result4 = sqlContext.sql(""" select srvc_ctgry_cd, clm_type_cd, *
from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr
where clm_type_cd<>"2" and srvc_ctgry_cd="OP FAC"
limit 10 """)


    if (result1.count == 0 && result2.count == 0 && result3.count == 0 && result4.count == 0) {
      val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select srvc_ctgry_cd, clm_type_cd, * from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where clm_type_cd<>'1' and srvc_ctgry_cd='IP ACUTE' ")
      val data = Array("'FCH.srvc_ctgry_cd', 'FCH.clm_type_cd', 'Data' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select srvc_ctgry_cd, clm_type_cd, * from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where clm_type_cd<>'1' and srvc_ctgry_cd='IP ACUTE' ")
      val data = Array("'FCH.srvc_ctgry_cd', 'FCH.clm_type_cd', 'Data' : Invalid")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }*/

  //==========================================

  test("ClaimFacilityHeaderExtract - Covered Days should be 0 for Inpatient fully denied claims - 062") {

    val id = Array("062")
    val name = Array("Test case : Covered Days should be 0 for Inpatient fully denied claims ")

    val result = sqlContext.sql(""" select sum(cvrd_days) from 
            (
            select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days,
            sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from
            (
            select *, case when last_srvc_dt = frst_srvc_dt then 1
            else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff,
            (HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days 
            from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR
            where HDR.clm_paymnt_stts_cd="D" and
            HDR.non_cvrd_amt>0 and
            HDR.clm_type_cd in ("1", "4") )a
            group by a.bhi_home_plan_id
            order by a.bhi_home_plan_id
            )a """)

    if (result.collectAsList.toString.contains("0")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select sum(cvrd_days) from (select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days,sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from (select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff, (HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR where HDR.clm_paymnt_stts_cd='D' and HDR.non_cvrd_amt>0 and HDR.clm_type_cd in ('1', '4') )a group by a.bhi_home_plan_id order by a.bhi_home_plan_id )a ")
      val data = Array("'FCH.sum(cvrd_days) : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select sum(cvrd_days) from (select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days,sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from (select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff, (HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR where HDR.clm_paymnt_stts_cd='D' and HDR.non_cvrd_amt>0 and HDR.clm_type_cd in ('1', '4') )a group by a.bhi_home_plan_id order by a.bhi_home_plan_id )a ")
      val data = Array("'FCH.sum(cvrd_days) : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - Non-Covered Days should be 0 for Inpatient fully paid claims - 063") {

    val id = Array("063")
    val name = Array("Test case : Non-Covered Days should be 0 for Inpatient fully paid claims ")

    val result = sqlContext.sql(""" select sum(non_cvrd_days) from
            (
            select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days,
            sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from
            (
            select *, case when last_srvc_dt = frst_srvc_dt then 1
            else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff,
            (HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days
            from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR
            inner join 
            (select bhi_home_plan_id as dtl_plan_id, clm_id as dtl_clm_id,
            case when array_contains(collect_set(clm_paymnt_stts_cd),cast('D' as varchar(1))) then "D"
            else "P" end as clm_stts
            from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl
            group by bhi_home_plan_id, clm_id) DTL
            on trim(HDR.clm_id)=trim(DTL.dtl_clm_id)
            where DTL.clm_stts="P" and
            HDR.non_cvrd_amt=0 and
            HDR.clm_type_cd in ("1", "4"))a
            group by a.bhi_home_plan_id
            order by a.bhi_home_plan_id
            )a """)

    if (result.collectAsList.toString.contains("0")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select sum(non_cvrd_days) from ( select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days, sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from ( select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff, (HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR inner join (select bhi_home_plan_id as dtl_plan_id, clm_id as dtl_clm_id, case when array_contains(collect_set(clm_paymnt_stts_cd),cast('D' as varchar(1))) then 'D' else 'P' end as clm_stts from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl group by bhi_home_plan_id, clm_id) DTL on trim(HDR.clm_id)=trim(DTL.dtl_clm_id) where DTL.clm_stts='P' and HDR.non_cvrd_amt=0 and HDR.clm_type_cd in ('1', '4'))a group by a.bhi_home_plan_id order by a.bhi_home_plan_id )a ")
      val data = Array("'FCH.sum(non_cvrd_days) : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select sum(non_cvrd_days) from ( select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days, sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from ( select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff, (HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR inner join (select bhi_home_plan_id as dtl_plan_id, clm_id as dtl_clm_id, case when array_contains(collect_set(clm_paymnt_stts_cd),cast('D' as varchar(1))) then 'D' else 'P' end as clm_stts from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl group by bhi_home_plan_id, clm_id) DTL on trim(HDR.clm_id)=trim(DTL.dtl_clm_id) where DTL.clm_stts='P' and HDR.non_cvrd_amt=0 and HDR.clm_type_cd in ('1', '4'))a group by a.bhi_home_plan_id order by a.bhi_home_plan_id )a ")
      val data = Array("'FCH.sum(non_cvrd_days) : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - Covered Days should be 0 for Outpatient claims - 064") {

    val id = Array("064")
    val name = Array("Test case : Covered Days should be 0 for Outpatient claims ")

    val result = sqlContext.sql(""" select sum(cvrd_days_for_paymnt_nbr)
from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr
where clm_type_cd=2 """)

    if (result.collectAsList.toString.contains("0")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select sum(cvrd_days_for_paymnt_nbr) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where clm_type_cd=2 ")
      val data = Array("'FCH.sum(non_cvrd_days) : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select sum(cvrd_days_for_paymnt_nbr) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where clm_type_cd=2 ")
      val data = Array("'FCH.sum(non_cvrd_days) : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - Non-Covered Days should be 0 for Outpatient claims - 065") {

    val id = Array("065")
    val name = Array("Test case : Non-Covered Days should be 0 for Outpatient claims ")

    val result = sqlContext.sql(""" select sum(non_cvrd_days_for_paymnt_nbr) 
from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr
where clm_type_cd=2 """)

    if (result.collectAsList.toString.contains("0")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select sum(non_cvrd_days_for_paymnt_nbr) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where clm_type_cd=2 ")
      val data = Array("'FCH.sum(non_cvrd_days) : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select sum(non_cvrd_days_for_paymnt_nbr) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr where clm_type_cd=2 ")
      val data = Array("'FCH.sum(non_cvrd_days) : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - Referential integrity with member for Zipcode & Country Code combination - 066") {

    val id = Array("066")
    val name = Array("Test case : Referential integrity with member for Zipcode & Country Code combination ")

    val result = sqlContext.sql(""" select *
              from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr clm
              left outer join """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp mbr
              on trim(clm.clm_mbr_zip_cd)=trim(mbr.mbr_curnt_prmry_zip_cd) and
              trim(clm.mbr_id)=trim(mbr.mbr_id) and
              trim(clm.clm_mbr_cntry_cd)=trim(mbr.mbr_curnt_cntry_cd)
              where mbr.mbr_curnt_prmry_zip_cd is NULL
              limit 20 """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select * from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr clm left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp mbr on trim(clm.clm_mbr_zip_cd)=trim(mbr.mbr_curnt_prmry_zip_cd) and trim(clm.mbr_id)=trim(mbr.mbr_id) and trim(clm.clm_mbr_cntry_cd)=trim(mbr.mbr_curnt_cntry_cd) where mbr.mbr_curnt_prmry_zip_cd is NULL ")
      val data = Array("'FCH.sum(non_cvrd_days) : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select * from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr clm left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp mbr on trim(clm.clm_mbr_zip_cd)=trim(mbr.mbr_curnt_prmry_zip_cd) and trim(clm.mbr_id)=trim(mbr.mbr_id) and trim(clm.clm_mbr_cntry_cd)=trim(mbr.mbr_curnt_cntry_cd) where mbr.mbr_curnt_prmry_zip_cd is NULL ")
      val data = Array("'FCH.sum(non_cvrd_days) : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - Validate zip code defaulta re valid - 067") {

    val id = Array("067")
    val name = Array("Test case : Validate zip code defaulta re valid ")

    val result = sqlContext.sql(s""" select CLM.CLM_ID                                         
from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr clm                                                                
left outer join ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  mbr                                                        
on trim(clm.clm_mbr_zip_cd)=trim(mbr.mbr_curnt_prmry_zip_cd) and                                                               
trim(clm.mbr_id)=trim(mbr.mbr_id) and                                                              
trim(clm.clm_mbr_cntry_cd)=trim(mbr.mbr_curnt_cntry_cd)                                                    
where mbr.mbr_curnt_prmry_zip_cd is NULL""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"""Test Query :  select CLM.CLM_ID                                         
from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr clm                                                                
left outer join ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  mbr                                                        
on trim(clm.clm_mbr_zip_cd)=trim(mbr.mbr_curnt_prmry_zip_cd) and                                                               
trim(clm.mbr_id)=trim(mbr.mbr_id) and                                                              
trim(clm.clm_mbr_cntry_cd)=trim(mbr.mbr_curnt_cntry_cd)                                                    
where mbr.mbr_curnt_prmry_zip_cd is NULL"""")
      val data = Array("'FCH.sum(non_cvrd_days) : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"""Test Query :  select CLM.CLM_ID                                         
from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr clm                                                                
left outer join ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  mbr                                                        
on trim(clm.clm_mbr_zip_cd)=trim(mbr.mbr_curnt_prmry_zip_cd) and                                                               
trim(clm.mbr_id)=trim(mbr.mbr_id) and                                                              
trim(clm.clm_mbr_cntry_cd)=trim(mbr.mbr_curnt_cntry_cd)                                                    
where mbr.mbr_curnt_prmry_zip_cd is NULL"""")
      val data = Array("'FCH.sum(non_cvrd_days) : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - Validate MHCD claims is populated correctly - 068") {

    val id = Array("068")
    val name = Array("Test case : Validate MHCD claims is populated correctly  ")

    val result = sqlContext.sql(s""" select H.CLM_ID  from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr h 
left outer join ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp m
ON trim(h.MBR_ID) = trim(m.MBR_ID)
AND trim(h.HOME_PLAN_PROD_ID) = trim(m.HOME_PLAN_PROD_ID)
where m.HOSP_BNFT_IND = 'Y' 
and m.MDCL_BNFT_IND = 'N' 
and m.MH_CD_BNFT_IND = 'N'
and H.CLM_PAYMNT_STTS_CD = 'P' 
and substr(H.prncpal_icd10_diag_cd,1,1) = 'F'
and H.FRST_SRVC_DT between m.CVRG_BGN_DT and m.CVRG_END_DT 
and m.HOME_PLAN_PROD_ID is not NULL""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"""Test Query :  select H.CLM_ID  from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr h 
left outer join ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp m
ON trim(h.MBR_ID) = trim(m.MBR_ID)
AND trim(h.HOME_PLAN_PROD_ID) = trim(m.HOME_PLAN_PROD_ID)
where m.HOSP_BNFT_IND = 'Y' 
and m.MDCL_BNFT_IND = 'N' 
and m.MH_CD_BNFT_IND = 'N'
and H.CLM_PAYMNT_STTS_CD = 'P' 
and substr(H.prncpal_icd10_diag_cd,1,1) = 'F'
and H.FRST_SRVC_DT between m.CVRG_BGN_DT and m.CVRG_END_DT 
and m.HOME_PLAN_PROD_ID is not NULL"""")
      val data = Array("'FCH.sum(non_cvrd_days) : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"""Test Query :  select H.CLM_ID  from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr h 
left outer join ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp m
ON trim(h.MBR_ID) = trim(m.MBR_ID)
AND trim(h.HOME_PLAN_PROD_ID) = trim(m.HOME_PLAN_PROD_ID)
where m.HOSP_BNFT_IND = 'Y' 
and m.MDCL_BNFT_IND = 'N' 
and m.MH_CD_BNFT_IND = 'N'
and H.CLM_PAYMNT_STTS_CD = 'P' 
and substr(H.prncpal_icd10_diag_cd,1,1) = 'F'
and H.FRST_SRVC_DT between m.CVRG_BGN_DT and m.CVRG_END_DT 
and m.HOME_PLAN_PROD_ID is not NULL"""")
      val data = Array("'H.CLM_ID : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimFacilityHeaderExtract - Display output of query - 069") {

    val id = Array("069")
    val name = Array("Test case : Display output of query  ")

    val result = sqlContext.sql(s"""select a.BHI_HOME_PLAN_ID, sum(a.TOTAL_DAYS_SUBM) as TOTAL_DAYS_SUBM,                                                                                       
sum(a.TTL_DAYS_CALC) as TTL_DAYS_CALC,                                                                                       
sum(a.COVRD_DAYS_SUBM) as COVRD_DAYS_SUBM,                                                                                  
sum(a.NON_CVR_DAYS_SUBM) as NON_CVR_DAYS_SUBM                                                                                       
from                                                                                      
(                                                                                            
SELECT H.BHI_HOME_PLAN_ID, H.clm_id,                                                                                            
SUM(H.cvrd_days_for_paymnt_nbr+H.non_cvrd_days_for_paymnt_nbr) AS TOTAL_DAYS_SUBM,                                                                                        
SUM(CASE WHEN H.last_srvc_dt = H.frst_srvc_dt AND FD.clm_id IS NOT NULL THEN 1 ELSE                                                                                         
DATEDIFF(H.last_srvc_dt, H.frst_srvc_dt) END) AS TTL_DAYS_CALC,                                                                                        
SUM(H.cvrd_days_for_paymnt_nbr) AS COVRD_DAYS_SUBM,                                                                                                 
SUM(H.non_cvrd_days_for_paymnt_nbr) AS NON_CVR_DAYS_SUBM,                                                                                                
SUM(H.ALWD_AMT) AS FAC_IP_ALLWD,                                                                                             
SUM(H.PAYMNT_AMT) AS FAC_IP_PMT,                                                                                             
SUM(H.CPAY_AMT) AS FAC_IP_COPAY,                                                                                               
SUM(H.DDCTBL_AMT) AS FAC_IP_DEDUCT,                                                                                        
SUM(H.COB_TPL_AMT) AS FAC_IP_COB,                                                                                             
SUM(H.sbmtd_amt) AS FAC_IP_SUBMT,                                                                                              
SUM(H.COINSRN_AMT) AS FAC_IP_COINS,                                                                                        
SUM(H.NON_CVRD_AMT) AS FAC_IP_NON_COV                                                                                            
FROM ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  H                                                                                                
LEFT OUTER JOIN                                                                                             
(SELECT DISTINCT FD1.BHI_HOME_PLAN_ID, FD1.CLM_ID, FD1.TRCBLTY_FLD_CD                                                                                             
FROM  ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl FD1                                                                                             
) AS FD                                                                                  
ON FD.BHI_HOME_PLAN_ID = H.BHI_HOME_PLAN_ID                                                                                  
AND FD.CLM_ID = H.CLM_ID                                                                                      
AND FD.TRCBLTY_FLD_CD = H.TRCBLTY_FLD_CD                                                                                               
WHERE H.clm_type_cd in ("1", "4")                                                                                          
group by H.BHI_HOME_PLAN_ID, H.clm_id                                                                                         
)a                                                                                            
group by a.BHI_HOME_PLAN_ID                                                                                              
order by a.BHI_HOME_PLAN_ID""")

    val a = result.rdd
    val status = Array("SUCCESS")
    val query = Array(s"""Test Query :  select a.BHI_HOME_PLAN_ID, sum(a.TOTAL_DAYS_SUBM) as TOTAL_DAYS_SUBM,                                                                                       
sum(a.TTL_DAYS_CALC) as TTL_DAYS_CALC,                                                                                       
sum(a.COVRD_DAYS_SUBM) as COVRD_DAYS_SUBM,                                                                                  
sum(a.NON_CVR_DAYS_SUBM) as NON_CVR_DAYS_SUBM                                                                                       
from                                                                                      
(                                                                                            
SELECT H.BHI_HOME_PLAN_ID, H.clm_id,                                                                                            
SUM(H.cvrd_days_for_paymnt_nbr+H.non_cvrd_days_for_paymnt_nbr) AS TOTAL_DAYS_SUBM,                                                                                        
SUM(CASE WHEN H.last_srvc_dt = H.frst_srvc_dt AND FD.clm_id IS NOT NULL THEN 1 ELSE                                                                                         
DATEDIFF(H.last_srvc_dt, H.frst_srvc_dt) END) AS TTL_DAYS_CALC,                                                                                        
SUM(H.cvrd_days_for_paymnt_nbr) AS COVRD_DAYS_SUBM,                                                                                                 
SUM(H.non_cvrd_days_for_paymnt_nbr) AS NON_CVR_DAYS_SUBM,                                                                                                
SUM(H.ALWD_AMT) AS FAC_IP_ALLWD,                                                                                             
SUM(H.PAYMNT_AMT) AS FAC_IP_PMT,                                                                                             
SUM(H.CPAY_AMT) AS FAC_IP_COPAY,                                                                                               
SUM(H.DDCTBL_AMT) AS FAC_IP_DEDUCT,                                                                                        
SUM(H.COB_TPL_AMT) AS FAC_IP_COB,                                                                                             
SUM(H.sbmtd_amt) AS FAC_IP_SUBMT,                                                                                              
SUM(H.COINSRN_AMT) AS FAC_IP_COINS,                                                                                        
SUM(H.NON_CVRD_AMT) AS FAC_IP_NON_COV                                                                                            
FROM ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  H                                                                                                
LEFT OUTER JOIN                                                                                             
(SELECT DISTINCT FD1.BHI_HOME_PLAN_ID, FD1.CLM_ID, FD1.TRCBLTY_FLD_CD                                                                                             
FROM  ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl FD1                                                                                             
) AS FD                                                                                  
ON FD.BHI_HOME_PLAN_ID = H.BHI_HOME_PLAN_ID                                                                                  
AND FD.CLM_ID = H.CLM_ID                                                                                      
AND FD.TRCBLTY_FLD_CD = H.TRCBLTY_FLD_CD                                                                                               
WHERE H.clm_type_cd in ("1", "4")                                                                                          
group by H.BHI_HOME_PLAN_ID, H.clm_id                                                                                         
)a                                                                                            
group by a.BHI_HOME_PLAN_ID                                                                                              
order by a.BHI_HOME_PLAN_ID"""")

    val data = Array("'FCH.sum(non_cvrd_days) : Valid")
    sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
    assert(1 == 1)

  }

  //==========================================
  
  test("ClaimFacilityHeaderExtract - Display output of query -1 - 70") {
    
    val id = Array("070")
    val name = Array("Test case : Display output of query -1")
    
    val result = sqlContext.sql(s"""select a.BHI_HOME_PLAN_ID, a.clm_type_cd, a.srvc_ctgry_cd, sum(a.TOTAL_DAYS_SUBM), sum(a.TTL_DAYS_CALC), sum(a.COVRD_DAYS_SUBM), sum(a.NON_CVR_DAYS_SUBM) from (SELECT H.BHI_HOME_PLAN_ID, H.clm_id, H.clm_type_cd, H.srvc_ctgry_cd,SUM(H.cvrd_days_for_paymnt_nbr+H.non_cvrd_days_for_paymnt_nbr) AS TOTAL_DAYS_SUBM,SUM(CASE WHEN H.last_srvc_dt = H.frst_srvc_dt AND FD.clm_id IS NOT NULL THEN 1 ELSE DATEDIFF(H.last_srvc_dt, H.frst_srvc_dt) END) AS TTL_DAYS_CALC,SUM(H.cvrd_days_for_paymnt_nbr) AS COVRD_DAYS_SUBM,SUM(H.non_cvrd_days_for_paymnt_nbr) AS NON_CVR_DAYS_SUBM,SUM(H.ALWD_AMT) AS FAC_IP_ALLWD, 	SUM(H.PAYMNT_AMT) AS FAC_IP_PMT, SUM(H.CPAY_AMT) AS FAC_IP_COPAY, SUM(H.DDCTBL_AMT) AS FAC_IP_DEDUCT, SUM(H.COB_TPL_AMT) AS FAC_IP_COB,SUM(H.sbmtd_amt) AS FAC_IP_SUBMT, SUM(H.COINSRN_AMT) AS FAC_IP_COINS, SUM(H.NON_CVRD_AMT) AS FAC_IP_NON_COV FROM ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr H LEFT OUTER JOIN (SELECT DISTINCT FD1.BHI_HOME_PLAN_ID, FD1.CLM_ID, FD1.TRCBLTY_FLD_CD FROM  ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl FD1) AS FD ON FD.BHI_HOME_PLAN_ID = H.BHI_HOME_PLAN_ID AND FD.CLM_ID = H.CLM_ID	AND FD.TRCBLTY_FLD_CD = H.TRCBLTY_FLD_CD group by H.BHI_HOME_PLAN_ID, H.clm_id, H.clm_type_cd,H.srvc_ctgry_cd having H.BHI_HOME_PLAN_ID="051")a	group by a.BHI_HOME_PLAN_ID, a.clm_type_cd, a.srvc_ctgry_cd	order by a.BHI_HOME_PLAN_ID, a.clm_type_cd, a.srvc_ctgry_cd	limit 10""")
    
    val a=result.rdd
    val status = Array("Success")
    val query = Array (s"""select a.BHI_HOME_PLAN_ID, a.clm_type_cd, a.srvc_ctgry_cd, sum(a.TOTAL_DAYS_SUBM), sum(a.TTL_DAYS_CALC), sum(a.COVRD_DAYS_SUBM), sum(a.NON_CVR_DAYS_SUBM) from (SELECT H.BHI_HOME_PLAN_ID, H.clm_id, H.clm_type_cd, H.srvc_ctgry_cd,SUM(H.cvrd_days_for_paymnt_nbr+H.non_cvrd_days_for_paymnt_nbr) AS TOTAL_DAYS_SUBM,SUM(CASE WHEN H.last_srvc_dt = H.frst_srvc_dt AND FD.clm_id IS NOT NULL THEN 1 ELSE DATEDIFF(H.last_srvc_dt, H.frst_srvc_dt) END) AS TTL_DAYS_CALC,SUM(H.cvrd_days_for_paymnt_nbr) AS COVRD_DAYS_SUBM,SUM(H.non_cvrd_days_for_paymnt_nbr) AS NON_CVR_DAYS_SUBM,SUM(H.ALWD_AMT) AS FAC_IP_ALLWD, 	SUM(H.PAYMNT_AMT) AS FAC_IP_PMT, SUM(H.CPAY_AMT) AS FAC_IP_COPAY, SUM(H.DDCTBL_AMT) AS FAC_IP_DEDUCT, SUM(H.COB_TPL_AMT) AS FAC_IP_COB,SUM(H.sbmtd_amt) AS FAC_IP_SUBMT, SUM(H.COINSRN_AMT) AS FAC_IP_COINS, SUM(H.NON_CVRD_AMT) AS FAC_IP_NON_COV FROM ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr H LEFT OUTER JOIN (SELECT DISTINCT FD1.BHI_HOME_PLAN_ID, FD1.CLM_ID, FD1.TRCBLTY_FLD_CD FROM  ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl FD1) AS FD ON FD.BHI_HOME_PLAN_ID = H.BHI_HOME_PLAN_ID AND FD.CLM_ID = H.CLM_ID	AND FD.TRCBLTY_FLD_CD = H.TRCBLTY_FLD_CD group by H.BHI_HOME_PLAN_ID, H.clm_id, H.clm_type_cd,H.srvc_ctgry_cd having H.BHI_HOME_PLAN_ID="051")a	group by a.BHI_HOME_PLAN_ID, a.clm_type_cd, a.srvc_ctgry_cd	order by a.BHI_HOME_PLAN_ID, a.clm_type_cd, a.srvc_ctgry_cd	limit 10""")
    
   sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
    assert(1 == 1) 
    
  }
  
  //==========================================
  
  test ("ClaimFacilityHeaderExtract - validation of Medicare group 195331 exclusion - 071") {
    val id = Array("071")
    val name = Array("Test case : validation of Medicare group 195331 exclusion ")

    val result = sqlContext.sql(s"""select  bhi_home_plan_id,clm_id  from ${dbname}_PCANDW1PH_nogbd_r000_ou.BCBSA_FCLTY_CLM_hdr where grp_nm='195331' limit 10""")
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,clm_id  from ${dbname}_PCANDW1PH_nogbd_r000_ou.BCBSA_FCLTY_CLM_hdr where grp_nm='195331' limit 10 ")
      val data = Array("'*' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,clm_id  from ${dbname}_PCANDW1PH_nogbd_r000_ou.BCBSA_FCLTY_CLM_hdr where grp_nm='195331' limit 10  ")
      val data = Array("'*' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
  }
  }
  
     //==========================================
  
  test ("ClaimFacilityHeaderExtract - validation of Covered days/Non covered days calculation - 072") {
    val id = Array("072")
    val name = Array("Test case : validation of Covered days/Non covered days calculation ")

    val result = sqlContext.sql(s"""select a.BHI_HOME_PLAN_ID, a.clm_type_cd, a.srvc_ctgry_cd, sum(a.TOTAL_DAYS_SUBM), sum(a.TTL_DAYS_CALC), sum(a.COVRD_DAYS_SUBM), sum(a.NON_CVR_DAYS_SUBM) from (SELECT H.BHI_HOME_PLAN_ID, H.clm_id, H.clm_type_cd, H.srvc_ctgry_cd,SUM(H.cvrd_days_for_paymnt_nbr+H.non_cvrd_days_for_paymnt_nbr) AS TOTAL_DAYS_SUBM,SUM(CASE WHEN H.last_srvc_dt = H.frst_srvc_dt AND FD.clm_id IS NOT NULL THEN 1 ELSE DATEDIFF(H.last_srvc_dt, H.frst_srvc_dt) END) AS TTL_DAYS_CALC,SUM(H.cvrd_days_for_paymnt_nbr) AS COVRD_DAYS_SUBM, SUM(H.non_cvrd_days_for_paymnt_nbr) AS NON_CVR_DAYS_SUBM,SUM(H.ALWD_AMT) AS FAC_IP_ALLWD,SUM(H.PAYMNT_AMT) AS FAC_IP_PMT, SUM(H.CPAY_AMT) AS FAC_IP_COPAY, SUM(H.DDCTBL_AMT) AS FAC_IP_DEDUCT, SUM(H.COB_TPL_AMT) AS FAC_IP_COB, SUM(H.sbmtd_amt) AS FAC_IP_SUBMT, SUM(H.COINSRN_AMT) AS FAC_IP_COINS, SUM(H.NON_CVRD_AMT) AS FAC_IP_NON_COVFROM from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr H LEFT OUTER JOIN (SELECT DISTINCT FD1.BHI_HOME_PLAN_ID, FD1.CLM_ID, FD1.TRCBLTY_FLD_CD FROM  ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl FD1) AS FD ON FD.BHI_HOME_PLAN_ID = H.BHI_HOME_PLAN_ID AND FD.CLM_ID = H.CLM_ID AND FD.TRCBLTY_FLD_CD = H.TRCBLTY_FLD_CD group by H.BHI_HOME_PLAN_ID, H.clm_id, H.clm_type_cd, H.srvc_ctgry_cd having H.BHI_HOME_PLAN_ID="051")a group by a.BHI_HOME_PLAN_ID, a.clm_type_cd, a.srvc_ctgry_cd order by a.BHI_HOME_PLAN_ID, a.clm_type_cd, a.srvc_ctgry_cd""")
    
      val a = result.rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.BHI_HOME_PLAN_ID, a.clm_type_cd, a.srvc_ctgry_cd, sum(a.TOTAL_DAYS_SUBM), sum(a.TTL_DAYS_CALC), sum(a.COVRD_DAYS_SUBM), sum(a.NON_CVR_DAYS_SUBM) from (SELECT H.BHI_HOME_PLAN_ID, H.clm_id, H.clm_type_cd, H.srvc_ctgry_cd,SUM(H.cvrd_days_for_paymnt_nbr+H.non_cvrd_days_for_paymnt_nbr) AS TOTAL_DAYS_SUBM,SUM(CASE WHEN H.last_srvc_dt = H.frst_srvc_dt AND FD.clm_id IS NOT NULL THEN 1 ELSE DATEDIFF(H.last_srvc_dt, H.frst_srvc_dt) END) AS TTL_DAYS_CALC,SUM(H.cvrd_days_for_paymnt_nbr) AS COVRD_DAYS_SUBM, SUM(H.non_cvrd_days_for_paymnt_nbr) AS NON_CVR_DAYS_SUBM,SUM(H.ALWD_AMT) AS FAC_IP_ALLWD,SUM(H.PAYMNT_AMT) AS FAC_IP_PMT, SUM(H.CPAY_AMT) AS FAC_IP_COPAY, SUM(H.DDCTBL_AMT) AS FAC_IP_DEDUCT, SUM(H.COB_TPL_AMT) AS FAC_IP_COB, SUM(H.sbmtd_amt) AS FAC_IP_SUBMT, SUM(H.COINSRN_AMT) AS FAC_IP_COINS, SUM(H.NON_CVRD_AMT) AS FAC_IP_NON_COVFROM from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr H LEFT OUTER JOIN (SELECT DISTINCT FD1.BHI_HOME_PLAN_ID, FD1.CLM_ID, FD1.TRCBLTY_FLD_CD FROM  '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl FD1) AS FD ON FD.BHI_HOME_PLAN_ID = H.BHI_HOME_PLAN_ID AND FD.CLM_ID = H.CLM_ID AND FD.TRCBLTY_FLD_CD = H.TRCBLTY_FLD_CD group by H.BHI_HOME_PLAN_ID, H.clm_id, H.clm_type_cd, H.srvc_ctgry_cd having H.BHI_HOME_PLAN_ID=051) a group by a.BHI_HOME_PLAN_ID, a.clm_type_cd, a.srvc_ctgry_cd order by a.BHI_HOME_PLAN_ID, a.clm_type_cd, a.srvc_ctgry_cd ")
      val data = Array("'*' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    
  }
  
   //==========================================
  
  test ("ClaimFacilityHeaderExtract - validation of Inpatient Fully Denied - 073") {
    val id = Array("073")
    val name = Array("Test case : validation of Inpatient Fully Denied ")

    val result = sqlContext.sql(s"""select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days,sum(cvrd_days_for_paymnt_nbr) as cvrd_days,sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from (select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff,(HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from ${dbname}_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg HDR where HDR.clm_paymnt_stts_cd="D" and HDR.non_cvrd_amt>0 and HDR.clm_type_cd in ("1", "4") )a group by a.bhi_home_plan_id order by a.bhi_home_plan_id""")
    
      val a = result.rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days,sum(cvrd_days_for_paymnt_nbr) as cvrd_days,sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from (select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff,(HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from ${dbname}_pcandw1ph_nogbd_r000_sg.bcbsa_fclty_clm_hdr_stg HDR where HDR.clm_paymnt_stts_cd='D' and HDR.non_cvrd_amt>0 and HDR.clm_type_cd in ('1', '4') )a group by a.bhi_home_plan_id order by a.bhi_home_plan_id ")
      val data = Array("'*' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
   
  }
  
  //==========================================
  
  test ("ClaimFacilityHeaderExtract - validation of Inpatient Fully Paid - 074") {
    val id = Array("074")
    val name = Array("Test case : validation of Inpatient Fully Paid ")

    val result = sqlContext.sql(s"""select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days, sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from (select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff,(HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR inner join (select bhi_home_plan_id as dtl_plan_id, clm_id as dtl_clm_id, case when array_contains(collect_set(clm_paymnt_stts_cd),cast('D' as varchar(1))) then "D" else "P" end as clm_stts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl group by bhi_home_plan_id, clm_id) DTL on trim(HDR.clm_id)=trim(DTL.dtl_clm_id) where DTL.clm_stts="P" and HDR.non_cvrd_amt=0 and HDR.clm_type_cd in ("1", "4"))a group by a.bhi_home_plan_id order by a.bhi_home_plan_id""")
    
      val a = result.rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days, sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from (select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff,(HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR inner join (select bhi_home_plan_id as dtl_plan_id, clm_id as dtl_clm_id, case when array_contains(collect_set(clm_paymnt_stts_cd),cast('D' as varchar(1))) then 'D' else 'P' end as clm_stts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl group by bhi_home_plan_id, clm_id) DTL on trim(HDR.clm_id)=trim(DTL.dtl_clm_id) where DTL.clm_stts='P' and HDR.non_cvrd_amt=0 and HDR.clm_type_cd in ('1', '4'))a group by a.bhi_home_plan_id order by a.bhi_home_plan_id ")
      val data = Array("'*' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
  }
  
    //==========================================
  
  test ("ClaimFacilityHeaderExtract - validation of Inpatient Partially Claims - case 1 Partially Paid - 075") {
    val id = Array("075")
    val name = Array("Test case : validation of Inpatient Partially Claims - case 1 Partially Paid ")

    val result = sqlContext.sql(s"""select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days,sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from (select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff, (HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR inner join (select bhi_home_plan_id as dtl_plan_id, clm_id as dtl_clm_id,case when array_contains(collect_set(clm_paymnt_stts_cd),cast('D' as varchar(1))) then "D" else "P" end as clm_stts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl group by bhi_home_plan_id, clm_id) DTL on trim(HDR.clm_id)=trim(DTL.dtl_clm_id) where DTL.clm_stts="D" and HDR.clm_type_cd in ("1", "4")and HDR.clm_paymnt_stts_cd<>"D")a group by a.bhi_home_plan_id order by a.bhi_home_plan_id""")
    
      val a = result.rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days,sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from (select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff, (HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR inner join (select bhi_home_plan_id as dtl_plan_id, clm_id as dtl_clm_id,case when array_contains(collect_set(clm_paymnt_stts_cd),cast('D' as varchar(1))) then 'D' else 'P' end as clm_stts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl group by bhi_home_plan_id, clm_id) DTL on trim(HDR.clm_id)=trim(DTL.dtl_clm_id) where DTL.clm_stts='D' and HDR.clm_type_cd in ('1', '4')and HDR.clm_paymnt_stts_cd<>'D')a group by a.bhi_home_plan_id order by a.bhi_home_plan_id ")
      val data = Array("'*' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
  }
  
  //==========================================
  
  test ("ClaimFacilityHeaderExtract - validation of Inpatient Partially Claims - case 2 Fully Denied with NC Amount = 0 - 076") {
    val id = Array("076")
    val name = Array("Test case : validation of Inpatient Partially Claims - case 2 Fully Denied with NC Amount = 0 ")

    val result = sqlContext.sql(s"""select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days,sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from (select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff,(HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR where HDR.clm_paymnt_stts_cd="D" and HDR.non_cvrd_amt=0 and HDR.clm_type_cd in ("1", "4") )a group by a.bhi_home_plan_id order by a.bhi_home_plan_id""")
    
      val a = result.rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days,sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from (select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff,(HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR where HDR.clm_paymnt_stts_cd='D' and HDR.non_cvrd_amt=0 and HDR.clm_type_cd in ('1', '4') )a group by a.bhi_home_plan_id order by a.bhi_home_plan_id ")
      val data = Array("'*' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
  }
  
   //==========================================
  
  test ("ClaimFacilityHeaderExtract - validation of Inpatient Partially Claims - case 2 Fully Paid with NC Amount > 0 - 077") {
    val id = Array("077")
    val name = Array("Test case : validation of Inpatient Partially Claims - case 2 Fully Paid with NC Amount > 0 ")

    val result = sqlContext.sql(s"""select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days,sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from (select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff,(HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR inner join (select bhi_home_plan_id as dtl_plan_id, clm_id as dtl_clm_id, case when array_contains(collect_set(clm_paymnt_stts_cd),cast('D' as varchar(1))) then "D" else "P" end as clm_stts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl group by bhi_home_plan_id, clm_id) DTL on trim(HDR.clm_id)=trim(DTL.dtl_clm_id) where DTL.clm_stts="P" and HDR.non_cvrd_amt>0 and HDR.clm_type_cd in ("1", "4"))a group by a.bhi_home_plan_id order by a.bhi_home_plan_id""")
    
      val a = result.rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.bhi_home_plan_id, sum(a.date_diff) as calculated_days, sum(a.total_days) as submitted_days,sum(cvrd_days_for_paymnt_nbr) as  cvrd_days, sum(non_cvrd_days_for_paymnt_nbr) as non_cvrd_days from (select *, case when last_srvc_dt = frst_srvc_dt then 1 else datediff(HDR.last_srvc_dt, HDR.frst_srvc_dt) end as date_diff,(HDR.cvrd_days_for_paymnt_nbr+HDR.non_cvrd_days_for_paymnt_nbr) as total_days from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr HDR inner join (select bhi_home_plan_id as dtl_plan_id, clm_id as dtl_clm_id, case when array_contains(collect_set(clm_paymnt_stts_cd),cast('D' as varchar(1))) then 'D' else 'P' end as clm_stts from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl group by bhi_home_plan_id, clm_id) DTL on trim(HDR.clm_id)=trim(DTL.dtl_clm_id) where DTL.clm_stts='P' and HDR.non_cvrd_amt>0 and HDR.clm_type_cd in ('1', '4'))a group by a.bhi_home_plan_id order by a.bhi_home_plan_id ")
      val data = Array("'*' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
  }
  
  
}