package com.anthem.hca.ndw.tests

import java.io.File
import org.scalatest.FunSuite
import org.apache.spark.sql.SparkSession
import scala.io.Source
import org.apache.spark.sql.DataFrame
import java.text.SimpleDateFormat
import java.util.Calendar

object PCADX_SCL_TA_ControlTable_Pharmacy_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_ControlTable_Pharmacy_TGT(args(0), args(1), args(2), args(3))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_ControlTable_Pharmacy_TGT(controlTable: String, extractTable: String, extractName: String, env: String) extends FunSuite {

  val spark = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
  val DATETIME_FORMAT1 = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss")
  val DATETIME1 = DATETIME_FORMAT1.format(Calendar.getInstance().getTime())
  var process_Name = "Pharmacy"
  
  test("Check home_plan_id count is 14 or not") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("001")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check home_plan_id count is 14 or not")
    val query = Array("Test Query : select count(*) from (select distinct bhi_home_plan_id from " + controlTable + ")a")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result = spark.sql("select count(*) from (select distinct bhi_home_plan_id from " + controlTable + ")a")
    val a = result.rdd

    if (result.first.getLong(0) == 14) {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    } else {

      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    }

  }

  test("Check home_plan_id and record count columns are matching with extract table") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("002")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check home_plan_id and record count columns are matching with extract table")
    val query = Array("Test Query : select bhi_home_plan_id, rcrd_cnt from " + controlTable + " and select bhi_home_plan_id, count(*) from " + extractTable + " group by bhi_home_plan_id")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result1 = spark.sql("select bhi_home_plan_id, rcrd_cnt from " + controlTable + "").rdd.map(_.mkString("|"))
    val result2 = spark.sql("select bhi_home_plan_id, count(*) from " + extractTable + " group by bhi_home_plan_id").rdd.map(_.mkString("|"))
    val ctl = result1.subtract(result2).map(_.concat("|ControlTable"))
    val exrt = result2.subtract(result1).map(_.concat("|ExtractTable"))
    val res = ctl.union(exrt)
    val res1 = res.sortBy(x => x, true, 1).toDF()
    res1.createOrReplaceTempView("table1")
    val res2 = sql("select * from table1 limit 10")
    val a = res2.rdd
    if (ctl.count != 0 || exrt.count != 0) {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    }
  }

  test("Check extract_name is correct or not") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("003")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check extract_name is correct or not")
    val query = Array("Test Query : select distinct extrct_nm from " + controlTable + "")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result = spark.sql("select distinct extrct_nm from " + controlTable + "")
    val a = result.rdd
    if (result.first.getString(0).trim.equals(extractName)) {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    }

  }
  test("Check min_clm_processed_dt column is empty or not") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("004")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check min_clm_processed_dt column is empty or not")
    val query = Array("Test Query : select distinct trim(min_clm_prcsd_dt) from " + controlTable + "")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result = spark.sql("select distinct trim(min_clm_prcsd_dt) from " + controlTable + "")
    val a = result.rdd
    if (result.take(1).isEmpty) {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)

    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    }

  }
  test("Control Table-Validate that min_clm_prcsd_dt column should be minimum Date of Bot table.") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("005")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Validate that min_clm_prcsd_dt column should be minimum Date of Bot table.")
    val query = Array("Test Query : select distinct min_clm_prcsd_dt from " + controlTable + " & select CAST(from_unixtime(unix_timestamp(CAST(min_clm_prcsd_dt AS String), 'yyyy-MM-dd')) AS TIMESTAMP) as mini from "+env+"_PCANDW1PH_nogbd_r000_in.bot_bcbsa_sbmsn_parm_inbnd where sbmsn_mode='D'")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result1 = spark.sql("select distinct min_clm_prcsd_dt from " + controlTable + "")

    val result2 = spark.sql("select CAST(from_unixtime(unix_timestamp(CAST(min_clm_prcsd_dt AS String), 'yyyy-MM-dd')) AS TIMESTAMP) as mini from "+env+"_PCANDW1PH_nogbd_r000_in.bot_bcbsa_sbmsn_parm_inbnd where sbmsn_mode='D'")

    if (result1.intersect(result2).take(1).isEmpty) {
      val r1 = result1.rdd.map(_.mkString("|"))
      val r2 = result2.rdd.map(_.mkString("|"))
      val ctl = r1.map(_.concat("|ControlTable"))
      val exrt = r2.map(_.concat("|BotTable"))
      val res = ctl.union(exrt); val a = res.sortBy(x => x, true, 1)
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    } else {
      val a = result1.rdd
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    }

  }
  test("Check max_clm_prcsd_dt column is empty or not") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("006")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check max_clm_prcsd_dt column is empty or not")
    val query = Array("Test Query : select distinct trim(max_clm_prcsd_dt) from " + controlTable + "")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result = spark.sql("select distinct trim(max_clm_prcsd_dt) from " + controlTable + "")
    val a = result.rdd
    if (result.take(1).isEmpty) {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)

    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    }

  }
  test("Control Table-Validate that max_clm_prcsd_dt column should be maximum Date of BOT table.") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("007")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Validate that max_clm_prcsd_dt column should be maximum Date of BOT table.")
    val query = Array("Test Query : select distinct max_clm_prcsd_dt from " + controlTable + " & select CAST(from_unixtime(unix_timestamp(CAST(max_clm_prcsd_dt AS String), 'yyyy-MM-dd')) AS TIMESTAMP) as mini from "+env+"_PCANDW1PH_nogbd_r000_in.bot_bcbsa_sbmsn_parm_inbnd where sbmsn_mode='D'")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result1 = spark.sql("select distinct max_clm_prcsd_dt from " + controlTable + "")

    val result2 = spark.sql("select CAST(from_unixtime(unix_timestamp(CAST(max_clm_prcsd_dt AS String), 'yyyy-MM-dd')) AS TIMESTAMP) as maxi from "+env+"_PCANDW1PH_nogbd_r000_in.bot_bcbsa_sbmsn_parm_inbnd where sbmsn_mode='D'")

    if (result1.intersect(result2).take(1).isEmpty) {

      val r1 = result1.rdd.map(_.mkString("|"))
      val r2 = result2.rdd.map(_.mkString("|"))
      val ctl = r1.map(_.concat("|ControlTable"))
      val exrt = r2.map(_.concat("|BotTable"))
      val res = ctl.union(exrt); val a = res.sortBy(x => x, true, 1)
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    } else {
      val a = result1.rdd
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    }

  }
  test("Check sbmsn_dt column is empty or not") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("008")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check sbmsn_dt column is empty or not")
    val query = Array("Test Query : select distinct trim(sbmsn_dt) from " + controlTable + "")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result = spark.sql("select distinct trim(sbmsn_dt) from " + controlTable + "")
    val a = result.rdd
    if (result.take(1).isEmpty) {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)

    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    }

  }

  test("Control Table-Validate that bhi_home_plan_id and tot_sub_amt columns should summed from all records in the Extract") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("009")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Validate that bhi_home_plan_id and tot_sub_amt columns should summed from all records in the Extract")
    val query = Array("Test Query : select bhi_home_plan_id, totl_sbmtd_amt from " + controlTable + " & select bhi_home_plan_id, sum(sbmtd_amt) from " + extractTable + " group by bhi_home_plan_id")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result1 = spark.sql("select bhi_home_plan_id, totl_sbmtd_amt from " + controlTable + "").rdd.map(_.mkString("|"))
    val result2 = spark.sql("select bhi_home_plan_id, sum(sbmtd_amt) from " + extractTable + " group by bhi_home_plan_id").rdd.map(_.mkString("|"))
    val ctl = result1.subtract(result2).map(_.concat("|ControlTable"))
    val exrt = result2.subtract(result1).map(_.concat("|ExtractTable"))
    val res = ctl.union(exrt)
    val res1 = res.sortBy(x => x, true, 1).toDF()
    res1.createOrReplaceTempView("table1")
    val res2 = sql("select * from table1 limit 10")
    val a = res2.rdd
    if (ctl.count != 0 || exrt.count != 0) {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    }
  }

  test("Control Table-Validate that bhi_home_plan_id and totl_non_cvrd_amt columns should summed from all records in the Extract") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("010")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Validate that bhi_home_plan_id and totl_non_cvrd_amt columns should summed from all records in the Extract")
    val query = Array("Test Query : select bhi_home_plan_id, totl_non_cvrd_amt from " + controlTable + " & select bhi_home_plan_id, sum(non_cvrd_amt) from " + extractTable + " group by bhi_home_plan_id")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result1 = spark.sql("select bhi_home_plan_id, totl_non_cvrd_amt from " + controlTable + "").rdd.map(_.mkString("|"))
    val result2 = spark.sql("select bhi_home_plan_id, sum(non_cvrd_amt) from " + extractTable + " group by bhi_home_plan_id").rdd.map(_.mkString("|"))
    val ctl = result1.subtract(result2).map(_.concat("|ControlTable"))
    val exrt = result2.subtract(result1).map(_.concat("|ExtractTable"))
    val res = ctl.union(exrt)
    val res1 = res.sortBy(x => x, true, 1).toDF()
    res1.createOrReplaceTempView("table1")
    val res2 = sql("select * from table1 limit 10")
    val a = res2.rdd
    if (ctl.count != 0 || exrt.count != 0) {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    }
  }

  test("Control Table-Validate that bhi_home_plan_id and totl_alwd_amt columns should summed from all records in the Extract") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("011")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Validate that bhi_home_plan_id and totl_alwd_amt columns should summed from all records in the Extract")
    val query = Array("Test Query : select bhi_home_plan_id, totl_alwd_amt from " + controlTable + " & select bhi_home_plan_id, sum(alwd_amt) from " + extractTable + " group by bhi_home_plan_id")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result1 = spark.sql("select bhi_home_plan_id, totl_alwd_amt from " + controlTable + "").rdd.map(_.mkString("|"))
    val result2 = spark.sql("select bhi_home_plan_id, sum(alwd_amt) from " + extractTable + " group by bhi_home_plan_id").rdd.map(_.mkString("|"))
    val ctl = result1.subtract(result2).map(_.concat("|ControlTable"))
    val exrt = result2.subtract(result1).map(_.concat("|ExtractTable"))
    val res = ctl.union(exrt)
    val res1 = res.sortBy(x => x, true, 1).toDF()
    res1.createOrReplaceTempView("table1")
    val res2 = sql("select * from table1 limit 10")
    val a = res2.rdd
    if (ctl.count != 0 || exrt.count != 0) {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    }
  }
  test("Control Table-Validate that bhi_home_plan_id and totl_paid_amt columns should summed from all records in the Extract") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("012")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Validate that bhi_home_plan_id and totl_paid_amt columns should summed from all records in the Extract")
    val query = Array("Test Query : select bhi_home_plan_id, totl_paid_amt from " + controlTable + " & select bhi_home_plan_id, sum(paymnt_amt) from " + extractTable + " group by bhi_home_plan_id")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result1 = spark.sql("select bhi_home_plan_id, totl_paid_amt from " + controlTable + "").rdd.map(_.mkString("|"))
    val result2 = spark.sql("select bhi_home_plan_id, sum(paymnt_amt) from " + extractTable + " group by bhi_home_plan_id").rdd.map(_.mkString("|"))
    val ctl = result1.subtract(result2).map(_.concat("|ControlTable"))
    val exrt = result2.subtract(result1).map(_.concat("|ExtractTable"))
    val res = ctl.union(exrt)
    val res1 = res.sortBy(x => x, true, 1).toDF()
    res1.createOrReplaceTempView("table1")
    val res2 = sql("select * from table1 limit 10")
    val a = res2.rdd
    if (ctl.count != 0 || exrt.count != 0) {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    }
  }

  test("Check tot_cob_tpl_amt column has 0 or not") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("013")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check tot_cob_tpl_amt column has 0 or not")
    val query = Array("Test Query : select distinct trim(tot_cob_tpl_amt) from " + controlTable + "")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result = spark.sql("select distinct trim(totl_cob_tpl_amt) from " + controlTable + "")
    val a = result.rdd
    if (result.first.getString(0) == "0.00" || result.first.getString(0) == "0") {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    }
  }

  test("Check tot_coinsur_amt column has 0 or not") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("014")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check tot_coinsur_amt column has 0 or not")
    val query = Array("Test Query : select distinct trim(tot_coinsur_amt) from " + controlTable + "")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result = spark.sql("select distinct trim(totl_coinsrn_amt) from " + controlTable + "")
    val a = result.rdd
    if (result.first.getString(0) == "0.00" || result.first.getString(0) == "0") {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    }
  }
  test("Check tot_copay_amt column has 0 or not") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("015")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check tot_copay_amt column has 0 or not")
    val query = Array("Test Query : select distinct trim(tot_copay_amt) from " + controlTable + "")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result = spark.sql("select distinct trim(totl_cpay_amt) from " + controlTable + "")
    val a = result.rdd
    if (result.first.getString(0) == "0.00" || result.first.getString(0) == "0") {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    }
  }

  test("Check tot_deduct_amt column has 0 or not") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("016")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check tot_deduct_amt column has 0 or not")
    val query = Array("Test Query : select distinct trim(tot_deduct_amt) from " + controlTable + "")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result = spark.sql("select distinct trim(totl_ddctbl_amt) from " + controlTable + "")
    val a = result.rdd
    if (result.first.getString(0) == "0.00" || result.first.getString(0) == "0") {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    }
  }

  test("Check tot_ff_srvc_eq_amt column has 0 or not") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("017")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check tot_ff_srvc_eq_amt column has 0 or not")
    val query = Array("Test Query : select distinct trim(tot_ff_srvc_eq_amt) from " + controlTable + "")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result = spark.sql("select distinct trim(totl_ffs_eqvlnt_amt) from " + controlTable + "")
    val a = result.rdd
    if (result.first.getString(0) == "0.00" || result.first.getString(0) == "0") {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    }
  }
  test("Check exclsn_ind column has 0 or not") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("018")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check exclsn_ind column has 0 or not")
    val query = Array("Test Query : select distinct trim(exclsn_ind) from " + controlTable + "")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result = spark.sql("select distinct trim(exclsn_ind) from " + controlTable + "")
    val a = result.rdd
    if (result.first.getString(0) == "0") {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    }
  }

  test("Check rcrd_stts_cd column has 0 or not") {

    import spark.implicits._
    import spark.sql
    val sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    val id = Array("019")
    val tcId = Array("Testcase Id : ControlTable_" + process_Name + "_" + id(0) + "")
    val test_Name = Array("Testcase Name : Check rcrd_stts_cd column has 0 or not")
    val query = Array("Test Query : select distinct trim(rcrd_stts_cd) from " + controlTable + "")
    val outPut = Array("SQL Query Output : ")
    val p = Array("PASS")
    val statusP = Array("Testcase Status : PASSED")
    val f = Array("FAIL")
    val statusF = Array("Testcase Status : FAILED")
    var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
    var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

    val result = spark.sql("select distinct trim(rcrd_stts_ind) from " + controlTable + "")
    val a = result.rdd
    if (result.first.getString(0) == "0") {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 1)
    } else {
      sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///"+env+"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Control_Tables/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_ControlTable_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
      assert(1 == 2)
    }
  }
 println("========> Control Table of " + process_Name)
}