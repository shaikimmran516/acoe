 package com.anthem.hca.ndw.tests

import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row
import java.nio.file.{ Paths, Files }
import java.io.FileReader
import java.io.FileNotFoundException
import java.io.IOException
import org.scalatest.FunSuite
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql._
import scala.io.Source
import java.text.SimpleDateFormat
import java.util.Calendar
import org.apache.spark.sql.functions._
import org.apache.spark.deploy.SparkHadoopUtil
import org.apache.hadoop.fs.{ FileSystem, Path, LocatedFileStatus, RemoteIterator }
import java.net.URI

object PCADX_SCL_TA_InboundTable_All_INB {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_InboundTable_All_INB(args(0), args(1), args(2))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_InboundTable_All_INB(filePath: String, dbName: String, env: String) extends FunSuite {

  val spark = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
  val DATETIME_FORMAT1 = new SimpleDateFormat("yyyy-MM-dd-HH-mm")
  val DATETIME1 = DATETIME_FORMAT1.format(Calendar.getInstance().getTime())
  import spark.implicits._
  import spark.sql
  val sc = spark.sparkContext
  val sqlContext = new SQLContext(sc)
  sc.setLogLevel("ERROR")

  val rdd1 = spark.sparkContext.parallelize(Seq(("REF_BCBSA", "true", "~"), ("REF_BOT", "true", "¤"), ("CROSSWALK", "true", "¤"), ("REFERENCE", "true", "~"), ("REF_RDM", "true", "¤")))
  val rddWithSchema = spark.createDataFrame(rdd1).toDF("sname", "headr", "delimitr")
  rddWithSchema.createOrReplaceTempView("dframe")
  val result1 = sql("select sname,headr,delimitr from dframe")
  result1.collect().foreach(t => {
    val sname1 = t.getString(0)
    val headr1 = t.getString(1)
    val delimitr1 = t.getString(2)

    test("Check count and data mismatches for Inbound Tables of " + sname1 + "") {

      println("Begun processing inbound tables in Sheet : " + sname1)

      val location = "hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/bin/ta/PCADX_NDW_TA_INBND_REF_BOT_TABLES.xlsx"

      val df1 = sqlContext.read.format("com.crealytics.spark.excel").option("sheetName", "" + sname1 + "").option("useHeader", "true").option("treatEmptyValuesAsNulls", "false").option("inferSchema", "false").option("location", location).option("addColorColumns", "false").load(location)
      df1.createOrReplaceTempView("table1")
      val df2 = sql("select Source,Target from table1")

      df2.collect().foreach(t => {

        val hconf = SparkHadoopUtil.get.newConfiguration(sc.getConf)
        val hdfs1 = FileSystem.get(hconf)

        //To access the HDFS path by declaring filePath variable
        val iterList = hdfs1.listStatus(new Path(filePath))

        // Convert the datatype from Hadoop File path into string and then change it into list
        var a = iterList.map(x => x.toString())
        var list = a.toList

        // We extract the hdfs path of the directories
        var p1 = list.map { x => x.split(";")(0).split("=")(1) }

        var namenode = ""

        if (env == "pr") {
          namenode = p1(0).substring(0, p1(0).indexOf("3/") + 1)
        } else {
          namenode = p1(0).substring(0, p1(0).indexOf("1/") + 1)
        }

        val dir_name = "" + namenode + "" + filePath + "" + t.getString(0)
        val dir_length = dir_name.length()

        //To pick the latest Directory by applying filter
        val StringList = p1.filter(x => (x.startsWith(dir_name)) && (x.charAt(dir_length).isLetter == false))
        var pathName = ""

        //To sorting directories as per ascending order
        val sortedStringList = StringList.sortWith(_.toString > _.toString)
        val listDirectories = sortedStringList.map(_.toString)

        println("For Table: " + t.getString(1))

        // println("The listed Directories are: " + listDirectories)
        if (listDirectories.size == 0) {
          println("Directory is not present ==>  " + dir_name)
        } else {
          pathName = listDirectories(0)
          println("****Directory name====>" + pathName)

          // We need to go into the directory and then sort the files.
          val dirPath = "" + pathName + "/"

          val iterList1 = hdfs1.listFiles(new Path(dirPath), false)
          //To keep all hdfs files into list
          var list1: List[String] = List()
          while (iterList1.hasNext) {
            list1 = list1 :+ iterList1.next.getPath.toString
          }

          // println("The value outside the loop is: " + list1)

          val file_name = "" + dirPath + "" + t.getString(0)

          //To pick the latest file by applying filter

          val listFiles1 = list1.filter(x => (x.startsWith(file_name)) && (x.charAt(file_name.length).isLetter == false))

          //To sorting files as per ascending order
          val sortedList1 = listFiles1.sortWith(_.toString > _.toString)
          val sortedStringList1 = sortedList1.map(_.toString)

          // Check if there are files in the directories
          if (sortedStringList1.size == 0) {
            println("File is not present ==>  " + file_name)
          } else {
            val pathName1 = sortedStringList1(0)
            println("****Source file name====>" + pathName1)

            val trgtTbl = t.getString(1).toLowerCase
            val test = sql("SHOW TABLES IN " + dbName + "_pcandw1ph_nogbd_r000_in").filter("tableName='" + trgtTbl + "'")
            if (test.count() == 1) {

              var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
              var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())
              var summaryStr: String = "---------------" + trgtTbl + "----------------";
              val data = spark.read.format("com.databricks.spark.csv").option("header", "" + headr1 + "").option("inferSchema", "false").option("delimiter", "" + delimitr1 + "").load(pathName1)
              val data1 = data.na.fill("")
              data1.createOrReplaceTempView("table")
              val eQuery1 = """select * from table"""
              val rQuery1 = """select * from """ + dbName + """_pcandw1ph_nogbd_r000_in.""" + trgtTbl + """"""
              val expectedDF = spark.sql(eQuery1)
              val resultDF = spark.sql(rQuery1)
              val expectedRDD = expectedDF.rdd
              val expectedRowCount = expectedDF.count()
              summaryStr = summaryStr + "\n" + """Count of Text file records: """ + expectedRowCount + "\n"
              val expectedRDDWithoutSpaces = expectedRDD.map(_.mkString("|")).map(_.split("\\|")).map(x => x.map(_.trim)).map(_.mkString("|"))
              val resultRDD = resultDF.rdd
              val resultRowCount = resultDF.count()
              summaryStr = summaryStr + """Count of Table records: """ + resultRowCount + "\n"
              val resultRDDWithoutSpaces = resultRDD.map(_.mkString("|")).map(_.split("\\|")).map(x => x.map(_.trim)).map(_.mkString("|"))
              val onlyExpectedDiff = expectedRDDWithoutSpaces.subtract(resultRDDWithoutSpaces)
              val onlyResultDiff = resultRDDWithoutSpaces.subtract(expectedRDDWithoutSpaces)
              val onlyResultDiffWithHive = onlyResultDiff.map(_.concat("|Table"))
              val onlyExpectedDiffWithDB2 = onlyExpectedDiff.map(_.concat("|Textfile"));
              val finalDiff = onlyResultDiffWithHive.union(onlyExpectedDiffWithDB2);
              val sortedFinalDiff = finalDiff.sortBy(x => x, true, 1)
              val summaryRDD = spark.sparkContext.parallelize(List(summaryStr))
              //Checks if both the table and file have 0 records
              if (expectedDF.count() == 0 && resultDF.count() == 0) {
                summaryRDD.coalesce(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Inbound_Tables/" + DATETIME1 + "/" + sname1 + "/FAILED_Zero_Count_in_" + trgtTbl + "_" + DATETIME)
                sortedFinalDiff.coalesce(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Inbound_Tables/" + DATETIME1 + "/" + sname1 + "/FAILED_Zero_Data_in_" + trgtTbl + "_" + DATETIME)
              } else if (expectedDF.count() == resultDF.count() && finalDiff.count == 0) {
                summaryRDD.coalesce(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Inbound_Tables/" + DATETIME1 + "/" + sname1 + "/PASSED_Count_of_" + trgtTbl + "_" + DATETIME)
                sortedFinalDiff.coalesce(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Inbound_Tables/" + DATETIME1 + "/" + sname1 + "/PASSED_Data_of_" + trgtTbl + "_" + DATETIME)
              } else if (expectedDF.count() == resultDF.count() && finalDiff.count > 0) {
                summaryRDD.coalesce(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Inbound_Tables/" + DATETIME1 + "/" + sname1 + "/PASSED_Count_of_" + trgtTbl + "_" + DATETIME)
                sortedFinalDiff.coalesce(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Inbound_Tables/" + DATETIME1 + "/" + sname1 + "/FAILED_Data_of_" + trgtTbl + "_" + DATETIME)
              } else if (expectedDF.count() != resultDF.count() && finalDiff.count == 0) {
                summaryRDD.coalesce(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Inbound_Tables/" + DATETIME1 + "/" + sname1 + "/FAILED_Count_of_" + trgtTbl + "_" + DATETIME)
                sortedFinalDiff.coalesce(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Inbound_Tables/" + DATETIME1 + "/" + sname1 + "/PASSED_Data_of_" + trgtTbl + "_" + DATETIME)
              } else {
                summaryRDD.coalesce(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Inbound_Tables/" + DATETIME1 + "/" + sname1 + "/FAILED_Count_of_" + trgtTbl + "_" + DATETIME)
                sortedFinalDiff.coalesce(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Inbound_Tables/" + DATETIME1 + "/" + sname1 + "/FAILED_Data_of_" + trgtTbl + "_" + DATETIME)
              }
            } else { println("******TABLE NOT FOUND=======>" + trgtTbl) }
          } // end of file check
        } //end of directory check
      })
      assert(1 == 1)
    }
  })

  val inDb = env + "_pcandw1ph_nogbd_r000_in"
  val whDb = env + "_pcandw1ph_nogbd_r000_wh"
  val arDb = env + "_pcandw1ph_nogbd_r000_ar"

  val Record_Count = spark.
    sql(s"""select * from
(
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_BHI_HOME_PLAN_ID_INBND" as tbl_nm , "REF_BCBSA" as inb_nm from $inDb.RFRNC_BCBSA_BHI_HOME_PLAN_ID_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_BHI_PROD_CTGRY_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_BHI_PROD_CTGRY_INBND union all	
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_INDSTRY_GRPG_SIC_CD_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_INDSTRY_GRPG_SIC_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_INDSTRY_GRPG_NAICS_CD_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_INDSTRY_GRPG_NAICS_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_ASO_CD_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_ASO_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_GRP_INDIV_CD_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_GRP_INDIV_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_mrkt_place_type_cd_inbnd" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.rfrnc_bcbsa_mrkt_place_type_cd_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_CNTRCT_GRP_SIZE_CD_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_CNTRCT_GRP_SIZE_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_CDHP_OFRD_CD_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_CDHP_OFRD_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_aca_metl_lvl_cd_inbnd" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.rfrnc_bcbsa_aca_metl_lvl_cd_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_CNTRY_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_CNTRY_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_ZIP_CD_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_ZIP_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_GNDR_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_GNDR_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_MBR_CNFDNTLTY_CD_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_MBR_CNFDNTLTY_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_ENRLMNT_ELGBLTY_STTS_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_ENRLMNT_ELGBLTY_STTS_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_MBR_MDCL_COB_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_MBR_MDCL_COB_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_MBR_RX_COB_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_MBR_RX_COB_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_ddctbl_ctgry_inbnd" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.rfrnc_bcbsa_ddctbl_ctgry_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_MBR_RLTNSHP_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_MBR_RLTNSHP_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_rx_bnft_tier_inbnd" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.rfrnc_bcbsa_rx_bnft_tier_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_GOV_SBSDY_IND_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_GOV_SBSDY_IND_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_cost_shrg_rdctn_type_inbnd" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.rfrnc_bcbsa_cost_shrg_rdctn_type_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_OOA_CD_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_OOA_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_nlo_acct_type_inbnd" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.rfrnc_bcbsa_nlo_acct_type_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_nlo_plan_type_inbnd" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.rfrnc_bcbsa_nlo_plan_type_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_DSCHRG_STTS_CD_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_DSCHRG_STTS_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_REIMB_TYPE_CD_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_REIMB_TYPE_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_sbmsn_type_cd_inbnd" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.rfrnc_bcbsa_sbmsn_type_cd_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_DIAG_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_DIAG_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_place_of_srvc_inbnd" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.rfrnc_bcbsa_place_of_srvc_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_NPI_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_NPI_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_NON_CNTRCTD_HHRMLS_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_NON_CNTRCTD_HHRMLS_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_BILLG_PROV_CNTRCTG_STTS_INBND"as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_BILLG_PROV_CNTRCTG_STTS_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_RNDRG_PROV_CNTRCTG_STTS_INBND"as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_RNDRG_PROV_CNTRCTG_STTS_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_ICD10_PROC_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_ICD10_PROC_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_POA_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_POA_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_NCPDP_INBND" as tbl_nm , "REF_BCBSA" as inb_nm  from $inDb.RFRNC_BCBSA_NCPDP_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "MLSA_CNTY_HIST_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.MLSA_CNTY_HIST_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "MLSA_ZIP_CD_HIST_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.MLSA_ZIP_CD_HIST_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "MLSA_ZIP_CNTY_HIST_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.MLSA_ZIP_CNTY_HIST_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_drg_inbnd" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.rfrnc_drg_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_HLTH_SRVC_CPT_HIST_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_HLTH_SRVC_CPT_HIST_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_HLTH_SRVC_HCPCS_HIST_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_HLTH_SRVC_HCPCS_HIST_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_HLTH_SRVC_HCPCS_HG_HIST_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_HLTH_SRVC_HCPCS_HG_HIST_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_HLTH_SRVC_HCPCS_DNTL_HIST_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_HLTH_SRVC_HCPCS_DNTL_HIST_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_HLTH_SRVC_HIPPS_HIST_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_HLTH_SRVC_HIPPS_HIST_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_ICD_PROC_ICD_9_HIST_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_ICD_PROC_ICD_9_HIST_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_ICD_PROC_ICD_10_HIST_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_ICD_PROC_ICD_10_HIST_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_DIAG_ICD_9_HIST_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_DIAG_ICD_9_HIST_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_DIAG_ICD_10_HIST_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_DIAG_ICD_10_HIST_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_CMN_CD_VAL_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_CMN_CD_VAL_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_DATA_ITEM_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_DATA_ITEM_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_PHYSCL_TBL_MAPG_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_PHYSCL_TBL_MAPG_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_LOINC_CD_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_LOINC_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_RVNU_CD_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_RVNU_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BASE_CD_VAL_TRNSLTN_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_BASE_CD_VAL_TRNSLTN_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BASE_CD_VAL_DFLT_INBND" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.RFRNC_BASE_CD_VAL_DFLT_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_sor_xwalk_inbnd" as tbl_nm , "REF_RDM" as inb_nm  from $inDb.rfrnc_sor_xwalk_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_SBMSN_PARM_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_SBMSN_PARM_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_PRFX_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_PRFX_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_CMPNY_CF_XWALK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_CMPNY_CF_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_MBU_CF_XWALK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_MBU_CF_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_MBRSHP_SOR_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_MBRSHP_SOR_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_PROD_CF_INBND"  as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_PROD_CF_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "bot_bcbsa_prcp_type_inbnd"  as tbl_nm , "REF_BOT" as inb_nm  from $inDb.bot_bcbsa_prcp_type_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_PLAN_SBMSN_INBND"  as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_PLAN_SBMSN_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BU_CLNT_XWALK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BU_CLNT_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_NTWK_PROD_XWALK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_NTWK_PROD_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_NLO_MAPG_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_NLO_MAPG_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "bot_bcbsa_plan_ntwk_fclty_inbnd" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.bot_bcbsa_plan_ntwk_fclty_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "bot_bcbsa_plan_ntwk_prfsnl_inbnd" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.bot_bcbsa_plan_ntwk_prfsnl_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "bot_bcbsa_host_ovrd_ndw_plan_inbnd" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.bot_bcbsa_host_ovrd_ndw_plan_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_HOST_PLAN_SRVCAREA_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_HOST_PLAN_SRVCAREA_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_CMS_PROV_TYPE_MAPG_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_CMS_PROV_TYPE_MAPG_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_BRTH_WT_XWALK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_BRTH_WT_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_DRG_CD_XWALK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_DRG_CD_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_DRG_MDC_CD_XWALK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_DRG_MDC_CD_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_BILL_TYPE_CD_XWALK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_BILL_TYPE_CD_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_SUTTER_TAX_EXCLSN_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_SUTTER_TAX_EXCLSN_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_CPT_HCPCS_XWALK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_CPT_HCPCS_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_PROC_MDFR_INCLSN_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_PROC_MDFR_INCLSN_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_RVNU_CD_XWALK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_RVNU_CD_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_BSIS_COST_DTRMN_CD_XWALK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_BSIS_COST_DTRMN_CD_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_DAW_CD_XWALK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_DAW_CD_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_EXTRCT_PRCSG_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_EXTRCT_PRCSG_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "BOT_BCBSA_CSTM_NTWK_INBND" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.BOT_BCBSA_CSTM_NTWK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "bot_bcbsa_mhcd_inbnd" as tbl_nm , "REF_BOT" as inb_nm  from $inDb.bot_bcbsa_mhcd_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_mrkt_place_type_xwalk_inbnd" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.rfrnc_bcbsa_mrkt_place_type_xwalk_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_ACA_METL_LVL_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_ACA_METL_LVL_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_GNDR_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_GNDR_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_mbr_cnfdntlty_xwalk_inbnd" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.rfrnc_bcbsa_mbr_cnfdntlty_xwalk_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_MBR_RLTNSHP_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_MBR_RLTNSHP_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_MBR_EMPLYMNT_STTS_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_MBR_EMPLYMNT_STTS_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_MBR_MDCL_COB_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_MBR_MDCL_COB_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_MBR_RX_COB_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_MBR_RX_COB_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_DDCTBL_CTGRY_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_DDCTBL_CTGRY_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_MH_CD_ENRLMNT_BNFT_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_MH_CD_ENRLMNT_BNFT_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_RX_BNFT_IND_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_RX_BNFT_IND_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_MH_CD_BNFT_IND_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_MH_CD_BNFT_IND_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_MDCL_BNFT_IND_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_MDCL_BNFT_IND_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_HOSP_BNFT_IND_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_HOSP_BNFT_IND_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_rx_crv_out_sbmsn_ind_xwalk_inbnd" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.rfrnc_bcbsa_rx_crv_out_sbmsn_ind_xwalk_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_rx_bnft_tier_xwalk_inbnd" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.rfrnc_bcbsa_rx_bnft_tier_xwalk_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_gov_sbsdy_ind_xwalk_inbnd" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.rfrnc_bcbsa_gov_sbsdy_ind_xwalk_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_cost_shrg_rdctn_type_xwalk_inbnd" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.rfrnc_bcbsa_cost_shrg_rdctn_type_xwalk_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_BCKT_PRCS_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_BCKT_PRCS_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_POA_CD_XWALK_INBND" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.RFRNC_BCBSA_POA_CD_XWALK_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_non_cvrd_rsn_cd_xwalk_inbnd" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.rfrnc_bcbsa_non_cvrd_rsn_cd_xwalk_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_brth_wt_xwalk_inbnd" as tbl_nm , "CROSSWALK" as inb_nm  from $inDb.rfrnc_bcbsa_brth_wt_xwalk_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_err_cd_inbnd" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.rfrnc_err_cd_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_place_of_srvc_cd_ordr_inbnd" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.rfrnc_place_of_srvc_cd_ordr_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_clm_paymnt_stts_inbnd" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.rfrnc_bcbsa_clm_paymnt_stts_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_CTGRY_OF_SRVC_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_CTGRY_OF_SRVC_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_bnft_paymnt_stts_inbnd" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.rfrnc_bcbsa_bnft_paymnt_stts_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_icd10_diag_inbnd" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.rfrnc_bcbsa_icd10_diag_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_RVNU_CD_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_RVNU_CD_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_HOST_PLAN_ID_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_HOST_PLAN_ID_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_PROV_SPCLTY_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_PROV_SPCLTY_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_PROV_TYPE_XREF_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_PROV_TYPE_XREF_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_ADMT_SRC_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_ADMT_SRC_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_ADMT_TYPE_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_ADMT_TYPE_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_BILL_STTS_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_BILL_STTS_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_BRTH_WT_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_BRTH_WT_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_DRG_MDC_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_DRG_MDC_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_CLM_TYPE_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_CLM_TYPE_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_ITS_CLM_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_ITS_CLM_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "RFRNC_BCBSA_TYPE_OF_BILL_INBND" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.RFRNC_BCBSA_TYPE_OF_BILL_INBND union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_proc_cd_inbnd" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.rfrnc_bcbsa_proc_cd_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_prov_type_inbnd" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.rfrnc_bcbsa_prov_type_inbnd union all
select count(*) as RECORD_COUNT,current_timestamp as CHECK_DATE,  "rfrnc_bcbsa_drg_inbnd" as tbl_nm , "REFERENCE" as inb_nm  from $inDb.rfrnc_bcbsa_drg_inbnd
)a""")

  // Capture the load volume
  Record_Count.createOrReplaceTempView("Record_Count")
  Record_Count.write.mode("overwrite").saveAsTable(env + "_pcandw1ph_nogbd_r000_wh.BLNCG_NDW_INB_REF_RCRD_CNT")

  // Archive the load volume
  spark.sql(s""" FROM $whDb.BLNCG_NDW_INB_REF_RCRD_CNT t2 INSERT INTO TABLE $arDb.BLNCG_NDW_INB_REF_RCRD_CNT_ARCHV PARTITION(year, month)
  SELECT t2.*, year(to_date(CHECK_DATE)) as year, month(to_date(CHECK_DATE)) as month DISTRIBUTE BY year,month""")

}