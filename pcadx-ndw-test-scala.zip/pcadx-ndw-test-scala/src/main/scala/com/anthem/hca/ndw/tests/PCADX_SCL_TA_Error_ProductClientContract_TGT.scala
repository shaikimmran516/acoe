package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Error_ProductClientContract_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Error_ProductClientContract_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_Error_ProductClientContract_TGT(dbname : String, env: String) extends FunSuite  {

	  val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())

     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Error"
      val prcss = "PCC"

    test("PCC Error-Check Error code when Account is equal to Individual and Group/Individual Code does not equal to Individual for grp_id column") {

    val id = Array("001")
    val name = Array("Test case : Check Error code when Account is equal to Individual and Group/Individual Code does not equal to Individual for grp_id column")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where trim(b.grp_id) <> 'Individual' and trim(b.acct_id) = 'Individual'""")

     if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(grp_id) <> 'Individual' and trim(acct_id) = 'Individual'")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(grp_id) <> 'Individual' and trim(acct_id) = 'Individual'")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when cstm_ntwk_ind does not equal to 'Y' and 'N' - 002") {

    val id = Array("002")
    val name = Array("Test case : Check Error code when cstm_ntwk_ind does not equal to 'Y' and 'N'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where trim(b.cstm_ntwk_ind)<>'Y' and trim(b.cstm_ntwk_ind)<>'N'""")

      if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(cstm_ntwk_ind)<>'Y' and trim(cstm_ntwk_ind)<>'N'")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(cstm_ntwk_ind)<>'Y' and trim(cstm_ntwk_ind)<>'N'")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when mbr_enrlmnt_ind does not equal to 'Y' and 'N' - 003") {

    val id = Array("003")
    val name = Array("Test case : Check Error code when mbr_enrlmnt_ind does not equal to 'Y' and 'N'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where trim(b.mbr_enrlmnt_ind)<>'Y' and trim(b.mbr_enrlmnt_ind)<>'N'""")
        
     if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(mbr_enrlmnt_ind)<>'Y' and trim(mbr_enrlmnt_ind)<>'N'")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(mbr_enrlmnt_ind)<>'Y' and trim(mbr_enrlmnt_ind)<>'N'")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check wheteher transitional_health_plan_indicator does not equal to 'Y' and 'N' in extract table - 004") {

    val id = Array("004")
    val name = Array("Test case : Check wheteher transitional_health_plan_indicator does not equal to 'Y' and 'N' in extract table")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where trim(b.trnstnl_hlth_plan_ind)<>'Y' and trim(b.trnstnl_hlth_plan_ind)<>'N'""")

      if (result.count == 0 || (result.collectAsList.toString.contains("423") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(b.trnstnl_hlth_plan_ind)<>'Y' and trim(b.trnstnl_hlth_plan_ind)<>'N'")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(b.trnstnl_hlth_plan_ind)<>'Y' and trim(b.trnstnl_hlth_plan_ind)<>'N'")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }

  //============================================================

  test("PCC Error-Check bhi_home_plan_id column values not located in reference table - 005") {

    val id = Array("005")
    val name = Array("Test case : Check bhi_home_plan_id column values not located in reference table")
      
    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result2 = sqlContext.sql("""select distinct a.bhi_home_plan_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') and bhi_home_plan_id in (select distinct a.bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306')")
       val data = Array("'bhi_home_plan_id': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') and bhi_home_plan_id in (select distinct a.bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306')")
       val data = Array("'bhi_home_plan_id'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when bhi_home_plan_id column values not located in reference table - 006") {

    val id = Array("006")
    val name = Array("Test case : Check Error code when bhi_home_plan_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("'bhi_home_plan_id': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("'bhi_home_plan_id'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================re-run and check

  test("PCC Error-Check SIC_CD column values not located in reference table - 007") {

    val id = Array("007")
    val name = Array("Test case : Check SIC_CD column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct indstry_grpg_sic_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_sic_cd_inbnd""")

    val result2 = sqlContext.sql("""select distinct a.sic_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='sic_cd' and b.err_cd='306'""")

    val result = result1.intersect(result2)
    
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct indstry_grpg_sic_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_sic_cd_inbnd where sic_cd in (select distinct a.sic_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='sic_cd' and b.err_cd='306')")
       val data = Array("'sic_cd': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct indstry_grpg_sic_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_sic_cd_inbnd where sic_cd in (select distinct a.sic_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='sic_cd' and b.err_cd='306')")
       val data = Array("'sic_cd'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when sic_cd column values not located in reference table - 008") {

    val id = Array("008")
    val name = Array("Test case : Check Error code when sic_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct indstry_grpg_sic_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_sic_cd_inbnd""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('sic_cd') and a.sic_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('sic_cd') and a.sic_cd NOT IN (select distinct indstry_grpg_sic_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_sic_cd_inbnd)")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('sic_cd') and a.sic_cd NOT IN (select distinct indstry_grpg_sic_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_sic_cd_inbnd)")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error- Check industry_grouping_naics_code column values not located in reference table - 009") {

    val id = Array("009")
    val name = Array("Test case : Check industry_grouping_naics_code column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct indstry_grpg_naics_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_naics_cd_inbnd""")

    val result2 = sqlContext.sql("""select distinct a.naics_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='naics_cd' and b.err_cd='306'""")

    val result = result1.intersect(result2)
    
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct indstry_grpg_naics_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_naics_cd_inbnd and indstry_grpg_naics_cd in (select distinct a.naics_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='naics_cd' and b.err_cd='306')")
       val data = Array("'indstry_grpg_naics_cd': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct indstry_grpg_naics_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_naics_cd_inbnd and indstry_grpg_naics_cd in (select distinct a.naics_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='naics_cd' and b.err_cd='306')")
       val data = Array("'indstry_grpg_naics_cd'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when indstry_grpg_naics_cd column values not located in reference table - 010") {

    val id = Array("010")
    val name = Array("Test case : Check Error code when indstry_grpg_naics_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct indstry_grpg_naics_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_naics_cd_inbnd""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('naics_cd') and a.naics_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('a.naics_cd') and a.naics_cd NOT IN (select distinct indstry_grpg_naics_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_naics_cd_inbnd)")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('a.naics_cd') and a.naics_cd NOT IN (select distinct indstry_grpg_naics_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_naics_cd_inbnd)")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check aso_ind_cd column values not located in reference table - 011") {

    val id = Array("011")
    val name = Array("Test case : Check aso_ind_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct aso_ind_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_aso_cd_inbnd""")

    val result2 = sqlContext.sql("""select distinct a.aso_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='aso_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================

  test("PCC Error-Check grp_indiv_cd column values not located in reference table - 012") {

    val id = Array("012")
    val name = Array("Test case : Check grp_indiv_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct grp_indiv_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_GRP_INDIV_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.grp_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='grp_id' and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct grp_indiv_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_GRP_INDIV_CD_INBND where grp_id in (select distinct a.grp_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='grp_id' and b.err_cd='306')")
       val data = Array("'grp_indiv_cd': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct grp_indiv_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_GRP_INDIV_CD_INBND where grp_id in (select distinct a.grp_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='grp_id' and b.err_cd='306')")
       val data = Array("'grp_indiv_cd'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when grp_id column values not located in reference table - 013") {

    val id = Array("013")
    val name = Array("Test case : Check Error code when grp_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct grp_indiv_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_GRP_INDIV_CD_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('grp_id') and a.grp_id NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('grp_id') and a.grp_id NOT IN (select distinct grp_indiv_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_GRP_INDIV_CD_INBND)")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('grp_id') and a.grp_id NOT IN (select distinct grp_indiv_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_GRP_INDIV_CD_INBND)")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check alpha_prefix_id column values not located in reference table - 014") {

    val id = Array("014")
    val name = Array("Test case : Check alpha_prefix_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,bcbsa_prfx_cd) as bcbsa_prfx_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prfx_rfrnc""")

    val result2 = sqlContext.sql("""select distinct concat(a.bhi_home_plan_id,a.prfx_cd) as bcbsa_prfx_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='prfx_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================

  test("PCC Error-Check cdhp_ofrd_cd column values not located in reference table - 015") {

    val id = Array("015")
    val name = Array("Test case : Check cdhp_ofrd_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct cdhp_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wk.work_bcbsa_product""")

    val result2 = sqlContext.sql("""select distinct a.cdhp_ofrd_type_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='cdhp_ofrd_type_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================

  test("PCC Error-Check traceability_field column values not located in reference table - 016") {

    val id = Array("016")
    val name = Array("Test case : Check traceability_field column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,sor_cd) as sor_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_trcblty_rfrnc""")

    val result2 = sqlContext.sql("""select distinct concat(a.bhi_home_plan_id,a.sor_cd) as sor_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='sor_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================

  test("PCC Error-Check home_plan_prod_id column values not located in reference table - 017") {

    val id = Array("017")
    val name = Array("Test case : Check home_plan_prod_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bcbsa_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_in.bot_bcbsa_ntwk_prod_xwalk_inbnd""")

    val result2 = sqlContext.sql("""select distinct a.home_plan_prod_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='home_plan_prod_id' and b.err_cd='306'""")

    val result = result1.intersect(result2)
    
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct bcbsa_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_ntwk_prod_xwalk_inbnd where bcbsa_prod_id in (select distinct a.home_plan_prod_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='home_plan_prod_id' and b.err_cd='306')")
       val data = Array("'home_plan_prod_id': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct bcbsa_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_ntwk_prod_xwalk_inbnd where bcbsa_prod_id in (select distinct a.home_plan_prod_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='home_plan_prod_id' and b.err_cd='306')")
       val data = Array("'home_plan_prod_id'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when home_plan_prod_id column values not located in reference table - 018") {

    val id = Array("018")
    val name = Array("Test case : Check Error code when home_plan_prod_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bcbsa_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_in.bot_bcbsa_ntwk_prod_xwalk_inbnd""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('home_plan_prod_id') and a.home_plan_prod_id NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('home_plan_prod_id') and a.home_plan_prod_id NOT IN (select distinct bcbsa_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_ntwk_prod_xwalk_inbnd)")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('home_plan_prod_id') and a.home_plan_prod_id NOT IN (select distinct bcbsa_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_ntwk_prod_xwalk_inbnd)")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check mrkt_place_type_cd column values not located in reference table - 019") {

    val id = Array("019")
    val name = Array("Test case : Check mrkt_place_type_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct mrkt_place_type_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_mrkt_place_type_xwalk_inbnd""")

    val result2 = sqlContext.sql("""select distinct a.mrkt_plc_type_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='mrkt_plc_type_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================

  test("PCC Error- Check aca_metl_lvl_cd column values not located in reference table - 020") {

    val id = Array("020")
    val name = Array("Test case : Check aca_metl_lvl_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct aca_metl_lvl_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_aca_metl_lvl_xwalk_inbnd""")

    val result2 = sqlContext.sql("""select distinct a.aca_metl_lvl_ind from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='aca_metl_lvl_ind' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================

  test("PCC Error- Check cntrct_grp_size_cd column values not located in reference table - 021") {

    val id = Array("021")
    val name = Array("Test case : Check cntrct_grp_size_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct cntrct_grp_size_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRCT_GRP_SIZE_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.cntrct_grp_size_cd from '"""+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='bcbsa_prod_clnt_cntrct_err' and b.clmn_nm='cntrct_grp_size_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }

  //============================================================

  test("PCC Error-Check Error code when bhi_home_plan_id column has spaces - 022") {

    val id = Array("022")
    val name = Array("Test case : Check Error code when bhi_home_plan_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when home_plan_prod_id column has spaces - 023") {

    val id = Array("023")
    val name = Array("Test case : Check Error code when home_plan_prod_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.home_plan_prod_id, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.home_plan_prod_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.home_plan_prod_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when acct_id column has spaces - 024") {

    val id = Array("024")
    val name = Array("Test case : Check Error code when acct_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.acct_id, "")," ", "")))=0""")

      if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.acct_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.acct_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when group column has spaces - 025") {

    val id = Array("025")
    val name = Array("Test case : Check Error code when group column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.grp_id, "")," ", "")))=0""")

      if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.grp_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.grp_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when subgrp_id column has spaces - 026") {

    val id = Array("026")
    val name = Array("Test case : Check Error code when subgrp_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.subgrp_id, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.subgrp_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.subgrp_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("PCC Error-Check Error code when sic_cd column has spaces - 027") {

    val id = Array("027")
    val name = Array("Test case : Check Error code when sic_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.sic_cd, "")," ", "")))=0""")

      if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sic_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sic_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when aso_cd column has spaces - 028") {

    val id = Array("028")
    val name = Array("Test case : Check Error code when aso_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.aso_cd, "")," ", "")))=0""")

      if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.aso_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.aso_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when grp_id column has spaces - 029") {

    val id = Array("029")
    val name = Array("Test case : Check Error code when grp_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.grp_id, "")," ", "")))=0""")

      if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where length(trim(regexp_replace(coalesce(b.grp_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where length(trim(regexp_replace(coalesce(b.grp_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("PCC Error-Check Error code when prfx_cd column has spaces - 030") {

    val id = Array("030")
    val name = Array("Test case : Check Error code when prfx_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.prfx_cd, "")," ", "")))=0""")

      if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where length(trim(regexp_replace(coalesce(b.prfx_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where length(trim(regexp_replace(coalesce(b.prfx_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("PCC Error-Check Error code when cstm_ntwk_ind column has spaces - 031") {

    val id = Array("031")
    val name = Array("Test case : Check Error code when cstm_ntwk_ind column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.cstm_ntwk_ind, "")," ", "")))=0""")

      if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.cstm_ntwk_ind, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.cstm_ntwk_ind, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("PCC Error-Check Error code when cdhp_ofrd_type_cd column has spaces - 032") {

    val id = Array("032")
    val name = Array("Test case : Check Error code when cdhp_ofrd_type_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.cdhp_ofrd_type_cd, "")," ", "")))=0""")

      if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.cdhp_ofrd_type_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.cdhp_ofrd_type_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("PCC Error-Check Error code when traceability_field column has spaces - 033") {

    val id = Array("033")
    val name = Array("Test case : Check Error code when traceability_field column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.sor_cd, "")," ", "")))=0""")

      if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sor_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sor_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("PCC Error-Check Error code when mbr_enrlmnt_ind column has spaces - 034") {

    val id = Array("034")
    val name = Array("Test case : Check Error code when mbr_enrlmnt_ind column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_enrlmnt_ind, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_enrlmnt_ind, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_enrlmnt_ind, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
 test("PCC Error-Check Error code when mrkt_plc_type_cd column has spaces - 035") {

    val id = Array("035")
    val name = Array("Test case : Check Error code when mrkt_plc_type_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mrkt_plc_type_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }
  
  //============================================================

  test("PCC Error-Check Error code when aca_metl_lvl_ind column has spaces - 036") {

    val id = Array("036")
    val name = Array("Test case : Check Error code when aca_metl_lvl_ind column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.aca_metl_lvl_ind, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }
  
  //============================================================

  test("PCC Error-Check Error code when transitional_health_plan_indicator column has spaces - 037") {

    val id = Array("037")
    val name = Array("Test case : Check Error code when transitional_health_plan_indicator column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.trnstnl_hlth_plan_ind, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }
  
  //============================================================

  test("PCC Error-Check Error code when cntrct_grp_size_cd column has spaces - 038") {

    val id = Array("038")
    val name = Array("Test case : Check Error code when cntrct_grp_size_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct_err b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.cntrct_grp_size_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }

  }