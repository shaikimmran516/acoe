package com.anthem.hca.ndw.tests

import java.io.File
import org.scalatest.FunSuite
import org.apache.spark.sql.SparkSession
import scala.io.Source
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.DataFrame
import java.text.SimpleDateFormat
import java.util.Calendar
import org.apache.spark.deploy.SparkHadoopUtil
import org.apache.hadoop.fs.{ FileSystem, Path, LocatedFileStatus, RemoteIterator }
import java.net.URI

object PCADX_SCL_TA_SplitFile_DataFile_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_SplitFile_DataFile_TGT(args(0), args(1), args(2), args(3))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_SplitFile_DataFile_TGT(filePath: String, fileLength: String, eName: String, env: String) extends FunSuite {

  val spark = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()

  /*def getListOfFiles(dir: File, extensions: List[String]): List[File] = {
    dir.listFiles.filter(_.isFile).toList.filter { file =>
      extensions.exists(file.getName.endsWith(_))
    }
  }
  val okFileExtensions = List("dat")
  val files = getListOfFiles(new File("" + filePath + ""), okFileExtensions)
  */

  //To get the HDFS configuration setup
  import spark.implicits._
  import spark.sql
  val sc = spark.sparkContext
  val hconf = SparkHadoopUtil.get.newConfiguration(sc.getConf)
  val hdfs1 = FileSystem.get(hconf)
  //To access the HDFS path by declaring filePath variable
  val iterList = hdfs1.listFiles(new Path(filePath), false)
  //To keep all hdfs files into list
  var list: List[String] = List()
  while (iterList.hasNext) {
    list = list :+ iterList.next.getPath.toString
  }
  val listFiles = list.filter(_.endsWith("dat"))

  listFiles.foreach(t => {
    val name = t
    val process_Name = eName
    val DATETIME_FORMAT1 = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss")
    val DATETIME1 = DATETIME_FORMAT1.format(Calendar.getInstance().getTime())

    /*  if (fileLength.equals("96")) {
      process_Name = "Account_Reporting"
    } else if (fileLength.equals("105")) {
      process_Name = "Product_Client_Contract"
    } else if (fileLength.equals("76")) {
      process_Name = "Product"
    } else if (fileLength.equals("")) {
      process_Name = "Alpha_Prefix"
    } else if (fileLength.equals("35") && eName.equals("Fac")) {
      process_Name = "Net_Cat_Fac_Ref"
    } else if (fileLength.equals("35") && eName.equals("Prof")) {
      process_Name = "Net_Cat_Prof_Ref"
    } else if (fileLength.equals("38")) {
      process_Name = "Traceability"
    } else if (fileLength.equals("")) {
      process_Name = "Member"
    } else if (fileLength.equals("807")) {
      process_Name = "Member_Demographic"
    } else if (fileLength.equals("529")) {
      process_Name = "Pharmacy"
    } else if (fileLength.equals("1646")) {
      process_Name = "Facility_Claim_Header"
    } else if (fileLength.equals("176")) {
      process_Name = "Facility_Claim_Details"
    } else if (fileLength.equals("901")) {
      process_Name = "Professional_For_Service"
    }*/

    //var extractName=eName
    if (eName == "STD_INP_CLAIM_HEADERS") {

      test("Check file length is correct or not for the file of " + name + "") {

        import spark.implicits._
        import spark.sql
        val sc = spark.sparkContext
        sc.setLogLevel("ERROR")

        val id = Array("001")
        val tcId = Array("Testcase Id : DataFile_" + process_Name + "_" + id(0) + "")
        val test_Name = Array("Testcase Name : Check file length is correct or not for the file of " + name + "")
        val query = Array("Test Query : select LENGTH(data) from data_file limit 1")
        val outPut = Array("SQL Query Output : ")
        val p = Array("PASS")
        val statusP = Array("Testcase Status : PASSED")
        val f = Array("FAIL")
        val statusF = Array("Testcase Status : FAILED")
        var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
        var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

        val file = sc.textFile("" + name + "").toDF("data")
        file.createOrReplaceTempView("data_file")
        val result = spark.sql("""select LENGTH(data) from data_file limit 1""")
        val a = result.rdd

        if (result.first.getInt(0) == 1646) {
          val area = Array("It is History file and Length should be 1646")
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(sc.parallelize(area, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 1)
        } else if (result.first.getInt(0) == 1691) {
          val area = Array("It is History 18.5 file and Length should be 1691")
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(sc.parallelize(area, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 1)
        } else {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 2)
        }

      }

    } else if (eName == "STD_PFO_CLAIMS") {

      test("Check file length is correct or not for the file of " + name + "") {

        import spark.implicits._
        import spark.sql
        val sc = spark.sparkContext
        sc.setLogLevel("ERROR")

        val id = Array("001")
        val tcId = Array("Testcase Id : DataFile_" + process_Name + "_" + id(0) + "")
        val test_Name = Array("Testcase Name : Check file length is correct or not for the file of " + name + "")
        val query = Array("Test Query : select LENGTH(data) from data_file limit 1")
        val outPut = Array("SQL Query Output : ")
        val p = Array("PASS")
        val statusP = Array("Testcase Status : PASSED")
        val f = Array("FAIL")
        val statusF = Array("Testcase Status : FAILED")
        var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
        var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

        val file = sc.textFile("" + name + "").toDF("data")
        file.createOrReplaceTempView("data_file")
        val result = spark.sql("""select LENGTH(data) from data_file limit 1""")
        val a = result.rdd

        // if (result.first.getInt(0) == 901 || result.first.getInt(0) == 931) {
        if (result.first.getInt(0) == 901) {
          val area = Array("It is History file and Length should be 901")
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(sc.parallelize(area, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 1)
        } else if (result.first.getInt(0) == 931) {
          val area = Array("It is History 18.5 file and Length should be 931")
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(sc.parallelize(area, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 1)
        } else {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 2)
        }

      }

    } else if (eName == "STD_MEMBER_DEMOGRAPHIC") {
      test("Check file length is correct or not for the file of " + name + "") {

        import spark.implicits._
        import spark.sql
        val sc = spark.sparkContext
        sc.setLogLevel("ERROR")

        val id = Array("001")
        val tcId = Array("Testcase Id : DataFile_" + process_Name + "_" + id(0) + "")
        val test_Name = Array("Testcase Name : Check file length is correct or not for the file of " + name + "")
        val query = Array("Test Query : select LENGTH(data) from data_file limit 1")
        val outPut = Array("SQL Query Output : ")
        val p = Array("PASS")
        val statusP = Array("Testcase Status : PASSED")
        val f = Array("FAIL")
        val statusF = Array("Testcase Status : FAILED")
        var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
        var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

        val file = sc.textFile("" + name + "").toDF("data")
        file.createOrReplaceTempView("data_file")
        val result = spark.sql("""select LENGTH(data) from data_file limit 1""")
        val a = result.rdd

        // if (result.first.getInt(0) == 807 || result.first.getInt(0) == 831) {
        if (result.first.getInt(0) == 807) {
          val area = Array("It is History file and Length should be 807")
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(sc.parallelize(area, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 1)
        } else if (result.first.getInt(0) == 831) {
          val area = Array("It is History 18.5 file and Length should be 831")
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(sc.parallelize(area, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 1)
        } else {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 2)
        }

      }
    } else {
      test("Check file length is correct or not for the file of " + name + "") {

        import spark.implicits._
        import spark.sql
        val sc = spark.sparkContext
        sc.setLogLevel("ERROR")

        val id = Array("001")
        val tcId = Array("Testcase Id : DataFile_" + process_Name + "_" + id(0) + "")
        val test_Name = Array("Testcase Name : Check file length is correct or not for the file of " + name + "")
        val query = Array("Test Query : select LENGTH(data) from data_file limit 1")
        val outPut = Array("SQL Query Output : ")
        val p = Array("PASS")
        val statusP = Array("Testcase Status : PASSED")
        val f = Array("FAIL")
        val statusF = Array("Testcase Status : FAILED")
        var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
        var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

        val file = sc.textFile("" + name + "").toDF("data")
        file.createOrReplaceTempView("data_file")
        val result = spark.sql("""select LENGTH(data) from data_file limit 1""")
        val a = result.rdd

        if (result.first.getInt(0) == fileLength.toInt) {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 1)
        } else {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 2)
        }

      }
    }

    test("Check file has null values or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("002")
      val tcId = Array("Testcase Id : DataFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check file has null values or not for the file of " + name + "")
      val query = Array("Test Query : select data from data_file where data rlike '[null]'")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val file = sc.textFile("" + name + "").toDF("data")
      file.createOrReplaceTempView("data_file")
      val result = spark.sql("""select data from data_file where data rlike '[null]'""")
      val a = result.rdd

      if (result.count() == 0) {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        result.createOrReplaceTempView("data_file1")
        val df2 = sql("select * from data_file1 limit 10")
        val a = df2.rdd
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }

    }

    test("Check file has Double Quotes or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("003")
      val tcId = Array("Testcase Id : DataFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check file has Double Quotes or not for the file of " + name + "")
      val query = Array("""Test Query : select data from data_file where data like '%"%' or data rlike '["]'""")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val file = sc.textFile("" + name + "").toDF("data")
      file.createOrReplaceTempView("data_file")
      val result = spark.sql("""select data from data_file where data like '%"%' or data rlike '["]'""")
      val a = result.rdd

      if (result.count() == 0) {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        result.createOrReplaceTempView("data_file1")
        val df2 = sql("select * from data_file1 limit 10")
        val a = df2.rdd
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }
    }

    test("Check file has Lower Case letters or not for the file of " + name + "") {

      import spark.implicits._
      import spark.sql
      val sc = spark.sparkContext
      sc.setLogLevel("ERROR")

      val id = Array("004")
      val tcId = Array("Testcase Id : DataFile_" + process_Name + "_" + id(0) + "")
      val test_Name = Array("Testcase Name : Check file has Lower Case letters or not for the file of " + name + "")
      val query = Array("Test Query :select data from data_file where data rlike '[a-z]' and data rlike '[^null]'")
      val outPut = Array("SQL Query Output : ")
      val p = Array("PASS")
      val statusP = Array("Testcase Status : PASSED")
      val f = Array("FAIL")
      val statusF = Array("Testcase Status : FAILED")
      var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
      var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

      val file = sc.textFile("" + name + "").toDF("data")
      file.createOrReplaceTempView("data_file")
      val result = spark.sql("""select data from data_file where data rlike '[a-z]' and data rlike '[^null]'""")
      val a = result.rdd

      if (result.count() == 0) {
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 1)
      } else {
        result.createOrReplaceTempView("data_file1")
        val df2 = sql("select * from data_file1 limit 10")
        val a = df2.rdd
        sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
        assert(1 == 2)
      }

    }

    if (name.contains("G1") || name.contains("G2") || name.contains("G3") || name.contains("G4")) {
      test("Check home plan id's of group id are populated correctly or not for the file of " + name + "") {

        import spark.implicits._
        import spark.sql
        val sc = spark.sparkContext
        sc.setLogLevel("ERROR")

        val id = Array("005")
        val tcId = Array("Testcase Id : DataFile_" + process_Name + "_" + id(0) + "")
        val test_Name = Array("Testcase Name : Check home plan id's of group id are populated correctly or not for the file of " + name + "")
        val query = Array("""Test Query : select distinct substr(data,0,3) from data_file""")
        val outPut = Array("SQL Query Output : ")
        val p = Array("PASS")
        val statusP = Array("Testcase Status : PASSED")
        val f = Array("FAIL")
        val statusF = Array("Testcase Status : FAILED")
        var DATETIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
        var DATETIME = DATETIME_FORMAT.format(Calendar.getInstance().getTime())

        val file = sc.textFile("" + name + "").toDF("data")
        file.createOrReplaceTempView("data_file")
        spark.sql("""select * from data_file""")
        val result1 = spark.sql("""select distinct substr(data,0,3) from data_file""").rdd.map(_.mkString("|"))
        //val result2 = spark.sql("""select distinct home_plan_id from data_file""")
        if (name.contains("G1")) {
          var rdd1 = spark.sparkContext.parallelize(List("051", "748", "266", "458", "102")).toDF("home_plan_id")
          rdd1.createOrReplaceTempView("dframe")
        } else if (name.contains("G2")) {
          var rdd1 = spark.sparkContext.parallelize(List("040")).toDF("home_plan_id")
          rdd1.createOrReplaceTempView("dframe")
        } else if (name.contains("G3")) {
          var rdd1 = spark.sparkContext.parallelize(List("062", "182", "271", "254", "425")).toDF("home_plan_id")
          rdd1.createOrReplaceTempView("dframe")
        } else if (name.contains("G4")) {
          var rdd1 = spark.sparkContext.parallelize(List("131", "161", "330")).toDF("home_plan_id")
          rdd1.createOrReplaceTempView("dframe")
        }

        val result2 = spark.sql("select home_plan_id from dframe").rdd.map(_.mkString("|"))

        val ctl = result1.subtract(result2).map(_.concat("|DataFile"))
        val exrt = result2.subtract(result1).map(_.concat("|ExpectedList"))
        val a = ctl.union(exrt).sortBy(x => x, true, 1)

        if (ctl.count != 0 || exrt.count != 0) {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusF, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + f.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 2)
        } else {
          sc.parallelize(tcId, 1).union(sc.parallelize(test_Name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(statusP, 1)).union(sc.parallelize(outPut, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"hdfs:///" + env + "/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/SplitFiles/DataFiles/" + process_Name + "/" + DATETIME1 + "/PCADX_TA_DataFile_" + process_Name + "_" + id.toList.mkString("") + "_" + p.toList.mkString("") + "_" + DATETIME + ".dat")
          assert(1 == 1)
        }

      }
    }

  })

}
