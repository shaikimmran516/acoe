package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import java.util.Date
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._


object PCADX_SCL_TA_Extract_MemberDemographic_TGT {
 
  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_MemberDemographic_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}


class PCADX_SCL_TA_Extract_MemberDemographic_TGT(dbname : String, env: String) extends FunSuite {

     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
  
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Extract"
      val prcss = "MemberDemographic"
  
   test("MemberDemoExtract -Validate that BHI HomePlan ID field is not NULL or contains blank spaces - 001") {
    val id = Array("001")
    val name = Array("Test case : Validate that BHI HomePlan ID field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,cnsstnt_mbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(bhi_home_plan_id, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
       val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that Consistent Member ID field is not NULL or contains blank spaces - 002") {
    val id = Array("002")
    val name = Array("Test case : Validate that Consistent Member ID field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,cnsstnt_mbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(cnsstnt_mbr_id, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(cnsstnt_mbr_id, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(cnsstnt_mbr_id, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
  test("MemberDemoExtract -Validate that Member Prefix field is not NULL or contains blank spaces - 003") {
    val id = Array("003")
    val name = Array("Test case : Validate that Member Prefix field is not NULL or contains blank spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id, cnsstnt_mbr_id ,mbr_prfx_txt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(mbr_prfx_txt, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, cnsstnt_mbr_id ,mbr_prfx_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prfx_txt, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Prefix'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, cnsstnt_mbr_id ,mbr_prfx_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prfx_txt, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Prefix' : No Invalid Values Found")
            
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   } 

   //===========================================
   
   test("MemberDemoExtract -Validate that Member Last Name field is not NULL or contains blank spaces - 004") {
    val id = Array("004")
    val name = Array("Test case : Validate that Member Last Name field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select bhi_home_plan_id, cnsstnt_mbr_id, mbr_last_nm from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(mbr_last_nm, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, cnsstnt_mbr_id, mbr_last_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_last_nm, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Last_Name'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, cnsstnt_mbr_id, mbr_last_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_last_nm, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Last_Name' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that Member First Name field is not NULL or contains blank spaces - 005") {
    val id = Array("005")
    val name = Array("Test case : Validate that Member First Name field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select bhi_home_plan_id, cnsstnt_mbr_id, mbr_frst_nm from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(mbr_frst_nm, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, cnsstnt_mbr_id, mbr_frst_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_frst_nm, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_First_Name'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, cnsstnt_mbr_id, mbr_frst_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_frst_nm, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_First_Name' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary Street Address 1 field is not NULL or contains blank spaces - 006") {
    val id = Array("006")
    val name = Array("Test case : Validate that Member Primary Street Address 1 field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_str_adrs_1_txt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(mbr_prmry_str_adrs_1_txt, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_str_adrs_1_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prmry_str_adrs_1_txt, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Primary_Street_Address1'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_str_adrs_1_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prmry_str_adrs_1_txt, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Primary_Street_Address1' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary City field is not NULL or contains blank spaces - 007") {
    val id = Array("007")
    val name = Array("Test case : Validate that Member Primary City field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_city_nm from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(mbr_prmry_city_nm, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_city_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prmry_city_nm, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Primary_City'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_city_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prmry_city_nm, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Primary_City' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary State field is not NULL or contains blank spaces - 008") {
    val id = Array("008")
    val name = Array("Test case : Validate that Member Primary State field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_st_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(mbr_prmry_st_cd, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_st_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prmry_st_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Primary_State'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
     val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_st_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prmry_st_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Primary_State' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary Zip Code field is not NULL or contains blank spaces - 009") {
    val id = Array("009")
    val name = Array("Test case : Validate that Member Primary Zip Code field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_zip_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(mbr_prmry_zip_cd, "")," ", "")))=0  """)
        
     
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_zip_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prmry_zip_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Primary_Zip_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
     val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_zip_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prmry_zip_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Primary_Zip_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary Zip Code + 4 field is not NULL or contains blank spaces - 010") {
   val id = Array("010")
    val name = Array("Test case : Validate that Member Primary Zip Code + 4 field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_zip_plus4_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(mbr_prmry_zip_plus4_cd, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_zip_plus4_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prmry_zip_plus4_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Primary_Zip_Code+4'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_zip_plus4_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prmry_zip_plus4_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Primary_Zip_Code+4' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary Phone Number field is not NULL or contains blank spaces - 011") {
    val id = Array("011")
    val name = Array("Test case : Validate that Member Primary Phone Number field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_phone_nbr from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(mbr_prmry_phone_nbr, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_phone_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prmry_phone_nbr, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Primary_Phone_Number'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_phone_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_prmry_phone_nbr, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Primary_Phone_Number' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that Member Secondary State field is not NULL or contains blank spaces - 012") {
    val id = Array("012")
    val name = Array("Test case : Validate that Member Secondary State field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_scndry_str_adrs_1_txt, mbr_scndry_st_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(mbr_scndry_st_cd, "")," ", "")))=0   and trim(mbr_scndry_str_adrs_1_txt) NOT IN ('') """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_scndry_str_adrs_1_txt, mbr_scndry_st_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_scndry_st_cd, ''),' ', '')))=0   and trim(mbr_scndry_str_adrs_1_txt) NOT IN ('')")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Secondary_Address1','Member_Secondary_State'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_scndry_str_adrs_1_txt, mbr_scndry_st_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_scndry_st_cd, ''),' ', '')))=0   and trim(mbr_scndry_str_adrs_1_txt) NOT IN ('')")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Secondary_Address1','Member_Secondary_State' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that Host Plan Override field is not NULL or contains blank spaces - 013") {
    val id = Array("013")
    val name = Array("Test case : Validate that Host Plan Override field is not NULL or contains blank spaces")

    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, host_plan_ovrd_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(host_plan_ovrd_cd, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, host_plan_ovrd_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(host_plan_ovrd_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Host_Plan_Override'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, host_plan_ovrd_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(host_plan_ovrd_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Host_Plan_Override' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }   

   //===========================================
   
   test("MemberDemoExtract -Validate that Member Participation Code field is not NULL or contains blank spaces - 014") {
    
     val id = Array("014")
     val name = Array("Test case : Validate that Member Participation Code field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_parn_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(mbr_parn_cd, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_parn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_parn_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Participation_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_parn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(mbr_parn_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Participation_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that ITS Subscriber ID field is not NULL or contains blank spaces - 015") {
    val id = Array("015")
    val name = Array("Test case : Validate that ITS Subscriber ID field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, its_sbscrbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(its_sbscrbr_id, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, its_sbscrbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(its_sbscrbr_id, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','ITS_Subscriber_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, its_sbscrbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(its_sbscrbr_id, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','ITS_Subscriber_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that Demographic Member Confidentiality Code field is not NULL or contains blank spaces - 016") {
    val id = Array("016")
    val name = Array("Test case : Validate that Demographic Member Confidentiality Code field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, dmgrphc_mbr_cnfdntlty_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(dmgrphc_mbr_cnfdntlty_cd, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, dmgrphc_mbr_cnfdntlty_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(dmgrphc_mbr_cnfdntlty_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Confidentiality_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, dmgrphc_mbr_cnfdntlty_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(dmgrphc_mbr_cnfdntlty_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Confidentiality_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that OOA Member Code field is not NULL or contains blank spaces - 017") {
    val id = Array("017")
    val name = Array("Test case : Validate that OOA Member Code field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, ooa_mbr_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(regexp_replace(coalesce(ooa_mbr_cd, "")," ", "")))=0  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, ooa_mbr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(ooa_mbr_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','OOA_Member_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, ooa_mbr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(regexp_replace(coalesce(ooa_mbr_cd, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','OOA_Member_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================
   
   test("MemberDemoExtract -Validate that  BHI Home Plan ID does not contain Special Characters - 018") {
    val id = Array("018")
    val name = Array("Test case : Validate that  BHI Home Plan ID does not contain Special Characters")
        
    val result = sqlContext.sql("""select bhi_home_plan_id,cnsstnt_mbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.bhi_home_plan_id  RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.bhi_home_plan_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.bhi_home_plan_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
    
  //===========================================
  
    test("MemberDemoExtract -Validate that Consistent Member ID does not contain Special Characters - 019") {
    val id = Array("019")
    val name = Array("Test case : Validate that Consistent Member ID does not contain Special Characters")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,cnsstnt_mbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.cnsstnt_mbr_id  RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.cnsstnt_mbr_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.cnsstnt_mbr_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

    }
  
    
  //===========================================
  
   test("MemberDemoExtract -Validate that Member Prefix does not contain Double Quote Character - 020") {
    val id = Array("020")
    val name = Array("Test case : Validate that Member Prefix does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prfx_txt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_prfx_txt   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prfx_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prfx_txt   RLIKE '%<double quote>%' ")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Prefix'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prfx_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prfx_txt   RLIKE '%<double quote>%' ")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Prefix' : No Invalid Values Found")
      
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Last Name does not contain Double Quote Character - 021") {
    val id = Array("021")
    val name = Array("Test case : Validate that Member Last Name does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_last_nm  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_last_nm  RLIKE "%[^A-z0-9']%" """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id,mbr_last_nm  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_last_nm  RLIKE '%[^A-z0-9']%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Last_Name'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id,mbr_last_nm  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_last_nm  RLIKE '%[^A-z0-9']%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Last_Name' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member First Name does not contain Double Quote Character - 022") {
    val id = Array("022")
    val name = Array("Test case : Validate that Member First Name does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_frst_nm  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_frst_nm   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_frst_nm  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_frst_nm   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_First_Name'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_frst_nm  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_frst_nm   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_First_Name' : No Invalid Values Found")
            
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Middle Initial does not contain Double Quote Character - 023") {
    val id = Array("023")
    val name = Array("Test case : Validate that Member Middle Initial does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_mid_init_nm  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_mid_init_nm   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_mid_init_nm  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_mid_init_nm   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Middle_Initial'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_mid_init_nm  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_mid_init_nm   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Middle_Initial' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Suffix does not contain Double Quote Character - 024") {
   val id = Array("024")
    val name = Array("Test case : Validate that Member Suffix does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_sfx_txt  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_sfx_txt  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_sfx_txt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_sfx_txt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Suffix'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_sfx_txt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_sfx_txt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Suffix' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary Street Address1 does not contain Double Quote Character - 025") {
    val id = Array("025")
    val name = Array("Test case : Validate that Member Primary Street Address1 does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_str_adrs_1_txt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_prmry_str_adrs_1_txt RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_str_adrs_1_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_str_adrs_1_txt RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_Street_Address1'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_str_adrs_1_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_str_adrs_1_txt RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_Street_Address1' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary Street Address2 does not contain Double Quote Character - 026") {
    val id = Array("026")
    val name = Array("Test case : Validate that Member Primary Street Address2 does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_str_adrs_2_txt  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_prmry_str_adrs_2_txt  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_str_adrs_2_txt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_str_adrs_2_txt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_Street_Address2'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_prmry_str_adrs_2_txt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_str_adrs_2_txt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_Street_Address2' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary City does not contain Double Quote Character - 027") {
    val id = Array("027")
    val name = Array("Test case : Validate that Member Primary City does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_city_nm from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_prmry_city_nm   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_city_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_city_nm   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_City'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_city_nm from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_city_nm   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_City' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary State does not contain Double Quote Character - 028") {
    val id = Array("028")
    val name = Array("Test case : Validate that Member Primary State does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_st_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_prmry_st_cd   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_st_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_st_cd   RLIKE '%<double quote>%' ")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_State'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_st_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_st_cd   RLIKE '%<double quote>%' ")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_State' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary Zip Code does not contain Double Quote Character - 029") {
    val id = Array("029")
    val name = Array("Test case : Validate that Member Primary Zip Code does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_zip_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_prmry_zip_cd   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_zip_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_zip_cd   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_Zip_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_zip_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_zip_cd   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_Zip_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary Zip Code + 4 does not contain Double Quote Character - 030") {
    val id = Array("030")
    val name = Array("Test case : Validate that Member Primary Zip Code + 4 does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_zip_plus4_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_prmry_zip_plus4_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_zip_plus4_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_zip_plus4_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_Zip_Code4'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_zip_plus4_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_zip_plus4_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_Zip_Code4' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary Phone Number does not contain Double Quote Character - 031") {
    val id = Array("031")
    val name = Array("Test case : Validate that Member Primary Phone Number does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_phone_nbr  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_prmry_phone_nbr  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_phone_nbr  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_phone_nbr  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_Phone_Number'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_phone_nbr  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_phone_nbr  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_Phone_Number' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Primary Email Address does not contain Double Quote Character - 032") {
    val id = Array("032")
    val name = Array("Test case : Validate that Member Primary Email Address does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_email_adrs_txt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_prmry_email_adrs_txt   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_email_adrs_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_email_adrs_txt   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_Email_Address'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id,mbr_prmry_email_adrs_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_prmry_email_adrs_txt   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Primary_Email_Address' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Secondary Street Address 1 does not contain Double Quote Character - 033") {
    val id = Array("033")
    val name = Array("Test case : Validate that Member Secondary Street Address 1 does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_str_adrs_1_txt  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_scndry_str_adrs_1_txt  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_str_adrs_1_txt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_scndry_str_adrs_1_txt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Secondary_Street_Address1'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_str_adrs_1_txt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_scndry_str_adrs_1_txt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Secondary_Street_Address1' : No Invalid Values Found")
     
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Secondary Street Address 2 does not contain Double Quote Character - 034") {
    val id = Array("034")
    val name = Array("Test case : Validate that Member Secondary Street Address 2 does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_str_adrs_2_txt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_scndry_str_adrs_2_txt  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_str_adrs_2_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_scndry_str_adrs_2_txt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Secondary_Street_Address2'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_str_adrs_2_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_scndry_str_adrs_2_txt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Secondary_Street_Address2' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
    test("MemberDemoExtract -Validate that Member Secondary City does not contain Double Quote Character - 035") {
    val id = Array("035")
    val name = Array("Test case : Validate that Member Secondary City does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_city_nm  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_scndry_city_nm  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_city_nm  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_scndry_city_nm  RLIKE '%<double quote>%' ")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Secondary_City'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_city_nm  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_scndry_city_nm  RLIKE '%<double quote>%' ")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Secondary_City' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    }
   
  //===========================================
    
   test("MemberDemoExtract -Validate that Member Secondary State does not contain Double Quote Character - 036") {
    val id = Array("036")
    val name = Array("Test case : Validate that Member Secondary State does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_st_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_scndry_st_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_st_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_scndry_st_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Secondary_State'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_st_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_scndry_st_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Secondary_State' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Secondary Zip Code does not contain Double Quote Character - 037") {
    val id = Array("037")
    val name = Array("Test case : Validate that Member Secondary Zip Code does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_zip_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_scndry_zip_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_zip_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_scndry_zip_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Secondary_Zip_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_zip_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_scndry_zip_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Secondary_Zip_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Secondary Zip Code + 4 does not contain Double Quote Character - 038") {
    val id = Array("038")
    val name = Array("Test case : Validate that Member Secondary Zip Code + 4 does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_zip_plus4_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_scndry_zip_plus4_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_zip_plus4_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_scndry_zip_plus4_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Secondary_Zip_Code4'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_scndry_zip_plus4_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_scndry_zip_plus4_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Secondary_Zip_Code4' : No Invalid Values Found")
          
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Host Plan Override does not contain Double Quote Character - 039") {
    val id = Array("039")
    val name = Array("Test case : Validate that Host Plan Override does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,host_plan_ovrd_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.host_plan_ovrd_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,host_plan_ovrd_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.host_plan_ovrd_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Host_Plan_Override'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,host_plan_ovrd_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.host_plan_ovrd_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Host_Plan_Override' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Member Participation Code does not contain Double Quote Character - 040") {
    val id = Array("040")
    val name = Array("Test case : Validate that Member Participation Code does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_parn_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mbr_parn_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_parn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_parn_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Participation_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mbr_parn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mbr_parn_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Member_Participation_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that ITS Subscriber ID does not contain Double Quote Character - 041") {
    val id = Array("041")
    val name = Array("Test case : Validate that ITS Subscriber ID does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,its_sbscrbr_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.its_sbscrbr_id  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,its_sbscrbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.its_sbscrbr_id  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','ITS_Subscriber_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,its_sbscrbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.its_sbscrbr_id  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','ITS_Subscriber_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that MMI Identifier does not contain Double Quote Character - 042") {
    val id = Array("042")
    val name = Array("Test case : Validate that MMI Identifier does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,mmi_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.mmi_id  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mmi_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mmi_id  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','MMI_Identifier'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,mmi_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.mmi_id  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','MMI_Identifier' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Host Plan Code does not contain Double Quote Character - 043") {
    val id = Array("043")
    val name = Array("Test case : Validate that Host Plan Code does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,host_plan_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.host_plan_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,host_plan_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.host_plan_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Host_Plan_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,host_plan_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.host_plan_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Host_Plan_Code' : No Invalid Values Found")      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Demographic Void Indicator does not contain Double Quote Character - 044") {
    val id = Array("044")
    val name = Array("Test case : Validate that Demographic Void Indicator does not contain Double Quote Character")
    
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,dmgrphc_void_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.dmgrphc_void_ind  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,dmgrphc_void_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.dmgrphc_void_ind  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Demographic_Void_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,dmgrphc_void_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.dmgrphc_void_ind  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Demographic_Void_Indicator : No Invalid Values Found'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Demographic Member Confidentiality Code does not contain Double Quote Character - 045") {
    val id = Array("045")
    val name = Array("Test case : Validate that Demographic Member Confidentiality Code does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,cnsstnt_mbr_id,dmgrphc_mbr_cnfdntlty_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.dmgrphc_mbr_cnfdntlty_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id,dmgrphc_mbr_cnfdntlty_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.dmgrphc_mbr_cnfdntlty_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Confidentiality_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id,dmgrphc_mbr_cnfdntlty_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.dmgrphc_mbr_cnfdntlty_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Confidentiality_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Effective Date does not contain Double Quote Character - 046") {
    val id = Array("046")
    val name = Array("Test case : Validate that Effective Date does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,efctv_dt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.efctv_dt  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,efctv_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.efctv_dt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Effective_Date'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,efctv_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.efctv_dt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Effective_Date' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Expiration Date does not contain Double Quote Character - 047") {
    val id = Array("047")
    val name = Array("Test case : Validate that Expiration Date does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,exprtn_dt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.exprtn_dt  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,exprtn_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.exprtn_dt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Expiration_Date'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,exprtn_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.exprtn_dt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Expiration_Date' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract -Validate that Out-of-Area (OOA) Member Code does not contain Double Quote Character - 048") {
    val id = Array("048")
    val name = Array("Test case : Validate that Out-of-Area (OOA) Member Code does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,cnsstnt_mbr_id,ooa_mbr_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a
      where a.ooa_mbr_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,ooa_mbr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.ooa_mbr_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Out-of-Area Member Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id,ooa_mbr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc a where a.ooa_mbr_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_MBR_ID','Out-of-Area Member Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
  //===========================================
   
    test("MemberDemoExtract - Check BHI Home Plan ID column values not located in reference table - 049") {

    val id = Array("049")
    val name = Array("Test case : Check BHI Home Plan ID column values not located in reference table")
    
    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result2 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 and bhi_home_plan_id not in (select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
      val data = Array("BHI_Home_Plan_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 and bhi_home_plan_id not in (select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
      val data = Array("BHI_Home_Plan_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
    }
   
  //===========================================
    
    test("MemberDemoExtract -Validate One record for each BHI Home Plan ID and Consistent MBR ID- 050") {
    
    val id = Array("050")
    val name = Array("Test case : Validate One record for each BHI Home Plan ID and Consistent MBR ID")
    
    val result = sqlContext.sql("""select bhi_home_plan_id, cnsstnt_mbr_id,efctv_dt,exprtn_dt,dmgrphc_void_ind, count(*) as count from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc group by bhi_home_plan_id, cnsstnt_mbr_id,efctv_dt,exprtn_dt,dmgrphc_void_ind""")
    result.createOrReplaceTempView("resultDF")
    
    val invalid = sqlContext.sql("""select * from resultDF where count > 1 """)
    
    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id, cnsstnt_mbr_id,efctv_dt,exprtn_dt,dmgrphc_void_ind, count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc group by bhi_home_plan_id, cnsstnt_mbr_id) where count > 1 ")
      val data = Array("'BHI HPID','Consistent_MBR_ID','efctv_dt','exprtn_dt','dmgrphc_void_ind','COUNT'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, cnsstnt_mbr_id,efctv_dt,exprtn_dt,dmgrphc_void_ind, count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc group by bhi_home_plan_id, cnsstnt_mbr_id")
      val data = Array("'BHI HPID','Consistent_MBR_ID','efctv_dt','exprtn_dt','dmgrphc_void_ind','COUNT'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

    }

  //===========================================
  
    
   test("MemberDemoExtract - Check BHI Home Plan ID + Consistent Member Id column values not located in Member table - 051") {

    val id = Array("051")
    val name = Array("Test case : Check BHI Home Plan ID + Consistent Member Id column values not located in Member table")
    
    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(cnsstnt_mbr_id ))) as CONCAT_SRC from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(cnsstnt_mbr_id ))) as CONCAT_TGT from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(cnsstnt_mbr_id ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(cnsstnt_mbr_id ))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'Home_Plan_Id + Consistent_MBR_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(cnsstnt_mbr_id ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(cnsstnt_mbr_id ))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'Home_Plan_Id + Consistent_MBR_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract - Check Member Primary State column values not located in reference table - 052") {

    val id = Array("052")
    val name = Array("Test case : Check Member Primary State column values not located in reference table")
    
    //val result1 = sqlContext.sql(""" select distinct cntry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd """)

    //val result2 = sqlContext.sql("""select distinct mbr_prmry_st_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  """)

    //val result = result2.except(result1)
    
    val result = sqlContext.sql("""select mbr.mbr_prmry_st_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC MBR 
      left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_prmry_st_cd)=trim(REF.ST_CD) 
        where MBR.mbr_prmry_st_cd is not NULL and MBR.mbr_prmry_zip_cd <> "00000" and REF.ST_CD is NULL """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select mbr.mbr_prmry_st_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC MBR left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_prmry_st_cd)=trim(REF.ST_CD) where MBR.mbr_prmry_st_cd is not NULL and MBR.mbr_prmry_zip_cd <> '00000' and REF.ST_CD is NULL ")
      val data = Array("'Member_Primary_StateCode' : No Invalid Values Found")
       
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select mbr.mbr_prmry_st_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC MBR left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_prmry_st_cd)=trim(REF.ST_CD) where MBR.mbr_prmry_st_cd is not NULL and MBR.mbr_prmry_zip_cd <> '00000' and REF.ST_CD is NULL ")
      val data = Array("'Invalid Member_Primary_StateCode'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract - Check Member Primary Zip Code column values not located in reference table - 053") {

    val id = Array("053")
    val name = Array("Test case : Check Member Primary Zip Code column values not located in reference table")
    
   // val result1 = sqlContext.sql(""" select distinct zip_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd """)

    //val result2 = sqlContext.sql("""select distinct mbr_prmry_zip_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  """)

    //val result = result2.except(result1)
    
    val result = sqlContext.sql("""select MBR.bhi_home_plan_id, count(*) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC MBR 
      left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_prmry_zip_cd)=trim(REF.ZIP_CD) 
        where mbr_prmry_zip_cd <> "99999" and length(trim(regexp_replace(mbr_prmry_zip_cd," ", "")))<>0 and REF.ZIP_CD is null 
        group by MBR.bhi_home_plan_id""")
        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS ")
      val query = Array("Test Query : select MBR.bhi_home_plan_id, count(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC MBR left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_prmry_zip_cd)=trim(REF.ZIP_CD) where mbr_prmry_zip_cd <> '99'")
      val data = Array("'BHI HomePlan ID','Count' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select MBR.bhi_home_plan_id, count(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC MBR left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_prmry_zip_cd)=trim(REF.ZIP_CD) where mbr_prmry_zip_cd <> '99'")
      val data = Array("'BHI HomePlan ID','Count' : Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract - Check column Member Secondary State values not located in reference table - 054") {

    val id = Array("054")
    val name = Array("Test case : Check column Member Secondary State values not located in reference table")
    
    //val result1 = sqlContext.sql(""" select distinct cntry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd """)

    //val result2 = sqlContext.sql("""select distinct mbr_scndry_st_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  """)

    //val result = result2.except(result1)
    
    val result = sqlContext.sql("""select mbr.mbr_scndry_st_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC MBR 
      left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_scndry_st_cd)=trim(REF.ST_CD) 
        where MBR.mbr_scndry_st_cd is not NULL and MBR.mbr_scndry_st_cd <> "00000" and REF.ST_CD is NULL""")
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select mbr.mbr_scndry_st_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC MBR left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_scndry_st_cd)=trim(REF.ST_CD) where MBR.mbr_scndry_st_cd is not NULL and MBR.mbr_scndry_st_cd <> '00000' and REF.ST_CD is NULL")
      val data = Array("'Member_Secondary_StateCode' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select mbr.mbr_scndry_st_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC MBR left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_scndry_st_cd)=trim(REF.ST_CD) where MBR.mbr_scndry_st_cd is not NULL and MBR.mbr_scndry_st_cd <> '00000' and REF.ST_CD is NULL")
      val data = Array("'Invalid Member_Secondary_StateCode'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract - Check Member Secondary ZipCode column values not located in reference table - 055") {

    val id = Array("055")
    val name = Array("Test case : Check Member Secondary ZipCode column values not located in reference table")
    
    //val result1 = sqlContext.sql(""" select distinct zip_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd """)

    //val result2 = sqlContext.sql("""select distinct mbr_scndry_zip_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  """)

    //val result = result2.except(result1)
    
    val result = sqlContext.sql("""select MBR.bhi_home_plan_id, count(*) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC MBR 
      left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_scndry_zip_cd)=trim(REF.ZIP_CD) 
        where mbr_scndry_zip_cd <> "99999" and length(trim(regexp_replace(mbr_scndry_zip_cd," ", "")))<>0 and REF.ZIP_CD is null 
        group by MBR.bhi_home_plan_id""")
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select MBR.bhi_home_plan_id, count(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC MBR  left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_scndry_zip_cd)=trim(REF.ZIP_CD)  where mbr_scndry_zip_cd <> '99999' and length(trim(regexp_replace(mbr_scndry_zip_cd,' ', '')))<>0 and REF.ZIP_CD is null  group by MBR.bhi_home_plan_id")
      val data = Array("'BHI HomePlan ID', 'Count' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select MBR.bhi_home_plan_id, count(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC MBR  left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_scndry_zip_cd)=trim(REF.ZIP_CD)  where mbr_scndry_zip_cd <> '99999' and length(trim(regexp_replace(mbr_scndry_zip_cd,' ', '')))<>0 and REF.ZIP_CD is null  group by MBR.bhi_home_plan_id")
      val data = Array("'BHI HomePlan ID', 'Count' : Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract - Check Member Participation Code column has Valid Values - 056") {

    val id = Array("056")
    val name = Array("Test case : Check Member Participation Code column has Valid Values ")
    
    val result = sqlContext.sql("""select distinct mbr_parn_cd, bhi_home_plan_id ,cnsstnt_mbr_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where mbr_parn_cd NOT IN ('Y','N','A','D','I')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mbr_parn_cd, bhi_home_plan_id ,cnsstnt_mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where mbr_parn_cd NOT IN ('Y','N','A','D','I') ")
      val data = Array("'Member_Participation_Code','BHI_HomePlan_ID','Consistent_MBR_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mbr_parn_cd, bhi_home_plan_id ,cnsstnt_mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where mbr_parn_cd NOT IN ('Y','N','A','D','I') ")
      val data = Array("'Invalid Member_Participation_Code','BHI_HomePlan_ID','Consistent_MBR_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
   }
   
  //===========================================
   
   test("MemberDemoExtract - Check ITS Subscriber ID column has First 3bytes as Alphabets - 057") {

    val id = Array("057")
    val name = Array("Test case : Check ITS Subscriber ID column has First 3bytes as Alphabets")
    
    val result = sqlContext.sql("""select bhi_home_plan_id ,cnsstnt_mbr_id ,its_sbscrbr_id ,substring(its_sbscrbr_id,0,3) as 3bytes_ITS_Subsciber_ID from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  """)
    result.createOrReplaceTempView("resultDF")
   
    val invalid = sqlContext.sql(""" select * from resultDF where 3bytes_ITS_Subsciber_ID RLIKE '%[^A-z]%' """)
    
    if (invalid.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from (select bhi_home_plan_id ,cnsstnt_mbr_id ,its_sbscrbr_id ,substring(its_sbscrbr_id,0,3) as 3bytes_ITS_Subsciber_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 ) where 3bytes_ITS_Subsciber_ID RLIKE '%[^A-z]%'")
      val data = Array("'BHI_HomePlan_ID','Consistent_MBR_ID','Invalid ITS_Subscriber_ID','First_3bytes' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id ,cnsstnt_mbr_id ,its_sbscrbr_id ,substring(its_sbscrbr_id,0,3) as 3bytes_ITS_Subsciber_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 ) where 3bytes_ITS_Subsciber_ID RLIKE '%[^A-z]%'")
      val data = Array("'BHI_HomePlan_ID','Consistent_MBR_ID','Invalid ITS_Subscriber_ID','First_3bytes'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
   
   test("MemberDemoExtract - Check Demographic Void Indicator column has Valid Values - 058") {

    val id = Array("058")
    val name = Array("Test case : Check Demographic Void Indicator column has Valid Values")
    
    val result = sqlContext.sql("""select distinct dmgrphc_void_ind , bhi_home_plan_id ,cnsstnt_mbr_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where dmgrphc_void_ind NOT IN ('Y','N')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct dmgrphc_void_ind , bhi_home_plan_id ,cnsstnt_mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where dmgrphc_void_ind NOT IN ('Y','N')  ")
      val data = Array("'Demographic_Void_Indicator','BHI_HomePlan_ID','Consistent_MBR_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct dmgrphc_void_ind , bhi_home_plan_id ,cnsstnt_mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where dmgrphc_void_ind NOT IN ('Y','N')  ")
      val data = Array("'Invalid Demographic_Void_Indicator','BHI_HomePlan_ID','Consistent_MBR_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
  
    test("MemberDemoExtract - Check Demographic Member Confidentiality Code column values not located in Ref table - 059") {

    val id = Array("059")
    val name = Array("Test case : Check Demographic Member Confidentiality Code column values not located in Ref table")
    
    val result1 = sqlContext.sql(""" select distinct mbr_cnfdntlty_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_cnfdntlty_cd_inbnd """)

    val result2 = sqlContext.sql("""select distinct dmgrphc_mbr_cnfdntlty_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct dmgrphc_mbr_cnfdntlty_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 and dmgrphc_mbr_cnfdntlty_cd not in (select distinct mbr_cnfdntlty_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_cnfdntlty_cd_inbnd)")
      val data = Array("'Demographic_Member_Confidentiality_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct dmgrphc_mbr_cnfdntlty_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 and dmgrphc_mbr_cnfdntlty_cd not in (select distinct mbr_cnfdntlty_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_cnfdntlty_cd_inbnd)")
      val data = Array("'Invalid Demographic_Member_Confidentiality_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
    
    test("MemberDemoExtract - Check Expiration Date is greater than Effective Date - 060") {

   val id = Array("060")
    val name = Array("Test case : Check Expiration Date is greater than Effective Date")
    
    val result = sqlContext.sql("""select date(efctv_dt) as Effective_Date, date(exprtn_dt) as Expiration_Date, bhi_home_plan_id , cnsstnt_mbr_id   from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  """)
    result.createOrReplaceTempView("resultDF")
    
    val invalid = sqlContext.sql(""" select * from resultDF where Expiration_date < Effective_Date """)
    
    if (invalid.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from (select date(efctv_dt) as Effective_Date, date(exprtn_dt) as Expiration_Date, bhi_home_plan_id , cnsstnt_mbr_id   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0) where Expiration_date < Effective_Date ")
      val data = Array("'Effective_Date','Invalid Expiration_date','BHI_HomePlan_ID','Consistent_MBR_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select date(efctv_dt) as Effective_Date, date(exprtn_dt) as Expiration_Date, bhi_home_plan_id , cnsstnt_mbr_id   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0) where Expiration_date < Effective_Date ")
      val data = Array("'Effective_Date','Invalid Expiration_date','BHI_HomePlan_ID','Consistent_MBR_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
  
   test("MemberDemoExtract - Check Out-of-Area (OOA) Member Code column values not located in Ref table - 061") {

    val id = Array("061")
    val name = Array("Test case : Check Out-of-Area (OOA) Member Code column values not located in Ref table")
    
    val result1 = sqlContext.sql(""" select distinct mbr_ooa_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_ooa_cd_inbnd """)

    val result2 = sqlContext.sql("""select distinct ooa_mbr_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct ooa_mbr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 and ooa_mbr_cd not in (select distinct mbr_ooa_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_ooa_cd_inbnd)")
      val data = Array("'OOA_Member_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct ooa_mbr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 and ooa_mbr_cd not in (select distinct mbr_ooa_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_ooa_cd_inbnd)")
      val data = Array("'Invalid OOA_Member_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  
  //===========================================
   
    test("MemberDemoExtract - Validate that Member Prefix column is populated  as per specified transformation logic in mapping document - 062") {

    val id = Array("062")
    val name = Array("Test case : Validate that Member Prefix column is populated  as per specified transformation logic in mapping document")
    
    val result = sqlContext.sql(""" select bhi_home_plan_id ,cnsstnt_mbr_id , mbr_prfx_txt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where trim(mbr_prfx_txt) NOT In ('Dr','MISS','Mr','Mrs','Ms','Prof','Capt','Rev','Lt','') """)

        
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id ,cnsstnt_mbr_id , mbr_prfx_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where trim(mbr_prfx_txt) NOT In ('Dr','MISS','Mr','Mrs','Ms','Prof','Capt','Rev','Lt','')")
      val data = Array("'Home_Plan_ID','Consistent_MBR_ID','Member_Prefix' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id ,cnsstnt_mbr_id , mbr_prfx_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where trim(mbr_prfx_txt) NOT In ('Dr','MISS','Mr','Mrs','Ms','Prof','Capt','Rev','Lt','')")
      val data = Array("'Home_Plan_ID','Consistent_MBR_ID','Member_Prefix'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
    
   test("MemberDemoExtract - Validate that Member Suffix column is populated  as per specified transformation logic in mapping document - 063") {

    val id = Array("063")
    val name = Array("Test case : Validate that Member Suffix column is populated  as per specified transformation logic in mapping document")
    
    val result = sqlContext.sql(""" select bhi_home_plan_id ,cnsstnt_mbr_id , mbr_sfx_txt  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where trim(mbr_sfx_txt)  NOT In ('I','II','III','IV','V','VI','VII','VIII','IX','X','Jr','Sr','MD','MBA','PhD','MA','DC','DO','JD','') """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id ,cnsstnt_mbr_id , mbr_sfx_txt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where trim(mbr_sfx_txt)  NOT In ('I','II','III','IV','V','VI','VII','VIII','IX','X','Jr','Sr','MD','MBA','PhD','MA','DC','DO','JD','')")
      val data = Array("'Home_Plan_ID','Consistent_MBR_ID','Member_Suffix' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id ,cnsstnt_mbr_id , mbr_sfx_txt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where trim(mbr_sfx_txt)  NOT In ('I','II','III','IV','V','VI','VII','VIII','IX','X','Jr','Sr','MD','MBA','PhD','MA','DC','DO','JD','')")
      val data = Array("'Home_Plan_ID','Consistent_MBR_ID','Member_Suffix'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
     
   test("MemberDemoExtract - Validate that Member Primary Email Address column is populated  as per specified transformation logic in mapping document - 064") {

    val id = Array("064")
    val name = Array("Test case : Validate that Member Primary Email Address column is populated  as per specified transformation logic in mapping document")
    
    val result = sqlContext.sql("""select bhi_home_plan_id ,cnsstnt_mbr_id ,mbr_prmry_email_adrs_txt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where mbr_prmry_email_adrs_txt RLIKE '%[^A-z0-9_.@]%' """)

   
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id ,cnsstnt_mbr_id ,mbr_prmry_email_adrs_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where mbr_prmry_email_adrs_txt RLIKE '%[^A-z0-9_.@]%'")
      val data = Array("'Home_Plan_ID','Consistent_MBR_ID','Member_Primary_EmailID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id ,cnsstnt_mbr_id ,mbr_prmry_email_adrs_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where mbr_prmry_email_adrs_txt RLIKE '%[^A-z0-9_.@]%'")
      val data = Array("'Home_Plan_ID','Consistent_MBR_ID','Member_Primary_EmailID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
      
   test("MemberDemoExtract - Validate that Host Plan Override column values not located in Reference Table  - 065") {

    val id = Array("065")
    val name = Array("Test case : Validate that Host Plan Override column values not located in Reference Table")
    
    val result1 = sqlContext.sql(""" select distinct hplan_ovrd_ndwplan_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.bcbsa_hplan_atrbn_ovrd  """)

    val result2 = sqlContext.sql("""select distinct host_plan_ovrd_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 and trim(host_plan_ovrd_cd) != ''  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct host_plan_ovrd_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 and trim(host_plan_ovrd_cd) != '' and host_plan_ovrd_cd not in (select distinct hplan_ovrd_ndwplan_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.bcbsa_hplan_atrbn_ovrd)")
      val data = Array("'Host_Plan_Override_Code ' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct host_plan_ovrd_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 and trim(host_plan_ovrd_cd) != '' and host_plan_ovrd_cd not in (select distinct hplan_ovrd_ndwplan_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.bcbsa_hplan_atrbn_ovrd)")
      val data = Array("'Invalid Host_Plan_Override_Code '")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
   
    test("MemberDemoExtract - Validate that Out-of-Area (OOA) Member Code column is populated  as per specified field format  - 066") {

    val id = Array("066")
    val name = Array("Test case : Validate that Out-of-Area (OOA) Member Code column is populated  as per specified field format")
    
    val result = sqlContext.sql("""select bhi_home_plan_id ,cnsstnt_mbr_id , ooa_mbr_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where ooa_mbr_cd NOT IN ('01','02') """)

     if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id ,cnsstnt_mbr_id , ooa_mbr_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where ooa_mbr_cd NOT IN ('01','02')")
      val data = Array("'Home_Plan_ID','Consistent_MBR_ID','OOA_Member_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id ,cnsstnt_mbr_id , ooa_mbr_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where ooa_mbr_cd NOT IN ('01','02')")
      val data = Array("'Home_Plan_ID','Consistent_MBR_ID','OOA_Member_Code")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
    
    test("MemberDemoExtract - Validate that phone number is not '0' or the length is <10  - 067") {

    val id = Array("067")
    val name = Array("Test case : Validate that phone number is not '0' or the length is <10")
    
    val result = sqlContext.sql(""" select mbr_prmry_phone_nbr,bhi_home_plan_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc 
      where mbr_prmry_phone_nbr ="0" or length(trim(mbr_prmry_phone_nbr))<10 """) 

     if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select mbr_prmry_phone_nbr,bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where mbr_prmry_phone_nbr ='0' or length(trim(mbr_prmry_phone_nbr))<10")
      val data = Array("'mbr_prmry_phone_nbr','bhi_home_plan_id' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select mbr_prmry_phone_nbr,bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where mbr_prmry_phone_nbr ='0' or length(trim(mbr_prmry_phone_nbr))<10")
      val data = Array("'mbr_prmry_phone_nbr','bhi_home_plan_id' : Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
    
    test("MemberDemoExtract - Out-of-Area (OOA) Member Code validation  - 068") {

    val id = Array("068")
    val name = Array("Test case : Out-of-Area (OOA) Member Code validation")
    
    val result1 = sqlContext.sql(""" select  bhi_home_plan_id,cnsstnt_mbr_id ,mbr_prmry_zip_cd,dmg.ooa_mbr_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc dmg inner join 
"""+dbname+"""_pcandw1ph_nogbd_r000_in.bot_bcbsa_host_plan_srvcarea_inbnd host on trim(dmg.mbr_prmry_zip_cd)=trim(host.zip_cd) where host.ath_wlp_ind_cd='N' 
and dmg.ooa_mbr_cd  <> '01' """) 
    
    val result2 = sqlContext.sql("""  select  bhi_home_plan_id,cnsstnt_mbr_id ,mbr_prmry_zip_cd,dmg.ooa_mbr_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc dmg 
where dmg.ooa_mbr_cd not in ('01','02') """)

    val result3 = sqlContext.sql(""" select  bhi_home_plan_id,cnsstnt_mbr_id ,mbr_prmry_zip_cd,dmg.ooa_mbr_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc dmg left outer join 
"""+dbname+"""_pcandw1ph_nogbd_r000_in.bot_bcbsa_host_plan_srvcarea_inbnd host on trim(dmg.mbr_prmry_zip_cd)=trim(host.zip_cd) where host.ath_wlp_ind_cd is NULL and 
dmg.ooa_mbr_cd = '01' """)

     if (result1.count == 0 && result2.count == 0 && result3.count == 0) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val c = result3.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id ,mbr_prmry_zip_cd,dmg.ooa_mbr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc dmg inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_host_plan_srvcarea_inbnd host on trim(dmg.mbr_prmry_zip_cd)=trim(host.zip_cd) where host.ath_wlp_ind_cd='N' and dmg.ooa_mbr_cd  <> '01' ")
      val query2 = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id ,mbr_prmry_zip_cd,dmg.ooa_mbr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc dmg where dmg.ooa_mbr_cd not in ('01','02') ")
      val query3 = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id ,mbr_prmry_zip_cd,dmg.ooa_mbr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc dmg left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_host_plan_srvcarea_inbnd host on trim(dmg.mbr_prmry_zip_cd)=trim(host.zip_cd) where host.ath_wlp_ind_cd is NULL and dmg.ooa_mbr_cd = '01' ")
      val data = Array("'bhi_home_plan_id','cnsstnt_mbr_id','mbr_prmry_zip_cd','ooa_mbr_cd' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(query3,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).union(c.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val c = result3.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id ,mbr_prmry_zip_cd,dmg.ooa_mbr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc dmg inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_host_plan_srvcarea_inbnd host on trim(dmg.mbr_prmry_zip_cd)=trim(host.zip_cd) where host.ath_wlp_ind_cd='N' and dmg.ooa_mbr_cd  <> '01' ")
      val query2 = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id ,mbr_prmry_zip_cd,dmg.ooa_mbr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc dmg where dmg.ooa_mbr_cd not in ('01','02') ")
      val query3 = Array("Test Query : select  bhi_home_plan_id,cnsstnt_mbr_id ,mbr_prmry_zip_cd,dmg.ooa_mbr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc dmg left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_host_plan_srvcarea_inbnd host on trim(dmg.mbr_prmry_zip_cd)=trim(host.zip_cd) where host.ath_wlp_ind_cd is NULL and dmg.ooa_mbr_cd = '01' ")
      val data = Array("'bhi_home_plan_id','cnsstnt_mbr_id','mbr_prmry_zip_cd','ooa_mbr_cd'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(query3,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).union(c.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
    
   test("MemberDemoExtract -Validate that Member Secondary Zip Code + 4 field is not NULL or contains blank spaces - 068") {
   val id = Array("010")
    val name = Array("Test case : Validate that Member Secondary Zip Code + 4 field is not NULL or contains blank spaces")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_scndry_zip_plus4_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc
        where length(trim(mbr_scndry_zip_plus4_cd))=0 or mbr_scndry_zip_plus4_cd is NULL  """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_scndry_zip_plus4_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(mbr_scndry_zip_plus4_cd))=0 or mbr_scndry_zip_plus4_cd is NULL  ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Secondary_Zip_Code+4'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id, cnsstnt_mbr_id, mbr_scndry_zip_plus4_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc where length(trim(mbr_scndry_zip_plus4_cd))=0 or mbr_scndry_zip_plus4_cd is NULL ")
      val data = Array("'BHI HPID','Consistent_Member_ID','Member_Secondary_Zip_Code+4' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   
  //===========================================
   
   test("MemberDemoExtract - Validate that there are 14 BHI Home Plan ID  - 069") {
    
    val id = Array("069")
     val name = Array("Test case : Validate that there are 14 BHI Home Plan ID ")
     
    val result = sqlContext.sql(""" select count(distinct bhi_home_plan_id) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc """)
    
        
    if (result.collectAsList.toString.contains("14")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
   
   /*
    test("MemberDemoExtract - Validate that Consistent Member ID column is populated  as per specified field format  - 062") {

    val id = Array("062")
    val name = Array("Test case : Validate that Consistent Member ID column is populated  as per specified field format")
    
    val result1 = sqlContext.sql("""select distinct(cnsstnt_mbr_id) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp """)

    val result2 = sqlContext.sql("""select distinct(cnsstnt_mbr_id) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(cnsstnt_mbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 and distinct(cnsstnt_mbr_id) not in (select distinct(cnsstnt_mbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'Consitent_Member_ID ' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(cnsstnt_mbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_dmgrphc  where err_id = '0' and exclsn_ind = 0 and distinct(cnsstnt_mbr_id) not in (select distinct(cnsstnt_mbr_id) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("' Invalid Consitent_Member_ID '")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   */
  
       
}