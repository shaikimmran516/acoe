package com.anthem.hca.vbp

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
//import com.holdenkarau.spark.testing.SharedSparkContext
//import com.holdenkarau.spark.testing.RDDComparisons
//import com.holdenkarau.spark.testing.DataFrameSuiteBase
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._
import sys.process._
import java.text.SimpleDateFormat
import java.sql.Timestamp
import org.joda.time._
import org.joda.time.format.DateTimeFormat
import java.util.Calendar
import java.sql.Timestamp
import java.text.SimpleDateFormat
import org.apache.spark.sql.DataFrame
import org.scalatest.exceptions.TestFailedException
import org.scalacheck.Prop
import org.scalacheck.Prop._
import org.scalatest.prop.Checkers
import org.scalacheck.Arbitrary._
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path

object PCADX_SCL_TA_EXTRACT_NCF_SSAV_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_EXTRACT_NCF_SSAV_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_EXTRACT_NCF_SSAV_TGT(dbname: String, env: String) extends FunSuite {

  val now = Calendar.getInstance().getTime()
  val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
  val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
  val currdate = formatter.format(new Date())
  val currdate1 = formatter1.format(new Date())

  val warehouseLocation = new File("/user/hive/warehouse").getAbsolutePath

  val sc = SparkContext.getOrCreate()
  sc.setLogLevel("ERROR")

  val spark = SparkSession.builder().appName("Automation test cases for VBP NCF Care Catchup")
    .config("spark.sql.warehouse.dir", warehouseLocation)
    .config("hive.exec.dynamic.partition", "true")
    .config("hive.exec.dynamic.partition.mode", "nonstrict")
    .config("spark.sql.parquet.compression.codec", "snappy")
    .config("hive.warehouse.data.skipTrash", "true")
    .config("spark.sql.parquet.writeLegacyFormat", "true")
    .enableHiveSupport().getOrCreate()

  spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode", "INFER_ONLY")
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  spark.conf.set("spark.sql.shuffle.partitons", 2010)

  import spark.implicits._
  import spark.sql

  val subj = "Extract"
  val prcss = "NCF_SSAV"

  val llk = spark.sql(f"""select distinct(load_log_key),load_dt from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn order by load_dt desc limit 1""")

  var df1 = llk.select($"load_log_key").rdd.first()(0)

  val sday = Calendar.getInstance()
  val startday = sday.get(Calendar.YEAR) + "-" + "%02d".format(sday.get(Calendar.MONTH).+(1)) + "-" + sday.getActualMinimum(Calendar.DATE)
  val endday = sday.get(Calendar.YEAR) + "-" + "%02d".format(sday.get(Calendar.MONTH).+(1)) + "-" + sday.getActualMaximum(Calendar.DATE)

  val RUNEND = endday.toString
  val RUNSTART = startday.toString()

  val sdf = new SimpleDateFormat("yyyy-MM-dd");
  val calendar = Calendar.getInstance()
  calendar.add(Calendar.YEAR, -1)
  calendar.set(Calendar.MONTH, 0)
  calendar.set(Calendar.DATE, 1)
  val ACT_INC_STR_DT = sdf.format(calendar.getTime())

  val edf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  calendar.add(Calendar.YEAR, 0)
  calendar.set(Calendar.MONTH, 11)
  calendar.set(Calendar.DATE, 31)
  calendar.set(Calendar.SECOND, 1)

  val ACT_INC_END_DT = edf.format(calendar.getTime())

  var startdateFnl = ""
  var enddateFnl = ""

  // we dont have to get the dates from AIX table. Instead we can get the last day of the running month in the sql using built in functions - not required for test cycle 3
  val ACTDatesSql1 = sql(f"""Select  strt_dtm,end_dtm  FROM ${dbname}_pcandw1ph_nogbd_r000_wh.BOT_BCBSA_EXTRCT_PRCSG WHERE subj_area_nm = "VBP_BCBSA_NON_CLM_FIN_SSAV"""")
  if (!ACTDatesSql1.head(1).isEmpty) {
    val actdates = ACTDatesSql1.rdd.map(x => (x.getTimestamp(0), x.getTimestamp(1)))
    val list: List[(Timestamp, Timestamp)] = actdates.collect().toList
    val startdate: List[Timestamp] = list.map(_._1)
    val enddate: List[Timestamp] = list.map(_._2)
    startdateFnl = startdate(0).toString().substring(0, 10)
    enddateFnl = enddate(0).toString().substring(0, 10)
  } else {
    startdateFnl = ACT_INC_STR_DT
    enddateFnl = ACT_INC_END_DT
  }
  
  //-------------------------------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate that MMI Identifier is not NULL - 001") {

    val id = Array("001")

    val name = Array("Validate that MMI Identifier is not NULL - 001")
    val src = (f"""select distinct cnsstnt_mbr_id,pe_id,mmi_id from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id is NULL""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate that Consistent Member ID is not NULL or contains blank spaces - 002") {

    val id = Array("002")
    val name = Array("Validate that Consistent Member ID is not NULL or contains blank spaces - 002")

    val result = spark.sql(s""" select distinct(b.cnsstnt_mbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b where length(trim(regexp_replace(cnsstnt_mbr_id," ",""))) = 0 or cnsstnt_mbr_id is null""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(b.cnsstnt_mbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b where length(trim(regexp_replace(cnsstnt_mbr_id,' ',''))) = 0 or cnsstnt_mbr_id is null")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(b.cnsstnt_mbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b where length(trim(regexp_replace(cnsstnt_mbr_id,' ',''))) = 0 or cnsstnt_mbr_id is null")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate that ITS Subscriber ID is not NULL or contains blank spaces - 003") {

    val id = Array("003")

    val name = Array("LCLAtrbn - Validate that ITS Subscriber ID is not NULL or contains blank spaces - 003")

    val result = spark.sql(s""" select distinct(its_sbscrbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where length(trim(regexp_replace(its_sbscrbr_id," ", "")))=0 or its_sbscrbr_id is null""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(its_sbscrbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where length(trim(regexp_replace(its_sbscrbr_id,' ', '')))=0 or its_sbscrbr_id is null")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(its_sbscrbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where length(trim(regexp_replace(its_sbscrbr_id,' ', '')))=0 or its_sbscrbr_id is null")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate for Home Plan Member ID is not NULL or contains blank spaces - 004") {

    val id = Array("004")

    val name = Array("Validate that Home Plan Member ID - 004 is not NULL or contains blank spaces")

    val result = spark.sql(s""" select distinct(b.mbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b where length(trim(regexp_replace(mbr_id," ",""))) = 0 or mbr_id is null""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(b.mbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b where length(trim(regexp_replace(mbr_id,' ',''))) = 0 or mbr_id is null")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(b.mbr_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b where length(trim(regexp_replace(mbr_id,' ',''))) = 0 or mbr_id is null")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate the NDW Home Plan ID - 005") {

    val id = Array("005")

    val name = Array("Validate the NDW Home Plan ID - 005")
    val src = (f"""select cnsstnt_mbr_id,pe_id,e.bhi_home_plan_id,'HOME' as member_type 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav e where mmi_id = '' and 
      e.bhi_home_plan_id not in (select distinct(x.bhi_home_plan_id) 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp_xwalk x) union all 
      select cnsstnt_mbr_id,pe_id,e.bhi_home_plan_id,'HOST' as member_type 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav e where trim(mmi_id) <> '' and 
      e.bhi_home_plan_id not in (select distinct(x.NDW_PLAN_CD) 
      from ${dbname}_pcandw1ph_nogbd_r000_in.BCBSA_MBR_PROD x)""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate the NDW Host Plan ID - 006") {

    val id = Array("006")

    val name = Array("Validate the NDW Host Plan ID - 006")
    val src = (f"""select cnsstnt_mbr_id,pe_id,e.bhi_host_plan_id,'HOST' as member_type 
      from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav e where trim(mmi_id) <> '' and 
      e.bhi_host_plan_id not in (select distinct(x.HOST_PLAN_CD) 
      from ${dbname}_pcandw1ph_nogbd_r000_in.BCBSA_MBR_PROD x)""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate the Payee Provider ID is not NULL or contains blank spaces - 007") {

    val id = Array("007")

    val name = Array("Validate the Payee Provider ID is not NULL or contains blank spaces - 007")
    val src = (f"""select cnsstnt_mbr_id,pe_id,payee_prov_id from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b WHERE length(trim(regexp_replace(payee_prov_id,' ',''))) = 0 or payee_prov_id is null""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate that Payee Provider First Name - 008") {

    val id = Array("008")

    val name = Array("Validate that Payee Provider First Name - 008")

    val result = spark.sql(f"""select cnsstnt_mbr_id,pe_id,b.payee_prov_frst_nm,'HOME' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist e
      ON b.payee_prov_frst_nm=e.atrbd_prov_frst_nm where mmi_id='' AND 
      trim(b.payee_prov_frst_nm)<>'' union all 
      select cnsstnt_mbr_id,pe_id,b.payee_prov_frst_nm,'HOST' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN e
      ON b.payee_prov_frst_nm=e.atrbd_prov_frst_nm where trim(mmi_id)<>'' AND 
      trim(b.payee_prov_frst_nm)<>''""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : select cnsstnt_mbr_id,pe_id,b.payee_prov_frst_nm,'HOME' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist eON b.payee_prov_frst_nm=e.atrbd_prov_frst_nm where mmi_id='' AND trim(b.payee_prov_frst_nm)<>'' union all select cnsstnt_mbr_id,pe_id,b.payee_prov_frst_nm,'HOST' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN eON b.payee_prov_frst_nm=e.atrbd_prov_frst_nm where trim(mmi_id)<>'' AND trim(b.payee_prov_frst_nm)<>''")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : select cnsstnt_mbr_id,pe_id,b.payee_prov_frst_nm,'HOME' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist eON b.payee_prov_frst_nm=e.atrbd_prov_frst_nm where mmi_id='' AND trim(b.payee_prov_frst_nm)<>'' union all select cnsstnt_mbr_id,pe_id,b.payee_prov_frst_nm,'HOST' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN eON b.payee_prov_frst_nm=e.atrbd_prov_frst_nm where trim(mmi_id)<>'' AND trim(b.payee_prov_frst_nm)<>''")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate that Payee Provider Last Name  - 009") {

    val id = Array("009")

    val name = Array("Validate that Payee Provider Last Name  - 009")

  val result = spark.sql(f"""select cnsstnt_mbr_id,pe_id,b.payee_prov_last_nm,'HOME' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist e
      ON b.payee_prov_last_nm=e.atrbd_prov_last_nm where mmi_id='' AND 
      trim(b.payee_prov_last_nm)<>'' union all 
      select cnsstnt_mbr_id,pe_id,b.payee_prov_last_nm,'HOST' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN e
      ON b.payee_prov_last_nm=e.atrbd_prov_last_nm where trim(mmi_id)<>'' AND 
      trim(b.payee_prov_last_nm)<>''""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : select cnsstnt_mbr_id,pe_id,b.payee_prov_last_nm,'HOME' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist eON b.payee_prov_last_nm=e.atrbd_prov_last_nm where mmi_id='' AND trim(b.payee_prov_last_nm)<>'' union all select cnsstnt_mbr_id,pe_id,b.payee_prov_last_nm,'HOST' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN eON b.payee_prov_last_nm=e.atrbd_prov_last_nm where trim(mmi_id)<>'' AND trim(b.payee_prov_last_nm)<>''")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : select cnsstnt_mbr_id,pe_id,b.payee_prov_last_nm,'HOME' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist eON b.payee_prov_last_nm=e.atrbd_prov_last_nm where mmi_id='' AND trim(b.payee_prov_last_nm)<>'' union all select cnsstnt_mbr_id,pe_id,b.payee_prov_last_nm,'HOST' as member_type from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN eON b.payee_prov_last_nm=e.atrbd_prov_last_nm where trim(mmi_id)<>'' AND trim(b.payee_prov_last_nm)<>''")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate that Payee Provider Organization Name  - 010") {

    val id = Array("010")

    val name = Array("Validate that Payee Provider Organization Name - 010")

  val result = spark.sql(f"""select cnsstnt_mbr_id,pe_id,b.prov_org_nm from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e ON b.prov_org_nm=e.EP_ORG_NM where trim(b.prov_org_nm)<>''""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : select cnsstnt_mbr_id,pe_id,b.prov_org_nm from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e ON b.prov_org_nm=e.EP_ORG_NM where trim(b.prov_org_nm)<>''")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : select cnsstnt_mbr_id,pe_id,b.prov_org_nm from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ep_prfl e ON b.prov_org_nm=e.EP_ORG_NM where trim(b.prov_org_nm)<>''")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate that Payee Provider Street Address 1  - 011") {

    val id = Array("011")

    val name = Array("Validate that Payee Provider Street Address 1 - 011")

    val src = f"""select cnsstnt_mbr_id,pe_id,b.prov_str_adrs_1_txt,'HOME' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist e
      ON b.prov_str_adrs_1_txt=e.atrbd_prov_str_adrs_1_txt where mmi_id='' AND 
      trim(b.prov_str_adrs_1_txt)<>'' union all 
      select cnsstnt_mbr_id,pe_id,b.prov_str_adrs_1_txt,'HOST' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN e
      ON b.prov_str_adrs_1_txt=e.atrbd_prov_str_adrs_1_txt where trim(mmi_id)<>'' AND 
      trim(b.prov_str_adrs_1_txt)<>''"""

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate the Payee Provider Street Address 2  - 012") {

    val id = Array("012")

    val name = Array("Validate the Payee Provider Street Address 2 - 012")

    val src = f"""select cnsstnt_mbr_id,pe_id,b.prov_str_adrs_2_txt,'HOME' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist e
      ON b.prov_str_adrs_2_txt=e.atrbd_prov_str_adrs_2_txt where mmi_id='' AND 
      trim(b.prov_str_adrs_2_txt)<>'' union all 
      select cnsstnt_mbr_id,pe_id,b.prov_str_adrs_2_txt,'HOST' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN e
      ON b.prov_str_adrs_2_txt=e.atrbd_prov_str_adrs_2_txt where trim(mmi_id)<>'' AND 
      trim(b.prov_str_adrs_2_txt)<>''"""

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate the Payee Provider City  - 013") {

    val id = Array("013")

    val name = Array("Validate the Payee Provider City  - 013")

    val src = f"""select cnsstnt_mbr_id,pe_id,b.prov_city_nm,'HOME' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist e
      ON b.prov_city_nm=e.atrbd_prov_city_nm where mmi_id='' AND 
      trim(b.prov_city_nm)<>'' union all 
      select cnsstnt_mbr_id,pe_id,b.prov_city_nm,'HOST' as member_type from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_wh.BCBSA_VBP_HOST_ATRBN e
      ON b.prov_city_nm=e.atrbd_prov_city_nm where trim(mmi_id)<>'' AND 
      trim(b.prov_city_nm)<>''"""

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate the Payee Provider State - 014") {

    val id = Array("014")

    val name = Array("Validate the Payee Provider State  - 014")

    val src = (f"""select cnsstnt_mbr_id,pe_id,b.prov_st_cd from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.EP_ADRS e
      ON b.prov_st_cd=e.EP_ADRS_ST_PRVNC_CD where trim(b.prov_st_cd)<>''""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate the Payee Provider ZIP Code  - 015") {

    val id = Array("015")

    val name = Array("Validate the Payee Provider ZIP Code - 015")

    val src = (f"""select cnsstnt_mbr_id,pe_id,b.prov_zip_cd from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.EP_ADRS e
      ON b.prov_zip_cd=e.EP_ADRS_POSTL_CD where trim(b.prov_zip_cd)<>''""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate the Performance Cycle Begin Date is not null or spaces - 016") {

    val id = Array("016")

    val name = Array("Validate the Performance Cycle Begin Date is not null or spaces - 016")

    val src = (f"""select cnsstnt_mbr_id,pe_id,prfrmn_cycl_strt_dt from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      WHERE length(trim(regexp_replace(prfrmn_cycl_strt_dt,' ',''))) = 0 or prfrmn_cycl_strt_dt is null""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate for Performance Cycle End Date  - 017") {

    val id = Array("017")

    val name = Array("Validate for Performance Cycle End Date  - 017")

    val src = (f"""select cnsstnt_mbr_id,pe_id,prfrmn_cycl_end_dt from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      WHERE length(trim(regexp_replace(prfrmn_cycl_end_dt,' ',''))) = 0 or prfrmn_cycl_end_dt is null""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate for Value-Based Program ID - 018") {

    val id = Array("018")

    val name = Array("Validate for Value-Based Program ID - 018")

    val src = (f"""select cnsstnt_mbr_id,pe_id,b.VBP_ID from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PI_BCBSA_PGM_PG_VBP e
      ON b.VBP_ID=e.BDTC_VBP_ID""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate for Provider Entity Identifier - 019") {

    val id = Array("019")

    val name = Array("Validate for Provider Entity Identifier - 019")

    val result = spark.sql(f""" select distinct(b.pe_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PI_ATRBN_MCID e ON b.pe_id=e.PG_ID""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(b.pe_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PI_ATRBN_MCID e ON b.pe_id=e.PG_ID")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(b.pe_id) from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.PI_ATRBN_MCID e ON b.pe_id=e.PG_ID")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate for Provider Entity Name is as per the transformation logic- 020") {

    val id = Array("020")

    val name = Array("Validate for Provider Entity Name is as per the transformation logic- 020")

    val result = spark.sql(f""" select b.PE_ID,b.PE_NM from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.pg_dtl e ON b.PE_NM=e.PG_NM""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select b.PE_ID,b.PE_NM from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.pg_dtl e ON b.PE_NM=e.PG_NM")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select b.PE_ID,b.PE_NM from ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b LEFT ANTI JOIN ${dbname}_pcandw1ph_nogbd_r000_in.pg_dtl e ON b.PE_NM=e.PG_NM")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //--------------------------------------------------------------------------------------

  test("NCF_SSAV - Validate for Payment Category Type is not NULL or spaces- 021") {

    val id = Array("021")

    val name = Array("Validate for Payment Category Type is not NULL or spaces- 021")
    val src = (f"""select cnsstnt_mbr_id,pe_id,paymnt_type_cd from 
      ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav b 
      WHERE length(trim(regexp_replace(paymnt_type_cd,' ',''))) = 0 or paymnt_type_cd is null""")

    val result = spark.sql(src)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : " + src)

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  } 

  //-----------------------------------------------------------------------------------------------------------

  test("NCF_SSAV - Fetch DATA FROM pi_fcs_mbr_trnsctn_hist for Home Members - 022") {

    val id = Array("022")

    val name = Array("Fetch DATA FROM pi_fcs_mbr_trnsctn_hist for Home Members  - 022")

    val resultN = spark.sql(s"""SELECT PI.mcid, PI.srvcg_npi, PI.fundg_type_paymnt_amt, 
      PI.cpttn_incrd_from_dt, PI.cpttn_incrd_to_dt, PI.cpttn_paymnt_type_cd AS CPTTN_PAYMNT_TYPE_CD, 
      PI.vbp_id, PI.cnsstnt_mbr_id, PI.srvcg_prov_npi, CASE WHEN TRIM(PI.CPTTN_PAYMNT_TYPE_CD) IN  
      ('M1', 'M3', 'R1', 'R3') THEN 'OA' END AS PAYMNT_TYPE_CD, PI.psgl_prod_cd, 
      PI.cpttn_fundg_from_dt, PI.cpttn_fundg_to_dt, PI.SSAV_RUN_RSLT_KEY, PI.mbr_efctv_dt, 
      SSAV.MSRMNT_PRD_STRT_DT AS PRFRMN_CYCL_STRT_DT, SSAV.MSRMNT_PRD_END_DT AS PRFRMN_CYCL_END_DT,PI.PG_ID 
      FROM ${dbname}_pcandw1ph_nogbd_r000_in.pi_fcs_mbr_trnsctn_hist PI 
      INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ssav_run_rslt SSAV 
      ON PI.SSAV_RUN_RSLT_KEY=SSAV.SSAV_RUN_RSLT_KEY AND  
      PI.MBRSHP_SOR_CD<>'1005' AND PI.PAYMNT_TYPE_CD = 'SSAV' AND PI.CHK_PAYMNT_IND = 'Y' 
      and PI.RCRD_STTS_CD<>'DEL' WHERE SSAV.MSRMNT_PRD_END_DT BETWEEN 
      '${startdateFnl}' AND '${enddateFnl}'""")

    //result.persist()

    resultN.write.format("parquet").mode("overwrite").insertInto(f"${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOME_SSAV_VBP")
    val result = spark.sql(f"select * from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOME_SSAV_VBP")

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_TRAN_HIST_HOME_SSAV")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT PI.mcid, PI.srvcg_npi, PI.fundg_type_paymnt_amt, PI.cpttn_incrd_from_dt, PI.cpttn_incrd_to_dt, PI.cpttn_paymnt_type_cd AS CPTTN_PAYMNT_TYPE_CD, PI.vbp_id, PI.cnsstnt_mbr_id, PI.srvcg_prov_npi, CASE WHEN TRIM(PI.CPTTN_PAYMNT_TYPE_CD) IN  ('M1', 'M3', 'R1', 'R3') THEN 'OA' END AS PAYMNT_TYPE_CD, PI.psgl_prod_cd, PI.cpttn_fundg_from_dt, PI.cpttn_fundg_to_dt, PI.SSAV_RUN_RSLT_KEY, PI.mbr_efctv_dt, SSAV.MSRMNT_PRD_STRT_DT AS PRFRMN_CYCL_STRT_DT, SSAV.MSRMNT_PRD_END_DT AS PRFRMN_CYCL_END_DT,PI.PG_ID FROM ${dbname}_pcandw1ph_nogbd_r000_in.pi_fcs_mbr_trnsctn_hist PI INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ssav_run_rslt SSAV ON PI.SSAV_RUN_RSLT_KEY=SSAV.SSAV_RUN_RSLT_KEY AND  PI.MBRSHP_SOR_CD<>'1005' AND PI.PAYMNT_TYPE_CD = 'SSAV' AND PI.CHK_PAYMNT_IND = 'Y' and PI.RCRD_STTS_CD<>'DEL' WHERE SSAV.MSRMNT_PRD_END_DT BETWEEN '${startdateFnl}' AND '${enddateFnl}'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_TRAN_HIST_HOME_SSAV")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT PI.mcid, PI.srvcg_npi, PI.fundg_type_paymnt_amt, PI.cpttn_incrd_from_dt, PI.cpttn_incrd_to_dt, PI.cpttn_paymnt_type_cd AS CPTTN_PAYMNT_TYPE_CD, PI.vbp_id, PI.cnsstnt_mbr_id, PI.srvcg_prov_npi, CASE WHEN TRIM(PI.CPTTN_PAYMNT_TYPE_CD) IN  ('M1', 'M3', 'R1', 'R3') THEN 'OA' END AS PAYMNT_TYPE_CD, PI.psgl_prod_cd, PI.cpttn_fundg_from_dt, PI.cpttn_fundg_to_dt, PI.SSAV_RUN_RSLT_KEY, PI.mbr_efctv_dt, SSAV.MSRMNT_PRD_STRT_DT AS PRFRMN_CYCL_STRT_DT, SSAV.MSRMNT_PRD_END_DT AS PRFRMN_CYCL_END_DT,PI.PG_ID FROM ${dbname}_pcandw1ph_nogbd_r000_in.pi_fcs_mbr_trnsctn_hist PI INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ssav_run_rslt SSAV ON PI.SSAV_RUN_RSLT_KEY=SSAV.SSAV_RUN_RSLT_KEY AND  PI.MBRSHP_SOR_CD<>'1005' AND PI.PAYMNT_TYPE_CD = 'SSAV' AND PI.CHK_PAYMNT_IND = 'Y' and PI.RCRD_STTS_CD<>'DEL' WHERE SSAV.MSRMNT_PRD_END_DT BETWEEN '${startdateFnl}' AND '${enddateFnl}'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------------------

  test("NCF_SSAV - Fetch Attribution Data from Hist table - 023") {

    val id = Array("023")

    val name = Array("NCF_SSAV - Fetch Attribution Data from Hist table 023")

    val result = spark.sql(s""" SELECT DISTINCT * FROM (SELECT LCL_ATR_HST.*, RANK() OVER (PARTITION BY LCL_ATR_HST.CNSSTNT_MBR_ID,LCL_ATR_HST.ATRBN_PRD_BGN_DT,LCL_ATR_HST.ATRBN_PRD_END_DT ORDER BY LCL_ATR_HST.atrbn_prd_bgn_dt DESC ) AS RNK FROM ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist LCL_ATR_HST) a WHERE RNK=1""")

    result.persist()

    if (result.count > 0) {
      result.createOrReplaceTempView("BCBSA_VBP_LCL_ATRBN_SSAV")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT DISTINCT * FROM (SELECT LCL_ATR_HST.*, RANK() OVER (PARTITION BY LCL_ATR_HST.CNSSTNT_MBR_ID,LCL_ATR_HST.ATRBN_PRD_BGN_DT,LCL_ATR_HST.ATRBN_PRD_END_DT ORDER BY LCL_ATR_HST.atrbn_prd_bgn_dt DESC ) AS RNK FROM ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist LCL_ATR_HST) a WHERE RNK=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("BCBSA_VBP_LCL_ATRBN_SSAV")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT DISTINCT * FROM (SELECT LCL_ATR_HST.*, RANK() OVER (PARTITION BY LCL_ATR_HST.CNSSTNT_MBR_ID,LCL_ATR_HST.ATRBN_PRD_BGN_DT,LCL_ATR_HST.ATRBN_PRD_END_DT ORDER BY LCL_ATR_HST.atrbn_prd_bgn_dt DESC ) AS RNK FROM ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist LCL_ATR_HST) a WHERE RNK=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------------------

  test("NCF_SSAV - Fetch provider Data from Hist table - 024") {

    val id = Array("024")

    val name = Array("NCF_SSAV - Fetch Provider Data from Hist table 024")

    val result = spark.sql(s""" SELECT DISTINCT * FROM (SELECT LCL_ATR_HST.*, RANK() OVER (PARTITION BY LCL_ATR_HST.CNSSTNT_MBR_ID,LCL_ATR_HST.ATRBD_PROV_NPI,LCL_ATR_HST.ATRBN_PRD_BGN_DT,LCL_ATR_HST.ATRBN_PRD_END_DT ORDER BY LCL_ATR_HST.atrbn_prd_bgn_dt DESC ) AS RNK1 FROM ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist LCL_ATR_HST) a WHERE RNK1=1""")

    result.persist()

    if (result.count > 0) {
      result.createOrReplaceTempView("BCBSA_VBP_LCL_ATRBN_SSAV_NPI")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT DISTINCT * FROM (SELECT LCL_ATR_HST.*, RANK() OVER (PARTITION BY LCL_ATR_HST.CNSSTNT_MBR_ID,LCL_ATR_HST.ATRBD_PROV_NPI,LCL_ATR_HST.ATRBN_PRD_BGN_DT,LCL_ATR_HST.ATRBN_PRD_END_DT ORDER BY LCL_ATR_HST.atrbn_prd_bgn_dt DESC ) AS RNK1 FROM ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist LCL_ATR_HST) a WHERE RNK1=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("BCBSA_VBP_LCL_ATRBN_SSAV_NPI")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT DISTINCT * FROM (SELECT LCL_ATR_HST.*, RANK() OVER (PARTITION BY LCL_ATR_HST.CNSSTNT_MBR_ID,LCL_ATR_HST.ATRBD_PROV_NPI,LCL_ATR_HST.ATRBN_PRD_BGN_DT,LCL_ATR_HST.ATRBN_PRD_END_DT ORDER BY LCL_ATR_HST.atrbn_prd_bgn_dt DESC ) AS RNK1 FROM ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_vbp_lcl_atrbn_hist LCL_ATR_HST) a WHERE RNK1=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------------------

  test("NCF_SSAV - amount calculation - 025") {

    val id = Array("025")

    val name = Array("NCF_SSAV - amount calculation- 025")

    val result = spark.sql(s"""select sum(H.FUNDG_TYPE_PAYMNT_AMT) as FUNDG_TYPE_PAYMNT_AMT, H.mcid, 
      H.cpttn_incrd_from_dt, H.PRFRMN_CYCL_STRT_DT, H.SRVCG_NPI,H.PG_ID 
      from SIT_TRAN_HIST_HOME_SSAV H where H.CPTTN_PAYMNT_TYPE_CD in  ('M1', 'M3', 'R1', 'R3') 
      GROUP BY H.MCID, H.cpttn_incrd_from_dt,H.PRFRMN_CYCL_STRT_DT,H.SRVCG_NPI,H.PG_ID""")

    result.persist()

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_TRAN_HIST_HOME_SSAV_AMT")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select sum(H.FUNDG_TYPE_PAYMNT_AMT) as FUNDG_TYPE_PAYMNT_AMT, H.mcid,H.cpttn_incrd_from_dt, H.PRFRMN_CYCL_STRT_DT, H.SRVCG_NPI,H.PG_IDfrom SIT_TRAN_HIST_HOME_SSAV H where H.CPTTN_PAYMNT_TYPE_CD in  ('M1', 'M3', 'R1', 'R3')GROUP BY H.MCID, H.cpttn_incrd_from_dt,H.PRFRMN_CYCL_STRT_DT,H.SRVCG_NPI,H.PG_ID")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_TRAN_HIST_HOME_SSAV_AMT")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select sum(H.FUNDG_TYPE_PAYMNT_AMT) as FUNDG_TYPE_PAYMNT_AMT, H.mcid,H.cpttn_incrd_from_dt, H.PRFRMN_CYCL_STRT_DT, H.SRVCG_NPI,H.PG_IDfrom SIT_TRAN_HIST_HOME_SSAV H where H.CPTTN_PAYMNT_TYPE_CD in  ('M1', 'M3', 'R1', 'R3')GROUP BY H.MCID, H.cpttn_incrd_from_dt,H.PRFRMN_CYCL_STRT_DT,H.SRVCG_NPI,H.PG_ID")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------------------

  test("NCF_SSAV - Combine all steps - 026") {

    val id = Array("026")

    val name = Array("NCF_SSAV - Combine all steps- 026")

    val resultN = spark.sql(s""" SELECT PIFCS.*,P1.FUNDG_TYPE_PAYMNT_AMT as PAYE_PAYMNT_AMT FROM 
      (SELECT '' as MMI_ID, PIFCS.MCID as CNSSTNT_MBR_ID, R1.its_sbscrbr_id as ITS_SBSCRBR_ID , 
      PIFCS.mcid as MBR_ID, R1.bhi_home_plan_id as BHI_HOME_PLAN_ID, R1.bhi_host_plan_id as BHI_HOST_PLAN_ID,
       R2.atrbd_prov_id as PAYEE_PROV_ID, PIFCS.srvcg_npi as payee_prov_npi, R2.atrbd_prov_frst_nm 
       as payee_prov_frst_nm, R2.atrbd_prov_last_nm as payee_prov_last_nm, R2.atrbd_prov_org_nm 
       as prov_org_nm, R2.atrbd_prov_str_adrs_1_txt as prov_str_adrs_1_txt, R2.atrbd_prov_str_adrs_2_txt 
       as prov_str_adrs_2_txt, R2.atrbd_prov_city_nm as prov_city_nm, R2.atrbd_prov_st_cd as prov_st_cd, 
       R2.atrbd_prov_zip_cd as prov_zip_cd, PIFCS.prfrmn_cycl_strt_dt, PIFCS.prfrmn_cycl_end_dt, 
       trunc(PIFCS.cpttn_incrd_from_dt, 'MONTH')  as paymnt_bgn_dt, last_day(PIFCS.cpttn_incrd_from_dt) 
       as paymnt_end_dt, R2.vbp_id as VBP_ID, R2.pe_id as PE_ID, R2.ATRBN_PROV_PGM_NM AS PE_NM , 
       'S' AS NCF_PAYMNT_TYPE_CD, PIFCS.PAYMNT_TYPE_CD AS PAYMNT_TYPE_CD, PIFCS.psgl_prod_cd as PSGL_PROD_CD,
        PIFCS.cpttn_fundg_from_dt AS CPTTN_FUNDG_FROM_DT, PIFCS.cpttn_fundg_to_dt AS CPTTN_FUNDG_TO_DT, 
        PIFCS.cpttn_incrd_from_dt AS CPTTN_INCRD_FROM_DT, PIFCS.cpttn_incrd_to_dt AS CPTTN_INCRD_TO_DT, 
        PIFCS.CPTTN_PAYMNT_TYPE_CD, PIFCS.mbr_efctv_dt from SIT_TRAN_HIST_HOME_SSAV PIFCS 
        LEFT OUTER JOIN BCBSA_VBP_LCL_ATRBN_SSAV R1 ON PIFCS.MCID=R1.CNSSTNT_MBR_ID 
        AND PIFCS.CPTTN_INCRD_FROM_DT=R1.ATRBN_PRD_BGN_DT LEFT OUTER JOIN BCBSA_VBP_LCL_ATRBN_SSAV_NPI R2 
        ON PIFCS.MCID=R2.CNSSTNT_MBR_ID AND PIFCS.SRVCG_NPI=R2.ATRBD_PROV_NPI 
        AND PIFCS.CPTTN_INCRD_FROM_DT=R2.ATRBN_PRD_BGN_DT) PIFCS LEFT OUTER JOIN SIT_TRAN_HIST_HOME_SSAV_AMT 
        P1 ON P1.mcid=PIFCS.MBR_ID and  P1.cpttn_incrd_from_dt=PIFCS.cpttn_incrd_from_dt and 
        P1.PRFRMN_CYCL_STRT_DT=PIFCS.PRFRMN_CYCL_STRT_DT and P1.SRVCG_NPI=PIFCS.payee_prov_npi  
        and P1.PG_ID=PIFCS.PE_ID""")

    //result.persist()

    resultN.write.format("parquet").mode("overwrite").insertInto(f"${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOME_SSAV_VBP_FNL")

    val result = spark.sql(f"select * from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOME_SSAV_VBP_FNL")

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_TRAN_HIST_HOME_SSAV_FNL")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from SIT_TRAN_HIST_HOME_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_TRAN_HIST_HOME_SSAV_FNL")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from SIT_TRAN_HIST_HOME_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------------------

  test("NCF_SSAV - MINUS query -1 (Reconcile amounts at record level) - 027") {

    val id = Array("027")

    val name = Array("NCF_SSAV - MINUS query -1 (Reconcile amounts at record level)- 027")

    val result1 = spark.sql(s""" select cnsstnt_mbr_id, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where load_log_key=${df1} and mmi_id = ''""")

    val result2 = spark.sql(s"""select DISTINCT cnsstnt_mbr_id, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from SIT_TRAN_HIST_HOME_SSAV_FNL""")

    val result = result1.except(result2)

    //result.persist()

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select cnsstnt_mbr_id, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where load_log_key=${df1} and mmi_id = '' minus select DISTINCT cnsstnt_mbr_id, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from SIT_TRAN_HIST_HOME_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select cnsstnt_mbr_id, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where load_log_key=${df1} and mmi_id = '' minus select DISTINCT cnsstnt_mbr_id, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from SIT_TRAN_HIST_HOME_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //---------------------------------------------------------------------------------------------
  
  test("NCF_SSAV  - HOME - MINUS query -2 (Reconcile amounts at PG_ID level) - 028") {

    val id = Array("028")
    val name = Array("Test case : - MINUS query -2 (Reconcile amounts at PG_ID level) - 028 ")

    val result1 = spark.sql(s"""select a.pe_id,sum(paye_paymnt_amt ) from( select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where load_log_key=${df1} and mmi_id = '') a group by a.pe_id""")
    
    val result2 = spark.sql(s"""select pe_id,sum(paye_paymnt_amt ) from (select distinct PE_ID,cnsstnt_mbr_id, PAYEE_PROV_NPI, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt, paye_paymnt_amt from SIT_TRAN_HIST_HOME_SSAV_FNL) A group by pe_id order by pe_id""")

    val result = result1.except(result2)

    //result.persist()
    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select a.pe_id,sum(paye_paymnt_amt ) from( select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where load_log_key=${df1} and mmi_id = '') a group by a.pe_id minus select pe_id,sum(paye_paymnt_amt ) from (select distinct PE_ID,cnsstnt_mbr_id, PAYEE_PROV_NPI, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt, paye_paymnt_amt from SIT_TRAN_HIST_HOME_SSAV_FNL) A group by pe_id order by pe_id")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select a.pe_id,sum(paye_paymnt_amt ) from( select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where load_log_key=${df1} and mmi_id = '') a group by a.pe_id minus select pe_id,sum(paye_paymnt_amt ) from (select distinct PE_ID,cnsstnt_mbr_id, PAYEE_PROV_NPI, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt, paye_paymnt_amt from SIT_TRAN_HIST_HOME_SSAV_FNL) A group by pe_id order by pe_i")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("NCF_SSAV  - HOME - MINUS query -3 (Validate Plan level details) - 029") {

    val id = Array("029")
    val name = Array("Test case : - MINUS query -3 (Validate Plan level details) - 029 ")

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where mmi_id = '' and load_log_key=${df1}""")
    
    val result2 = spark.sql("""select DISTINCT CNSSTNT_MBR_ID,MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PE_ID, PE_NM, vbp_id from SIT_TRAN_HIST_HOME_SSAV_FNL""")

    val result = result1.except(result2)
    //result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where mmi_id = '' and load_log_key=${df1} minus select DISTINCT CNSSTNT_MBR_ID,MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PE_ID, PE_NM, vbp_id from SIT_TRAN_HIST_HOME_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where mmi_id = '' and load_log_key=${df1} minus select DISTINCT CNSSTNT_MBR_ID,MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PE_ID, PE_NM, vbp_id from SIT_TRAN_HIST_HOME_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("NCF_SSAV  - HOME - MINUS query -4 (Validate payment details) - 030") {

    val id = Array("030")
    val name = Array("Test case : - MINUS query -4 (Validate payment details) - 030 ")

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where mmi_id = '' and load_log_key=${df1}""")
    
    val result2 = spark.sql(s"""select DISTINCT cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from SIT_TRAN_HIST_HOME_SSAV_FNL""")

    val result = result1.except(result2)
    //result.persist()
    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where mmi_id = '' and load_log_key=${df1} minus select DISTINCT CNSSTNT_MBR_ID,MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PE_ID, PE_NM, vbp_id from SIT_TRAN_HIST_HOME_SSAV_FNL minus select DISTINCT cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from SIT_TRAN_HIST_HOME_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID,PE_NM, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where mmi_id = '' and load_log_key=${df1} minus select DISTINCT CNSSTNT_MBR_ID,MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PE_ID, PE_NM, vbp_id from SIT_TRAN_HIST_HOME_SSAV_FNL minus select DISTINCT cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from SIT_TRAN_HIST_HOME_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("NCF_SSAV  - HOME - MINUS query -5 (Validate provider details) - 031") {

    val id = Array("031")
    val name = Array("Test case : - MINUS query -5 (Validate provider details) - 031 ")

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where mmi_id = '' and load_log_key=${df1}""")
    
    val result2 = spark.sql(s"""select DISTINCT cnsstnt_mbr_id, PE_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from SIT_TRAN_HIST_HOME_SSAV_FNL""")

    val result = result1.except(result2)

    //result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where mmi_id = '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PE_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from SIT_TRAN_HIST_HOME_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where mmi_id = '' union all select distinct cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where mmi_id = '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PE_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from SIT_TRAN_HIST_HOME_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------------------

  test("NCF_SSAV - Fetch DATA FROM pi_fcs_mbr_trnsctn_hist for Host Members - 032") {

    val id = Array("032")

    val name = Array("NCF_SSAV - Fetch DATA FROM pi_fcs_mbr_trnsctn_hist for Host Members - 032")

    val resultN = spark.sql(s"""SELECT PI.MBR_KEY, PI.PG_ID,PI.mcid, PI.srvcg_npi, PI.fundg_type_paymnt_amt, 
      PI.cpttn_incrd_from_dt, PI.cpttn_incrd_to_dt, PI.cpttn_paymnt_type_cd AS CPTTN_PAYMNT_TYPE_CD, 
      PI.vbp_id, PI.cnsstnt_mbr_id, PI.srvcg_prov_npi, CASE WHEN TRIM(PI.CPTTN_PAYMNT_TYPE_CD) IN  ('M1', 'M3', 'R1', 'R3') THEN 'OA' END AS 
       PAYMNT_TYPE_CD, PI.psgl_prod_cd,PI.cpttn_fundg_from_dt, PI.cpttn_fundg_to_dt, PI.SSAV_RUN_RSLT_KEY, PI.mbr_efctv_dt, 
      SSAV.MSRMNT_PRD_STRT_DT AS PRFRMN_CYCL_STRT_DT, SSAV.MSRMNT_PRD_END_DT AS PRFRMN_CYCL_END_DT 
      FROM ${dbname}_PCANDW1PH_nogbd_r000_in.pi_fcs_mbr_trnsctn_hist PI
       INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ssav_run_rslt SSAV 
       ON PI.SSAV_RUN_RSLT_KEY=SSAV.SSAV_RUN_RSLT_KEY AND PI.MBRSHP_SOR_CD='1005' 
       AND PI.PAYMNT_TYPE_CD = 'SSAV' AND PI.CHK_PAYMNT_IND = 'Y' and PI.RCRD_STTS_CD<>'DEL'	   
       WHERE SSAV.MSRMNT_PRD_END_DT BETWEEN '${startdateFnl}' AND '${enddateFnl}'""")

    //result.persist()
    resultN.write.format("parquet").mode("overwrite").insertInto(f"${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOST_SSAV_VBP")
    val result = spark.sql(f"select * from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOST_SSAV_VBP")

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_TRAN_HIST_HOST_SSAV")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : SELECT PI.MBR_KEY, PI.PG_ID,PI.mcid, PI.srvcg_npi, PI.fundg_type_paymnt_amt, PI.cpttn_incrd_from_dt, PI.cpttn_incrd_to_dt, PI.cpttn_paymnt_type_cd AS CPTTN_PAYMNT_TYPE_CD, PI.vbp_id, PI.cnsstnt_mbr_id, PI.srvcg_prov_npi, CASE WHEN TRIM(PI.CPTTN_PAYMNT_TYPE_CD) IN  ('M1', 'M3', 'R1', 'R3') THEN 'OA' END AS  PAYMNT_TYPE_CD, PI.psgl_prod_cd,PI.cpttn_fundg_from_dt, PI.cpttn_fundg_to_dt, PI.SSAV_RUN_RSLT_KEY, PI.mbr_efctv_dt, SSAV.MSRMNT_PRD_STRT_DT AS PRFRMN_CYCL_STRT_DT, SSAV.MSRMNT_PRD_END_DT AS PRFRMN_CYCL_END_DT FROM ${dbname}_PCANDW1PH_nogbd_r000_in.pi_fcs_mbr_trnsctn_hist PI INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ssav_run_rslt SSAV  ON PI.SSAV_RUN_RSLT_KEY=SSAV.SSAV_RUN_RSLT_KEY AND PI.MBRSHP_SOR_CD='1005'  AND PI.PAYMNT_TYPE_CD = 'SSAV' AND PI.CHK_PAYMNT_IND = 'Y' and PI.RCRD_STTS_CD<>'DEL' WHERE SSAV.MSRMNT_PRD_END_DT BETWEEN '${startdateFnl}' AND '${enddateFnl}'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_TRAN_HIST_HOST_SSAV")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : SELECT PI.MBR_KEY, PI.PG_ID,PI.mcid, PI.srvcg_npi, PI.fundg_type_paymnt_amt, PI.cpttn_incrd_from_dt, PI.cpttn_incrd_to_dt, PI.cpttn_paymnt_type_cd AS CPTTN_PAYMNT_TYPE_CD, PI.vbp_id, PI.cnsstnt_mbr_id, PI.srvcg_prov_npi, CASE WHEN TRIM(PI.CPTTN_PAYMNT_TYPE_CD) IN  ('M1', 'M3', 'R1', 'R3') THEN 'OA' END AS  PAYMNT_TYPE_CD, PI.psgl_prod_cd,PI.cpttn_fundg_from_dt, PI.cpttn_fundg_to_dt, PI.SSAV_RUN_RSLT_KEY, PI.mbr_efctv_dt, SSAV.MSRMNT_PRD_STRT_DT AS PRFRMN_CYCL_STRT_DT, SSAV.MSRMNT_PRD_END_DT AS PRFRMN_CYCL_END_DT FROM ${dbname}_PCANDW1PH_nogbd_r000_in.pi_fcs_mbr_trnsctn_hist PI INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_in.ssav_run_rslt SSAV  ON PI.SSAV_RUN_RSLT_KEY=SSAV.SSAV_RUN_RSLT_KEY AND PI.MBRSHP_SOR_CD='1005'  AND PI.PAYMNT_TYPE_CD = 'SSAV' AND PI.CHK_PAYMNT_IND = 'Y' and PI.RCRD_STTS_CD<>'DEL' WHERE SSAV.MSRMNT_PRD_END_DT BETWEEN '${startdateFnl}' AND '${enddateFnl}'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------------------

  test("NCF_SSAV - pulling data for host for BCBSA_MBR_PROD - 033") {

    val id = Array("033")

    val name = Array("NCF_SSAV - pulling data for host for BCBSA_MBR_PROD - 033")

    val result = spark.sql(s""" select * from (select distinct MBR_KEY,BCBSA_MSTR_MBR_ID, its_sbscrbr_id, CNSSTNT_MBR_ID, HOME_PLAN_MBR_ID, NDW_PLAN_CD , HOST_PLAN_CD ,BCBSA_BGN_DT, BCBSA_END_DT,VRSN_CLOS_DT, RANK() OVER(PARTITION BY MBR_KEY ORDER BY BCBSA_BGN_DT DESC, BCBSA_END_DT DESC, VRSN_CLOS_DT DESC) as rnm from ${dbname}_pcandw1ph_nogbd_r000_in.BCBSA_MBR_PROD where Host_plan_cd in ('040', '330', '131', '102', '425', '458', '161', '254', '051', '748', '062', '266', '271', '182')) A where rnm=1""")

    result.persist()

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_VBP_SSAV_BCBSA_MBR")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"Test Query : select * from (select distinct MBR_KEY,BCBSA_MSTR_MBR_ID, its_sbscrbr_id, CNSSTNT_MBR_ID, HOME_PLAN_MBR_ID, NDW_PLAN_CD , HOST_PLAN_CD ,BCBSA_BGN_DT, BCBSA_END_DT,VRSN_CLOS_DT, RANK() OVER(PARTITION BY MBR_KEY ORDER BY BCBSA_BGN_DT DESC, BCBSA_END_DT DESC, VRSN_CLOS_DT DESC) as rnm from ${dbname}_pcandw1ph_nogbd_r000_in.BCBSA_MBR_PROD where Host_plan_cd in ('040', '330', '131', '102', '425', '458', '161', '254', '051', '748', '062', '266', '271', '182')) A where rnm=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_VBP_SSAV_BCBSA_MBR")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"Test Query : select * from (select distinct MBR_KEY,BCBSA_MSTR_MBR_ID, its_sbscrbr_id, CNSSTNT_MBR_ID, HOME_PLAN_MBR_ID, NDW_PLAN_CD , HOST_PLAN_CD ,BCBSA_BGN_DT, BCBSA_END_DT,VRSN_CLOS_DT, RANK() OVER(PARTITION BY MBR_KEY ORDER BY BCBSA_BGN_DT DESC, BCBSA_END_DT DESC, VRSN_CLOS_DT DESC) as rnm from ${dbname}_pcandw1ph_nogbd_r000_in.BCBSA_MBR_PROD where Host_plan_cd in ('040', '330', '131', '102', '425', '458', '161', '254', '051', '748', '062', '266', '271', '182')) A where rnm=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------------------

  test("NCF_SSAV - pulling data for host attribution (Same as CARE) - 034") {

    val id = Array("034")

    val name = Array("NCF_SSAV - pulling data for host attribution (Same as CARE) - 034")

    val result = spark.sql(s""" SELECT * FROM (SELECT HOST_ATR_HST.*, RANK() OVER (PARTITION BY HOST_ATR_HST.mmi_id,HOST_ATR_HST.ndw_home_plan_mbr_id,HOST_ATR_HST.CNSSTNT_MBR_ID,HOST_ATR_HST.atrbd_prd_end_dt ORDER BY HOST_ATR_HST.atrbd_prd_bgn_dt DESC ) AS RNK1 from ${dbname}_pcandw1ph_nogbd_r000_WH.BCBSA_VBP_HOST_ATRBN HOST_ATR_HST) A WHERE RNK1=1""")

    result.persist()

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_BCBSA_VBP_HOST_ATRBN_CNSSTNT_NPI")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT * FROM (SELECT HOST_ATR_HST.*, RANK() OVER (PARTITION BY HOST_ATR_HST.mmi_id,HOST_ATR_HST.ndw_home_plan_mbr_id,HOST_ATR_HST.CNSSTNT_MBR_ID,HOST_ATR_HST.atrbd_prd_end_dt ORDER BY HOST_ATR_HST.atrbd_prd_bgn_dt DESC ) AS RNK1 from ${dbname}_pcandw1ph_nogbd_r000_WH.BCBSA_VBP_HOST_ATRBN HOST_ATR_HST) A WHERE RNK1=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_BCBSA_VBP_HOST_ATRBN_CNSSTNT_NPI")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT * FROM (SELECT HOST_ATR_HST.*, RANK() OVER (PARTITION BY HOST_ATR_HST.mmi_id,HOST_ATR_HST.ndw_home_plan_mbr_id,HOST_ATR_HST.CNSSTNT_MBR_ID,HOST_ATR_HST.atrbd_prd_end_dt ORDER BY HOST_ATR_HST.atrbd_prd_bgn_dt DESC ) AS RNK1 from ${dbname}_pcandw1ph_nogbd_r000_WH.BCBSA_VBP_HOST_ATRBN HOST_ATR_HST) A WHERE RNK1=1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------------------

  test("NCF_SSAV -amount calculation- 35") {

    val id = Array("035")

    val name = Array("NCF_SSAV -amount calculation- 35")

    val result = spark.sql(s"""select sum(H.FUNDG_TYPE_PAYMNT_AMT) as FUNDG_TYPE_PAYMNT_AMT, H.MBR_KEY, H.cpttn_incrd_from_dt, H.PRFRMN_CYCL_STRT_DT, H.SRVCG_NPI,H.PG_ID from SIT_TRAN_HIST_HOST_SSAV H where H.CPTTN_PAYMNT_TYPE_CD in  ('M1', 'M3', 'R1', 'R3') GROUP BY H.MBR_KEY, H.cpttn_incrd_from_dt , H.PRFRMN_CYCL_STRT_DT,H.SRVCG_NPI,H.PG_ID""")

    result.persist()

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_TRAN_HIST_HOST_SSAV_AMT")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select sum(H.FUNDG_TYPE_PAYMNT_AMT) as FUNDG_TYPE_PAYMNT_AMT, H.MBR_KEY, H.cpttn_incrd_from_dt, H.PRFRMN_CYCL_STRT_DT, H.SRVCG_NPI,H.PG_ID from SIT_TRAN_HIST_HOST_SSAV H where H.CPTTN_PAYMNT_TYPE_CD in  ('M1', 'M3', 'R1', 'R3') GROUP BY H.MBR_KEY, H.cpttn_incrd_from_dt , H.PRFRMN_CYCL_STRT_DT,H.SRVCG_NPI,H.PG_ID")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_TRAN_HIST_HOST_SSAV_AMT")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select sum(H.FUNDG_TYPE_PAYMNT_AMT) as FUNDG_TYPE_PAYMNT_AMT, H.MBR_KEY, H.cpttn_incrd_from_dt, H.PRFRMN_CYCL_STRT_DT, H.SRVCG_NPI,H.PG_ID from SIT_TRAN_HIST_HOST_SSAV H where H.CPTTN_PAYMNT_TYPE_CD in  ('M1', 'M3', 'R1', 'R3') GROUP BY H.MBR_KEY, H.cpttn_incrd_from_dt , H.PRFRMN_CYCL_STRT_DT,H.SRVCG_NPI,H.PG_ID")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------------------

  test("NCF_SSAV -Combine all steps- 36") {

    val id = Array("036")

    val name = Array("NCF_SSAV -Combine all steps- 36")

    val resultN = spark.sql(s"""SELECT PIFCS.*,P1.FUNDG_TYPE_PAYMNT_AMT as PAYE_PAYMNT_AMT FROM 
      (select MBR.bcbsa_mstr_mbr_id as MMI_ID, MBR.CNSSTNT_MBR_ID, MBR.ITS_SBSCRBR_ID, 
      MBR.HOME_PLAN_MBR_ID AS MBR_ID, MBR.ndw_plan_cd as BHI_HOME_PLAN_ID, MBR.HOST_PLAN_CD 
      as BHI_HOST_PLAN_ID, HIST.srvcg_npi as PAYEE_PROV_NPI, trunc(HIST.cpttn_incrd_from_dt, 'MONTH') 
      as PAYMNT_BGN_DT, last_day(HIST.cpttn_incrd_from_dt) as PAYMNT_END_DT, HIST.PRFRMN_CYCL_STRT_DT, 
      HIST.PRFRMN_CYCL_END_DT , HIST.PAYMNT_TYPE_CD, HIST.pg_id as pe_id, DTL.PG_NM as pe_nm, 
      HIST.PSGL_PROD_CD, HIST.CPTTN_FUNDG_FROM_DT, HIST.CPTTN_FUNDG_TO_DT, HIST.cpttn_incrd_from_dt, 
      HIST.cpttn_incrd_to_dt, HIST.mbr_efctv_dt,BCBSA.atrbd_prov_id as PAYEE_PROV_ID, 
      BCBSA.atrbd_prov_frst_nm as PAYEE_PROV_FRST_NM, BCBSA.atrbd_prov_last_nm as PAYEE_PROV_LAST_NM, 
      BCBSA.atrbd_prov_org_nm as PROV_ORG_NM, BCBSA.atrbd_prov_str_adrs_1_txt as PROV_STR_ADRS_1_TXT, 
      BCBSA.atrbd_prov_str_adrs_2_txt as PROV_STR_ADRS_2_TXT, BCBSA.atrbd_prov_city_nm as PROV_CITY_NM, 
      BCBSA.atrbd_prov_st_cd as PROV_ST_CD, BCBSA.atrbd_prov_zip_cd as PROV_ZIP_CD, BCBSA.VBP_ID,HIST.MBR_KEY 
      from SIT_TRAN_HIST_HOST_SSAV HIST INNER JOIN  SIT_VBP_SSAV_BCBSA_MBR MBR ON MBR.MBR_KEY=HIST.MBR_KEY 
      left outer join SIT_BCBSA_VBP_HOST_ATRBN_CNSSTNT_NPI BCBSA ON MBR.CNSSTNT_MBR_ID=BCBSA.CNSSTNT_MBR_ID 
      AND HIST.CPTTN_INCRD_FROM_DT = BCBSA.atrbd_prd_bgn_dt and  HIST.srvcg_npi = BCBSA.atrbd_npi_prov_id 
      left outer join ${dbname}_pcandw1ph_nogbd_r000_in.PG_DTL DTL ON HIST.PG_ID=DTL.PG_ID 
      AND HIST.CPTTN_INCRD_FROM_DT BETWEEN DTL.pg_dtl_efctv_dt AND DTL.pg_dtl_trmntn_dt) PIFCS 
      LEFT OUTER JOIN SIT_TRAN_HIST_HOST_SSAV_AMT P1 ON P1.MBR_KEY=PIFCS.MBR_KEY and 
      P1.cpttn_incrd_from_dt=PIFCS.cpttn_incrd_from_dt and P1.PRFRMN_CYCL_STRT_DT=PIFCS.PRFRMN_CYCL_STRT_DT 
      and P1.SRVCG_NPI=PIFCS.payee_prov_npi and P1.PG_ID=PIFCS.PE_ID""")

    //result.persist()
    resultN.write.format("parquet").mode("overwrite").insertInto(f"${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOST_SSAV_VBP_FNL")

    val result = spark.sql(f"select * from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOST_SSAV_VBP_FNL")

    if (result.count > 0) {
      result.createOrReplaceTempView("SIT_TRAN_HIST_HOST_SSAV_FNL")
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from SIT_TRAN_HIST_HOST_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      result.createOrReplaceTempView("SIT_TRAN_HIST_HOST_SSAV_FNL")
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from SIT_TRAN_HIST_HOST_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------------------

  test("NCF_SSAV - MINUS query -6 (Reconcile amounts at record level) - 037") {

    val id = Array("037")

    val name = Array("NCF_SSAV - MINUS query -6 (Reconcile amounts at record level) - 037")

    val result1 = spark.sql(s""" select cnsstnt_mbr_id,MMI_ID,MBR_ID, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id,MMI_ID,MBR_ID, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where load_log_key=${df1} and trim(mmi_id) <> ''""")

    val result2 = spark.sql(s"""select DISTINCT cnsstnt_mbr_id,MMI_ID,MBR_ID, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from SIT_TRAN_HIST_HOST_SSAV_FNL""")

    val result = result1.except(result2)

    //result.persist()

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select cnsstnt_mbr_id,MMI_ID,MBR_ID, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id,MMI_ID,MBR_ID, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where load_log_key=${df1} and trim(mmi_id) <> '' minus select DISTINCT cnsstnt_mbr_id,MMI_ID,MBR_ID, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from SIT_TRAN_HIST_HOST_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select cnsstnt_mbr_id,MMI_ID,MBR_ID, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id,MMI_ID,MBR_ID, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where load_log_key=${df1} and trim(mmi_id) <> '' minus select DISTINCT cnsstnt_mbr_id,MMI_ID,MBR_ID, bhi_home_plan_id, PAYEE_PROV_ID, paymnt_bgn_dt,paymnt_end_dt,PRFRMN_CYCL_STRT_DT,prfrmn_cycl_end_dt,vbp_id, paye_paymnt_amt from SIT_TRAN_HIST_HOST_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("NCF_SSAV  - HOST - MINUS query -7 (Reconcile amounts at PG_ID level) - 038") {

    val id = Array("038")
    val name = Array("Test case : - HOST - MINUS query -7 (Reconcile amounts at PG_ID level) - 038 ")

    val result1 = spark.sql(s"""select a.pe_id,sum(paye_paymnt_amt ) from( select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where load_log_key=${df1} and trim(mmi_id) <> '') a group by a.pe_id order by a.pe_id""")

    val result2 = spark.sql(s"""select pg_id,sum(FUNDG_TYPE_PAYMNT_AMT) from SIT_TRAN_HIST_HOST_SSAV_AMT group by pg_id order by pg_id""")

    val result = result1.except(result2)

    //result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select a.pe_id,sum(paye_paymnt_amt ) from( select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where load_log_key=${df1} and trim(mmi_id) <> '') a group by a.pe_id order by a.pe_id minus select pg_id,sum(FUNDG_TYPE_PAYMNT_AMT) from SIT_TRAN_HIST_HOST_SSAV_AMT group by pg_id order by pg_id")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select a.pe_id,sum(paye_paymnt_amt ) from( select cnsstnt_mbr_id, PE_ID, payee_prov_npi, paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, PE_ID, payee_prov_npi,  paymnt_bgn_dt, paye_paymnt_amt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where load_log_key=${df1} and trim(mmi_id) <> '') a group by a.pe_id order by a.pe_id minus select pg_id,sum(FUNDG_TYPE_PAYMNT_AMT) from SIT_TRAN_HIST_HOST_SSAV_AMT group by pg_id order by pg_id")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("NCF_SSAV  - HOST - MINUS query -8 (Validate Plan level details) - 039") {

    val id = Array("039")
    val name = Array("Test case : - HOST - MINUS query -8 (Validate Plan level details) - 039 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where trim(mmi_id) <> '' and load_log_key=${df1}""")
    
    val result2 = spark.sql(s"""select DISTINCT CNSSTNT_MBR_ID,MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PE_ID, vbp_id from SIT_TRAN_HIST_HOST_SSAV_FNL""")

    val result = result1.except(result2)

    //result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT CNSSTNT_MBR_ID,MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PE_ID, vbp_id from SIT_TRAN_HIST_HOST_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id,its_sbscrbr_id, PE_ID, vbp_id from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT CNSSTNT_MBR_ID,MMI_ID, MBR_ID, bhi_home_plan_id,bhi_host_plan_id, its_sbscrbr_id, PE_ID, vbp_id from SIT_TRAN_HIST_HOST_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("NCF_SSAV  - HOST - MINUS query -9 (Validate payment details) - 040") {

    val id = Array("040")
    val name = Array("Test case : - HOST - MINUS query -9 (Validate payment details) - 040 ")

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where trim(mmi_id) <> '' and load_log_key=${df1}""")
    
    val result2 = spark.sql(s"""select DISTINCT cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from SIT_TRAN_HIST_HOST_SSAV_FNL""")

    val result = result1.except(result2)

    //result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from SIT_TRAN_HIST_HOST_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PE_ID,paymnt_type_cd, paymnt_bgn_dt,paymnt_end_dt,prfrmn_cycl_strt_dt,prfrmn_cycl_end_dt from SIT_TRAN_HIST_HOST_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("NCF_SSAV  - HOST - MINUS query -10 (Validate provider details) - 041") {

    val id = Array("041")
    val name = Array("Test case : - HOST - MINUS query -10 (Validate provider details) - 041")

    val result1 = spark.sql(s"""select cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where trim(mmi_id) <> '' and load_log_key=${df1}""")
    
    val result2 = spark.sql(s"""select DISTINCT cnsstnt_mbr_id, PE_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from SIT_TRAN_HIST_HOST_SSAV_FNL""")

    val result = result1.except(result2)

    //result.persist()

    val rc = result.count

    if (rc == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PE_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from SIT_TRAN_HIST_HOST_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where trim(mmi_id) <> '' union all select distinct cnsstnt_mbr_id, Pe_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav_err where trim(mmi_id) <> '' and load_log_key=${df1} minus select DISTINCT cnsstnt_mbr_id, PE_ID,payee_prov_npi, payee_prov_id,payee_prov_frst_nm, payee_prov_last_nm, prov_org_nm, prov_str_adrs_1_txt, prov_str_adrs_2_txt, prov_city_nm, prov_st_cd, prov_zip_cd from SIT_TRAN_HIST_HOST_SSAV_FNL")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("NCF_SSAV  - Default columns check - 042") {

    val id = Array("042")
    val name = Array("Test case : - Default columns check - 042 ")

    val result = spark.sql(s"""select distinct ncf_paymnt_type_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where ncf_paymnt_type_cd <> 'S'""")

    //result.persist()

    //   val rc=result.count

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select distinct ncf_paymnt_type_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where ncf_paymnt_type_cd <> 'S'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select distinct ncf_paymnt_type_cd from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav where ncf_paymnt_type_cd <> 'S'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //-----------------------------------------------------------------------------------------------

  test("NCF_SSAV  - Duplicate check - 043") {

    val id = Array("043")
    val name = Array("Test case : - Duplicate check - 043 ")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    val result = spark.sql(s"""select MMI_ID,cnsstnt_mbr_id,bhi_home_plan_id,bhi_host_plan_id,paymnt_bgn_dt,ncf_paymnt_type_cd,count(1) as record_count from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav group by MMI_ID,cnsstnt_mbr_id,bhi_home_plan_id,bhi_host_plan_id,paymnt_bgn_dt,ncf_paymnt_type_cd having count(1)>1""")

    //result.persist()

    //   val rc=result.count

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select MMI_ID,cnsstnt_mbr_id,bhi_home_plan_id,bhi_host_plan_id,paymnt_bgn_dt,ncf_paymnt_type_cd,count(1) as record_count from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav group by MMI_ID,cnsstnt_mbr_id,bhi_home_plan_id,bhi_host_plan_id,paymnt_bgn_dt,ncf_paymnt_type_cd having count(1)>1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select MMI_ID,cnsstnt_mbr_id,bhi_home_plan_id,bhi_host_plan_id,paymnt_bgn_dt,ncf_paymnt_type_cd,count(1) as record_count from ${dbname}_PCANDW1PH_nogbd_r000_ou.bcbsa_vbp_non_clm_fncl_ssav group by MMI_ID,cnsstnt_mbr_id,bhi_home_plan_id,bhi_host_plan_id,paymnt_bgn_dt,ncf_paymnt_type_cd having count(1)>1")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  } 
  
  //-------------------------------------------------------------------------------------------------------
  
  test("NCF_SSAV  - Truncate table 'SIT_TRAN_HIST_HOME_SSAV_VBP' and 'SIT_TRAN_HIST_HOST_SSAV_VBP' and validating for record count - 043") {

    val id = Array("043")
    val name = Array("Test case:Truncate table 'SIT_TRAN_HIST_HOME_SSAV_VBP' and 'SIT_TRAN_HIST_HOST_SSAV_VBP' and validating for record count - 043")

    val curr_date = Calendar.getInstance().getTime
    val min_date = new Timestamp(curr_date.getYear, curr_date.getMonth - 1, 1, 0, 0, 0, 0)

    spark.sql(s"""truncate table ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOME_SSAV_VBP""")
    
    val result2 = spark.sql(s"""select * from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOME_SSAV_VBP limit 1""")
    
    spark.sql(s"""truncate table ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOST_SSAV_VBP""")
    
    val result4 = spark.sql(s"""select * from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOST_SSAV_VBP limit 1""")

    if (result2.count == 0 && result4.count == 0) {
      val a = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select count(*) from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOME_SSAV_VBP / select count(*) from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOST_SSAV_VBP")

 //     sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result2.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select count(*) from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOME_SSAV_VBP / select count(*) from ${dbname}_pcandw1ph_nogbd_r000_wk.SIT_TRAN_HIST_HOST_SSAV_VBP")

 //     sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(a.map(_.toString)).repartition(1).union(b.map(_.toString)).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/VBP/Extract_Tables/NCF_SSAV/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

}