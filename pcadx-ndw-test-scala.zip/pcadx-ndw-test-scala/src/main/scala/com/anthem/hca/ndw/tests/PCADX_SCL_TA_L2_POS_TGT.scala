package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession

import org.apache.spark.sql.SparkSession
import java.io.File
import org.apache.spark.sql.DataFrame
import com.anthem.hca.ndw.utils.PCADX_SCL_TA_Utilities._
import java.text.SimpleDateFormat
import org.apache.spark.sql.SaveMode
import java.util.Calendar
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel
import java.util.Date
import java.text.SimpleDateFormat



object PCADX_SCL_TA_L2_POS_TGT {


  
def main(args: Array[String]) {
  


val dbname: String = args(0)
val SUBJ_AREA_NM: String=args(1)
val PRCS_NM: String=args(2)


val appName = "Datapipe from L2 cases for POS" // we will make this generic going forward

val warehouseLocation = new File("/user/hive/warehouse").getAbsolutePath
val options = Map("path" -> "/user/hive/warehouse")

val spark = SparkSession
.builder()
.appName(appName)
.config("spark.sql.warehouse.dir", warehouseLocation)
.enableHiveSupport()
.getOrCreate()

spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode","INFER_ONLY")
spark.conf.set("spark.sql.crossJoin.enabled","true")
spark.conf.set("spark.sql.hive.convertMetastoreParquet", "false")

import spark.implicits._
val home_plan_id =spark.sql("select distinct bhi_home_plan_id from "+dbname+"_pcandw1ph_nogbd_r000_wh.bot_bcbsa_plan_sbmsn")
val  home_plan=home_plan_id.select("bhi_home_plan_id").collect().map(_(0)).toList


spark.sql("select count(*) as CNT,bhi_home_plan_id FROM  "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs_err group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Error")

spark.sql("SELECT count(*) as CNT,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Total")

spark.sql("  select SUM(CASE WHEN trim(SEL.clm_mbr_zip_cd) IN ('IN','') THEN  SEL.CNT ELSE 0 END) AS A,  SUM(CASE WHEN SEL.clm_mbr_cntry_cd IN ('IV','UN') THEN  SEL.CNT ELSE 0 END) AS B , SUM(CASE WHEN trim(prncpal_icd9_diag_cd)=''  and trim(prncpal_icd10_diag_cd)='' THEN  SEL.CNT ELSE 0 END) AS C,  SUM(CASE WHEN bnft_paymnt_stts_cd = 'O' THEN  SEL.CNT ELSE 0 END) AS D, SUM(CASE WHEN SEL.ctgry_of_srvc_cd = 'OP PROF' THEN  SEL.CNT ELSE 0 END) AS E,  SUM(CASE WHEN SEL.ctgry_of_srvc_cd='IP PROF' THEN  SEL.CNT ELSE 0 END) AS F,SUM(CASE WHEN SEL.ctgry_of_srvc_cd='IP OTHER' THEN  SEL.CNT ELSE 0 END) AS G,  SUM(CASE WHEN SEL.clm_paymnt_stts_cd = 'D' THEN  SEL.CNT ELSE 0 END) AS H, SUM(CASE WHEN SEL.plos_cd = '11' THEN  SEL.CNT ELSE 0 END) AS I,SUM(CASE WHEN SEL.plos_cd = '01' THEN  SEL.CNT ELSE 0 END) AS J,bhi_home_plan_id    FROM  (  SELECT 1 AS CNT, prncpal_icd9_diag_cd, prncpal_icd10_diag_cd,  bnft_paymnt_stts_cd, ctgry_of_srvc_cd, clm_paymnt_stts_cd, plos_cd,  clm_mbr_zip_cd, clm_mbr_cntry_cd,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs  WHERE   ((trim(prncpal_icd9_diag_cd)=''  and trim(prncpal_icd10_diag_cd)='') OR trim(clm_mbr_zip_cd) IN ('IN','') OR clm_mbr_cntry_cd IN ('IV','UN')  OR bnft_paymnt_stts_cd = 'O' OR TRIM(ctgry_of_srvc_cd) IN ('OP PROF','IP PROF','IP OTHER') OR clm_paymnt_stts_cd='D' OR plos_cd IN ('11','01') ) )  SEL  group by bhi_home_plan_id ").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("POSDetails")

spark.sql("select SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_mbr_zip_cd' THEN SEL.CNT ELSE 0 END) AS ProOthSerMembZipCdClm64,  SUM(CASE WHEN lower(SEL.FIELD_NM)='prncpal_icd9_diag_cd' THEN SEL.CNT ELSE 0 END) AS ProOthSerICD9DiagCD67,  SUM(CASE WHEN lower(SEL.FIELD_NM)='prncpal_icd10_diag_cd' THEN SEL.CNT ELSE 0 END) AS ProOthSerICD10DiagCD114,SUM(CASE WHEN lower(SEL.FIELD_NM)='cpt_hcpcs_codes' THEN SEL.CNT ELSE 0 END) AS ProOthSerICD9CPTHCPCSCd69,  SUM(CASE WHEN lower(SEL.FIELD_NM)='ctgry_of_srvc_cd' THEN SEL.CNT ELSE 0 END) AS ProOthSerCtgyService71,  SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_paymnt_stts_cd' THEN SEL.CNT ELSE 0 END) AS ProOthSerClmPmtSts75,  SUM(CASE WHEN lower(SEL.FIELD_NM)='plos_cd' THEN SEL.CNT ELSE 0 END) AS ProOthSerPlService77,bhi_home_plan_id from (select err_id,1 as CNT ,clmn_nm  as FIELD_NM ,load_log_key from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_prfsnl_othr_srvcs'  and lower(clmn_nm) in  ('clm_mbr_zip_cd','cpt_hcpcs_codes' 'prncpal_icd10_diag_cd', 'prncpal_icd9_diag_cd', 'ctgry_of_srvc_cd', 'clm_paymnt_stts_cd', 'plos_cd')) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs b on  SEL.err_id=b.err_id and  SEL.load_log_key=b.load_log_key group by  bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("AudPOS")

spark.sql("select SUM(CASE WHEN lower(SEL.FIELD_NM)='billg_prov_id' AND billg_prov_cntrctg_stts_ind = 'Y' THEN SEL.CNT ELSE 0 END) AS A, SUM(CASE WHEN lower(SEL.FIELD_NM)='rndrg_prov_id' AND rndrg_prov_cntrctg_stts_ind = 'Y' THEN SEL.CNT ELSE 0 END) AS D,bhi_home_plan_id from (select 1 as CNT ,clmn_nm  as FIELD_NM,err_id,load_log_key from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_prfsnl_othr_srvcs'  ) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs FACHEAD on SEL.err_id=FACHEAD.err_id and SEL.load_log_key=FACHEAD.load_log_key WHERE  FACHEAD.ctgry_of_srvc_cd <> 'VOID' AND ((FACHEAD.billg_prov_cntrctg_stts_ind = 'Y' AND lower(SEL.FIELD_NM) = 'billg_prov_id') OR (FACHEAD.rndrg_prov_cntrctg_stts_ind='Y' AND lower(SEL.FIELD_NM) = 'rndrg_prov_id')) group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("VOID")




// Rule 1-4
home_plan.foreach(bhi_home_plan_id => {

val sqlbshow=" select a.CNT*100/(b.CNT) as ProOthSer63  FROM  (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs_err FH where    bhi_home_plan_id='"+bhi_home_plan_id +"' ) a join (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b    "

val sqlb=" select a.CNT*100/(b.CNT) as ProOthSer63  FROM  (  SELECT  CNT  FROM Error FH where    bhi_home_plan_id='"+bhi_home_plan_id +"' ) a join (  SELECT  CNT  FROM Total FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b    "

val b=spark.sql(sqlb).withColumn("sql",lit(sqlbshow))



//Rule 5

val sqlashow = "select ProOthSerMembZipCdClm64*100/Total_CNT as ProOthSerMembZipCdClm64,ProOthSerICD9DiagCD67*100/Total_CNT as ProOthSerICD9DiagCD67,ProOthSerICD10DiagCD114*100/Total_CNT as ProOthSerICD10DiagCD114,ProOthSerICD9CPTHCPCSCd69*100/Total_CNT as ProOthSerICD9CPTHCPCSCd69,ProOthSerCtgyService71*100/Total_CNT as ProOthSerCtgyService71,ProOthSerClmPmtSts75*100/Total_CNT as ProOthSerClmPmtSts75,ProOthSerPlService77*100/Total_CNT as ProOthSerPlService77 from  (select SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_mbr_zip_cd' THEN SEL.CNT ELSE 0 END) AS ProOthSerMembZipCdClm64,  SUM(CASE WHEN lower(SEL.FIELD_NM)='prncpal_icd9_diag_cd' THEN SEL.CNT ELSE 0 END) AS ProOthSerICD9DiagCD67,  SUM(CASE WHEN lower(SEL.FIELD_NM)='prncpal_icd10_diag_cd' THEN SEL.CNT ELSE 0 END) AS ProOthSerICD10DiagCD114,SUM(CASE WHEN lower(SEL.FIELD_NM)='cpt_hcpcs_codes' THEN SEL.CNT ELSE 0 END) AS ProOthSerICD9CPTHCPCSCd69,  SUM(CASE WHEN lower(SEL.FIELD_NM)='ctgry_of_srvc_cd' THEN SEL.CNT ELSE 0 END) AS ProOthSerCtgyService71,  SUM(CASE WHEN lower(SEL.FIELD_NM)='clm_paymnt_stts_cd' THEN SEL.CNT ELSE 0 END) AS ProOthSerClmPmtSts75,  SUM(CASE WHEN lower(SEL.FIELD_NM)='plos_cd' THEN SEL.CNT ELSE 0 END) AS ProOthSerPlService77 from (select err_id,1 as CNT ,clmn_nm  as FIELD_NM ,load_log_key from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_prfsnl_othr_srvcs'  and lower(clmn_nm) in  ('clm_mbr_zip_cd','cpt_hcpcs_codes' 'prncpal_icd10_diag_cd', 'prncpal_icd9_diag_cd', 'ctgry_of_srvc_cd', 'clm_paymnt_stts_cd', 'plos_cd')) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs b on  SEL.err_id=b.err_id and  SEL.load_log_key=b.load_log_key where  bhi_home_plan_id='"+bhi_home_plan_id +"') a   cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs POS where   bhi_home_plan_id='"+bhi_home_plan_id +"') total  "

val sqla = "select ProOthSerMembZipCdClm64*100/Total_CNT as ProOthSerMembZipCdClm64,ProOthSerICD9DiagCD67*100/Total_CNT as ProOthSerICD9DiagCD67,ProOthSerICD10DiagCD114*100/Total_CNT as ProOthSerICD10DiagCD114,ProOthSerICD9CPTHCPCSCd69*100/Total_CNT as ProOthSerICD9CPTHCPCSCd69,ProOthSerCtgyService71*100/Total_CNT as ProOthSerCtgyService71,ProOthSerClmPmtSts75*100/Total_CNT as ProOthSerClmPmtSts75,ProOthSerPlService77*100/Total_CNT as ProOthSerPlService77 from  (select * from AudPOS where  bhi_home_plan_id='"+bhi_home_plan_id +"') a   cross join (SELECT CNT as Total_CNT  FROM Total POS where   bhi_home_plan_id='"+bhi_home_plan_id +"') total  "


var a=spark.sql(sqla).withColumn("sql",lit(sqla))



//Rule 6-9

val sqlcshow = "SELECT  A*100/Total_CNT as ProOthSerMembZipCdClm65,B*100/Total_CNT as ProOthSerMembCntryClm66, C*100/Total_CNT as ProOthSerDiagCD68,D*100/Total_CNT as ProOthSerBnftPmtStsCd70, E*100/Total_CNT as ProOthSerCtgyService72,F*100/Total_CNT as ProOthSerCtgyService73, G*100/Total_CNT as ProOthSerCtgyService74,H*100/Total_CNT as ProOthSerClmPmtSts76, I*100/Total_CNT as ProOthSerPlService78,J*100/Total_CNT as ProOthSerPlService79 from ( select SUM(CASE WHEN trim(SEL.clm_mbr_zip_cd) IN ('IN','') THEN  SEL.CNT ELSE 0 END) AS A,  SUM(CASE WHEN SEL.clm_mbr_cntry_cd IN ('IV','UN') THEN  SEL.CNT ELSE 0 END) AS B , SUM(CASE WHEN trim(prncpal_icd9_diag_cd)=''  and trim(prncpal_icd10_diag_cd)='' THEN  SEL.CNT ELSE 0 END) AS C,  SUM(CASE WHEN bnft_paymnt_stts_cd = 'O' THEN  SEL.CNT ELSE 0 END) AS D, SUM(CASE WHEN SEL.ctgry_of_srvc_cd = 'OP PROF' THEN  SEL.CNT ELSE 0 END) AS E,  SUM(CASE WHEN SEL.ctgry_of_srvc_cd='IP PROF' THEN  SEL.CNT ELSE 0 END) AS F,SUM(CASE WHEN SEL.ctgry_of_srvc_cd='IP OTHER' THEN  SEL.CNT ELSE 0 END) AS G,  SUM(CASE WHEN SEL.clm_paymnt_stts_cd = 'D' THEN  SEL.CNT ELSE 0 END) AS H, SUM(CASE WHEN SEL.plos_cd = '11' THEN  SEL.CNT ELSE 0 END) AS I,SUM(CASE WHEN SEL.plos_cd = '01' THEN  SEL.CNT ELSE 0 END) AS J    FROM  (  SELECT 1 AS CNT, prncpal_icd9_diag_cd, prncpal_icd10_diag_cd,  bnft_paymnt_stts_cd, ctgry_of_srvc_cd, clm_paymnt_stts_cd, plos_cd,  clm_mbr_zip_cd, clm_mbr_cntry_cd  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs  WHERE   bhi_home_plan_id='"+bhi_home_plan_id +"' and ((trim(prncpal_icd9_diag_cd)=''  and trim(prncpal_icd10_diag_cd)='') OR trim(clm_mbr_zip_cd) IN ('IN','') OR clm_mbr_cntry_cd IN ('IV','UN')  OR bnft_paymnt_stts_cd = 'O' OR TRIM(ctgry_of_srvc_cd) IN ('OP PROF','IP PROF','IP OTHER') OR clm_paymnt_stts_cd='D' OR plos_cd IN ('11','01') ) )  SEL )a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total "

val sqlc = "SELECT  A*100/Total_CNT as ProOthSerMembZipCdClm65,B*100/Total_CNT as ProOthSerMembCntryClm66, C*100/Total_CNT as ProOthSerDiagCD68,D*100/Total_CNT as ProOthSerBnftPmtStsCd70, E*100/Total_CNT as ProOthSerCtgyService72,F*100/Total_CNT as ProOthSerCtgyService73, G*100/Total_CNT as ProOthSerCtgyService74,H*100/Total_CNT as ProOthSerClmPmtSts76, I*100/Total_CNT as ProOthSerPlService78,J*100/Total_CNT as ProOthSerPlService79 from ( select * from POSDetails where   bhi_home_plan_id='"+bhi_home_plan_id +"')a cross join (SELECT CNT as Total_CNT  FROM Total FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total "



var c=spark.sql(sqlc).withColumn("sql",lit(sqlcshow))

//Rule 10-13

val sqldshow = "select A*100/Total_CNT as ProOthSer107,D*100/Total_CNT as ProOthSer108 from  (select SUM(CASE WHEN lower(SEL.FIELD_NM)='billg_prov_id' AND billg_prov_cntrctg_stts_ind = 'Y' THEN SEL.CNT ELSE 0 END) AS A, SUM(CASE WHEN lower(SEL.FIELD_NM)='rndrg_prov_id' AND rndrg_prov_cntrctg_stts_ind = 'Y' THEN SEL.CNT ELSE 0 END) AS D from (select 1 as CNT ,clmn_nm  as FIELD_NM,err_id,load_log_key from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_prfsnl_othr_srvcs'  ) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs FACHEAD on SEL.err_id=FACHEAD.err_id and SEL.load_log_key=FACHEAD.load_log_key WHERE  FACHEAD.ctgry_of_srvc_cd <> 'VOID' AND ((FACHEAD.billg_prov_cntrctg_stts_ind = 'Y' AND lower(SEL.FIELD_NM) = 'billg_prov_id') OR (FACHEAD.rndrg_prov_cntrctg_stts_ind='Y' AND lower(SEL.FIELD_NM) = 'rndrg_prov_id')) AND   bhi_home_plan_id='"+bhi_home_plan_id +") a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"

val sqld = "select A*100/Total_CNT as ProOthSer107,D*100/Total_CNT as ProOthSer108 from  (select * from VOID where   bhi_home_plan_id='"+bhi_home_plan_id +"') a cross join (SELECT CNT as Total_CNT  FROM Total FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"




var d=spark.sql(sqld).withColumn("sql",lit(sqldshow))


var e=output(spark, TestIDGen(spark,ReportOutput(spark,dbname,a).union(ReportOutput(spark,dbname,b)).union(ReportOutput(spark,dbname,c)).union(ReportOutput(spark,dbname,d))),SUBJ_AREA_NM,PRCS_NM, bhi_home_plan_id.toString())

e.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_RSLT")
//e(1).write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_SQL")


})



}
  
  

}