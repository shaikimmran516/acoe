package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Error_FCD_TGT {
 
  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Error_FCD_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}


 class PCADX_SCL_TA_Error_FCD_TGT(dbname : String, env: String) extends FunSuite{

     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
     
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Error"
      val prcss = "FacilityDetails"
     
     
   test("Facility Detail Error-Check bhi_home_plan_id column values not located in reference table - 001") {

    val id = Array("001")
    val name = Array("Test case : Check bhi_home_plan_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result2 = sqlContext.sql("""select distinct a.bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join 
      """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bhi_home_plan_id') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') and bhi_home_plan_id in  (select distinct a.bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') and bhi_home_plan_id in  (select distinct a.bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Detail Error-Check Error code when bhi_home_plan_id column values not located in reference table - 002") {

    val id = Array("002")
    val name = Array("Test case : Check Error code when bhi_home_plan_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
   test("Facility Detail Error-Check trcblty_fld_cd column values not located in reference table - 003") {

    val id = Array("003")
    val name = Array("Test case : Check trcblty_fld_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,sor_cd) as trcblty_fld_cd from 
      """+dbname+"""_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT""")

    val result2 = sqlContext.sql("""select distinct concat(a.bhi_home_plan_id,a.trcblty_fld_cd) as trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('trcblty_fld_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,sor_cd) as trcblty_fld_cd from  '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT where concat(bhi_home_plan_id,sor_cd) in (select distinct concat(a.bhi_home_plan_id,a.trcblty_fld_cd) as trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('trcblty_fld_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,sor_cd) as trcblty_fld_cd from  '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT where concat(bhi_home_plan_id,sor_cd) in (select distinct concat(a.bhi_home_plan_id,a.trcblty_fld_cd) as trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('trcblty_fld_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Detail Error-Check cpt_hcpcs_cd column values not located in reference table - 004") {

    val id = Array("004")
    val name = Array("Test case : Check cpt_hcpcs_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct proc_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROC_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.cpt_hcpcs_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('cpt_hcpcs_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct proc_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROC_CD_INBND where proc_cd in (select distinct a.cpt_hcpcs_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('cpt_hcpcs_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct proc_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROC_CD_INBND where proc_cd in (select distinct a.cpt_hcpcs_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('cpt_hcpcs_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================

  test("Facility Detail Error-Check Error code when cpt_hcpcs_cd column values not located in reference table -  005") {

    val id = Array("005")
    val name = Array("Test case : Check Error code when cpt_hcpcs_cd column values not located in reference table")

    
    val result1 = sqlContext.sql("""select distinct proc_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROC_CD_INBND""")
    

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('cpt_hcpcs_cd') and a.cpt_hcpcs_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('cpt_hcpcs_cd') and a.cpt_hcpcs_cd NOT IN (select distinct proc_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROC_CD_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('cpt_hcpcs_cd') and a.cpt_hcpcs_cd NOT IN (select distinct proc_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROC_CD_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Detail Error-Check bnft_paymnt_stts_cd column values not located in reference table - 006") {

    val id = Array("006")
    val name = Array("Test case : Check bnft_paymnt_stts_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bnft_paymnt_stts_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd""")

    val result2 = sqlContext.sql("""select distinct a.bnft_paymnt_stts_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bnft_paymnt_stts_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct bnft_pymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_bnft_pymnt_stts_cd_inbnd where bnft_pymnt_stts_cd in (select distinct a.bnft_paymnt_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('bnft_paymnt_stts_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct bnft_pymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_bnft_pymnt_stts_cd_inbnd where bnft_pymnt_stts_cd in (select distinct a.bnft_paymnt_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('bnft_paymnt_stts_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Detail Error-Check Error code when bnft_paymnt_stts_cd column values not located in reference table - 007") {

    val id = Array("007")
    val name = Array("Test case : Check Error code when bnft_paymnt_stts_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bnft_paymnt_stts_cd  from """+dbname+"""_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bnft_paymnt_stts_cd') and a.bnft_paymnt_stts_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bnft_paymnt_stts_cd') and a.bnft_paymnt_stts_cd NOT IN (select distinct bnft_pymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_bnft_pymnt_stts_cd_inbnd)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bnft_paymnt_stts_cd') and a.bnft_paymnt_stts_cd NOT IN (select distinct bnft_pymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_bnft_pymnt_stts_cd_inbnd)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Detail Error-Check clm_paymnt_stts_cd column values not located in reference table - 008") {

    val id = Array("008")
    val name = Array("Test case : Check clm_paymnt_stts_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct clm_paymnt_stts_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CLM_PaYMNT_STTS_INBND""")

    val result2 = sqlContext.sql("""select distinct a.clm_paymnt_stts_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm='clm_paymnt_stts_cd' and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct clm_pymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CLM_PYMNT_STTS_INBND where clm_paymnt_stts_cd in (select distinct a.clm_paymnt_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm='clm_paymnt_stts_cd' and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct clm_pymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CLM_PYMNT_STTS_INBND where clm_paymnt_stts_cd in (select distinct a.clm_paymnt_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm='clm_paymnt_stts_cd' and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Detail Error-Check Error code when clm_paymnt_stts_cd column values not located in reference table - 009") {

    val id = Array("009")
    val name = Array("Test case : Check Error code when clm_paymnt_stts_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct clm_paymnt_stts_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CLM_PaYMNT_STTS_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm='clm_paymnt_stts_cd' and a.clm_paymnt_stts_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm='clm_paymnt_stts_cd' and a.clm_paymnt_stts_cd NOT IN (select distinct clm_pymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CLM_PYMNT_STTS_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm='clm_paymnt_stts_cd' and a.clm_paymnt_stts_cd NOT IN (select distinct clm_pymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CLM_PYMNT_STTS_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Detail Error-Check prmry_non_cvrd_rsn_cd column values not located in reference table - 010") {

    val id = Array("010")
    val name = Array("Test case : Check prmry_non_cvrd_rsn_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.prmry_non_cvrd_rsn_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('prmry_non_cvrd_rsn_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('prmry_non_cvrd_rsn_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('prmry_non_cvrd_rsn_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }

  //============================================================
  
  test("Facility Detail Error-Check Error code when prmry_non_cvrd_rsn_cd column values not located in reference table - 011") {

    val id = Array("011")
    val name = Array("Test case : Check Error code when prmry_non_cvrd_rsn_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('prmry_non_cvrd_rsn_cd') and a.prmry_non_cvrd_rsn_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('prmry_non_cvrd_rsn_cd') and a.prmry_non_cvrd_rsn_cd NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('prmry_non_cvrd_rsn_cd') and a.prmry_non_cvrd_rsn_cd NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
   test("Facility Detail Error-Check non_cvrd_rsn_cd_2 column values not located in reference table - 012") {

    val id = Array("012")
    val name = Array("Test case : Check non_cvrd_rsn_cd_2 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.prmry_non_cvrd_rsn_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_2') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where prmry_non_cvrd_rsn_cd in (select distinct a.prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_2') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where prmry_non_cvrd_rsn_cd in (select distinct a.prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_2') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================

  test("Facility Detail Error-Check Error code when non_cvrd_rsn_cd_2 column values not located in reference table - 013") {

    val id = Array("013")
    val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_2 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_2') and a.non_cvrd_rsn_cd_2 NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_2') and a.non_cvrd_rsn_cd_2 NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_2') and a.non_cvrd_rsn_cd_2 NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
   test("Facility Detail Error-Check non_cvrd_rsn_cd_3 column values not located in reference table - 014") {

    val id = Array("014")
    val name = Array("Test case : Check non_cvrd_rsn_cd_3 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.prmry_non_cvrd_rsn_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_3') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_3') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_3') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================

  test("Facility Detail Error-Check Error code when non_cvrd_rsn_cd_3 column values not located in reference table - 015") {

    val id = Array("015")
    val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_3 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_3') and a.non_cvrd_rsn_cd_3 NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_3') and a.non_cvrd_rsn_cd_3 NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_3') and a.non_cvrd_rsn_cd_3 NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
   test("Facility Detail Error-Check non_cvrd_rsn_cd_4 column values not located in reference table - 016") {

    val id = Array("016")
    val name = Array("Test case : Check non_cvrd_rsn_cd_4 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.prmry_non_cvrd_rsn_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_4') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_4') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_4') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================

  test("Facility Detail Error-Check Error code when non_cvrd_rsn_cd_4 column values not located in reference table - 017") {

    val id = Array("017")
    val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_4 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd_4 from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_4 NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_4 NOT IN (select distinct non_cvrd_rsn_cd_4 from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_4 NOT IN (select distinct non_cvrd_rsn_cd_4 from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Detail Error-Check rvnu_cd column values not located in reference table - 018") {

    val id = Array("018")
    val name = Array("Test case : Check rvnu_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct rvnu_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_RVNU_CD_INBND """)

    val result2 = sqlContext.sql("""select distinct a.prmry_non_cvrd_rsn_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('rvnu_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct rvnu_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_RVNU_CD_INBND where rvnu_cd in (elect distinct a.prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('rvnu_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct rvnu_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_RVNU_CD_INBND where rvnu_cd in (elect distinct a.prmry_non_cvrd_rsn_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('rvnu_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Detail Error-Check Error code when rvnu_cd column values not located in reference table - 019") {

    val id = Array("019")
    val name = Array("Test case : Check Error code when rvnu_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct rvnu_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_RVNU_CD_INBND """)

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('rvnu_cd') and a.rvnu_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('rvnu_cd') and a.rvnu_cd NOT IN (select distinct rvnu_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_RVNU_CD_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('rvnu_cd') and a.rvnu_cd NOT IN (select distinct rvnu_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_RVNU_CD_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }

 //============================================================

  test("Facility Detail Error-Check Error code when clm_line_nbr not in correct nu-meric format - 020") {

    val id = Array("020")
    val name = Array("Test case : Check Error code when clm_line_nbr not in correct nu-meric format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr rlike '[^0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("310") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr rlike '[^0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr rlike '[^0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Detail Error-Check Error code when clm_line_nbr less than 000 - 021") {

    val id = Array("021")
    val name = Array("Test case : Check Error code when clm_line_nbr less than 000")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr < 000""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr < 000")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr < 000")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Detail Error-Check Error code when clm_line_nbr exceeds 999 - 022") {

    val id = Array("022")
    val name = Array("Test case : Check Error code when clm_line_nbr exceeds 999")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr > 999""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr > 999")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('clm_line_nbr') and b.clm_line_nbr > 999")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
   test("Facility Detail Error-Check Error code when adjstmnt_sqnc_nbr not in correct nu-meric format - 023") {

    val id = Array("023")
    val name = Array("Test case : Check Error code when adjstmnt_sqnc_nbr not in correct nu-meric format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('adjstmnt_sqnc_nbr') and b.adjstmnt_sqnc_nbr rlike '[^0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("310") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('adjstmnt_sqnc_nbr') and b.adjstmnt_sqnc_nbr rlike '[^0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('adjstmnt_sqnc_nbr') and b.adjstmnt_sqnc_nbr rlike '[^0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Detail Error-Check Error code when prmry_non_cvrd_rsn_cd is not equal to '00','70','D' - 024") {

    val id = Array("024")
    val name = Array("Test case : Check Error code when prmry_non_cvrd_rsn_cd is not equal to '00','70','D'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('prmry_non_cvrd_rsn_cd') and b.prmry_non_cvrd_rsn_cd NOT IN ('00','70','D')""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('prmry_non_cvrd_rsn_cd') and b.prmry_non_cvrd_rsn_cd NOT IN ('00','70','D')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('prmry_non_cvrd_rsn_cd') and b.prmry_non_cvrd_rsn_cd NOT IN ('00','70','D')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
    test("Facility Detail Error-Check Error code when non_cvrd_rsn_cd_2 is not equal to '00','70','D' - 025") {

    val id = Array("025")
    val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_2 is not equal to '00','70','D'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_rsn_cd_2') and b.non_cvrd_rsn_cd_2 NOT IN ('00','70','D')""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_2') and b.non_cvrd_rsn_cd_2 NOT IN ('00','70','D')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_2') and b.non_cvrd_rsn_cd_2 NOT IN ('00','70','D')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
    
   test("Facility Detail Error-Check Error code when non_cvrd_rsn_cd_3 is not equal to '00','70','D' - 026") {

    val id = Array("026")
    val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_3 is not equal to '00','70','D'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_rsn_cd_3') and b.non_cvrd_rsn_cd_3 NOT IN ('00','70','D')""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_3') and b.non_cvrd_rsn_cd_3 NOT IN ('00','70','D')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_3') and b.non_cvrd_rsn_cd_3 NOT IN ('00','70','D')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
     
   test("Facility Detail Error-Check Error code when non_cvrd_rsn_cd_4 is not equal to '00','70','D' - 027") {

    val id = Array("027")
    val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_4 is not equal to '00','70','D'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_rsn_cd_4') and b.non_cvrd_rsn_cd_4 NOT IN ('00','70','D')""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_4') and b.non_cvrd_rsn_cd_4 NOT IN ('00','70','D')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_4') and b.non_cvrd_rsn_cd_4 NOT IN ('00','70','D')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Detail Error-Check Error code when sbmtd_amt not in correct decimal format - 028") {

    val id = Array("028")
    val name = Array("Test case : Check Error code when sbmtd_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('sbmtd_amt') and b.sbmtd_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('sbmtd_amt') and b.sbmtd_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('sbmtd_amt') and b.sbmtd_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
    test("Facility Detail Error-Check Error code when sbmtd_amt is less than or equal to -0 -029") {

    val id = Array("029")
    val name = Array("Test case : Check Error code when sbmtd_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('sbmtd_amt') and b.sbmtd_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('sbmtd_amt') and b.sbmtd_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('sbmtd_amt') and b.sbmtd_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
    
    test("Facility Detail Error-Check Error code when non_cvrd_amt not in correct decimal format - 030") {

    val id = Array("030")
    val name = Array("Test case : Check Error code when non_cvrd_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_amt') and b.non_cvrd_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_amt') and b.non_cvrd_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
        val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_amt') and b.non_cvrd_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
   
    test("Facility Detail Error-Check Error code when non_cvrd_amt is less than or equal to -0 - 031") {

    val id = Array("031")
    val name = Array("Test case : Check Error code when non_cvrd_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_amt') and b.non_cvrd_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_amt') and b.non_cvrd_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_amt') and b.non_cvrd_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
    
    test("Facility Detail Error-Check Error code when alwd_amt not in correct decimal format - 032") {

    val id = Array("032")
    val name = Array("Test case : Check Error code when alwd_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('alwd_amt') and b.alwd_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('alwd_amt') and b.alwd_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('alwd_amt') and b.alwd_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
   
    test("Facility Detail Error-Check Error code when alwd_amt is less than or equal to -0 -  033") {

    val id = Array("033")
    val name = Array("Test case : Check Error code when alwd_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('alwd_amt') and b.alwd_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('alwd_amt') and b.alwd_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('alwd_amt') and b.alwd_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
    
   test("Facility Detail Error-Check Error code when paymnt_amt not in correct decimal format - 034") {

    val id = Array("034")
    val name = Array("Test case : Check Error code when paymnt_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('paymnt_amt') and b.paymnt_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('paymnt_amt') and b.paymnt_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('paymnt_amt') and b.paymnt_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
    test("Facility Detail Error-Check Error code when paymnt_amt is less than or equal to -0 - 035") {

    val id = Array("035")
    val name = Array("Test case : Check Error code when paymnt_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('paymnt_amt') and b.paymnt_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('paymnt_amt') and b.paymnt_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('paymnt_amt') and b.paymnt_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
    
   test("Facility Detail Error-Check Error code when cob_tpl_amt not in correct decimal format 036") {

    val id = Array("036")
    val name = Array("Test case : Check Error code when cob_tpl_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('cob_tpl_amt') and b.cob_tpl_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('cob_tpl_amt') and b.cob_tpl_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('cob_tpl_amt') and b.cob_tpl_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Detail Error-Check Error code when cob_tpl_amt is less than or equal to -0 - 037") {

    val id = Array("037")
    val name = Array("Test case : Check Error code when cob_tpl_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('cob_tpl_amt') and b.cob_tpl_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('cob_tpl_amt') and b.cob_tpl_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('cob_tpl_amt') and b.cob_tpl_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
    
   test("Facility Detail Error-Check Error code when coinsrn_amt not in correct decimal format -  038") {

    val id = Array("038")
    val name = Array("Test case : Check Error code when coinsrn_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('coinsrn_amt') and b.coinsrn_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('coinsrn_amt') and b.coinsrn_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('coinsrn_amt') and b.coinsrn_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Detail Error-Check Error code when coinsrn_amt is less than or equal to -0 - 039") {

    val id = Array("039")
    val name = Array("Test case : Check Error code when coinsrn_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('coinsrn_amt') and b.coinsrn_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('coinsrn_amt') and b.coinsrn_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('coinsrn_amt') and b.coinsrn_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Detail Error-Check Error code when cpay_amt not in correct decimal format - 040") {

    val id = Array("040")
    val name = Array("Test case : Check Error code when cpay_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('cpay_amt') and b.cpay_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('cpay_amt') and b.cpay_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('cpay_amt') and b.cpay_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Detail Error-Check Error code when cpay_amt is less than or equal to -0 - 041") {

    val id = Array("041")
    val name = Array("Test case : Check Error code when cpay_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('cpay_amt') and b.cpay_amt > -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('cpay_amt') and b.cpay_amt > -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('cpay_amt') and b.cpay_amt > -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
   //============================================================
   
    test("Facility Detail Error-Check Error code when ddctbl_amt not in correct decimal format - 042") {

    val id = Array("042")
    val name = Array("Test case : Check Error code when ddctbl_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('ddctbl_amt') and b.ddctbl_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('ddctbl_amt') and b.ddctbl_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('ddctbl_amt') and b.ddctbl_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
   
    test("Facility Detail Error-Check Error code when ddctbl_amt is less than or equal to -0 - 043") {

    val id = Array("043")
    val name = Array("Test case : Check Error code when ddctbl_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('ddctbl_amt') and b.ddctbl_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('ddctbl_amt') and b.ddctbl_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('ddctbl_amt') and b.ddctbl_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }

  //============================================================

  test("Facility Detail Error- Check Error code when home_plan_cd column has spaces - 044") {

    val id = Array("044")
    val name = Array("Test case : Check Error code when home_plan_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('bhi_home_plan_id') and length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('bhi_home_plan_id') and length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('bhi_home_plan_id') and length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Detail Error- Check Error code when clm_id column has spaces - 045") {

    val id = Array("045")
    val name = Array("Test case : Check Error code when clm_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('clm_id') and length(trim(regexp_replace(coalesce(b.clm_id, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_id') and length(trim(regexp_replace(coalesce(b.clm_id, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_id') and length(trim(regexp_replace(coalesce(b.clm_id, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
   test("Facility Detail Error- Check Error code when trcblty_fld_cd column has spaces - 046") {

    val id = Array("046")
    val name = Array("Test case : Check Error code when trcblty_fld_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('trcblty_fld_cd') and length(trim(regexp_replace(coalesce(b.trcblty_fld_cd, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('trcblty_fld_cd') and length(trim(regexp_replace(coalesce(b.trcblty_fld_cd, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('trcblty_fld_cd') and length(trim(regexp_replace(coalesce(b.trcblty_fld_cd, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Detail Error- Check Error code when bnft_paymnt_stts_cd column has spaces - 047") {

    val id = Array("047")
    val name = Array("Test case : Check Error code when bnft_paymnt_stts_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('bnft_paymnt_stts_cd') and length(trim(regexp_replace(coalesce(b.bnft_paymnt_stts_cd, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('bnft_paymnt_stts_cd') and length(trim(regexp_replace(coalesce(b.bnft_paymnt_stts_cd, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('bnft_paymnt_stts_cd') and length(trim(regexp_replace(coalesce(b.bnft_paymnt_stts_cd, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
    test("Facility Detail Error- Check Error code when clm_paymnt_stts_cd column has spaces - 048") {

    val id = Array("048")
    val name = Array("Test case : Check Error code when clm_paymnt_stts_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm='clm_paymnt_stts_cd' and length(trim(regexp_replace(coalesce(b.clm_paymnt_stts_cd, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm='clm_paymnt_stts_cd' and length(trim(regexp_replace(coalesce(b.clm_paymnt_stts_cd, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm='clm_paymnt_stts_cd' and length(trim(regexp_replace(coalesce(b.clm_paymnt_stts_cd, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
    
    test("Facility Detail Error- Check Error code when sbmtd_amt column has spaces - 049") {

    val id = Array("049")
    val name = Array("Test case : Check Error code when sbmtd_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('sbmtd_amt') and length(trim(regexp_replace(coalesce(b.sbmtd_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('sbmtd_amt') and length(trim(regexp_replace(coalesce(b.sbmtd_amt, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('sbmtd_amt') and length(trim(regexp_replace(coalesce(b.sbmtd_amt, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================

  test("Facility Detail Error- Check Error code when non_cvrd_amt column has spaces - 050") {

    val id = Array("050")
    val name = Array("Test case : Check Error code when non_cvrd_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('non_cvrd_amt') and length(trim(regexp_replace(coalesce(b.non_cvrd_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join'''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('non_cvrd_amt') and length(trim(regexp_replace(coalesce(b.non_cvrd_amt, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join'''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('non_cvrd_amt') and length(trim(regexp_replace(coalesce(b.non_cvrd_amt, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Detail Error- Check Error code when alwd_amt column has spaces - 051") {

    val id = Array("051")
    val name = Array("Test case : Check Error code when alwd_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('alwd_amt') and length(trim(regexp_replace(coalesce(b.alwd_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('alwd_amt') and length(trim(regexp_replace(coalesce(b.alwd_amt, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('alwd_amt') and length(trim(regexp_replace(coalesce(b.alwd_amt, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Detail Error- Check Error code when paymnt_amt column has spaces - 052") {

    val id = Array("052")
    val name = Array("Test case : Check Error code when paymnt_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('paymnt_amt') and length(trim(regexp_replace(coalesce(b.paymnt_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('paymnt_amt') and length(trim(regexp_replace(coalesce(b.paymnt_amt, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('paymnt_amt') and length(trim(regexp_replace(coalesce(b.paymnt_amt, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Detail Error- Check Error code when cob_tpl_amt column has spaces - 053") {

    val id = Array("053")
    val name = Array("Test case : Check Error code when cob_tpl_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('cob_tpl_amt') and length(trim(regexp_replace(coalesce(b.cob_tpl_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('cob_tpl_amt') and length(trim(regexp_replace(coalesce(b.cob_tpl_amt, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('cob_tpl_amt') and length(trim(regexp_replace(coalesce(b.cob_tpl_amt, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Detail Error- Check Error code when coinsrn_amt column has spaces - 054") {

    val id = Array("054")
    val name = Array("Test case : Check Error code when coinsrn_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('coinsrn_amt') and length(trim(regexp_replace(coalesce(b.coinsrn_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('coinsrn_amt') and length(trim(regexp_replace(coalesce(b.coinsrn_amt, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('coinsrn_amt') and length(trim(regexp_replace(coalesce(b.coinsrn_amt, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
   test("Facility Detail Error- Check Error code when cpay_amt column has spaces - 055") {

    val id = Array("055")
    val name = Array("Test case : Check Error code when cpay_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('cpay_amt') and length(trim(regexp_replace(coalesce(b.cpay_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('cpay_amt') and length(trim(regexp_replace(coalesce(b.cpay_amt, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('cpay_amt') and length(trim(regexp_replace(coalesce(b.cpay_amt, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Detail Error- Check Error code when ddctbl_amt column has spaces - 056") {

    val id = Array("056")
    val name = Array("Test case : Check Error code when ddctbl_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('ddctbl_amt') and length(trim(regexp_replace(coalesce(b.ddctbl_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('ddctbl_amt') and length(trim(regexp_replace(coalesce(b.ddctbl_amt, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('ddctbl_amt') and length(trim(regexp_replace(coalesce(b.ddctbl_amt, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimDetail/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }

 }