package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession

import org.apache.spark.sql.SparkSession
import java.io.File
import org.apache.spark.sql.DataFrame
import com.anthem.hca.ndw.utils.PCADX_SCL_TA_Utilities._
import java.text.SimpleDateFormat
import org.apache.spark.sql.SaveMode
import java.util.Calendar
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel
import java.util.Date
import java.text.SimpleDateFormat



object PCADX_SCL_TA_L2_Product_TGT {


  
def main(args: Array[String]) {
  


val dbname: String = args(0)
val SUBJ_AREA_NM: String=args(1)
val PRCS_NM: String=args(2)


val appName = "Datapipe from L2 cases for Product" // we will make this generic going forward

val warehouseLocation = new File("/user/hive/warehouse").getAbsolutePath
val options = Map("path" -> "/user/hive/warehouse")

val spark = SparkSession
.builder()
.appName(appName)
.config("spark.sql.warehouse.dir", warehouseLocation)
.enableHiveSupport()
.getOrCreate()

spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode","INFER_ONLY")
spark.conf.set("spark.sql.crossJoin.enabled","true")

import spark.implicits._
val home_plan_id =spark.sql("select distinct bhi_home_plan_id from "+dbname+"_pcandw1ph_nogbd_r000_wh.bot_bcbsa_plan_sbmsn")
val  home_plan=home_plan_id.select("bhi_home_plan_id").collect().map(_(0)).toList

spark.sql("SELECT count(*) as CNT,bhi_home_plan_id   FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod FH group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Total")

spark.sql("SELECT count(*) as CNT,bhi_home_plan_id   FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_err FH group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("Error")

spark.sql("select bhi_home_plan_id,SUM(CASE WHEN lower(SEL.FIELD_NM)='bhi_prod_catgry_cd' THEN SEL.CNT ELSE 0 END) AS PRODCat11 from (select err_id,1 as CNT ,clmn_nm as FIELD_NM,load_log_key  from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_prod'   and lower(clmn_nm) in  ('bhi_prod_catgry_cd')) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod b on  SEL.err_id=b.err_id and SEL.load_log_key=b.load_log_key  group by bhi_home_plan_id ").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("ProdDetails")

// Rule 1-4
home_plan.foreach(bhi_home_plan_id => {

val sqlbshow=" select a.CNT*100/(b.CNT) as PRODAll10  FROM  (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod_err FH where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) a join (  SELECT count(*) as CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b"  

val sqlb=" select a.CNT*100/(b.CNT) as PRODAll10  FROM  (  SELECT CNT  FROM Error FH where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) a join (  SELECT  CNT  FROM Total FH  where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b" 

var b=spark.sql(sqlb).withColumn("sql",lit(sqlbshow))
	
//Rule reject columns

val sqlashow = "select PRODCat11*100/Total_CNT as PRODCat11 from  (select SUM(CASE WHEN SEL.FIELD_NM='bhi_prod_catgry_cd' THEN SEL.CNT ELSE 0 END) AS PRODCat11 from (select err_id,1 as CNT ,clmn_nm,load_log_key  as FIELD_NM from "+dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_ERR_LOG  where lower(tbl_nm) = 'bcbsa_prod'   and lower(clmn_nm) in  ('bhi_prod_catgry_cd')) SEL join "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod b on  SEL.err_id=b.err_id and SEL.load_log_key=b.load_log_key  and  bhi_home_plan_id='"+bhi_home_plan_id +"' ) a cross join (SELECT count(*) as Total_CNT  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prod FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"

val sqla = "select PRODCat11*100/Total_CNT as PRODCat11 from  (select * from ProdDetails where  bhi_home_plan_id='"+bhi_home_plan_id +"' ) a cross join (SELECT CNT as Total_CNT  FROM Total FH where   bhi_home_plan_id='"+bhi_home_plan_id +"') total"

 val a=spark.sql(sqla).withColumn("sql",lit(sqlashow))









val e=output(spark, TestIDGen(spark,ReportOutput(spark,dbname,a).union(ReportOutput(spark,dbname,b))),SUBJ_AREA_NM,PRCS_NM, bhi_home_plan_id.toString())

e.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_RSLT")
//e(1).write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_SQL")


})



}
  
  

}