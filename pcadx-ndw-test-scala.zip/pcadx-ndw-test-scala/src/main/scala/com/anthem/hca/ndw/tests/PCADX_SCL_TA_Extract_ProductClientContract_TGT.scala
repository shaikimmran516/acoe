package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import java.util.Date
import java.text.SimpleDateFormat

object PCADX_SCL_TA_Extract_ProductClientContract_TGT {
 
  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_ProductClientContract_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}


class PCADX_SCL_TA_Extract_ProductClientContract_TGT(dbname : String, env: String) extends FunSuite {

     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
  
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Extract"
      val prcss = "ProductClientContract"
      
 
    test("PCCExtract -Validate One record for each BHI Home Plan ID,Home Product ID,Acoount,Group & SunGroup- 001") {
    
    val id = Array("001")
    val name = Array("Test case : Validate One record for each BHI Home Plan ID,Home Product ID,Acoount,Group & SunGroup")
    
    val result = sqlContext.sql("""select bhi_home_plan_id ,home_plan_prod_id,acct_id,grp_id,subgrp_id,count(*) as count from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct group by bhi_home_plan_id,home_plan_prod_id,acct_id,grp_id,subgrp_id""")
    result.createOrReplaceTempView("resultDF")
    
    val invalid = sqlContext.sql("""select * from resultDF where count > 1 """)
    
    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id ,home_plan_prod_id,acct_id,grp_id,subgrp_id,count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct group by bhi_home_plan_id,home_plan_prod_id,acct_id,grp_id,subgrp_id) where count > 1")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_NO','GROUP','SUB_GROUP','COUNT'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id ,home_plan_prod_id,acct_id,grp_id,subgrp_id,count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct group by bhi_home_plan_id,home_plan_prod_id,acct_id,grp_id,subgrp_id")
      val data = Array("'BHI HPID','PRODUCT_ID','ACCOUNT_NO','GROUP','SUB_GROUP','COUNT'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  //===========================================
  
     
    
   test("PCCExtract -Validate that all the records have the correct [BHI Home Plan ID] as per Anthem - 002") {
     
    val id = Array("002")
    val name = Array("Test case : Validate that all the records have the correct [BHI Home Plan ID] as per Anthem")

    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,err_id,exclsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') and err_id = '0' and exclsn_ind = '0' """)
     
         
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') and err_id = '0' and exclsn_ind = '0' ")
      val data = Array("'BHI HPID','PRODUCT_ID','ERR_ID','EXCLSN_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') and err_id = '0' and exclsn_ind = '0' ")
      val data = Array("'BHI HPID','PRODUCT_ID','ERR_ID','EXCLSN_ID' : No Invalid Values Found")
            
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  //===========================================
   
   test("PCCExtract -Validate that BHI Home Plan ID is not NULL or contains blank spaces  - 003") {
    
    val id = Array("003")
    val name = Array("Test case : Validate that BHI Home Plan ID is not NULL or contains blank spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(bhi_home_plan_id, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }  
  
  //===========================================

   
  test("PCCExtract -Validate that  BHI Home Plan ID does not contain Special Characters - 004") {
    
    val id = Array("004")
    val name = Array("Test case : Validate that  BHI Home Plan ID does not contain Special Characters")

    
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','PRODUCT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.bhi_home_plan_id  LIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','PRODUCT_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
    
  //===========================================
  

  test("PCCExtract -Validate that HomePlan ProductID field is not NULL or contains blank spaces - 005") {
    
    val id = Array("005")
    val name = Array("Test case : Validate that HomePlan ProductID field is not NULL or contains blank spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(home_plan_prod_id, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(home_plan_prod_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(home_plan_prod_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    
  }
  
  //===========================================
  
  test("PCCExtract -Validate that HomePlan ProductID field does not contain Special Characters - 006") {
    
    val id = Array("006")
    val name = Array("Test case : Validate that HomePlan ProductID field does not contain Special Characters")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.home_plan_prod_id  RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.home_plan_prod_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','PRODUCT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.home_plan_prod_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','PRODUCT_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
  
  test("PCCExtract -Validate that Account field is not NULL or contains blank spaces - 007") {
    
    val id = Array("007")
    val name = Array("Test case : Validate that Account field is not NULL or contains blank spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,acct_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(acct_id, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(acct_id, ''),' ' ''))=0 ")
      val data = Array("'BHI HPID','ACCOUNT_NO'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(acct_id, ''),' ' ''))=0 ")
      val data = Array("'BHI HPID','ACCOUNT_NO' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  //===========================================
  
   test("PCCExtract -Validate that Account field does not contain Special Characters - 008") {
    
    val id = Array("008")
    val name = Array("Test case : Validate that Account field does not contain Special Characters")

    
    val result = sqlContext.sql("""select bhi_home_plan_id,acct_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.acct_id  RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.acct_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','ACCOUNT_NO'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.acct_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','ACCOUNT_NO' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
  
 test("PCCExtract -Validate that Group field is not NULL or contains blank spaces - 009") {
    
    val id = Array("009")
    val name = Array("Test case : Validate that Group field is not NULL or contains blank spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,grp_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(grp_id, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,grp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(grp_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','GROUP'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,grp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(grp_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','GROUP' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
 }
 
   //===========================================
 
   test("PCCExtract -Validate that Group field does not contain Special Characters - 010") {
    
    val id = Array("010")
    val name = Array("Test case : Validate that Group field does not contain Special Characters")
       
    val result = sqlContext.sql("""select bhi_home_plan_id,grp_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.grp_id  RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,grp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.grp_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','GROUP'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,grp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.grp_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','GROUP' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
 
   test("PCCExtract -Validate that SubGroup field is not NULL or contains blank spaces - 011") {
    
     val id = Array("011")
    val name = Array("Test case : Validate that SubGroup field is not NULL or contains blank spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,subgrp_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(subgrp_id, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,subgrp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(subgrp_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','SUB_GROUP'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,subgrp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(subgrp_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','SUB_GROUP' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
   //===========================================
   
   test("PCCExtract -Validate that SubGroup field does not contain Special Characters - 012") {
   
     val id = Array("012")
    val name = Array("Test case : Validate that SubGroup field does not contain Special Characters")

    val result = sqlContext.sql("""select bhi_home_plan_id,subgrp_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
 where a.subgrp_id  RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,subgrp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.subgrp_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','SUB_GROUP'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,subgrp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.subgrp_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','SUB_GROUP' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
  
 test("PCCExtract -Validate SubGroup='NOSUB' if Group='NOGRP' - 013") {
    
   val id = Array("013")
    val name = Array("Test case : Validate SubGroup='NOSUB' if Group='NOGRP")

    val result = sqlContext.sql("""select bhi_home_plan_id,subgrp_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where grp_id='NOGRP' and subgrp_id!='NOSUB'""")
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,subgrp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where grp_id='NOGRP' and subgrp_id!='NOSUB'")
      val data = Array("'BHI HPID','SUB_GROUP'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,subgrp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where grp_id='NOGRP' and subgrp_id!='NOSUB'")
      val data = Array("'BHI HPID','SUB_GROUP' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    
    
 }
  
  //===========================================
 
   test("PCCExtract -Validate that SIC Code is not NULL or contains blank spaces - 014") {
    
     val id = Array("014")
    val name = Array("Test case : Validate that SIC Code is not NULL or contains blank spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,sic_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(sic_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,sic_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(sic_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','SIC_CODE'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,sic_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(sic_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','SIC_CODE' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
 
   //===========================================
 
   test("PCCExtract -Validate that SIC Code does not contain Double Quote Character - 015") {
    
     val id = Array("015")
     val name = Array("Test case : Validate that SIC Code does not contain Double Quote Character")

    
    val result = sqlContext.sql("""select bhi_home_plan_id,sic_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.sic_cd   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,sic_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.sic_cd   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','SIC_CODE '")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
       val query = Array("Test Query : select bhi_home_plan_id,sic_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.sic_cd   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','SIC_CODE ' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    
    
 }
  
  //===========================================
 
 test("PccExtract -Check SIC Code values not located in reference table - 016") {

   val id = Array("016")
   val name = Array("Test case : Check SIC Code values not located in reference table")

    val result1 = sqlContext.sql("""select distinct indstry_grpg_sic_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_sic_cd_inbnd""")

    val result2 = sqlContext.sql("""select distinct sic_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0""")

    val result = result2.except(result1)
    
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct sic_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0 and sic_cd not in (select distinct indstry_grpg_sic_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_sic_cd_inbnd)")
       val data = Array("SIC_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct sic_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0 and sic_cd not in (select distinct indstry_grpg_sic_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_sic_cd_inbnd)")
      val data = Array("SIC_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
  
   //===========================================
  
 test("PCCExtract -Validate that NAICS Code does not contain Double Quote Character - 017") {
    
   val id = Array("017")
    val name = Array("Test case : Validate that NAICS Code does not contain Double Quote Character")

        
    val result = sqlContext.sql("""select bhi_home_plan_id,naics_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.naics_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,naics_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.naics_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','NAICS_CODE '")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,naics_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.naics_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','NAICS_CODE' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    
    
 }
  
  //===========================================
 
 test("PccExtract -Check NAICS Code values not located in reference table - 018") {

    val id = Array("018")
    val name = Array("Test case : Check NAICS Code values not located in reference table")

    val result1 = sqlContext.sql("""select distinct indstry_grpg_naics_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_naics_cd_inbnd""")

    val result2 = sqlContext.sql("""select distinct naics_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind=0 and naics_cd != 'NA' """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct naics_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind=0 and naics_cd != 'NA' and naics_cd not in (select distinct indstry_grpg_naics_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_naics_cd_inbnd)")
      val data = Array("NAICS_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct naics_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind=0 and naics_cd != 'NA' and naics_cd not in (select distinct indstry_grpg_naics_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_indstry_grpg_naics_cd_inbnd)")
      val data = Array("NAICS_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
 
  //===========================================
 
  test("PccExtract -Check NAICS Code default value - 019") {

    val id = Array("019")
    val name = Array("Test case : Check NAICS Code default value 'NA'")

    val result = sqlContext.sql("""select distinct a.naics_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where naics_cd='NA' """)
    
    if (result.count == 1) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct a.naics_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where naics_cd='NA'")
      val data = Array("NAICS_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct a.naics_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where naics_cd='NA'")
      val data = Array("NAICS_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }  //  Repeated at number 62 case
  
  //===========================================
  
  test("PCCExtract -Validate that National Account Indicator does not contain Null or Spaces - 020") {
    
    val id = Array("020")
    val name = Array("Test case : Validate that National Account Indicator does not contain Null or Spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,natl_acct_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(natl_acct_ind, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,natl_acct_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(natl_acct_ind, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','National_Account_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,natl_acct_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(natl_acct_ind, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','National_Account_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  //===========================================
  
  test("PCCExtract -Validate that National Account Indicator does not  Double Quote Character - 021") {
    
    val id = Array("021")
    val name = Array("Test case : Validate that National Account Indicator does not  Double Quote Character")

           
    val result = sqlContext.sql("""select bhi_home_plan_id,natl_acct_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.natl_acct_ind  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,natl_acct_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.natl_acct_ind  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','National_Account_Indicator '")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,natl_acct_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.natl_acct_ind  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','National_Account_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
 
   //===========================================
  
   test("PccExtract -Check National Account Indicator default value - 022") {

    val id = Array("022")
    val name = Array("Test case : Check National Account Indicator default value")

    val result = sqlContext.sql("""select distinct a.natl_acct_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where natl_acct_ind !='Y' and natl_acct_ind != 'N' """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct a.natl_acct_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where natl_acct_ind !='Y' and natl_acct_ind != 'N' ")
      val data = Array("National_Account_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct a.natl_acct_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where natl_acct_ind !='Y' and natl_acct_ind != 'N' ")
      val data = Array("Invalid_National_Account_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
  
  //===========================================
  
  
  test("PCCExtract -Validate that ASO Code does not contain Null or Spaces - 023") {
    
    val id = Array("023")
    val name = Array("Test case : Validate that ASO Code does not contain Null or Spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,aso_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(aso_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,aso_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(aso_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','ASO_CODE'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,aso_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(aso_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','ASO_CODE' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
   //===========================================
  
  test("PCCExtract -Validate that ASO Code does not contain Double Quote Character - 024") {
   
    val id = Array("024")
    val name = Array("Test case : Validate that ASO Code does not contain Double Quote Character")

           
    val result = sqlContext.sql("""select bhi_home_plan_id,aso_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.aso_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,aso_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.aso_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','ASO_CODE '")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,aso_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.aso_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','ASO_CODE' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
 
   //===========================================
  
 test("PccExtract -Check ASO Code values not located in reference table - 025") {

    val id = Array("025")
    val name = Array("Test case : Check ASO Code values not located in reference table")

    val result1 = sqlContext.sql("""select distinct aso_ind_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_aso_cd_inbnd""")

    val result2 = sqlContext.sql("""select distinct aso_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0""")

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct aso_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0 and aso_cd noy in (select distinct aso_ind_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_aso_cd_inbnd)")
      val data = Array("'ASO_CODE' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct aso_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0 and aso_cd noy in (select distinct aso_ind_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_aso_cd_inbnd)")
      val data = Array("Inavlid ASO_CODE'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
 
  //===========================================
 
 test("PccExtract -Check ASO Code Indicator Valid value - 026") {

    val id = Array("026")
    val name = Array("Test case : Check ASO Code Indicator Valid value")

    val result = sqlContext.sql("""select distinct a.aso_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where aso_cd !='Y' and aso_cd != 'N' and aso_cd != 'O' """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct a.aso_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where aso_cd !='Y' and aso_cd != 'N' and aso_cd != 'O'")
      val data = Array("'ASO_Code_Value' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct a.aso_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where aso_cd !='Y' and aso_cd != 'N' and aso_cd != 'O'")
      val data = Array("Invalid_ASO_Code_Value'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
  
  //===========================================
  
 
  test("PCCExtract -Validate that Group/Individual Code does not contain Null or Spaces  - 027") {
    
    val id = Array("027")
    val name = Array("Test case : Validate that Group/Individual Code does not contain Null or Spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,cntrct_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(cntrct_type_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cntrct_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(cntrct_type_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Group/Individual_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cntrct_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(cntrct_type_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Group/Individual_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  //===========================================
  
   test("PCCExtract -Validate that Group/Individual Code does not contain Double Quote Character - 028") {
    
     val id = Array("028")
    val name = Array("Test case : Validate that Group/Individual Code does not contain Double Quote Character")

         
    val result = sqlContext.sql("""select bhi_home_plan_id,cntrct_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.cntrct_type_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cntrct_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.cntrct_type_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Group/Individual_Code '")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cntrct_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.cntrct_type_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Group/Individual_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
 
   //===========================================
   
 test("PccExtract -Check Group/Individual Code  values not located in reference table - 029") {

    val id = Array("029")
    val name = Array("Test case : Check Group/Individual Code  values not located in reference table")

    val result1 = sqlContext.sql("""select distinct grp_indiv_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_grp_indiv_cd_inbnd""")

    val result2 = sqlContext.sql("""select distinct cntrct_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0""")

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct cntrct_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0 and cntrct_type_cd not in (select distinct grp_indiv_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_grp_indiv_cd_inbnd) ")
      val data = Array("'Group/Individual_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct cntrct_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0 and cntrct_type_cd not in (select distinct grp_indiv_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_grp_indiv_cd_inbnd) ")
      val data = Array("Invalid Group/Individual_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
 
  //===========================================
  
 test("PccExtract -Check Group/Individual Code default value - 030") {

    val id = Array("030")
    val name = Array("Test case : Check Group/Individual Code default value")

    val result = sqlContext.sql("""select distinct a.cntrct_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where cntrct_type_cd != 'GROUP' and cntrct_type_cd != 'INDIVIDUAL'  """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct a.cntrct_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where cntrct_type_cd != 'GROUP' and cntrct_type_cd != 'INDIVIDUAL' ")
      val data = Array("'Group/Individual Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct a.cntrct_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where cntrct_type_cd != 'GROUP' and cntrct_type_cd != 'INDIVIDUAL' ")
      val data = Array("Invalid_Group/Individual Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
  
  //===========================================
  
  test("PCCExtract -Validate that AlphaPrefix Code does not contain Null or Spaces - 031") {
    
    val id = Array("031")
    val name = Array("Test case : Validate that AlphaPrefix Code does not contain Null or Spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,prfx_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(prfx_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,prfx_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(prfx_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','AlphaPrefix_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,prfx_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(prfx_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','AlphaPrefix_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  //===========================================
  
   test("PCCExtract -Validate that AlphaPrefix Code does not contain Double Quote Character - 032") {
    val id = Array("032")
    val name = Array("Test case : Validate that AlphaPrefix Code does not contain Double Quote Character")
        
    val result = sqlContext.sql("""select bhi_home_plan_id,prfx_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.prfx_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,prfx_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.prfx_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','AlphaPrefix_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,prfx_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.prfx_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','AlphaPrefix_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
 
   //===========================================
  
  test("PccExtract - Validate that Alpha Prefix column value is getting correctly populated - 033") {
    val id = Array("033")
    val name = Array("Test case : Validate that Alpha Prefix column value is getting correctly populated")

    
    val result1 = sqlContext.sql(""" select distinct concat(trim(bhi_home_plan_id) , trim(bcbsa_prfx_cd))  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prfx_rfrnc  """)
    val result2 = sqlContext.sql(""" select distinct concat(trim(bhi_home_plan_id) , trim(prfx_cd))  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0""")
         
    val result = result2.except(result1)
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct concat(trim(bhi_home_plan_id) , trim(prfx_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0 not in (select distinct concat(trim(bhi_home_plan_id) , trim(bcbsa_prfx_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfx_rfrnc  where err_id = '0' and exclsn_ind = 0) ")
      val data = Array("'Invalid Alpha_Prefix_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct concat(trim(bhi_home_plan_id) , trim(prfx_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0 not in (select distinct concat(trim(bhi_home_plan_id) , trim(bcbsa_prfx_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfx_rfrnc  where err_id = '0' and exclsn_ind = 0) ")
      val data = Array("'Alpha_Prefix_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
    //===========================================
   
   
   test("PCCExtract -Validate that Custom Network Indicator does not contain Null or Spaces - 034") {
    val id = Array("034")
    val name = Array("Test case : Validate that Custom Network Indicator does not contain Null or Spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,cstm_ntwk_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(cstm_ntwk_ind, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cstm_ntwk_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(cstm_ntwk_ind, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Custom_Network_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cstm_ntwk_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(cstm_ntwk_ind, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Custom_Network_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
 
   //===========================================
   
   test("PCCExtract -Validate that Custom Network Indicator does not contain Double Quote Character - 035") {
    val id = Array("035")
    val name = Array("Test case : Validate that Custom Network Indicator does not contain Double Quote Character")
        
    val result = sqlContext.sql("""select bhi_home_plan_id,cstm_ntwk_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.cstm_ntwk_ind  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cstm_ntwk_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.cstm_ntwk_ind  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Custom_Network_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cstm_ntwk_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.cstm_ntwk_ind  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Custom_Network_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
 
   //===========================================
   
  test("PccExtract -Check Custom Network Indicator default value - 036") {

    val id = Array("036")
    val name = Array("Test case : Check Custom Network Indicator default value ")

    val result = sqlContext.sql("""select distinct a.cstm_ntwk_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where cstm_ntwk_ind !='Y' and cstm_ntwk_ind != 'N' """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct a.cstm_ntwk_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where cstm_ntwk_ind !='Y' and cstm_ntwk_ind != 'N' ")
      val data = Array("'Custom_Network_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct a.cstm_ntwk_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where cstm_ntwk_ind !='Y' and cstm_ntwk_ind != 'N' ")
      val data = Array("Invalid_Custom_Network_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
  
  //===========================================
  
  test("PCCExtract -Validate that CDHP Offered Code does not contain Null or Spaces - 037") {
    val id = Array("037")
    val name = Array("Test case : Validate that CDHP Offered Code does not contain Null or Spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,cdhp_ofrd_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(cdhp_ofrd_type_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cdhp_ofrd_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(cdhp_ofrd_type_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','CDHP_Offered_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cdhp_ofrd_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(cdhp_ofrd_type_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','CDHP_Offered_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  //===========================================
  
  test("PCCExtract -Validate that CDHP Offered Code does not contain Double Quote Character - 038") {
    val id = Array("038")
    val name = Array("Test case : Validate that CDHP Offered Code does not contain Double Quote Character")
        
    val result = sqlContext.sql("""select bhi_home_plan_id,cdhp_ofrd_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.cdhp_ofrd_type_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cdhp_ofrd_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.cdhp_ofrd_type_cd  RLIKE '%<double quote>%' ")
      val data = Array("'BHI HPID','CDHP_Offered_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cdhp_ofrd_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.cdhp_ofrd_type_cd  RLIKE '%<double quote>%' ")
      val data = Array("'BHI HPID','CDHP_Offered_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
 
   //===========================================
  
   test("PccExtract -Check CDHP Offered Code values not located in reference table - 039") {

    val id = Array("039")
    val name = Array("Test case : Check CDHP Offered Code values not located in reference table")
    
    val result1 = sqlContext.sql("""select distinct trim(cdhp_ofrd_cd) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cdhp_ofrd_cd_inbnd""")

    val result2 = sqlContext.sql("""select distinct trim(cdhp_ofrd_type_cd) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0""")

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct trim(cdhp_ofrd_type_cd) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0 and trim(cdhp_ofrd_type_cd) not in (select distinct trim(cdhp_ofrd_cd) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cdhp_ofrd_cd_inbnd) ")
      val data = Array("'CDHP_Offered_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct trim(cdhp_ofrd_type_cd) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0 and trim(cdhp_ofrd_type_cd) not in (select distinct trim(cdhp_ofrd_cd) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cdhp_ofrd_cd_inbnd) ")
      val data = Array("'CDHP_Offered_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
 
  //===========================================
  
   test("PCCExtract -Validate that Traceability Field does not contain Null or Spaces - 040") {
    val id = Array("040")
    val name = Array("Test case : Validate that Traceability Field does not contain Null or Spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,sor_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(sor_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(sor_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Traceability_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(sor_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Traceability_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  //===========================================
  
   test("PCCExtract -Validate that Traceability Field does not contain Double Quote Character - 041") {
    val id = Array("041")
    val name = Array("Test case : Validate that Traceability Field does not contain Double Quote Character")

    
        
    val result = sqlContext.sql("""select bhi_home_plan_id,sor_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.sor_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.sor_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Traceability_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,sor_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.sor_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Traceability_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
 
   //===========================================
  
   test("PCCExtract -Validate that Traceability Code value is getting correctly populated - 042") {
    val id = Array("042")
    val name = Array("Test case : Validate that Traceability Code value is getting correctly populated")

        
    val result1 = sqlContext.sql(""" select distinct concat(trim(bhi_home_plan_id) , trim(sor_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc  """)
    val result2 = sqlContext.sql(""" select distinct concat(trim(bhi_home_plan_id) , trim(sor_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0""")
         
    val result = result2.except(result1)
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :select distinct concat(trim(bhi_home_plan_id) , trim(sor_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0 not in (select distinct concat(trim(bhi_home_plan_id) , trim(sor_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc  where err_id = '0' and exclsn_ind = 0 ) ")
      val data = Array("'Invalid Traceability_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :select distinct concat(trim(bhi_home_plan_id) , trim(sor_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0 not in (select distinct concat(trim(bhi_home_plan_id) , trim(sor_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc  where err_id = '0' and exclsn_ind = 0 ) ")
      val data = Array("'Traceability_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
    
    
   //===========================================
   
  test("PCCExtract -Validate that Member Enrollment Indicator does not contain Null or Spaces - 043") {
    val id = Array("043")
    val name = Array("Test case : Validate that Member Enrollment Indicator does not contain Null or Spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,mbr_enrlmnt_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(mbr_enrlmnt_ind, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_enrlmnt_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(mbr_enrlmnt_ind, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Member_Enrollment_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_enrlmnt_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(mbr_enrlmnt_ind, ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Member_Enrollment_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
 }
 
 //===========================================
 
  test("PCCExtract -Validate that Member Enrollment Indicator does not contain Double Quote Character - 044") {
    val id = Array("044")
    val name = Array("Test case : Validate that Member Enrollment Indicator does not contain Double Quote Character")

       
    val result = sqlContext.sql("""select bhi_home_plan_id,mbr_enrlmnt_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.mbr_enrlmnt_ind  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_enrlmnt_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.mbr_enrlmnt_ind  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Member_Enrollment_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_enrlmnt_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.mbr_enrlmnt_ind  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Member_Enrollment_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
 
   //===========================================
   
  test("PccExtract - Check Member_Enrollment_Indicator default value - 045") {

    val id = Array("045")
    val name = Array("Test case : Check Member_Enrollment_Indicator default value")

    val result = sqlContext.sql("""select distinct mbr_enrlmnt_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where mbr_enrlmnt_ind !='Y' and mbr_enrlmnt_ind != 'N' """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mbr_enrlmnt_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where mbr_enrlmnt_ind !='Y' and mbr_enrlmnt_ind != 'N' ")
      val data = Array("'Custom_Network_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mbr_enrlmnt_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where mbr_enrlmnt_ind !='Y' and mbr_enrlmnt_ind != 'N' ")
      val data = Array("Invalid_Custom_Network_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
  
  //===========================================
 
   
   test("PccExtract -Check BCBSA Product ID values not located in reference table - 046") {

    val id = Array("046")
    val name = Array("Test case : Check BCBSA Product ID values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bcbsa_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_in.bot_bcbsa_ntwk_prod_xwalk_inbnd """)

    val result2 = sqlContext.sql("""select distinct bcbsa_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0""")

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct bcbsa_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0 and bcbsa_prod_id not in (select distinct bcbsa_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_ntwk_prod_xwalk_inbnd) ")
      val data = Array("'BCBSA_Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct bcbsa_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0 and bcbsa_prod_id not in (select distinct bcbsa_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_ntwk_prod_xwalk_inbnd) ")
      val data = Array("Invalid BCBSA_Product_ID")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
  
   
  //===========================================
   
  test("PCCExtract -Validate that Marketplace Type Code does not contain Null or Spaces - 047") {
    val id = Array("047")
    val name = Array("Test case : Validate that Marketplace Type Code does not contain Null or Spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,mrkt_plc_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(mrkt_plc_type_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mrkt_plc_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(mrkt_plc_type_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Marketplace_Type_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mrkt_plc_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(mrkt_plc_type_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Marketplace_Type_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  
  //===========================================
  
   test("PCCExtract -Validate that Marketplace Type Code does not contain Double Quote Character - 048") {
    val id = Array("048")
    val name = Array("Test case : Validate that Marketplace Type Code does not contain Double Quote Character")
       
    val result = sqlContext.sql("""select bhi_home_plan_id,mrkt_plc_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.mrkt_plc_type_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mrkt_plc_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.mrkt_plc_type_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Marketplace_Type_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mrkt_plc_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.mrkt_plc_type_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Marketplace_Type_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
 
   //===========================================
  
   test("PccExtract -Check Marketplace Type Code values not located in reference table - 049") {

    val id = Array("049")
    val name = Array("Test case : Check Marketplace Type Code values not located in reference table")

    val result1 = sqlContext.sql("""select distinct mrkt_place_type_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mrkt_place_type_xwalk_inbnd""")

    val result2 = sqlContext.sql("""select distinct mrkt_plc_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0""")

    val result = result2.except(result1)
    if (result.count == 0) { 
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mrkt_plc_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0 and mrkt_plc_type_cd not in (select distinct mrkt_place_type_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mrkt_place_type_xwalk_inbnd)")
      val data = Array("'Marketplace_Type_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mrkt_plc_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0 and mrkt_plc_type_cd not in (select distinct mrkt_place_type_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mrkt_place_type_xwalk_inbnd)")
      val data = Array("Invalid Marketplace_Type_Code")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
 
  //===========================================
 
  
  test("PCCExtract -Validate that ACA Metal Level Indicator does not contain Null or Spaces- 050") {
    val id = Array("050")
    val name = Array("Test case : Validate that ACA Metal Level Indicator does not contain Null or Spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,aca_metl_lvl_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(aca_metl_lvl_ind, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,aca_metl_lvl_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(aca_metl_lvl_ind, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','ACA_Metal_Level_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,aca_metl_lvl_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(aca_metl_lvl_ind, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','ACA_Metal_Level_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  
  //===========================================
  
  test("PCCExtract -Validate that ACA Metal Level Indicator does not contain Double Quote Character - 051") {
    val id = Array("051")
    val name = Array("Test case : Validate that ACA Metal Level Indicator does not contain Double Quote Character")

         
    val result = sqlContext.sql("""select bhi_home_plan_id,aca_metl_lvl_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.aca_metl_lvl_ind  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,aca_metl_lvl_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.aca_metl_lvl_ind  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','ACA_Metal_Level_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,aca_metl_lvl_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.aca_metl_lvl_ind  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','ACA_Metal_Level_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
 
   //=========================================== 
  
   test("PccExtract -Check ACA Metal Level Indicator values not located in reference table - 052") {

    val id = Array("052")
    val name = Array("Test case : Check ACA Metal Level Indicator values not located in reference table")

    val result1 = sqlContext.sql("""select distinct trim(aca_metl_lvl_cd) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_aca_metl_lvl_xwalk_inbnd""")

    val result2 = sqlContext.sql("""select distinct trim(aca_metl_lvl_ind) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct aca_metl_lvl_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where  aca_metl_lvl_ind not in (select distinct aca_metl_lvl_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_aca_metl_lvl_xwalk_inbnd)")
      val data = Array("'ACA_Metal_Level_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct aca_metl_lvl_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where aca_metl_lvl_ind not in (select distinct aca_metl_lvl_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_aca_metl_lvl_xwalk_inbnd)")
      val data = Array("Invalid ACA_Metal_Level_Indicator")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
 
  //=========================================== 
 
  test("PCCExtract -Validate that Transitional Health Plan Indicator does not contain Null or Spaces - 053") {
    val id = Array("053")
    val name = Array("Test case : Validate that Transitional Health Plan Indicator does not contain Null or Spaces")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,trnstnl_hlth_plan_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(trnstnl_hlth_plan_ind, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,trnstnl_hlth_plan_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(trnstnl_hlth_plan_ind, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Transitional_Health_Plan_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,trnstnl_hlth_plan_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(trnstnl_hlth_plan_ind, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Transitional_Health_Plan_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
  //===========================================
  
  test("PCCExtract -Validate that Transitional Health Plan Indicator does not contain Double Quote Character - 054") {
    val id = Array("054")
    val name = Array("Test case : Validate that Transitional Health Plan Indicator does not contain Double Quote Character ")
            
    val result = sqlContext.sql("""select bhi_home_plan_id,trnstnl_hlth_plan_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.trnstnl_hlth_plan_ind  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,trnstnl_hlth_plan_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.trnstnl_hlth_plan_ind  RLIKE '%<double quote>%' ")
      val data = Array("'BHI HPID','Transitional_Health_Plan_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,trnstnl_hlth_plan_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.trnstnl_hlth_plan_ind  RLIKE '%<double quote>%' ")
      val data = Array("'BHI HPID','Transitional_Health_Plan_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
 
   //=========================================== 
   
  test("PccExtract -Check Transitional Health Plan Indicator default value - 055") {

    val id = Array("055")
    val name = Array("Test case : Check Transitional Health Plan Indicator default value")

    val result = sqlContext.sql("""select distinct trnstnl_hlth_plan_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where trnstnl_hlth_plan_ind !='Y' and trnstnl_hlth_plan_ind != 'N'  """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct trnstnl_hlth_plan_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where trnstnl_hlth_plan_ind !='Y' and trnstnl_hlth_plan_ind != 'N'  ")
      val data = Array("'Transitional_Health_Plan_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct trnstnl_hlth_plan_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where trnstnl_hlth_plan_ind !='Y' and trnstnl_hlth_plan_ind != 'N'  ")
      val data = Array("Invalid_Transitional_Health_Plan_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    }
  }
  
  //===========================================
  
   test("PCCExtract -Validate that Contract Group Size Code does not contain Null or Spaces - 056") {
    val id = Array("056")
    val name = Array("Test case : Validate that Contract Group Size Code does not contain Null or Spaces")

    val result = sqlContext.sql("""select bhi_home_plan_id,cntrct_grp_size_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct
        where length(trim(regexp_replace(coalesce(cntrct_grp_size_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cntrct_grp_size_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(cntrct_grp_size_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Contract_Group_Size_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cntrct_grp_size_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where length(trim(regexp_replace(coalesce(cntrct_grp_size_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Contract_Group_Size_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
    
 
   //===========================================
 
   test("PCCExtract -Validate that Contract Group Size Code does not contain Double Quote Character - 057") {
    val id = Array("057")
    val name = Array("Test case : Validate that Contract Group Size Code does not contain Double Quote Character")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,cntrct_grp_size_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a
      where a.cntrct_grp_size_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cntrct_grp_size_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.cntrct_grp_size_cd  RLIKE '%<double quote>%'  ")
      val data = Array("'BHI HPID','Contract_Group_Size_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cntrct_grp_size_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct a where a.cntrct_grp_size_cd  RLIKE '%<double quote>%'  ")
      val data = Array("'BHI HPID','Contract_Group_Size_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  } 
 
   //=========================================== 
  
   test("PccExtract -Check Contract Group Size Code values not located in reference table - 058") {

    val id = Array("058")
    val name = Array("Test case : Check Contract Group Size Code values not located in reference table")

    val result1 = sqlContext.sql("""select distinct cntrct_grp_size_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntrct_grp_size_cd_inbnd""")

    val result2 = sqlContext.sql("""select distinct cntrct_grp_size_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0""")

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct cntrct_grp_size_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0 and cntrct_grp_size_cd not in (select distinct cntrct_grp_size_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntrct_grp_size_cd_inbnd)")
      val data = Array("'Contract_Group_Size_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct cntrct_grp_size_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where err_id = '0' and exclsn_ind = 0 and cntrct_grp_size_cd not in (select distinct cntrct_grp_size_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntrct_grp_size_cd_inbnd)")
      val data = Array("'Contract_Group_Size_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
 
  //=========================================== 
 
   test("PccExtract - Validate that Product Client Contract  extract includes only products which are available on product extract - 059") {
    val id = Array("059")
    val name = Array("Test case : Validate that Product Client Contract  extract includes only products which are available on product extract")

    
    val result1 = sqlContext.sql(""" select distinct home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod """)
    val result2 = sqlContext.sql(""" select distinct home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0""")
         
    val result = result2.except(result1)
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0 and home_plan_prod_id not in (select distinct home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where err_id = '0' and exclsn_ind = 0) ")
      val data = Array("'Invalid HomePlan Product ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0 and home_plan_prod_id not in (select distinct home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod where err_id = '0' and exclsn_ind = 0) ")
      val data = Array("'HomePlan Product ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
   
   //===========================================
   
    test("PccExtract - Validate that Home Plan Product ID column is populated  as per the logic in mapping document - 060") {
    val id = Array("060")
    val name = Array("Test case : Validate that Home Plan Product ID column is populated  as per the logic in mapping document")

    
    val result1 = sqlContext.sql(""" select distinct prod_cf_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa """)
    val result2 = sqlContext.sql(""" select distinct home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0""")
         
    val result = result2.except(result1)
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0 and home_plan_prod_id not in (select distinct prod_cf_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa)")
      val data = Array("'Invalid HomePlan Product ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where err_id = '0' and exclsn_ind = 0 and home_plan_prod_id not in (select distinct prod_cf_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa)")
      val data = Array("'HomePlan Product ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    }
   
    //===========================================
  
   
   test("PccExtract - Industry Grouping- SIC code column should be populated  as per specified transformation logic in mapping document - 061") {
    val id = Array("061")
    val name = Array("Test case : Industry Grouping- SIC code column should be populated  as per specified transformation logic in mapping document")

    
    val result1 = sqlContext.sql(""" select distinct sic_dgt_12_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_in.sic  """)
    val result2 = sqlContext.sql(""" select distinct(trim(sic_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where sic_cd <> '9999' """)
         
    val result = result2.except(result1)
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(trim(sic_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where sic_cd <> '9999'  and (trim(sic_cd)) not in (select distinct sic_dgt_12_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_in.sic)")
      val data = Array("'Invalid SIC_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(trim(sic_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  where sic_cd <> '9999'  and (trim(sic_cd)) not in (select distinct sic_dgt_12_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_in.sic)")
      val data = Array("'SIC_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
    //===========================================
   
   test("PccExtract - Industry Grouping- NAICS code column is defaulted to 'NA' - 062") {
    val id = Array("062")
    val name = Array("Test case : Industry Grouping- NAICS code column is defaulted to 'NA'")

    
    val result = sqlContext.sql(""" select distinct naics_cd, count(*) as counts  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where  naics_cd = 'NA' group by naics_cd """)
         
      if (result.count < 1) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct naics_cd, count(*) as counts  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where  naics_cd = 'NA' group by naics_cd ")
      val data = Array("'Count Of DefaultValue- Industry_Grouping_NAICS_code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct naics_cd, count(*) as counts  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where  naics_cd = 'NA' group by naics_cd ")
      val data = Array("'Count Of DefaultValue- Industry_Grouping_NAICS_code'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
    //===========================================
   
   test("PccExtract - Validate Marketplace Type Code column should have Valid values - 063") {
    val id = Array("063")
    val name = Array("Test case : Validate Marketplace Type Code column should have Valid values")

    val result = sqlContext.sql(""" select distinct mrkt_plc_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where  mrkt_plc_type_cd NOT IN ('NA','UN','PEX','OFX','SBM','SFP','FSM','FFM') """)
     
        
     if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select distinct mrkt_plc_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where  mrkt_plc_type_cd NOT IN ('NA','UN','PEX','OFX','SBM','SFP','FSM','FFM')")
      val data = Array("'Invalid  Marketplace_Type_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select distinct mrkt_plc_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where  mrkt_plc_type_cd NOT IN ('NA','UN','PEX','OFX','SBM','SFP','FSM','FFM')")
      val data = Array("'Marketplace_Type_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
    //===========================================
   
   test("PccExtract -  Validate ACA Metal Level Indicator column should have Valid values - 064") {
    val id = Array("064")
    val name = Array("Test case : Validate ACA Metal Level Indicator column should have Valid values")

    
    val result = sqlContext.sql(""" select distinct trim(aca_metl_lvl_ind) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where  trim(aca_metl_lvl_ind)  NOT IN ('NA','UN','01','02','03','04','05','06') """)
              
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct aca_metl_lvl_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where  aca_metl_lvl_ind  NOT IN ('NA','UN','01','02','03','04','05','06')")
      val data = Array("'Invalid ACA Metal_Level_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct aca_metl_lvl_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where  aca_metl_lvl_ind  NOT IN ('NA','UN','01','02','03','04','05','06')")
      val data = Array("'ACA Metal_Level_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
    //===========================================
   
   test("PccExtract -  Validate Contract Group Size Code column should have Valid values - 065") {
    val id = Array("065")
    val name = Array("Test case : Validate Contract Group Size Code column should have Valid values ")
    
     val result = sqlContext.sql(""" select distinct cntrct_grp_size_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where cntrct_grp_size_cd NOT IN ('NA','UN','01','02','03','04','05','06') """)
    
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct cntrct_grp_size_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where cntrct_grp_size_cd NOT IN ('NA','UN','01','02','03','04','05','06')")
      val data = Array("'Invalid Contract_Group_Size_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct cntrct_grp_size_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where cntrct_grp_size_cd NOT IN ('NA','UN','01','02','03','04','05','06')")
      val data = Array("'Contract_Group_Size_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
    //===========================================
   
   test("PccExtract - Validate Validate that CDHP Offered Code column should have Valid values - 066") {
    val id = Array("066")
    val name = Array("Test case : Validate Validate that CDHP Offered Code column should have Valid values")

    val result = sqlContext.sql(""" select distinct trim(cdhp_ofrd_type_cd) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where trim(cdhp_ofrd_type_cd)  NOT IN ('BOTH','HRA','HSA','NONE','OTHER') """)

       
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct trim(cdhp_ofrd_type_cd) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where trim(cdhp_ofrd_type_cd)  NOT IN ('BOTH','HRA','HSA','NONE','OTHER')")
      val data = Array("'Invalid CDHP_Offered_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct trim(cdhp_ofrd_type_cd) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct where trim(cdhp_ofrd_type_cd)  NOT IN ('BOTH','HRA','HSA','NONE','OTHER')")
      val data = Array("'CDHP_Offered_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
    //===========================================
   
   test("PccExtract - Validate that there are 14 BHI Home Plan ID  - 067 ") {
    
    val id = Array("067")
     val name = Array("Test case : Validate that there are 14 BHI Home Plan ID ")
     
    val result = sqlContext.sql(""" select count(distinct bhi_home_plan_id) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct """)
    
        
    if (result.collectAsList.toString.contains("14")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  
  //==========================================
   
  test("PccExtract - Validate the referential integrity between PCC and Product Extracts - 068 ") {
    
    val id = Array("068")
     val name = Array("Test case : Validate the referential integrity between PCC and Product Extracts ")
     
    val result = sqlContext.sql(""" SELECT PCC.bhi_home_plan_id, PCC.home_plan_prod_id
                                    from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT PCC
                                    left outer join """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_prod PROD
                                    on trim(PCC.bhi_home_plan_id)=trim(PROD.bhi_home_plan_id) and
                                    trim(PCC.home_plan_prod_id)=trim(PROD.home_plan_prod_id)
                                    where PROD.home_plan_prod_id is NULL """)
                                        
        
    if (result.count==0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
  
  test("PccExtract - Validate the referential integrity between PCC and Alpha Prefix Extracts  - 069 ") {
    
    val id = Array("069")
     val name = Array("Test case : Validate the referential integrity between PCC and Alpha Prefix Extracts ")
     
    val result = sqlContext.sql(""" select distinct PCC.prfx_cd
                                    from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct PCC
                                    left outer join """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prfx_rfrnc PRFX
                                    on trim(PCC.prfx_cd)=trim(PRFX.bcbsa_prfx_cd)
                                    where PRFX.bcbsa_prfx_cd is NULL """)
    
        
    if (result.count==0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
  
  test("PccExtract - Validate that all account ids present in Account Reporting are there in PCC extract  - 070 ") {
    
    val id = Array("070")
     val name = Array("Test case : Validate that all account ids present in Account Reporting are there in PCC extract ")
     
    val result = sqlContext.sql(""" select trim(PCC.acct_id) 
                                    from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct PCC
                                    left outer join """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg AR
                                    on trim(PCC.acct_id)=trim(AR.acct_id)
                                    where AR.acct_id is NULL """)
                                        
        
    if (result.count==0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
  
  test("PccExtract - Validate that all product ids present in Account Reporting are there in PCC extract  - 071 ") {
    
    val id = Array("071")
     val name = Array("Test case : Validate that all product ids present in Account Reporting are there in PCC extract ")
     
    val result = sqlContext.sql(""" select trim(PCC.home_plan_prod_id) 
                                    from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct PCC
                                    left outer join """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_acct_rptg AR
                                    on trim(PCC.home_plan_prod_id)=trim(AR.home_plan_prod_id)
                                    where AR.home_plan_prod_id is NULL """)
    
        
    if (result.count==0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
  
  test("PccExtract - Validate that Group/Indiv field is as per the new mapping logic Logic  - 072 ") {
    
    val id = Array("072")
     val name = Array("Test case : Validate that Group/Indiv field is as per the new mapping logic Logic ")
     
    val result1 = sqlContext.sql(""" select * 
                                    from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_prod_clnt_cntrct
                                    where (acct_id='INDIV' or GRP_ID='INDIV') and cntrct_type_cd='GROUP' """)
    
    val result2 = sqlContext.sql(""" select distinct cntrct_type_cd
                                    from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_prod_clnt_cntrct
                                    where (acct_id='INDIV' or GRP_ID='INDIV') """)                                
                                    
        
    if (result1.count==0 && (result2.count==0 && result2.collectAsList.toString.contains("INDIVIDUAL"))) {
      val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prod_clnt_cntrct ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
  
  test("PccExtract - Validate for Medicare group 195331 exclusion  - 073 ") {
    
    val id = Array("073")
     val name = Array("Test case : Validate for Medicare group 195331 exclusion ")
     
    val result1 = sqlContext.sql(""" select  bhi_home_plan_id, ACCT_ID from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_prod_clnt_cntrct where grp_id='195331'  limit 10 """)                             
                                    
        
    if (result1.count==0) {
      val a = result1.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select  bhi_home_plan_id, ACCT_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_prod_clnt_cntrct where grp_id='195331'limit 10 ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select  bhi_home_plan_id, ACCT_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_prod_clnt_cntrct where grp_id='195331'limit 10")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/ProductClientContract/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
}