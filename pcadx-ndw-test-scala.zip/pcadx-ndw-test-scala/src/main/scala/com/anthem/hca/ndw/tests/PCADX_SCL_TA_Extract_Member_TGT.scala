package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Extract_Member_TGT {
 
  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_Member_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}


 class PCADX_SCL_TA_Extract_Member_TGT(dbname : String, env: String) extends FunSuite {

     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val formatter2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
     val currdate2 = formatter2.format(new Date())
     
  
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Extract"
      val prcss = "Member"
   
   test("MemberExtract -Validate that BHI HomePlan ID field is not NULL or contains blank spaces  - 001") {
    
     val id = Array("001")
     val name = Array("Test case : Validate that BHI HomePlan ID field is not NULL or contains blank spaces")
     
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(bhi_home_plan_id, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==2)
    }
    else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(bhi_home_plan_id, ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','PRODUCT_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
     }
    
  //===========================================
  
 
  test("MemberExtract -Validate that HomePlan Product ID field is not NULL or contains blank spaces - 002") {
    val id = Array("002")
    val name = Array("Test case : Validate that HomePlan Product ID field is not NULL or contains blank spaces")
    
     val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(home_plan_prod_id, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(home_plan_prod_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','PRODUCT_ID'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(home_plan_prod_id, ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','PRODUCT_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
  
   //===========================================
  
  
   test("MemberExtract -Validate that Member ID field is not NULL or contains blank spaces  - 003") {
    val id = Array("003")
    val name = Array("Test case : Validate that Member ID field is not NULL or contains blank spaces")
    
     val result = sqlContext.sql("""select bhi_home_plan_id,mbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(mbr_id, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_id, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Member_ID'")
    sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_id, ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Member_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
   //===========================================

   test("MemberExtract -Validate that Consistent Member ID field is not NULL or contains blank spaces and Double Quote Characters - 004") {
    val id = Array("004")
    val name = Array("Test case : Validate that Consistent Member ID field is not NULL or contains blank spaces and Double Quote Characters")
     val result = sqlContext.sql("""select bhi_home_plan_id,cnsstnt_mbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(cnsstnt_mbr_id, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
     val a = result.limit(10).rdd
     val status = Array("FAILED")
     val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(cnsstnt_mbr_id, ''),' ', '')))=0 ")
     val data = Array("'BHI HPID','Consistent_Member_ID'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(cnsstnt_mbr_id, ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Consistent_Member_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================

   test("MemberExtract -Validate that Traceability field is not NULL or contains blank spaces and Double Quote Characters - 005") {
    val id = Array("005")
    val name = Array("Test case : Validate that Traceability field is not NULL or contains blank spaces and Double Quote Characters")
     val result = sqlContext.sql("""select bhi_home_plan_id,src_sys_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(src_sys_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,src_sys_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(src_sys_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Traceability'")
    sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,src_sys_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(src_sys_cd, ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    
   }

   //===========================================
   
   test("MemberExtract -Validate that Member's Gender is not NULL or contains blank spaces - 006") {
    val id = Array("006")
    val name = Array("Test case : Validate that Member's Gender is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id,mbr_gndr_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(mbr_gndr_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_gndr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_gndr_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Member_Gender'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_gndr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_gndr_cd, ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Member_Gender' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================

  test("MemberExtract -Validate that Member's Current Country is not NULL or contains blank spaces - 007") {
    val id = Array("007")
    val name = Array("Test case : Validate that Member's Current Country is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id,mbr_curnt_cntry_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(mbr_curnt_cntry_cd , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_curnt_cntry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_curnt_cntry_cd , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Member_Current_Country'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_curnt_cntry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_curnt_cntry_cd , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Member_Current_Country' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

   test("MemberExtract -Validate that  Member Confidentiality Code is not NULL or contains blank spaces - 008") {
    val id = Array("008")
    val name = Array("Test case : Validate that  Member Confidentiality Code is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id,mbr_cnfdntlty_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(mbr_cnfdntlty_cd, "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_cnfdntlty_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_cnfdntlty_cd, ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Member_Confidentiality_Code'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_cnfdntlty_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where length(trim(regexp_replace(coalesce(mbr_cnfdntlty_cd, ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Member_Confidentiality_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
 //===========================================

 test("MemberExtract -Validate that Account is not NULL or contains blank spaces - 009") {
    val id = Array("009")
    val name = Array("Test case : Validate that Account is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id, acct_id   from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(acct_id  , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, acct_id   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(acct_id  , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Account'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, acct_id   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(acct_id  , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Account' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

 test("MemberExtract -Validate that Group is not NULL or contains blank spaces - 010") {
    val id = Array("010")
    val name = Array("Test case : Validate that Group is not NULL or contains blank spaces ")
     val result = sqlContext.sql("""select bhi_home_plan_id,grp_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(grp_id , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,grp_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(grp_id , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Group'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,grp_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(grp_id , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Group' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

 test("MemberExtract -Validate that Subgroup is not NULL or contains blank spaces - 011") {
    val id = Array("011")
    val name = Array("Test case : Validate that Subgroup is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id,subgrp_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(subgrp_id , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,subgrp_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(subgrp_id , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Subgroup'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,subgrp_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(subgrp_id , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Subgroup' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
 
   //===========================================
 
 test("MemberExtract -Validate that Member Relationship is not NULL or contains blank spaces - 012") {
    val id = Array("012")
    val name = Array("Test case : Validate that Member Relationship is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id, mbr_rltnshp_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(mbr_rltnshp_cd , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, mbr_rltnshp_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_rltnshp_cd , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Member_Relationship'")
    sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, mbr_rltnshp_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_rltnshp_cd , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Member_Relationship' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================

  test("MemberExtract -Validate that Home Plan Product ID-Subscriber is not NULL or contains blank spaces - 013") {
    val id = Array("013")
    val name = Array("Test case : Validate that Home Plan Product ID-Subscriber is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id, sbscrbr_home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(sbscrbr_home_plan_prod_id , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, sbscrbr_home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(sbscrbr_home_plan_prod_id , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Home_Plan_Product_ID_Subscriber'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, sbscrbr_home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(sbscrbr_home_plan_prod_id , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Home_Plan_Product_ID_Subscriber' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
  
 //===========================================

  
   test("MemberExtract -Validate that Subscriber ID is not NULL or contains blank spaces - 014") {
    val id = Array("014")
    val name = Array("Test case : Validate that Subscriber ID is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id, sbscrbr_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(sbscrbr_id , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, sbscrbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(sbscrbr_id , ''),' ', '')))=0  ")
      val data = Array("'BHI HPID','Subscriber_ID'")
    sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, sbscrbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(sbscrbr_id , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Subscriber_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }

   //===========================================

 test("MemberExtract -Validate that Enrollment Eligibility Status is not NULL or contains blank spaces - 015") {
    val id = Array("015")
    val name = Array("Test case : Validate that Enrollment Eligibility Status is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id, enrlmnt_elgblty_stts_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(enrlmnt_elgblty_stts_cd , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, enrlmnt_elgblty_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(enrlmnt_elgblty_stts_cd  , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Enrollment_Eligibility_Status'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, enrlmnt_elgblty_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(enrlmnt_elgblty_stts_cd  , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Enrollment_Eligibility_Status' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

 test("MemberExtract -Validate that Member Medical COB Code is not NULL or contains blank spaces - 016") {
    val id = Array("016")
    val name = Array("Test case : Validate that Member Medical COB Code is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id, mbr_mdcl_cob_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(mbr_mdcl_cob_cd , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, mbr_mdcl_cob_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_mdcl_cob_cd , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Member_Medical_COB_Code'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, mbr_mdcl_cob_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_mdcl_cob_cd , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Member_Medical_COB_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

 test("MemberExtract -Validate that Member Pharmacy COB Code is not NULL or contains blank spaces - 017") {
    val id = Array("017")
    val name = Array("Test case : Validate that Member Pharmacy COB Code is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id,mbr_phrmcy_cob_cd   from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(mbr_phrmcy_cob_cd , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_phrmcy_cob_cd   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_phrmcy_cob_cd , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Member_Pharmacy_COB_Code'")
    sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_phrmcy_cob_cd   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mbr_phrmcy_cob_cd , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Member_Pharmacy_COB_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

 
  test("MemberExtract -Validate that Deductible Category is not NULL or contains blank spaces - 018") {
    val id = Array("018")
    val name = Array("Test case : Validate that Deductible Category is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id,ddctbl_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(ddctbl_ctgry_cd , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,ddctbl_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(ddctbl_ctgry_cd , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Deductible_Category'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,ddctbl_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(ddctbl_ctgry_cd , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Deductible_Category' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
 //===========================================

 test("MemberExtract -Validate that MH/CD Enrollment Benefit is not NULL or contains blank spaces - 019") {
    val id = Array("019")
    val name = Array("Test case : Validate that MH/CD Enrollment Benefit is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id,mh_cd_enrlmnt_bnft_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(mh_cd_enrlmnt_bnft_cd , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mh_cd_enrlmnt_bnft_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mh_cd_enrlmnt_bnft_cd , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','MH/CD_Enrollment_Benefit'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mh_cd_enrlmnt_bnft_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(mh_cd_enrlmnt_bnft_cd , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','MH/CD_Enrollment_Benefit' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

 test("MemberExtract -Validate that BHI Network Category - Facility is not NULL or contains blank spaces - 020") {
    val id = Array("020")
    val name = Array("Test case : Validate that BHI Network Category - Facility is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id, fclty_bnfts_bhi_ntwk_ctgry_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(fclty_bnfts_bhi_ntwk_ctgry_cd , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, fclty_bnfts_bhi_ntwk_ctgry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(fclty_bnfts_bhi_ntwk_ctgry_cd , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','BHI_Network_Category_Facility'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, fclty_bnfts_bhi_ntwk_ctgry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(fclty_bnfts_bhi_ntwk_ctgry_cd , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','BHI_Network_Category_Facility' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

 test("MemberExtract -Validate that BHI Network Category - Professional is not NULL or contains blank spaces - 021") {
    val id = Array("021")
    val name = Array("Test case : Validate that BHI Network Category - Professional is not NULL or contains blank spaces ")
     val result = sqlContext.sql("""select bhi_home_plan_id, prfsnl_bnfts_bhi_ntwk_ctgry_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(prfsnl_bnfts_bhi_ntwk_ctgry_cd , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, prfsnl_bnfts_bhi_ntwk_ctgry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(prfsnl_bnfts_bhi_ntwk_ctgry_cd , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','BHI_Network_Category_Professional'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, prfsnl_bnfts_bhi_ntwk_ctgry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(prfsnl_bnfts_bhi_ntwk_ctgry_cd , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','BHI_Network_Category_Professional' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

 
  test("MemberExtract -Validate that Plan Network Category - Facility is not NULL or contains blank spaces - 022") {
    val id = Array("022")
    val name = Array("Test case : Validate that Plan Network Category - Facility is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id, fclty_bnfts_plan_ntwk_ctgry_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(fclty_bnfts_plan_ntwk_ctgry_cd , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, fclty_bnfts_plan_ntwk_ctgry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(fclty_bnfts_plan_ntwk_ctgry_cd , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Plan_Network_Category_Facility'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, fclty_bnfts_plan_ntwk_ctgry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(fclty_bnfts_plan_ntwk_ctgry_cd , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Plan_Network_Category_Facility' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
 //===========================================

 test("MemberExtract -Validate that Plan Network Category - Professional is not NULL or contains blank spaces - 023") {
    val id = Array("023")
    val name = Array("Test case :Validate that Plan Network Category - Professional is not NULL or contains blank spaces")
      
     val result = sqlContext.sql("""select bhi_home_plan_id, prfsnl_bnfts_plan_ntwk_ctgry_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(prfsnl_bnfts_plan_ntwk_ctgry_cd , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, prfsnl_bnfts_plan_ntwk_ctgry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(prfsnl_bnfts_plan_ntwk_ctgry_cd , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Plan_Network_Category_Professional'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, prfsnl_bnfts_plan_ntwk_ctgry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(prfsnl_bnfts_plan_ntwk_ctgry_cd , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Plan_Network_Category_Professional' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

 test("MemberExtract -Validate that Pharmacy Carve Out Submission Indicator is not NULL or contains blank spaces - 024") {
    val id = Array("024")
    val name = Array("Test case : Validate that Pharmacy Carve Out Submission Indicator is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id, phrmcy_crv_out_sbmsn_ind  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(phrmcy_crv_out_sbmsn_ind , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, phrmcy_crv_out_sbmsn_ind  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(phrmcy_crv_out_sbmsn_ind , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Pharmacy_Carve_Out_Submission_Indicator'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, phrmcy_crv_out_sbmsn_ind  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(phrmcy_crv_out_sbmsn_ind , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Pharmacy_Carve_Out_Submission_Indicator : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

 test("MemberExtract -Validate that Pharmacy Benefit Tiers is not NULL or contains blank spaces - 025") {
   val id = Array("025")
    val name = Array("Test case : Validate that Pharmacy Benefit Tiers is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id, phrmcy_bnft_tiers_nbr_txt  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(phrmcy_bnft_tiers_nbr_txt , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, phrmcy_bnft_tiers_nbr_txt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(phrmcy_bnft_tiers_nbr_txt , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Pharmacy_Benefit_Tiers'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, phrmcy_bnft_tiers_nbr_txt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(phrmcy_bnft_tiers_nbr_txt , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Pharmacy_Benefit_Tiers' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

 test("MemberExtract -Validate that Government Subsidies Indicator is not NULL or contains blank spaces - 026") {
    val id = Array("026")
    val name = Array("Test case : Validate that Government Subsidies Indicator is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id,gov_sbsdy_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(gov_sbsdy_ind , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,gov_sbsdy_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(gov_sbsdy_ind , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Government_Subsidies_Indicator'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,gov_sbsdy_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(gov_sbsdy_ind , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Government_Subsidies_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   //===========================================

 test("MemberExtract -Validate that Cost Sharing Reductions (CSR) Type  is not NULL or contains blank spaces - 027") {
    val id = Array("027")
    val name = Array("Test case : Validate that Cost Sharing Reductions (CSR) Type  is not NULL or contains blank spaces")
    
     val result = sqlContext.sql("""select bhi_home_plan_id, csr_type_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(csr_type_cd , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, csr_type_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(csr_type_cd , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','CSR_Type_Code'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, csr_type_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(csr_type_cd , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','CSR_Type_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
 
 //===========================================

test("MemberExtract -Validate that Qualified Health Plan ID  is not NULL or contains blank spaces - 028") {
    val id = Array("028")
    val name = Array("Test case : Validate that Qualified Health Plan ID  is not NULL or contains blank spaces")
     val result = sqlContext.sql("""select bhi_home_plan_id, qhp_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp
        where length(trim(regexp_replace(coalesce(qhp_id , "")," ", "")))=0 """)
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, qhp_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(qhp_id , ''),' ', '')))=0 ")
      val data = Array("'BHI HPID','Qualified_Health_Plan_ID '")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, qhp_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where length(trim(regexp_replace(coalesce(qhp_id , ''),' ', '')))=0 ")
      val data = Array(" 'BHI HPID','Qualified_Health_Plan_ID ' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
   
   //===========================================

 test("MemberExtract -Validate that BHI HomePlan ID field should not contain Special Characters - 029") {
    val id = Array("029")
    val name = Array("Test case : Validate that BHI HomePlan ID field should not contain Special Characters")
    
    val result = sqlContext.sql("""select  bhi_home_plan_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
      where a.bhi_home_plan_id  RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.bhi_home_plan_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','PRODUCT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.bhi_home_plan_id  RLIKE '%[^A-z0-9]%'")
      val data = Array(" 'BHI HPID','PRODUCT_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================

   test("MemberExtract -Validate that BHI HomePlan Product ID field should not contain Special Characters - 030") {
    val id = Array("030")
    val name = Array("Test case : Validate that BHI HomePlan Product ID field should not contain Special Character")
     val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
      where a.home_plan_prod_id  RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.home_plan_prod_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','PRODUCT_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.home_plan_prod_id  RLIKE '%[^A-z0-9]%'")
      val data = Array(" 'BHI HPID','PRODUCT_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
   
 
    
   test("MemberExtract -Validate that Member ID field should not contain Special Characters - 031") {
    val id = Array("031")
    val name = Array("Test case : Validate that Member ID field should not contain Special Characters")
    
     val result = sqlContext.sql("""select bhi_home_plan_id,mbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
      where a.mbr_id  RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','Member_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_id  RLIKE '%[^A-z0-9]%'")
      val data = Array(" 'BHI HPID','Member_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
   

   test("MemberExtract -Validate that Consistent Member ID should not contain Double Quote Characters - 032") {
    val id = Array("032")
    val name = Array("Test case : Validate that Consistent Member ID should not contain Double Quote Characters")
      val result = sqlContext.sql("""select bhi_home_plan_id,cnsstnt_mbr_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
      where a.cnsstnt_mbr_id RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.cnsstnt_mbr_id RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Consistent_Member_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cnsstnt_mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.cnsstnt_mbr_id RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Consistent_Member_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
  
  
   test("MemberExtract -Validate that Traceability field should not contain Double Quote Characters - 033") {
    val id = Array("033")
    val name = Array("Test case : Validate that Traceability field should not contain Double Quote Characters")
      val result = sqlContext.sql("""select bhi_home_plan_id,src_sys_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
      where a.src_sys_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,src_sys_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.src_sys_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Traceability'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,src_sys_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a  where a.src_sys_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================

   
   test("MemberExtract -Validate that Member's Current Primary Zip Code should not contain Double Quote Characters - 034") {
    val id = Array("034")
    val name = Array("Test case : Validate that Member's Current Primary Zip Code should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,mbr_curnt_prmry_zip_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.mbr_curnt_prmry_zip_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_curnt_prmry_zip_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_curnt_prmry_zip_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Member_Current_Primary_Zip_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_curnt_prmry_zip_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_curnt_prmry_zip_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Member_Current_Primary_Zip_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
   
  test("MemberExtract -Validate that Member's Current Country should not contain Double Quote Characters - 035") {
    val id = Array("035")
    val name = Array("Test case : Validate that Member's Current Country should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,mbr_curnt_cntry_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.mbr_curnt_cntry_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_curnt_cntry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_curnt_cntry_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Member_Current_Country'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_curnt_cntry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_curnt_cntry_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Member_Current_Country' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
    
   test("MemberExtract -Validate that Member Gender should not contain Double Quote Characters - 036") {
    val id = Array("036")
    val name = Array("Test case : Validate that Member Gender should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,mbr_gndr_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.mbr_gndr_cd   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_gndr_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_gndr_cd   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Member_Gender'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_gndr_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_gndr_cd   RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Member_Gender' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
     
   test("MemberExtract -Validate that Member Confidentiality Code should not contain Double Quote Characters - 037") {
    val id = Array("037")
    val name = Array("Test case : Validate that Member Confidentiality Code should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,mbr_cnfdntlty_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.mbr_cnfdntlty_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_cnfdntlty_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_cnfdntlty_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Member_Confidentiality_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_cnfdntlty_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_cnfdntlty_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Member_Confidentiality_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
  
   test("MemberExtract -Validate that Account field should not contain Special Characters - 038") {
    val id = Array("038")
    val name = Array("Test case : Validate that Account field should not contain Special Characters")
    
     val result = sqlContext.sql("""select bhi_home_plan_id,acct_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
      where a.acct_id  RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.acct_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','Account'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.acct_id  RLIKE '%[^A-z0-9]%'")
      val data = Array(" 'BHI HPID','Account' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
   
   test("MemberExtract -Validate that Group field should not contain Special Characters - 039") {
    val id = Array("039")
    val name = Array("Test case : Validate that Group field should not contain Special Character")
    
     val result = sqlContext.sql("""select bhi_home_plan_id,grp_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
      where a.grp_id  RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,grp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.grp_id  RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','Group'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,grp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.grp_id  RLIKE '%[^A-z0-9]%'")
      val data = Array(" 'BHI HPID','Group' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
   
   test("MemberExtract -Validate that Subgroup field should not contain Special Characters - 040") {
    val id = Array("040")
    val name = Array("Test case : Validate that Subgroup field should not contain Special Characters")
    
     val result = sqlContext.sql("""select bhi_home_plan_id,subgrp_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
      where a.subgrp_id  RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : elect bhi_home_plan_id,subgrp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.subgrp_id  RLIKE '%[^A-z0-9]%'")
       val data = Array("'BHI HPID','Subgroup'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : elect bhi_home_plan_id,subgrp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.subgrp_id  RLIKE '%[^A-z0-9]%'")
      val data = Array(" 'BHI HPID','Subgroup' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
   
   test("MemberExtract -Validate that Coverage Begin Date field should not contain Special Characters - 041") {
    val id = Array("041")
    val name = Array("Test case : Validate that Coverage Begin Date field should not contain Special Characters ")
    
     val result = sqlContext.sql("""select bhi_home_plan_id,cvrg_bgn_dt  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
      where a.cvrg_bgn_dt RLIKE '%[^A-z0-9]%'""")
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cvrg_bgn_dt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.cvrg_bgn_dt RLIKE '%[^A-z0-9]%'")
      val data = Array("'BHI HPID','Coverage_Begin_Date'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cvrg_bgn_dt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.cvrg_bgn_dt RLIKE '%[^A-z0-9]%'")
      val data = Array(" 'BHI HPID','Coverage_Begin_Date' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
   
   
   test("MemberExtract -Validate that Coverage End Date should not contain Double Quote Characters - 042") {
    val id = Array("042")
    val name = Array("Test case : Validate that Coverage End Date should not contain Double Quote Characters")
    
    
    val result = sqlContext.sql("""select bhi_home_plan_id,cvrg_end_dt  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.cvrg_end_dt   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,cvrg_end_dt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.cvrg_end_dt   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Coverage_End_Date'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,cvrg_end_dt  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.cvrg_end_dt   RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Coverage_End_Date' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
     
  test("MemberExtract -Validate that Member Relationship should not contain Double Quote Characters - 043") {
    val id = Array("043")
    val name = Array("Test case : Validate that Member Relationship should not contain Double Quote Characters")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,mbr_rltnshp_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.mbr_rltnshp_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_rltnshp_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_rltnshp_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Member_Relationship'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_rltnshp_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_rltnshp_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Member_Relationship' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
      
   test("MemberExtract -Validate that Home Plan Product ID-Subscriber  should not contain Double Quote Characters - 044") {
    val id = Array("044")
    val name = Array("Test case : Validate that Home Plan Product ID-Subscriber  should not contain Double Quote Characters - 044")
    val result = sqlContext.sql("""select bhi_home_plan_id,sbscrbr_home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.sbscrbr_home_plan_prod_id  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,sbscrbr_home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.sbscrbr_home_plan_prod_id  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Home_Plan_Product_ID_Subscriber'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,sbscrbr_home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.sbscrbr_home_plan_prod_id  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Home_Plan_Product_ID_Subscriber' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
       
   test("MemberExtract -Validate that Subscriber ID should not contain Double Quote Characters - 045") {
    val id = Array("045")
    val name = Array("Test case : Validate that Subscriber ID should not contain Double Quote Characters") 
    
    val result = sqlContext.sql("""select bhi_home_plan_id,sbscrbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.sbscrbr_id  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,sbscrbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.sbscrbr_id  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Subscriber_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,sbscrbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.sbscrbr_id  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Subscriber_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
  
  //===========================================
        
   test("MemberExtract -Validate that Enrollment Eligibility Status should not contain Double Quote Characters - 046") {
    val id = Array("046")
    val name = Array("Test case : Validate that BHI HomePlan ID field is not NULL or contains blank spaces")
    val result = sqlContext.sql("""select bhi_home_plan_id,enrlmnt_elgblty_stts_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.enrlmnt_elgblty_stts_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,enrlmnt_elgblty_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.enrlmnt_elgblty_stts_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Enrollment_Eligibility_Status'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,enrlmnt_elgblty_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.enrlmnt_elgblty_stts_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Enrollment_Eligibility_Status' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
         
  test("MemberExtract -Validate that Member Medical COB Code should not contain Double Quote Characters - 047") {
    val id = Array("047")
    val name = Array("Test case : Validate that Member Medical COB Code should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,mbr_mdcl_cob_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.mbr_mdcl_cob_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_mdcl_cob_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_mdcl_cob_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Member_Medical_COB_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_mdcl_cob_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_mdcl_cob_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Member_Medical_COB_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
          
      
   test("MemberExtract -Validate that Member Pharmacy COB Code should not contain Double Quote Characters - 048") {
    val id = Array("048")
    val name = Array("Test case : Validate that Member Pharmacy COB Code should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,mbr_phrmcy_cob_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.mbr_phrmcy_cob_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_phrmcy_cob_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_phrmcy_cob_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Member_Pharmacy_COB_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_phrmcy_cob_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mbr_phrmcy_cob_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Member_Pharmacy_COB_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
       
       
       
   test("MemberExtract -Validate that Deductible Category should not contain Double Quote Characters - 049") {
    val id = Array("049")
    val name = Array("Test case : Validate that Deductible Category should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,ddctbl_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.ddctbl_ctgry_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,ddctbl_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.ddctbl_ctgry_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Deductible_Category'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,ddctbl_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.ddctbl_ctgry_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Deductible_Category' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
       
       
   test("MemberExtract -Validate that MH/CD Enrollment Benefit should not contain Double Quote Characters - 050") {
    val id = Array("050")
    val name = Array("Test case : Validate that MH/CD Enrollment Benefit should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,mh_cd_enrlmnt_bnft_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.mh_cd_enrlmnt_bnft_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mh_cd_enrlmnt_bnft_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mh_cd_enrlmnt_bnft_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','MH/CD_Enrollment_Benefit'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mh_cd_enrlmnt_bnft_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mh_cd_enrlmnt_bnft_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','MH/CD_Enrollment_Benefit' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
        
        
   test("MemberExtract -Validate that Pharmacy Benefit Indicator should not contain Double Quote Characters - 051") {
    val id = Array("051")
    val name = Array("Test case : Validate that Pharmacy Benefit Indicator should not contain Double Quote Characters")

    val result = sqlContext.sql("""select bhi_home_plan_id,phrmcy_bnft_ind  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.phrmcy_bnft_ind   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,phrmcy_bnft_ind  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.phrmcy_bnft_ind   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Pharmacy_Benefit_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,phrmcy_bnft_ind  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.phrmcy_bnft_ind   RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Pharmacy_Benefit_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
         
         
   test("MemberExtract -Validate that MH/CD Benefit Indicator should not contain Double Quote Characters - 052") {
    val id = Array("052")
    val name = Array("Test case : Validate that MH/CD Benefit Indicator should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,mh_cd_bnft_ind  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.mh_cd_bnft_ind   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mh_cd_bnft_ind  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mh_cd_bnft_ind   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','MH/CD_Benefit_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mh_cd_bnft_ind  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mh_cd_bnft_ind   RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','MH/CD_Benefit_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
          
          
   test("MemberExtract -Validate that Medical Benefit Indicator should not contain Double Quote Characters - 053") {
    val id = Array("053")
    val name = Array("Test case : Validate that Medical Benefit Indicator should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,mdcl_bnft_ind  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.mdcl_bnft_ind   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mdcl_bnft_ind  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mdcl_bnft_ind   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Medical_Benefit_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mdcl_bnft_ind  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.mdcl_bnft_ind   RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Medical_Benefit_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

   }
  
  //===========================================
           
  test("MemberExtract -Validate that Hospital Benefit Indicator should not contain Double Quote Characters - 054") {
    val id = Array("054")
    val name = Array("Test case : Validate that BHI HomePlan ID field is not NULL or contains blank spaces")
    val result = sqlContext.sql("""select bhi_home_plan_id,hosp_bnft_ind  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.hosp_bnft_ind   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,hosp_bnft_ind  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.hosp_bnft_ind   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Hospital_Benefit_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,hosp_bnft_ind  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.hosp_bnft_ind   RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Hospital_Benefit_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
            
            
  test("MemberExtract -Validate that  BHI Network Category - Facility should not contain Double Quote Characters - 055") {
    val id = Array("055")
    val name = Array("Test case : Validate that  BHI Network Category - Facility should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,fclty_bnfts_bhi_ntwk_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.fclty_bnfts_bhi_ntwk_ctgry_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,fclty_bnfts_bhi_ntwk_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.fclty_bnfts_bhi_ntwk_ctgry_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','BHI_Network_Category_Facility'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,fclty_bnfts_bhi_ntwk_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.fclty_bnfts_bhi_ntwk_ctgry_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','BHI_Network_Category_Facility' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
  
   test("MemberExtract -Validate that BHI Network Category - Professional  should not contain Double Quote Characters - 056") {
    val id = Array("056")
    val name = Array("Test case : Validate that BHI Network Category - Professional  should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,prfsnl_bnfts_bhi_ntwk_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.prfsnl_bnfts_bhi_ntwk_ctgry_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,prfsnl_bnfts_bhi_ntwk_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.prfsnl_bnfts_bhi_ntwk_ctgry_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','BHI_Network_Category_Professional'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,prfsnl_bnfts_bhi_ntwk_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.prfsnl_bnfts_bhi_ntwk_ctgry_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','BHI_Network_Category_Professional' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
   }
  
  //===========================================
   
   test("MemberExtract -Validate that Plan Network Category - Facility  should not contain Double Quote Characters - 057") {
    val id = Array("057")
    val name = Array("Test case : Validate that Plan Network Category - Facility  should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,fclty_bnfts_plan_ntwk_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.fclty_bnfts_plan_ntwk_ctgry_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,fclty_bnfts_plan_ntwk_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.fclty_bnfts_plan_ntwk_ctgry_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Plan_Network_Category_Facility'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,fclty_bnfts_plan_ntwk_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.fclty_bnfts_plan_ntwk_ctgry_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Plan_Network_Category_Facility' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
    
   test("MemberExtract -Validate that  Plan Network Category - Professional should not contain Double Quote Characters - 058") {
    val id = Array("058")
    val name = Array("Test case : Validate that  Plan Network Category - Professional should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,prfsnl_bnfts_plan_ntwk_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.prfsnl_bnfts_plan_ntwk_ctgry_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,prfsnl_bnfts_plan_ntwk_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.prfsnl_bnfts_plan_ntwk_ctgry_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Plan_Network_Category_Professional'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,prfsnl_bnfts_plan_ntwk_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.prfsnl_bnfts_plan_ntwk_ctgry_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Plan_Network_Category_Professional' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
     
   test("MemberExtract -Validate that Pharmacy Carve Out Submission Indicator  should not contain Double Quote Characters - 059") {
    val id = Array("059")
    val name = Array("Test case : Validate that Pharmacy Carve Out Submission Indicator  should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,phrmcy_crv_out_sbmsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.phrmcy_crv_out_sbmsn_ind  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,phrmcy_crv_out_sbmsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.phrmcy_crv_out_sbmsn_ind  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Pharmacy_Carve_Out_Submission_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,phrmcy_crv_out_sbmsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.phrmcy_crv_out_sbmsn_ind  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Pharmacy_Carve_Out_Submission_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
      
   test("MemberExtract -Validate that Pharmacy Benefit Tiers  should not contain Double Quote Characters - 060") {
    val id = Array("060")
    val name = Array("Test case : Validate that Pharmacy Benefit Tiers  should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,phrmcy_bnft_tiers_nbr_txt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.phrmcy_bnft_tiers_nbr_txt  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,phrmcy_bnft_tiers_nbr_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.phrmcy_bnft_tiers_nbr_txt  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Pharmacy_Benefit_Tiers'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,phrmcy_bnft_tiers_nbr_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.phrmcy_bnft_tiers_nbr_txt  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Pharmacy_Benefit_Tiers' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
       
   test("MemberExtract -Validate that Benefit Package ID  should not contain Double Quote Characters - 061") {
    val id = Array("061")
    val name = Array("Test case : Validate that Benefit Package ID  should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,bnft_pkg_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.bnft_pkg_id   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,bnft_pkg_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.bnft_pkg_id   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Benefit_Package_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,bnft_pkg_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.bnft_pkg_id   RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Benefit_Package_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
        
   test("MemberExtract -Validate that Government Subsidies Indicator  should not contain Double Quote Characters - 062") {
    val id = Array("062")
    val name = Array("Test case : Validate that Government Subsidies Indicator  should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,gov_sbsdy_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.gov_sbsdy_ind  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,gov_sbsdy_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.gov_sbsdy_ind  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Government_Subsidies_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,gov_sbsdy_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.gov_sbsdy_ind  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Government_Subsidies_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
         
  test("MemberExtract -Validate that  Cost Sharing Reductions (CSR) Type  should not contain Double Quote Characters - 063") {
    val id = Array("063")
    val name = Array("Test case : Validate that  Cost Sharing Reductions (CSR) Type  should not contain Double Quote Characters")
    
    val result = sqlContext.sql("""select bhi_home_plan_id,csr_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.csr_type_cd  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,csr_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.csr_type_cd  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','CSR_Type_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,csr_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.csr_type_cd  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','CSR_Type_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
          
   test("MemberExtract -Validate that Qualified Health Plan ID should not contain Double Quote Characters - 064") {
    val id = Array("064")
    val name = Array("Test case : Validate that Qualified Health Plan ID  should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,qhp_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.qhp_id  RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,qhp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.qhp_id  RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','Qualified_Health_Plan_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,qhp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.qhp_id  RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','Qualified_Health_Plan_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
           
   test("MemberExtract -Validate that NLO Account Type should not contain Double Quote Characters - 065") {
    val id = Array("065")
    val name = Array("Test case : Validate that NLO Account Type should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,nlo_acct_type_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.nlo_acct_type_cd   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,nlo_acct_type_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.nlo_acct_type_cd   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','NLO_Account_Type '")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,nlo_acct_type_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.nlo_acct_type_cd   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','NLO_Account_Type ' :  No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
           
 
   test("MemberExtract -Validate that NLO Plan Type  should not contain Double Quote Characters - 066") {
    val id = Array("066")
    val name = Array("Test case :Validate that NLO Plan Type  should not contain Double Quote Characters")
    val result = sqlContext.sql("""select bhi_home_plan_id,nlo_plan_type_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a
    where a.nlo_plan_type_cd   RLIKE '%"%' """)
    
            
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,nlo_plan_type_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.nlo_plan_type_cd   RLIKE '%<double quote>%'")
      val data = Array("'BHI HPID','NLO_Plan_Type '")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,nlo_plan_type_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp a where a.nlo_plan_type_cd   RLIKE '%<double quote>%'")
      val data = Array(" 'BHI HPID','NLO_Plan_Type ' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  

  //===========================================
  
  
  test("MemberExtract -Validate that all the records have the correct [BHI Home Plan ID] as per Anthem - 067") {
   val id = Array("067")
    val name = Array("Test case : Validate that all the records have the correct [BHI Home Plan ID] as per Anthem")
    val result = sqlContext.sql("""select bhi_home_plan_id,home_plan_prod_id,err_id,exclsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where
    bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') and err_id = '0' and exclsn_ind = '0'""")
     
        
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') and err_id = '0' and exclsn_ind = '0'")
      val data = Array("'BHI HPID','PRODUCT_ID','ERR_ID','EXCLSN_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,home_plan_prod_id,err_id,exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') and err_id = '0' and exclsn_ind = '0'")
      val data = Array(" 'BHI HPID','PRODUCT_ID','ERR_ID','EXCLSN_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }

  //===========================================
 
  test("MemberExtract - Check  Member Current Country Code column values not located in Ref table - 068") {

    val id = Array("068")
    val name = Array("Test case : Check  Member Current Country Code column values not located in Ref table")
    
    val result1 = sqlContext.sql(""" select distinct cntry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd """)

    val result2 = sqlContext.sql("""select distinct mbr_curnt_cntry_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where  mbr_curnt_cntry_cd not in ('UN')""")

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mbr_curnt_cntry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where  mbr_curnt_cntry_cd not in ('UN') and mbr_curnt_cntry_cd not in (select distinct cntry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd)")
      val data = Array("  'Member_Current_Country' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mbr_curnt_cntry_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where  mbr_curnt_cntry_cd not in ('UN') and mbr_curnt_cntry_cd not in (select distinct cntry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd)")
      val data = Array("'Invalid  Member_Current_Country'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================

 
  test("MemberExtract - Check Member's Current Primary Zip Code column values not located in Ref table - 069") {

    val id = Array("069")
    val name = Array("Test case : Check Member's Current Primary Zip Code column values not located in Ref table")
    
    //val result1 = sqlContext.sql(""" select distinct zip_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd """)

    //val result2 = sqlContext.sql("""select distinct mbr_curnt_prmry_zip_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    //val result = result2.except(result1)
    
    val result =sqlContext.sql("""select MBR.bhi_home_plan_id, count(*) from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp MBR left outer join """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd REF on trim(MBR.mbr_curnt_prmry_zip_cd)=trim(REF.ZIP_CD) where mbr_curnt_prmry_zip_cd <> '99999' and length(trim(regexp_replace(mbr_curnt_prmry_zip_cd,' ', '')))<>0 and REF.ZIP_CD is null group by MBR.bhi_home_plan_id""")
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mbr_curnt_prmry_zip_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and mbr_curnt_prmry_zip_cd not in (select distinct zip_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd)")
      val data = Array(" 'Members_Current_Primary_Zip_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mbr_curnt_prmry_zip_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and mbr_curnt_prmry_zip_cd not in (select distinct zip_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd)")
      val data = Array("'Invalid Members_Current_Primary_Zip_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
  
  test("MemberExtract - Check  Member Gender column values not located in Ref table - 070") {

    val id = Array("070")
    val name = Array("Test case : Check  Member Gender column values not located in Ref table")
    
    val result1 = sqlContext.sql(""" select distinct gndr_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_gndr_inbnd """)

    val result2 = sqlContext.sql("""select distinct mbr_gndr_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mbr_gndr_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0  and mbr_gndr_cd not in (select distinct gndr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_gndr_inbnd)")
      val data = Array(" 'Member_Gender' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mbr_gndr_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0  and mbr_gndr_cd not in (select distinct gndr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_gndr_inbnd)")
      val data = Array("'Invalid Member_Gender'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================

  
  test("MemberExtract - Check Member Confidentiality Code column values not located in Ref table - 071") {

    val id = Array("071")
    val name = Array("Test case : Check Member Confidentiality Code column values not located in Ref table")
    
    val result1 = sqlContext.sql(""" select distinct mbr_cnfdntlty_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_cnfdntlty_cd_inbnd """)

    val result2 = sqlContext.sql("""select distinct mbr_cnfdntlty_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mbr_cnfdntlty_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and mbr_cnfdntlty_cd not in (select distinct mbr_cnfdntlty_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_cnfdntlty_cd_inbnd)")
      val data = Array(" 'Member_Confidentiality_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mbr_cnfdntlty_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and mbr_cnfdntlty_cd not in (select distinct mbr_cnfdntlty_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_cnfdntlty_cd_inbnd)")
      val data = Array("'Invalid Member_Confidentiality_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================

  
  test("MemberExtract - Check Member Relationship column values not located in Ref table - 072") {
    val id = Array("072")
    val name = Array("Test case : Check Member Relationship column values not located in Ref table")
    
    val result1 = sqlContext.sql(""" select distinct mbr_rltnshp_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_rltnshp_inbnd """)

    val result2 = sqlContext.sql("""select distinct mbr_rltnshp_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mbr_rltnshp_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and mbr_rltnshp_cd not in (select distinct mbr_rltnshp_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_rltnshp_inbnd)")
      val data = Array(" 'Member_Relationship' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mbr_rltnshp_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and mbr_rltnshp_cd not in (select distinct mbr_rltnshp_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_rltnshp_inbnd)")
      val data = Array("'Invalid Member_Relationship'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================

  
  test("MemberExtract - Check Enrollment Eligibility Status column values not located in Ref table - 073") {

    val id = Array("073")
    val name = Array("Test case : Check Enrollment Eligibility Status column values not located in Ref table")
    
    val result1 = sqlContext.sql(""" select distinct enrlmnt_elgblty_stts_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_enrlmnt_elgblty_stts_inbnd """)

    val result2 = sqlContext.sql("""select distinct enrlmnt_elgblty_stts_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct enrlmnt_elgblty_stts_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where  enrlmnt_elgblty_stts_cd not in (select distinct enrlmnt_elgblty_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_enrlmnt_elgblty_stts_inbnd)")
      val data = Array(" 'Enrollment_Eligibility_Status' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct enrlmnt_elgblty_stts_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where  enrlmnt_elgblty_stts_cd not in (select distinct enrlmnt_elgblty_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_enrlmnt_elgblty_stts_inbnd)")
      val data = Array("'Invalid Enrollment_Eligibility_Status'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================

  
  test("MemberExtract - Check Member Medical COB Code column values not located in Ref table - 074") {

    val id = Array("074")
    val name = Array("Test case : Check Member Medical COB Code column values not located in Ref table")
    
    val result1 = sqlContext.sql(""" select distinct mbr_mdcl_cob_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_mdcl_cob_inbnd """)

    val result2 = sqlContext.sql("""select distinct mbr_mdcl_cob_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mbr_mdcl_cob_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0  and mbr_mdcl_cob_cd not in (select distinct mbr_mdcl_cob_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_mdcl_cob_inbnd)")
      val data = Array(" 'Member_Medical_COB_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mbr_mdcl_cob_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0  and mbr_mdcl_cob_cd not in (select distinct mbr_mdcl_cob_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_mdcl_cob_inbnd)")
      val data = Array("'Invalid Member_Medical_COB_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================

  
  test("MemberExtract - Check Member Pharmacy COB Code column values not located in Ref table - 075") {

    val id = Array("075")
    val name = Array("Test case : Check Member Pharmacy COB Code column values not located in Ref table")
    
    val result1 = sqlContext.sql(""" select distinct mbr_phrmcy_cob_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_rx_cob_inbnd """)

    val result2 = sqlContext.sql("""select distinct mbr_phrmcy_cob_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mbr_phrmcy_cob_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and mbr_phrmcy_cob_cd not in (select distinct mbr_phrmcy_cob_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_rx_cob_inbnd)")
      val data = Array(" 'Member_Pharmacy_COB_Code' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mbr_phrmcy_cob_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and mbr_phrmcy_cob_cd not in (select distinct mbr_phrmcy_cob_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mbr_rx_cob_inbnd)")
      val data = Array("'Invalid Member_Pharmacy_COB_Code'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================

  
  test("MemberExtract - Check Deductible Category column values not located in Ref table - 076") {

    val id = Array("076")
    val name = Array("Test case : Check Deductible Category column values not located in Ref table")
    
    val result1 = sqlContext.sql(""" select distinct ddctbl_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_ddctbl_ctgry_inbnd """)

    val result2 = sqlContext.sql("""select distinct ddctbl_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct ddctbl_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where ddctbl_ctgry_cd not in (select distinct ddctbl_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_ddctbl_ctgry_inbnd )")
      val data = Array(" 'Deductible_Category' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct ddctbl_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where ddctbl_ctgry_cd not in (select distinct ddctbl_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_ddctbl_ctgry_inbnd )")
      val data = Array("'Invalid Deductible_Category'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================

  
  test("MemberExtract - Check MH/CD Enrollment Benefit column values not located in Ref table - 077") {

    val id = Array("077")
    val name = Array("Test case : Check MH/CD Enrollment Benefit column values not located in Ref table ")
    
    val result1 = sqlContext.sql(""" select distinct mh_cd_enrlmnt_bnft_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mh_cd_enrlmnt_bnft_xwalk_inbnd """)

    val result2 = sqlContext.sql("""select distinct mh_cd_enrlmnt_bnft_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0  and mh_cd_enrlmnt_bnft_cd != 'N'""")

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mh_cd_enrlmnt_bnft_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0  and mh_cd_enrlmnt_bnft_cd != 'N' and mh_cd_enrlmnt_bnft_cd not in (select distinct mh_cd_enrlmnt_bnft_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mh_cd_enrlmnt_bnft_xwalk_inbnd)")
      val data = Array(" 'MH/CD_Enrollment_Benefit' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mh_cd_enrlmnt_bnft_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0  and mh_cd_enrlmnt_bnft_cd != 'N' and mh_cd_enrlmnt_bnft_cd not in (select distinct mh_cd_enrlmnt_bnft_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_mh_cd_enrlmnt_bnft_xwalk_inbnd)")
      val data = Array("'Invalid MH/CD_Enrollment_Benefit'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================

  
  test("MemberExtract - Check Pharmacy Carve Out Submission Indicator column values not located in Ref table - 078") {

    val id = Array("078")
    val name = Array("Test case : Check Pharmacy Carve Out Submission Indicator column values not located in Ref table")
    
    val result1 = sqlContext.sql(""" select distinct phrmcy_crv_out_sbmsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_rx_crv_out_sbmsn_ind_xwalk_inbnd """)

    val result2 = sqlContext.sql("""select distinct phrmcy_crv_out_sbmsn_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct phrmcy_crv_out_sbmsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where  phrmcy_crv_out_sbmsn_ind not in (select distinct phrmcy_crv_out_sbmsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_rx_crv_out_sbmsn_ind_xwalk_inbnd)")
      val data = Array(" 'Pharmacy_Carve_Out_Submission_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct phrmcy_crv_out_sbmsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where phrmcy_crv_out_sbmsn_ind not in (select distinct phrmcy_crv_out_sbmsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_rx_crv_out_sbmsn_ind_xwalk_inbnd)")
      val data = Array("'Invalid Pharmacy_Carve_Out_Submission_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================

  
  test("MemberExtract - Check Pharmacy Benefit Tiers column values not located in Ref table - 079") {

    val id = Array("079")
    val name = Array("Test case : Check Pharmacy Benefit Tiers column values not located in Ref table")
    
    val result1 = sqlContext.sql(""" select distinct phrmcy_bnft_tier_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_rx_bnft_tier_inbnd """)

    val result2 = sqlContext.sql("""select distinct phrmcy_bnft_tiers_nbr_txt from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct phrmcy_bnft_tiers_nbr_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and phrmcy_bnft_tiers_nbr_txt not in (select distinct phrmcy_bnft_tier_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_rx_bnft_tier_inbnd)")
      val data = Array("'Pharmacy_Benefit_Tiers' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct phrmcy_bnft_tiers_nbr_txt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and phrmcy_bnft_tiers_nbr_txt not in (select distinct phrmcy_bnft_tier_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_rx_bnft_tier_inbnd)")
      val data = Array("'Invalid Pharmacy_Benefit_Tiers'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================

  
  test("MemberExtract - Check Government Subsidies Indicator column values not located in Ref table - 080") {

    val id = Array("080")
    val name = Array("Test case : Check Government Subsidies Indicator column values not located in Ref table")
    val result1 = sqlContext.sql(""" select distinct gov_sbsdy_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_gov_sbsdy_ind_inbnd """)

    val result2 = sqlContext.sql("""select distinct gov_sbsdy_ind from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct gov_sbsdy_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and gov_sbsdy_ind not in (select distinct gov_sbsdy_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_gov_sbsdy_ind_inbnd)")
      val data = Array(" 'Government_Subsidies_Indicator' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct gov_sbsdy_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and gov_sbsdy_ind not in (select distinct gov_sbsdy_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_gov_sbsdy_ind_inbnd)")
      val data = Array("'Invalid Government_Subsidies_Indicator'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================

  
  test("MemberExtract - Check Cost Sharing Reductions (CSR) Type  column values not located in Ref table - 081") {

    val id = Array("081")
    val name = Array("Test case : Check Cost Sharing Reductions (CSR) Type  column values not located in Ref table")
    val result1 = sqlContext.sql(""" select distinct csr_type_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cost_shrg_rdctn_type_inbnd """)

    val result2 = sqlContext.sql("""select distinct csr_type_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct csr_type_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where  csr_type_cd not in (select distinct csr_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cost_shrg_rdctn_type_inbnd) ")
      val data = Array(" 'Cost_Sharing_Reductions (CSR) Type' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct csr_type_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where  csr_type_cd not in (select distinct csr_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cost_shrg_rdctn_type_inbnd) ")
      val data = Array("'Invalid Cost_Sharing_Reductions (CSR) Type '")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  
  //===========================================

test("MemberExtract - Validate that Home Plan Product ID column is populated  as per the logic in mapping document - 082") {
    val id = Array("082")
    val name = Array("Test case : Validate that Home Plan Product ID column is populated  as per the logic in mapping document")
    
    val result1 = sqlContext.sql(""" select distinct prod_cf_cd  from """+dbname+"""_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa """)
    val result2 = sqlContext.sql(""" select distinct home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0""")
         
    val result = result2.except(result1)
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and home_plan_prod_id not in (select distinct prod_cf_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_co)")
      val data = Array("'Invalid HomePlan Product ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and home_plan_prod_id not in (select distinct prod_cf_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_co)")
      val data = Array(" 'HomePlan Product ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    }
   
    //===========================================
  
 test("MemberExtract - Check BHI Home Plan ID + Product Id column values not located in Product table - 083") {

    val id = Array("083")
    val name = Array("Test case : Check BHI Home Plan ID + Product Id column values not located in Product table")
    
    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_SRC from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_TGT from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0""")

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0 not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod)")
      val data = Array(" 'Home_Plan_Id + Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0 not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod)")
      val data = Array("'Home_Plan_Id + Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
    //===========================================



test("MemberExtract - Validate that Consistent Member ID column is populated  as per the logic in mapping document - 084") {
    val id = Array("084")
    val name = Array("Test case : Validate that Consistent Member ID column is populated  as per the logic in mapping document")
    
    val result1 = sqlContext.sql(""" select distinct mcid  from """+dbname+"""_pcandw1ph_nogbd_r000_in.PI_MCID_MBR_KEY_XWALK_ALL  """)
    val result2 = sqlContext.sql(""" select distinct cnsstnt_mbr_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0""")
         
    val result = result2.except(result1)
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct cnsstnt_mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and cnsstnt_mbr_id not in (select distinct mcid  from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.all_mbr_mcid)")
      val data = Array("'Invalid Consistent Member ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct cnsstnt_mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and cnsstnt_mbr_id not in (select distinct mcid  from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.all_mbr_mcid)")
      val data = Array(" 'Consistent Member ID'  : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    }
  
    //===========================================

  test("MemberExtract - Check BHI Home Plan ID + Traceability column values not located in Traceability table - 085") {

    val id = Array("085")
    val name = Array("Test case : Check BHI Home Plan ID + Traceability column values not located in Traceability table")
    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(src_sys_cd ))) as CONCAT_TGT from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0""")

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(src_sys_cd ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc)")
      val data = Array("'Home_Plan_Id + Traceability' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(src_sys_cd ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc)")
      val data = Array("'Home_Plan_Id + Traceability'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================


test("MemberExtract -Validate Member DOB is not greater tha Current Timestamp - 086") {
    val id = Array("086")
    val name = Array("Test case : Validate Member DOB is not greater tha Current Timestamp")
      import sqlContext.sql

    val result = sqlContext.sql("""select bhi_home_plan_id,mbr_brth_dt,mbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp""")
    result.createOrReplaceTempView("resultDF")
    
    val Invalid = result.filter($"mbr_brth_dt".gt(currdate2))
    Invalid.createOrReplaceTempView("InvalidDF")
    val invalidDOB = sqlContext.sql("""select a.mbr_brth_dt,b.bhi_home_plan_id,b.mbr_id,count(*) as Count from InvalidDF a join resultDF b on a.mbr_brth_dt = b.mbr_brth_dt group by a.mbr_brth_dt,b.bhi_home_plan_id,b.mbr_id""")
    
    
    if (invalidDOB.count > 0) {
      val a = invalidDOB.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select a.mbr_brth_dt,b.bhi_home_plan_id,count(*) as Count from InvalidDF a join resultDF b on a.mbr_brth_dt = b.mbr_brth_dt group by a.mbr_brth_dt,b.bhi_home_plan_id")
      val data = Array("'Invalid_Member_DOB','BHI HPID','MBR_ID','Count'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select a.mbr_brth_dt,b.bhi_home_plan_id,count(*) as Count from InvalidDF a join resultDF b on a.mbr_brth_dt = b.mbr_brth_dt group by a.mbr_brth_dt,b.bhi_home_plan_id")
      val data = Array(" 'Member_DOB','BHI HPID','MBR_ID','Count' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
 
  test("MemberExtract -Validate Member DOB is not greater than 125years - 087") {
    val id = Array("087")
    val name = Array("Test case : Validate Member DOB is not greater than 125years")
    
   val result = sqlContext.sql("""select bhi_home_plan_id,mbr_id,date(mbr_brth_dt) as MemberDOB,current_date() as CurrentDate from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp""")
    
   val valid = result.filter($"MemberDOB".lt(currdate1))
    valid.createOrReplaceTempView("validDF")
    
   val age = sqlContext.sql("""select bhi_home_plan_id,mbr_id,CurrentDate,MemberDOB,floor((datediff(to_date(CurrentDate),to_date(MemberDOB)))/365) as Age from validDF """)
   age.createOrReplaceTempView("ageDF")
    
   val invalid = sqlContext.sql(""" select MemberDOB,bhi_home_plan_id,mbr_id,Age from ageDF where Age > 125 """)
   
    
    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select MemberDOB,bhi_home_plan_id,Age from (select bhi_home_plan_id,CurrentDate,MemberDOB,floor((datediff(to_date(CurrentDate),to_date(MemberDOB)))/365) as Age from validDF) where Age > 125")
      val data = Array("'Invalid_Member_DOB','BHI HPID','Member ID','Age'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select MemberDOB,bhi_home_plan_id,Age from (select bhi_home_plan_id,CurrentDate,MemberDOB,floor((datediff(to_date(CurrentDate),to_date(MemberDOB)))/365) as Age from validDF) where Age > 125")
      val data = Array(" 'Member_DOB','BHI HPID','Member ID','Age' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
  
   test("MemberExtract - Check Member Gender Code column has Valid Values - 088") {

    val id = Array("088")
    val name = Array("Test case : Check Member Gender Code column has Valid Values")
    val result = sqlContext.sql("""select distinct  mbr_gndr_cd ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mbr_gndr_cd NOT IN ('M','F','U')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct  mbr_gndr_cd ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mbr_gndr_cd NOT IN ('M','F','U')")
      val data = Array(" 'Member_Gender_Code','BHI_HomePlan_ID','Product_ID'  : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct  mbr_gndr_cd ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mbr_gndr_cd NOT IN ('M','F','U')")
      val data = Array("'Invalid Member_Gender_Code','BHI_HomePlan_ID','Product_ID'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
   
  test("MemberExtract - Validate that Subsciber ID column is populated  as per the logic in mapping document - 089") {
    val id = Array("089")
    val name = Array("Test case : Validate that Subsciber ID column is populated  as per the logic in mapping document")
    
    val result1 = sqlContext.sql(""" select distinct mcid  from """+dbname+"""_pcandw1ph_nogbd_r000_in.PI_MCID_MBR_KEY_XWALK_ALL  """)
    val result2 = sqlContext.sql(""" select distinct sbscrbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0""")
         
    val result = result2.except(result1)
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct sbscrbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and sbscrbr_id not in (select distinct mcid  from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.all_mbr_mcid)")
      val data = Array("'Invalid Subsciber ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct sbscrbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and sbscrbr_id not in (select distinct mcid  from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.all_mbr_mcid)")
      val data = Array(" 'Subsciber ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
  }
   
    //===========================================
  
  
  test("MemberExtract - Check  BHI Home Plan ID + Home Plan Product ID + Account + Group + Subgroup column values not located in PCC table - 090") {

    val id = Array("090")
    val name = Array("Test case : Check  BHI Home Plan ID + Home Plan Product ID + Account + Group + Subgroup column values not located in PCC table")
    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) , trim(acct_id) , trim(grp_id) , trim(subgrp_id))) as CONCAT_SRC from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) , trim(acct_id) , trim(grp_id) , trim(subgrp_id))) as CONCAT_TGT from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0""")

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : elect distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) , trim(acct_id) , trim(grp_id) , trim(subgrp_id))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) , trim(acct_id) , trim(grp_id) , trim(subgrp_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct)")
      val data = Array(" 'Home_Plan_Id + Product + Acoount + Group + Sub Group' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : elect distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) , trim(acct_id) , trim(grp_id) , trim(subgrp_id))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) , trim(acct_id) , trim(grp_id) , trim(subgrp_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct)")
      val data = Array("'Home_Plan_Id + Product + Acoount + Group + Sub Group'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //===========================================
  
  test("MemberExtract -Validate SubGroup='NOSUB' if Group='NOGRP' - 091") {
    val id = Array("091")
    val name = Array("Test case : Validate SubGroup='NOSUB' if Group='NOGRP'")
    val result = sqlContext.sql("""select bhi_home_plan_id,subgrp_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where grp_id='NOGRP' and subgrp_id!='NOSUB'""")
        
   
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,subgrp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where grp_id='NOGRP' and subgrp_id!='NOSUB'")
      val data = Array("'BHI HPID','SUB_GROUP'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,subgrp_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where grp_id='NOGRP' and subgrp_id!='NOSUB'")
      val data = Array(" 'BHI HPID','SUB_GROUP' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    
    
 }
  
  //===========================================
  
  test("MemberExtract - Check Coverage End Date is before Coverage Begin date - 092") {
    val id = Array("092")
    val name = Array("Test case : Check Coverage End Date is before Coverage Begin date")
    val result = sqlContext.sql("""select bhi_home_plan_id, date(cvrg_bgn_dt) as BeginDate, date(cvrg_end_dt) as EndDate from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0""")
    
    result.createOrReplaceTempView("resultDF")
    
    val invalid = sqlContext.sql(""" select * from resultDF where EndDate < BeginDate """)
   
    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id, date(cvrg_bgn_dt) as BeginDate, date(cvrg_end_dt) as EndDate from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0) where EndDate < BeginDate")
      val data = Array("'BHI HPID','Coverage_Begin_Date','Coverage_End_Date'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from (select bhi_home_plan_id, date(cvrg_bgn_dt) as BeginDate, date(cvrg_end_dt) as EndDate from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0) where EndDate < BeginDate")
      val data = Array(" 'BHI HPID','Coverage_Begin_Date','Coverage_End_Date' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    
    
 }
  
  //===========================================
  
  
   test("MemberExtract - Check Member Medical COB Code column has Valid Values - 093") {

    val id = Array("093")
    val name = Array("Test case : Check Member Medical COB Code column has Valid Values")
    
    val result = sqlContext.sql("""select distinct  mbr_mdcl_cob_cd  ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mbr_mdcl_cob_cd NOT IN ('P','S','M','N','A')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : elect distinct  mbr_mdcl_cob_cd  ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mbr_mdcl_cob_cd NOT IN ('P','S','M','N','A')")
      val data = Array(" 'MBR_Medical_COB_Code','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : elect distinct  mbr_mdcl_cob_cd  ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mbr_mdcl_cob_cd NOT IN ('P','S','M','N','A')")
      val data = Array("'Invalid MBR_Medical_COB_Code','BHI_HomePlan_ID','Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
  
   test("MemberExtract - Check Member Pharmacy COB Code column has Valid Values - 094") {

   val id = Array("094")
    val name = Array("Test case : Check Member Pharmacy COB Code column has Valid Values")
    
    val result = sqlContext.sql("""select distinct  mbr_phrmcy_cob_cd ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mbr_phrmcy_cob_cd  NOT IN ('P','S','M','N','A')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct  mbr_phrmcy_cob_cd ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mbr_phrmcy_cob_cd  NOT IN ('P','S','M','N','A')")
      val data = Array(" 'MBR_Pharmacy_COB_Code','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct  mbr_phrmcy_cob_cd ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mbr_phrmcy_cob_cd  NOT IN ('P','S','M','N','A')")
      val data = Array("'Invalid MBR_Pharmacy_COB_Code','BHI_HomePlan_ID','Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
  
   test("MemberExtract - Check Deductible Category column has Valid Values - 095") {

    val id = Array("095")
    val name = Array("Test case : Check Deductible Category column has Valid Values")
    
    val result = sqlContext.sql("""select distinct  ddctbl_ctgry_cd ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where ddctbl_ctgry_cd  NOT IN ('0','1','2','3','4','5','N','U')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct  ddctbl_ctgry_cd ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where ddctbl_ctgry_cd  NOT IN ('0','1','2','3','4','5','N','U') ")
      val data = Array(" 'Deductible_Category','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct  ddctbl_ctgry_cd ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where ddctbl_ctgry_cd  NOT IN ('0','1','2','3','4','5','N','U') ")
      val data = Array("'Invalid Deductible_Category','BHI_HomePlan_ID','Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //=========================================== 
  
 test("MemberExtract - Check MH/CD Enrollment Benefit column has Valid Values - 096") {

    val id = Array("096")
    val name = Array("Test case : Check MH/CD Enrollment Benefit column has Valid Values")
    
    val result = sqlContext.sql("""select distinct mh_cd_enrlmnt_bnft_cd ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mh_cd_enrlmnt_bnft_cd  NOT IN ('B','C','M','N')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mh_cd_enrlmnt_bnft_cd ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mh_cd_enrlmnt_bnft_cd  NOT IN ('B','C','M','N')")
      val data = Array(" 'MH/CD_Enrollment_Benefit','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mh_cd_enrlmnt_bnft_cd ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mh_cd_enrlmnt_bnft_cd  NOT IN ('B','C','M','N')")
      val data = Array("'Invalid MH/CD_Enrollment_Benefit','BHI_HomePlan_ID','Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //=========================================== 
  
   test("MemberExtract - Check Pharmacy Benefit Indicator column has Valid Values - 097") {

    val id = Array("097")
    val name = Array("Test case : Check Pharmacy Benefit Indicator column has Valid Values")
    
    val result = sqlContext.sql("""select distinct phrmcy_bnft_ind  ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where phrmcy_bnft_ind  NOT IN ('Y','N')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct phrmcy_bnft_ind  ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where phrmcy_bnft_ind  NOT IN ('Y','N') ")
      val data = Array(" 'Pharmacy_Benefit_Indicator','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct phrmcy_bnft_ind  ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where phrmcy_bnft_ind  NOT IN ('Y','N') ")
      val data = Array("'Invalid Pharmacy_Benefit_Indicator','BHI_HomePlan_ID','Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //=========================================== 
   
  test("MemberExtract - Check MH/CD Benefit Indicator column has Valid Values - 098") {

    val id = Array("098")
    val name = Array("Test case : Check MH/CD Benefit Indicator column has Valid Values")
    
    val result = sqlContext.sql("""select distinct mh_cd_bnft_ind ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mh_cd_bnft_ind  NOT IN ('Y','N')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mh_cd_bnft_ind ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mh_cd_bnft_ind  NOT IN ('Y','N') ")
      val data = Array(" 'MH/CD_Benefit_Indicator','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mh_cd_bnft_ind ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mh_cd_bnft_ind  NOT IN ('Y','N') ")
      val data = Array("'Invalid MH/CD_Benefit_Indicator','BHI_HomePlan_ID','Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //=========================================== 
    
 test("MemberExtract - Check Medical Benefit Indicator column has Valid Values - 099") {

    val id = Array("099")
    val name = Array("Test case : Check Medical Benefit Indicator column has Valid Values")
    
    val result = sqlContext.sql("""select distinct  mdcl_bnft_ind ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mdcl_bnft_ind  NOT IN ('Y','N')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct  mdcl_bnft_ind ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mdcl_bnft_ind  NOT IN ('Y','N') ")
      val data = Array(" 'Medical_Benefit_Indicator','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct  mdcl_bnft_ind ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where mdcl_bnft_ind  NOT IN ('Y','N') ")
      val data = Array("'Invalid Medical_Benefit_Indicator','BHI_HomePlan_ID','Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //=========================================== 
     
   test("MemberExtract - Check Hospital Benefit Indicator column has Valid Values - 100") {

   val id = Array("100")
    val name = Array("Test case : Check Hospital Benefit Indicator column has Valid Values")
    
    val result = sqlContext.sql("""select distinct  hosp_bnft_ind ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where hosp_bnft_ind  NOT IN ('Y','N')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct  hosp_bnft_ind ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where hosp_bnft_ind  NOT IN ('Y','N')  ")
      val data = Array(" 'Hospital_Benefit_Indicator','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct  hosp_bnft_ind ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where hosp_bnft_ind  NOT IN ('Y','N')  ")
      val data = Array("'Invalid Hospital_Benefit_Indicator','BHI_HomePlan_ID','Product_ID'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //=========================================== 
  
  
  test("MemberExtract - Check BHI Network Category - Facility has 1 PPO value - 101") {

    val id = Array("101")
    val name = Array("Test case : Check BHI Network Category - Facility has 1 PPO value")
    
    val result = sqlContext.sql("""select distinct fclty_bnfts_bhi_ntwk_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where fclty_bnfts_bhi_ntwk_ctgry_cd = 'PPO' """)
    
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct fclty_bnfts_bhi_ntwk_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where fclty_bnfts_bhi_ntwk_ctgry_cd = 'PPO'")
      val data = Array(" 'BHI Network Category-Facility has No PPO value' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct fclty_bnfts_bhi_ntwk_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where fclty_bnfts_bhi_ntwk_ctgry_cd = 'PPO'")
      val data = Array("'BHI Network Category-Facility has No PPO value'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
  
   test("MemberExtract - Check BHI Network Category - Professional has 1 PPO value - 102") {

    val id = Array("102")
    val name = Array("Test case : Check BHI Network Category - Professional has 1 PPO value")
    
    val result = sqlContext.sql("""select distinct prfsnl_bnfts_bhi_ntwk_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where prfsnl_bnfts_bhi_ntwk_ctgry_cd = 'PPO' """)
    
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct prfsnl_bnfts_bhi_ntwk_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where prfsnl_bnfts_bhi_ntwk_ctgry_cd = 'PPO'")
      val data = Array("'BHI Network Category-Professional has No PPO value'  : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct prfsnl_bnfts_bhi_ntwk_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where prfsnl_bnfts_bhi_ntwk_ctgry_cd = 'PPO'")
      val data = Array("'BHI Network Category-Professional has No PPO value'")
     sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
  
 test("MemberExtract - Check BHI Home Plan ID + Plan Network category facility column values not located in Plan Network category facility table - 103") {

    val id = Array("103")
    val name = Array("Test case : Check BHI Home Plan ID + Plan Network category facility column values not located in Plan Network category facility table")
    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(plan_fclty_ntwk_ctgry_cd))) as CONCAT_SRC from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_plan_ntwk_fclty  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(fclty_bnfts_plan_ntwk_ctgry_cd  ))) as CONCAT_TGT from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0""")

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(fclty_bnfts_plan_ntwk_ctgry_cd  ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(plan_fclty_ntwk_ctgry_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_plan_ntwk_fclty)")
      val data = Array(" 'Home_Plan_Id + Plan Network category facility' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(fclty_bnfts_plan_ntwk_ctgry_cd  ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(plan_fclty_ntwk_ctgry_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_plan_ntwk_fclty)")
      val data = Array("'Home_Plan_Id + Plan Network category facility'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //=========================================== 
  
 test("MemberExtract - Check BHI Home Plan ID + Plan Network category Professional column values not located in Plan Network category Professional table - 104") {

    val id = Array("104")
    val name = Array("Test case : Check BHI Home Plan ID + Plan Network category Professional column values not located in Plan Network category Professional table")
    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(plan_prfsnl_ntwk_ctgry_cd))) as CONCAT_SRC from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_plan_ntwk_prfsnl  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(prfsnl_bnfts_plan_ntwk_ctgry_cd   ))) as CONCAT_TGT from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0""")

    val result = result2.except(result1)
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(prfsnl_bnfts_plan_ntwk_ctgry_cd   ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(plan_prfsnl_ntwk_ctgry_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_plan_ntwk_prfsnl)")
      val data = Array(" 'Home_Plan_Id + Plan Network category Professional' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(prfsnl_bnfts_plan_ntwk_ctgry_cd   ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(plan_prfsnl_ntwk_ctgry_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_plan_ntwk_prfsnl)")
      val data = Array("'Home_Plan_Id + Plan Network category Professional'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   
  //=========================================== 
  
  test("MemberExtract - Check Pharmacy Carve Out Submission Indicator column has Valid Values - 105") {

    val id = Array("105")
    val name = Array("Test case : Check Pharmacy Carve Out Submission Indicator column has Valid Values")
    
    val result = sqlContext.sql("""select distinct phrmcy_crv_out_sbmsn_ind ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where phrmcy_crv_out_sbmsn_ind   NOT IN ('Y','N','C','X')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct phrmcy_crv_out_sbmsn_ind ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where phrmcy_crv_out_sbmsn_ind   NOT IN ('Y','N','C','X')")
      val data = Array(" 'Pharmacy_Carve_Out_Submission_Indicator','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct phrmcy_crv_out_sbmsn_ind ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where phrmcy_crv_out_sbmsn_ind   NOT IN ('Y','N','C','X')")
      val data = Array("'Invalid Pharmacy_Carve_Out_Submission_Indicator','BHI_HomePlan_ID','Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //=========================================== 
 
  test("MemberExtract - Check Pharmacy Benefit Tiers column has Valid Values - 106") {

    val id = Array("106")
    val name = Array("Test case : Check Pharmacy Benefit Tiers column has Valid Values")
    
    val result = sqlContext.sql("""select distinct phrmcy_bnft_tiers_nbr_txt ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where phrmcy_bnft_tiers_nbr_txt NOT IN ('00','01','02','03','04','98')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct phrmcy_bnft_tiers_nbr_txt ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where phrmcy_bnft_tiers_nbr_txt NOT IN ('00','01','02','03','04','98')")
      val data = Array(" 'Pharmacy_Benefit_Tiers','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct phrmcy_bnft_tiers_nbr_txt ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where phrmcy_bnft_tiers_nbr_txt NOT IN ('00','01','02','03','04','98')")
      val data = Array("'Invalid Pharmacy_Benefit_Tiers','BHI_HomePlan_ID','Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //=========================================== 
 
    
   test("MemberExtract - Check Benefit Package ID has 1 NA value - 107") {

    val id = Array("107")
    val name = Array("Test case : Check Benefit Package ID has 1 NA value")
    
    val result = sqlContext.sql("""select distinct bnft_pkg_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where bnft_pkg_id not in ('NA') """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct bnft_pkg_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where bnft_pkg_id  not in ('NA')")
      val data = Array(" Benefit Package ID has only 'NA' value'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct bnft_pkg_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where bnft_pkg_id not in ('NA')")
      val data = Array("'Invalid Benefit Package ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //===========================================
   
   
  test("MemberExtract - Check Government Subsidies Indicator column has Valid Values - 108") {

    val id = Array("108")
    val name = Array("Test case : Check Government Subsidies Indicator column has Valid Values")
    
    val result = sqlContext.sql("""select distinct gov_sbsdy_ind ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where gov_sbsdy_ind NOT IN ('Y','N','U')  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct gov_sbsdy_ind ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where gov_sbsdy_ind NOT IN ('Y','N','U')")
      val data = Array(" 'Government_Subsidies_Indicator','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct gov_sbsdy_ind ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where gov_sbsdy_ind NOT IN ('Y','N','U')")
      val data = Array("'Invalid Government_Subsidies_Indicator','BHI_HomePlan_ID','Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //=========================================== 

  
 test("MemberExtract - Check NLO Account Type  column has Valid Values - 109") {

    val id = Array("109")
    val name = Array("Test case : Check NLO Account Type  column has Valid Values")
    
    val result = sqlContext.sql("""select distinct nlo_acct_type_cd ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where nlo_acct_type_cd  NOT IN ('03',trim(' '))  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct nlo_acct_type_cd ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where nlo_acct_type_cd  NOT IN ('03',trim(' '))")
      val data = Array(" 'NLO_Account_Type ','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct nlo_acct_type_cd ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where nlo_acct_type_cd  NOT IN ('03',trim(' '))")
      val data = Array("'Invalid NLO_Account_Type ','BHI_HomePlan_ID','Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //=========================================== 
 
  test("MemberExtract - Check NLO Plan Type  column has Valid Values - 110") {

    val id = Array("110")
    val name = Array("Test case : Check NLO Plan Type  column has Valid Values")
    val result = sqlContext.sql("""select distinct nlo_plan_type_cd ,bhi_home_plan_id ,home_plan_prod_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where nlo_plan_type_cd NOT IN ('01','02',trim(' '))  """)

    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct nlo_plan_type_cd ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where nlo_plan_type_cd NOT IN ('01','02',trim(' '))")
      val data = Array(" 'NLO_Plan_Type ','BHI_HomePlan_ID','Product_ID' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct nlo_plan_type_cd ,bhi_home_plan_id ,home_plan_prod_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where nlo_plan_type_cd NOT IN ('01','02',trim(' '))")
      val data = Array("'Invalid NLO_Plan_Type ','BHI_HomePlan_ID','Product_ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
  
  //=========================================== 

test("MemberExtract - Check Ref Integrity of Member and Acoount Reporting - 111") {

    val id = Array("111")
    val name = Array("Test case : Check Ref Integrity of Member and Acoount Reporting")
    
    val result = sqlContext.sql("""select MBR.bhi_home_plan_id,MBR.mbr_id,MBR.acct_id,AR.acct_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp MBR 
      left outer join """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_acct_rptg AR on trim(MBR.acct_id)=trim(AR.acct_id) where AR.acct_id is NULL 
        group by MBR.bhi_home_plan_id,MBR.mbr_id,MBR.acct_id,AR.acct_id """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_id,acct_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp MBR  where MBR.acct_id is not NULL and trim(MBR.acct_id) not in  (select trim(AR.acct_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_acct_rptg AR) group by MBR.bhi_home_plan_id")
      val data = Array(" 'BHI_HomePlan_ID','MBR ID','MBR Account ID','ACCNT Account ID' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_id,acct_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp MBR  where MBR.acct_id is not NULL and trim(MBR.acct_id) not in  (select trim(AR.acct_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_acct_rptg AR) group by MBR.bhi_home_plan_id")
      val data = Array(" 'BHI_HomePlan_ID','MBR ID','MBR Account ID','ACCNT Account ID' : Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================

  test("MemberExtract - Count of pharmacy indicator, pharmacy cob code, pharmacy benefit tiers should be equal- 112") {

    val id = Array("112")
    val name = Array("Test case :  Count of pharmacy indicator, pharmacy cob code, pharmacy benefit tiers should be equal")
    
    val result1 = sqlContext.sql("""select * from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where phrmcy_bnft_ind='N' """)
   
    val result2 = sqlContext.sql("""select * from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where phrmcy_bnft_tiers_nbr_txt ='98' """)
    
    val result3 = sqlContext.sql("""select * from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mbr_phrmcy_cob_cd ='N' """)
    val res1 = result1.count
    val res2 = result2.count
    val res3 = result3.count
    if (res1 == res2 && res1 == res3) {
      val a = result1.rdd
      val b = result2.rdd
      val c = result3.rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where phrmcy_bnft_ind='N' ")
      val query2 = Array("Test Query : select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where phrmcy_bnft_tiers_nbr_txt ='98' ")
      val query3 = Array("Test Query : select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mbr_phrmcy_cob_cd ='N' ")
      val data = Array(" Count of pharmacy indicator, pharmacy cob code, pharmacy benefit tiers are equal")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(query3,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).union(c.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } 
    else {
      val a = result1.rdd
      val b = result2.rdd
      val c = result3.rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where phrmcy_bnft_ind='N' ")
      val query2 = Array("Test Query : select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where phrmcy_bnft_tiers_nbr_txt ='98' ")
      val query3 = Array("Test Query : select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mbr_phrmcy_cob_cd ='N' ")
      val data = Array(" Count of pharmacy indicator, pharmacy cob code, pharmacy benefit tiers are not equal")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(query3,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).union(c.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================

   test("MemberExtract - Count of MHCD enrollment benefit and MHCD bnft ind should be equal- 113") {

    val id = Array("113")
    val name = Array("Test case : Count of MHCD enrollment benefit and MHCD bnft ind should be equal")
    
    val result1 = sqlContext.sql("""select count(*) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mh_cd_enrlmnt_bnft_cd ='N' """)
    
    val result2 = sqlContext.sql("""select count(*) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mh_cd_bnft_ind ='N' """)

    
    if (result1.first() == result2.first()) {
      val a = result1.rdd
      val b = result2.rdd
     
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mh_cd_enrlmnt_bnft_cd ='N' ")
      val query2 = Array("Test Query : select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mh_cd_bnft_ind ='N'")
      
      val data = Array(" Count of MHCD enrollment benefit and MHCD bnft ind are equal")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.rdd
      val b = result2.rdd
      
      val status = Array("FAILED")
      val query1 = Array("Test Query : select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mh_cd_enrlmnt_bnft_cd ='N' ")
      val query2 = Array("Test Query : select count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mh_cd_bnft_ind ='N'")
      
      val data = Array(" Count of MHCD enrollment benefit and MHCD bnft ind are not equal")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("MemberExtract - Count of Hospital and Medical bnft ind should be equal- 114") {

    val id = Array("114")
    val name = Array("Test case : Count of Hospital and Medical bnft ind should be equal")
    
    val result1 = sqlContext.sql(""" select count(*) from ts_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mdcl_bnft_ind  ='N' and bhi_home_plan_id <>'254' """)
    
    val result2 = sqlContext.sql(""" select count(*) from ts_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where hosp_bnft_ind ='N' and bhi_home_plan_id <>'254' """)

    
    if (result1.first() == result2.first()) {
      val a = result1.rdd
      val b = result2.rdd
     
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select count(*) from ts_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mdcl_bnft_ind  ='N' and bhi_home_plan_id <>'254'")
      val query2 = Array("Test Query : select count(*) from ts_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where hosp_bnft_ind ='N' and bhi_home_plan_id <>'254'")
      
      val data = Array(" Count of Hospital and Medical bnft ind are equal")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.rdd
      val b = result2.rdd
      
      val status = Array("FAILED")
      val query1 = Array("Test Query : select count(*) from ts_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mdcl_bnft_ind  ='N' and bhi_home_plan_id <>'254'")
      val query2 = Array("Test Query : select count(*) from ts_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where hosp_bnft_ind ='N' and bhi_home_plan_id <>'254'")
      
      val data = Array(" Count of Hospital and Medical bnft ind are not equal")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("MemberExtract - Validate that Member Confidentiality Code has values other than NON - 115") {

    val id = Array("115")
    val name = Array("Test case : Validate that Member Confidentiality Code has values other than NON")
    
    val result = sqlContext.sql("""select distinct mbr_cnfdntlty_cd,bhi_home_plan_id,mbr_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where mbr_cnfdntlty_cd<>'NON'""")
    
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mbr_cnfdntlty_cd ,bhi_home_plan_id,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where mbr_cnfdntlty_cd<>'NON'")
      val data = Array(" 'Member Confidentiality Code','BHI_HomePlan_ID','MBR ID' : Valid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mbr_cnfdntlty_cd ,bhi_home_plan_id,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where mbr_cnfdntlty_cd<>'NON'")
      val data = Array(" 'Member Confidentiality Code','BHI_HomePlan_ID','MBR ID' : No Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("MemberExtract - Validate that No record should have country code as 'NA' - 116") {

    val id = Array("116")
    val name = Array("Test case : Validate that No record should have country code as 'NA'")
    
    val result = sqlContext.sql("""select mbr_curnt_cntry_cd,bhi_home_plan_id,mbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where mbr_curnt_cntry_cd='NA'""")
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select mbr_curnt_cntry_cd,bhi_home_plan_id,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where mbr_curnt_cntry_cd='NA'")
      val data = Array(" 'Member Current Country Code','BHI_HomePlan_ID','MBR ID' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select mbr_curnt_cntry_cd,bhi_home_plan_id,mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where mbr_curnt_cntry_cd='NA'")
      val data = Array(" 'Member Current Country Code','BHI_HomePlan_ID','MBR ID' : Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("MemberExtract - Validate that Coverage End Date should not lie in year '8888' for any record - 117") {

    val id = Array("117")
    val name = Array("Test case : Validate that Coverage End Date should not lie in year '8888' for any record")
    
    val result = sqlContext.sql("""select cvrg_end_dt,bhi_home_plan_id,mbr_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where cvrg_end_dt like '%8888%' """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select cvrg_end_dt,bhi_home_plan_id,mbr_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where cvrg_end_dt like '%8888%'")
      val data = Array(" 'Coverage End date','BHI_HomePlan_ID','MBR ID' : No Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select cvrg_end_dt,bhi_home_plan_id,mbr_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where cvrg_end_dt like '%8888%'")
      val data = Array(" 'Coverage End date','BHI_HomePlan_ID','MBR ID' :Invalid Values Found")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("MemberExtract - Validate that all members which have pharmacy coverage have pharmacy benefit indicator as 'Y' - 118") {

    val id = Array("118")
    val name = Array("Test case : Validate that all members which have pharmacy coverage have pharmacy benefit indicator as 'Y' ")
    
    val result = sqlContext.sql("""select * from (select MBR.mbr_id,case when array_contains(collect_set(MBR.phrmcy_bnft_ind),'Y') then 1 else 0 end as ind from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp MBR inner join """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm CLM on MBR.mbr_id = CLM.mbr_id and MBR.acct_id=CLM.acct_cd and MBR.grp_id=CLM.grp_cd and MBR.subgrp_id=CLM.subgrp_cd group by MBR.mbr_id having ind = 0)a """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from (select MBR.mbr_id,case when array_contains(collect_set(MBR.phrmcy_bnft_ind),'Y') then 1 else 0 end as ind from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp MBR inner join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm CLM on MBR.mbr_id = CLM.mbr_id and MBR.acct_id=CLM.acct_cd and MBR.grp_id=CLM.grp_cd and MBR.subgrp_id=CLM.subgrp_cd group by MBR.mbr_id having ind = 0)a")
      val data = Array("Member has Pharmacy Coverage but the Pharmacy Benefit Indicator is 'Y' ")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select MBR.mbr_id,case when array_contains(collect_set(MBR.phrmcy_bnft_ind),'Y') then 1 else 0 end as ind from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp MBR inner join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_phrmcy_clm CLM on MBR.mbr_id = CLM.mbr_id and MBR.acct_id=CLM.acct_cd and MBR.grp_id=CLM.grp_cd and MBR.subgrp_id=CLM.subgrp_cd group by MBR.mbr_id having ind = 0)a")
      val data = Array("Member has Pharmacy Coverage but the Pharmacy Benefit Indicator is 'N'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("MemberExtract - Validate that there are no Medicare Supplement products in the submission - 119") {

    val id = Array("119")
    val name = Array("Test case :  Validate that there are no Medicare Supplement products in the submission")
    
    val result = sqlContext.sql(""" select bhi_home_plan_id,mbr_id,home_plan_prod_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where home_plan_prod_id in ("MPLCN","MPPMS") """)
    
    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where home_plan_prod_id in ('MPLCN','MPPMS')")
      val data = Array("'BHI HomePlan ID','Member ID','HomePlan Product ID' : No Invalid values")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_id,home_plan_prod_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp where home_plan_prod_id in ('MPLCN','MPPMS')")
      val data = Array("'BHI HomePlan ID','Member ID','HomePlan Product ID' ")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
  
   
   test("MemberExtract - Member medical COB Code as per mapping doc - 120") {

    val id = Array("120")
    val name = Array("Test case :  Member medical COB Code as per mapping doc")
    
    val result1 = sqlContext.sql(""" select bhi_home_plan_id,mbr_id, count(*) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mdcl_bnft_ind="Y" and mbr_mdcl_cob_cd ="N" 
group by bhi_home_plan_id,mbr_id order by bhi_home_plan_id """)

    val result2 = sqlContext.sql(""" select bhi_home_plan_id,mbr_id, count(*) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mdcl_bnft_ind="Y" and hosp_bnft_ind="Y" and ddctbl_ctgry_cd<>"N" 
and mbr_mdcl_cob_cd ="N" group by bhi_home_plan_id,mbr_id order by bhi_home_plan_id """)
    
    if (result1.count == 0 && result2.count == 0) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select bhi_home_plan_id,mbr_id, count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mdcl_bnft_ind='Y' and mbr_mdcl_cob_cd ='N' group by bhi_home_plan_id,mbr_id order by bhi_home_plan_id")
      val query2 = Array("Test Query : select bhi_home_plan_id,mbr_id, count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mdcl_bnft_ind='Y' and hosp_bnft_ind='Y' and ddctbl_ctgry_cd<>'N' and mbr_mdcl_cob_cd ='N' group by bhi_home_plan_id,mbr_id order by bhi_home_plan_id ")
      val data = Array("'BHI HomePlan ID','Member ID','Count' : No Invalid values")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select bhi_home_plan_id,mbr_id, count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mdcl_bnft_ind='Y' and mbr_mdcl_cob_cd ='N' group by bhi_home_plan_id,mbr_id order by bhi_home_plan_id")
      val query2 = Array("Test Query : select bhi_home_plan_id,mbr_id, count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mdcl_bnft_ind='Y' and hosp_bnft_ind='Y' and ddctbl_ctgry_cd<>'N' and mbr_mdcl_cob_cd ='N' group by bhi_home_plan_id,mbr_id order by bhi_home_plan_id ")
      val data = Array("'BHI HomePlan ID','Member ID','Count' ")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("MemberExtract - Medical and Hospital Benefit Ind, Except plan 254, should be on sync - 121") {

    val id = Array("121")
    val name = Array("Test case : Medical and Hospital Benefit Ind, Except plan 254, should be on sync ")
    
    val result1 = sqlContext.sql(""" select bhi_home_plan_id, count(*) cnt1 from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp 
      where mdcl_bnft_ind="N" and bhi_home_plan_id <>"254" group by bhi_home_plan_id order by bhi_home_plan_id """)
      result1.createOrReplaceTempView("result1DF")
      
    val result2 = sqlContext.sql(""" select bhi_home_plan_id, count(*) cnt2 from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp 
      where hosp_bnft_ind="N" and bhi_home_plan_id <>"254" group by bhi_home_plan_id order by bhi_home_plan_id """)
    result2.createOrReplaceTempView("result2DF")
      
    val result =  sqlContext.sql(""" select a.bhi_home_plan_id,a.cnt1,b.cnt2,case when a.cnt1=b.cnt2 then '0' else '1' end as match from result1DF a  join result2DF b 
        on a.bhi_home_plan_id=b.bhi_home_plan_id""").createOrReplaceTempView("resultDF")
      val invalid = sqlContext.sql(""" select * from resultDF a having a.match='1' """)
      
    if (invalid.count == 0) {
      val a = result1.limit(15).rdd
      val b = result2.limit(15).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query1 : select bhi_home_plan_id, count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mdcl_bnft_ind='N' and bhi_home_plan_id <>'254' group by bhi_home_plan_id order by bhi_home_plan_id")
      val query2 = Array("Test Query2 : select bhi_home_plan_id, count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where hosp_bnft_ind='N' and bhi_home_plan_id <>'254' group by bhi_home_plan_id order by bhi_home_plan_id")
      val data1 = Array("'BHI HomePlan ID','Count'")
      val data2 = Array("'BHI HomePlan ID','Count'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(data1,1)).union(a.map(_.toString)).union(sc.parallelize(query2,1)).union(sc.parallelize(data2,1)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(15).rdd
      val b = result2.limit(15).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query1 : select bhi_home_plan_id, count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mdcl_bnft_ind='N' and bhi_home_plan_id <>'254' group by bhi_home_plan_id order by bhi_home_plan_id")
      val query2 = Array("Test Query2 : select bhi_home_plan_id, count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where hosp_bnft_ind='N' and bhi_home_plan_id <>'254' group by bhi_home_plan_id order by bhi_home_plan_id")
      val data1 = Array("'BHI HomePlan ID','Count'")
      val data2 = Array("'BHI HomePlan ID','Count'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(data1,1)).union(a.map(_.toString)).union(sc.parallelize(query2,1)).union(sc.parallelize(data2,1)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("MemberExtract - Medical Benefit Indicator for plan 254 - 122") {

    val id = Array("122")
    val name = Array("Test case : Medical Benefit Indicator for plan 254 ")
    
    val result = sqlContext.sql(""" select bhi_home_plan_id,mbr_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp 
      where home_plan_prod_id in ("MPPEH", "MPPHH") and mdcl_bnft_ind="Y" and bhi_home_plan_id="254" """)

   
    if (result.count == 0 ) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where home_plan_prod_id in ('MPPEH', 'MPPHH') and mdcl_bnft_ind='Y' and bhi_home_plan_id='254'")
      val data = Array("'BHI HomePlan ID','Member ID' : No Invalid values")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where home_plan_prod_id in ('MPPEH', 'MPPHH') and mdcl_bnft_ind='Y' and bhi_home_plan_id='254'")
      val data = Array("'BHI HomePlan ID','Member ID' ")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("MemberExtract - Hospital Benefit Indicator for plan 254 - 123") {

    val id = Array("123")
    val name = Array("Test case : Hospital Benefit Indicator for plan 254 ")
    
    val result = sqlContext.sql(""" select bhi_home_plan_id,mbr_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp 
      where home_plan_prod_id in ("MPPEH", "MPPHH") and hosp_bnft_ind="N" and bhi_home_plan_id="254" """)

   
    if (result.count == 0 ) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where home_plan_prod_id in ('MPPEH', 'MPPHH') and hosp_bnft_ind='N' and bhi_home_plan_id='254' ")
      val data = Array("'BHI HomePlan ID','Member ID' : No Invalid values")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,mbr_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where home_plan_prod_id in ('MPPEH', 'MPPHH') and hosp_bnft_ind='N' and bhi_home_plan_id='254' ")
      val data = Array("'BHI HomePlan ID','Member ID' ")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("MemberExtract - Check Member-Subscriber Referential Integrity - 124") {

    val id = Array("124")
    val name = Array("Test case : Check Member-Subscriber Referential Integrity ")
    
    val result = sqlContext.sql(""" select distinct SUB.sbscrbr_home_plan_prod_id, SUB.sbscrbr_id, SUB.mbr_id, SUB.home_plan_prod_id
from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp SUB  left outer join """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp MBR 
on trim(SUB.sbscrbr_home_plan_prod_id)=trim(MBR.home_plan_prod_id) and trim(SUB.sbscrbr_id)=trim(MBR.mbr_id) where MBR.mbr_id is NULL """)

   
    if (result.count == 0 ) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct SUB.sbscrbr_home_plan_prod_id, SUB.sbscrbr_id, SUB.mbr_id, SUB.home_plan_prod_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp SUB  left outer join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp MBR on trim(SUB.sbscrbr_home_plan_prod_id)=trim(MBR.home_plan_prod_id) and trim(SUB.sbscrbr_id)=trim(MBR.mbr_id) where MBR.mbr_id is NULL ")
      val data = Array("'sbscrbr_home_plan_prod_id', 'sbscrbr_id', 'mbr_id', 'home_plan_prod_id' : No Invalid values")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct SUB.sbscrbr_home_plan_prod_id, SUB.sbscrbr_id, SUB.mbr_id, SUB.home_plan_prod_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp SUB  left outer join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp MBR on trim(SUB.sbscrbr_home_plan_prod_id)=trim(MBR.home_plan_prod_id) and trim(SUB.sbscrbr_id)=trim(MBR.mbr_id) where MBR.mbr_id is NULL ")
      val data = Array("'sbscrbr_home_plan_prod_id', 'sbscrbr_id', 'mbr_id', 'home_plan_prod_id' ")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
   test("MemberExtract - Hospital Benenfit Indicator and Medical COB Code should be in Sync. - 125") {

    val id = Array("125")
    val name = Array("Test case : Hospital Benenfit Indicator and Medical COB Code should be in Sync. ")
    
    val result1 = sqlContext.sql(""" select bhi_home_plan_id, count(*) cnt1 from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp 
      where hosp_bnft_ind="N" group by bhi_home_plan_id order by bhi_home_plan_id """)
      result1.createOrReplaceTempView("result1DF")
      
    val result2 = sqlContext.sql(""" select bhi_home_plan_id, count(*) cnt2 from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp 
      where mbr_mdcl_cob_cd="N" group by bhi_home_plan_id order by bhi_home_plan_id """)
    result2.createOrReplaceTempView("result2DF")
    
      val result =  sqlContext.sql(""" select a.bhi_home_plan_id,a.cnt1,b.cnt2,case when a.cnt1=b.cnt2 then '0' else '1' end as match from result1DF a  join result2DF b 
        on a.bhi_home_plan_id=b.bhi_home_plan_id""").createOrReplaceTempView("resultDF")
      val invalid = sqlContext.sql(""" select * from resultDF a having a.match='1' """)
      
    if (invalid.count == 0 ) {
      val a = result1.limit(15).rdd
      val b = result2.limit(15).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query1 : select bhi_home_plan_id, count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where hosp_bnft_ind='N' group by bhi_home_plan_id order by bhi_home_plan_id")
      val query2 = Array("Test Query2 : select bhi_home_plan_id, count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mbr_mdcl_cob_cd='N' group by bhi_home_plan_id order by bhi_home_plan_id")
      val data1 = Array("'BHI HomePlan ID','Count'")
      val data2 = Array("'BHI HomePlan ID','Count'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(data1,1)).union(a.map(_.toString)).union(sc.parallelize(query2,1)).union(sc.parallelize(data2,1)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result1.limit(15).rdd
      val b = result2.limit(15).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query1 : select bhi_home_plan_id, count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where hosp_bnft_ind='N' group by bhi_home_plan_id order by bhi_home_plan_id")
      val query2 = Array("Test Query2 : select bhi_home_plan_id, count(*) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where mbr_mdcl_cob_cd='N' group by bhi_home_plan_id order by bhi_home_plan_id")
      val data1 = Array("'BHI HomePlan ID','Count'")
      val data2 = Array("'BHI HomePlan ID','Count'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(data1,1)).union(a.map(_.toString)).union(sc.parallelize(query2,1)).union(sc.parallelize(data2,1)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
   
    test("MemberExtract - Check Member-PCCr Referential Integrity - 126") {

    val id = Array("126")
    val name = Array("Test case : Check Member-PCC Referential Integrity ")
    
    val result = sqlContext.sql(""" select distinct MBR.BHI_HOME_PLAN_ID, MBR.HOME_PLAN_PROD_ID, MBR.ACCT_ID, MBR.GRP_ID,MBR.SUBGRP_ID 
      from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP MBR left outer join """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT PCC 
        on trim(MBR.BHI_HOME_PLAN_ID)=trim(PCC.BHI_HOME_PLAN_ID) and trim(MBR.HOME_PLAN_PROD_ID)=trim(PCC.HOME_PLAN_PROD_ID) and 
        trim(MBR.ACCT_ID)=trim(PCC.ACCT_ID) and trim(MBR.GRP_ID)=trim(PCC.GRP_ID) and trim(MBR.SUBGRP_ID)=trim(PCC.SUBGRP_ID) where PCC.SUBGRP_ID is null """)

   
    if (result.count == 0 ) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct MBR.BHI_HOME_PLAN_ID, MBR.HOME_PLAN_PROD_ID, MBR.ACCT_ID, MBR.GRP_ID,MBR.SUBGRP_ID from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP MBR left outer join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT PCC on trim(MBR.BHI_HOME_PLAN_ID)=trim(PCC.BHI_HOME_PLAN_ID) and trim(MBR.HOME_PLAN_PROD_ID)=trim(PCC.HOME_PLAN_PROD_ID) and trim(MBR.ACCT_ID)=trim(PCC.ACCT_ID) and trim(MBR.GRP_ID)=trim(PCC.GRP_ID) and trim(MBR.SUBGRP_ID)=trim(PCC.SUBGRP_ID) where PCC.SUBGRP_ID is null ")
      val data = Array("'BHI_HOME_PLAN_ID', 'HOME_PLAN_PROD_ID', 'ACCT_ID', 'GRP_ID','SUBGRP_ID' : No Invalid values")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct MBR.BHI_HOME_PLAN_ID, MBR.HOME_PLAN_PROD_ID, MBR.ACCT_ID, MBR.GRP_ID,MBR.SUBGRP_ID from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP MBR left outer join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT PCC on trim(MBR.BHI_HOME_PLAN_ID)=trim(PCC.BHI_HOME_PLAN_ID) and trim(MBR.HOME_PLAN_PROD_ID)=trim(PCC.HOME_PLAN_PROD_ID) and trim(MBR.ACCT_ID)=trim(PCC.ACCT_ID) and trim(MBR.GRP_ID)=trim(PCC.GRP_ID) and trim(MBR.SUBGRP_ID)=trim(PCC.SUBGRP_ID) where PCC.SUBGRP_ID is null ")
      val data = Array("'BHI_HOME_PLAN_ID', 'HOME_PLAN_PROD_ID', 'ACCT_ID', 'GRP_ID','SUBGRP_ID' : No Invalid values")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(status,1)).union(sc.parallelize(query,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================
    
    test("MemberExtract - Validate that there are 14 BHI Home Plan ID  - 127") {
    
    val id = Array("127")
     val name = Array("Test case : Validate that there are 14 BHI Home Plan ID ")
     
    val result = sqlContext.sql(""" select count(distinct bhi_home_plan_id) from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP """)
    
        
    if (result.collectAsList.toString.contains("14")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
    
 //===========================================
    
    test("MemberExtract - Validate that all the segments of a member have only latest Zip Code  - 128") {
    
    val id = Array("128")
     val name = Array("Test case : Validate that all the segments of a member have only latest Zip Code ")
     
    val result = sqlContext.sql(""" select * from
            (
            select bhi_home_plan_id, mbr_id, count(distinct mbr_curnt_prmry_zip_cd) as cnt
            from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP
            group by bhi_home_plan_id, mbr_id
            )a
            where a.cnt>1 """)
    
        
    if (result.count==0 ) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select * from ( select bhi_home_plan_id, mbr_id, count(distinct mbr_curnt_prmry_zip_cd) as cnt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP group by bhi_home_plan_id, mbr_id )a where a.cnt>1 ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select * from ( select bhi_home_plan_id, mbr_id, count(distinct mbr_curnt_prmry_zip_cd) as cnt from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP group by bhi_home_plan_id, mbr_id )a where a.cnt>1 ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
    
    //===========================================
    
    test("MemberExtract - Validate for Medicare group 195331 exclusion  - 129") {
    
    val id = Array("129")
     val name = Array("Test case : Validate for Medicare group 195331 exclusion ")
     
    val result = sqlContext.sql(""" select  bhi_home_plan_id, ACCT_ID from """+dbname+"""_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP where grp_id='195331' limit 10 """)
    
        
    if (result.count==0 ) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select  bhi_home_plan_id, ACCT_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP where grp_id='195331' limit 10 ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select  bhi_home_plan_id, ACCT_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_MBRSHP where grp_id='195331' limit 10 ")
      val data = Array("'Count' : Invalid")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }

  }
  
  //==========================================
/*
  
   test("MemberExtract -Validate One record for each BHI Home Plan ID,Home Product ID & Member ID - 067") {
    
    val id = Array("067")
    val name = Array("Test case : Validate One record for each BHI Home Plan ID,Home Product ID & Member ID")
    
    val result = sqlContext.sql("""select bhi_home_plan_id ,home_plan_prod_id, mbr_id,count(*) as count from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp group by bhi_home_plan_id,home_plan_prod_id,mbr_id""")
    result.createOrReplaceTempView("resultDF")
    
    val invalid = sqlContext.sql("""select * from resultDF where count > 1 """)
    
    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id ,home_plan_prod_id, mbr_id,count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp group by bhi_home_plan_id,home_plan_prod_id,mbr_id) where count > 1 ")
      val data = Array("'BHI HPID','PRODUCT_ID','MEMBER_ID','COUNT'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id ,home_plan_prod_id, mbr_id,count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp group by bhi_home_plan_id,home_plan_prod_id,mbr_id")
      val data = Array("'BHI HPID','PRODUCT_ID','MEMBER_ID','COUNT'")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================

  
  test("MemberExtract -Validate One record for each  Home Plan ID, Home Plan Product ID, Member ID, Consistent Member ID, Traceability Field, Member Date of Birth, Member’s Current Primary Zip Code, Member’s Current Country, Member’s Current County, Member Gender and Member Confidentiality Code - 083") {
    
    val id = Array("083")
    val name = Array("Test case : Validate One record for each  Home Plan ID, Home Plan Product ID, Member ID, Consistent Member ID, Traceability Field, Member Date of Birth, Member’s Current Primary Zip Code, Member’s Current Country, Member’s Current County, Member Gender and Member Confidentiality Code")
    
    val result = sqlContext.sql("""select bhi_home_plan_id ,home_plan_prod_id, mbr_id,cnsstnt_mbr_id ,src_sys_cd ,
      mbr_brth_dt ,mbr_curnt_prmry_zip_cd ,mbr_curnt_cntry_cd ,mbr_curnt_cnty_cd ,mbr_gndr_cd ,mbr_cnfdntlty_cd, count(*) as count from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp group by bhi_home_plan_id,home_plan_prod_id,mbr_id,cnsstnt_mbr_id ,src_sys_cd ,
      mbr_brth_dt ,mbr_curnt_prmry_zip_cd ,mbr_curnt_cntry_cd ,mbr_curnt_cnty_cd ,mbr_gndr_cd ,mbr_cnfdntlty_cd """)
    
      result.createOrReplaceTempView("resultDF")
    
    val invalid = sqlContext.sql("""select * from resultDF where count > 1 """)
    
    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id ,home_plan_prod_id, mbr_id,cnsstnt_mbr_id ,src_sys_cd , mbr_brth_dt ,mbr_curnt_prmry_zip_cd ,mbr_curnt_cntry_cd ,mbr_curnt_cnty_cd ,mbr_gndr_cd ,mbr_cnfdntlty_cd, count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp group by bhi_home_plan_id,home_plan_prod_id,mbr_id,cnsstnt_mbr_id ,src_sys_cd , mbr_brth_dt ,mbr_curnt_prmry_zip_cd ,mbr_curnt_cntry_cd ,mbr_curnt_cnty_cd ,mbr_gndr_cd ,mbr_cnfdntlty_cd) where count > 1 ")
      val data = Array("'BHI HPID','PRODUCT_ID','MEMBER_ID','Consistent_MBR_ID','Traceability','MBR_DOB','Zip_Code','Current_Country','Current_County','Gender_Code','Confidentiality_Code','COUNT'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id ,home_plan_prod_id, mbr_id,cnsstnt_mbr_id ,src_sys_cd , mbr_brth_dt ,mbr_curnt_prmry_zip_cd ,mbr_curnt_cntry_cd ,mbr_curnt_cnty_cd ,mbr_gndr_cd ,mbr_cnfdntlty_cd, count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp group by bhi_home_plan_id,home_plan_prod_id,mbr_id,cnsstnt_mbr_id ,src_sys_cd , mbr_brth_dt ,mbr_curnt_prmry_zip_cd ,mbr_curnt_cntry_cd ,mbr_curnt_cnty_cd ,mbr_gndr_cd ,mbr_cnfdntlty_cd")
      val data = Array(" 'BHI HPID','PRODUCT_ID','MEMBER_ID','Consistent_MBR_ID','Traceability','MBR_DOB','Zip_Code','Current_Country','Current_County','Gender_Code','Confidentiality_Code','COUNT' ")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }

  }
  
  //===========================================
 

test("MemberExtract - Validate that Member ID column is populated  as per the logic in mapping document - 086") {
   val id = Array("086")
    val name = Array("Test case : Validate that Member ID column is populated  as per the logic in mapping document")
    
    val result1 = sqlContext.sql(""" select distinct mcid  from """+dbname+"""_pcandw1ph_nogbd_r000_wh.all_mbr_mcid """)
    val result2 = sqlContext.sql(""" select distinct mbr_id  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0""")
         
    val result = result2.except(result1)
    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and mbr_id not in (select distinct mcid  from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.all_mbr_mcid)")
      val data = Array("'Invalid Member ID'")
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct mbr_id  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  where err_id = '0' and exclsn_ind = 0 and mbr_id not in (select distinct mcid  from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.all_mbr_mcid)")
      val data = Array(" 'Member' : No Invalid Values Found")
      
      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==1)
    }
    }
  */
  
   
}