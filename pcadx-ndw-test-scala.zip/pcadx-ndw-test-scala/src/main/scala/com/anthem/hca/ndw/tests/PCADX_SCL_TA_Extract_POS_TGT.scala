package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Extract_POS_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Extract_POS_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_Extract_POS_TGT(dbname: String, env: String) extends FunSuite {

  val now = Calendar.getInstance().getTime()
  val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
  val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
  val currdate = formatter.format(new Date())
  val currdate1 = formatter1.format(new Date())

  val sc = SparkContext.getOrCreate()
  sc.setLogLevel("ERROR")
  val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").config("spark.sql.hive.convertMetastoreParquet", "false").enableHiveSupport().getOrCreate()

  import sqlContext.implicits._
  import sqlContext.sql

  val subj = "Extract"
  val prcss = "POS"

  test("ClaimProfessionalExtract -Validated NULL or blank spaces checks for all Columns - 001") {
    val id = Array("001")
    val name = Array("Test case : Validated NULL or blank spaces checks for all Columns")

    val col_name = Array(
      "bhi_home_plan_id",
      "clm_id",
      "trcblty_fld_cd",
      "host_plan_id",
      "home_plan_prod_id",
      "acct_cd",
      "grp_cd",
      "subgrp_cd",
      "mbr_id",
      "clm_mbr_cntry_cd",
      "billg_prov_id",
      "billg_prov_spclty_cd",
      "billg_prov_cntry_cd",
      "pcp_prov_id",
      "pcp_prov_spclty_cd",
      "pcp_prov_cntry_cd",
      "rndrg_prov_id",
      "rndrg_prov_spclty_cd",
      "rndrg_prov_cntry_cd",
      "rndrg_prov_type_cd",
      "cpt_hcpcs_codes",
      "bnft_paymnt_stts_cd",
      "ctgry_of_srvc_cd",
      "clm_paymnt_stts_cd",
      "its_clm_ind",
      "plos_cd",
      "prmry_non_cvrd_rsn_cd",
      "non_cvrd_rsn_cd_2",
      "non_cvrd_rsn_cd_3",
      "non_cvrd_rsn_cd_4",
      "reimbmnt_type_cd",
      "sbmsn_type_cd",
      "totl_units_nbr",
      "adjdctd_dt",
      "clm_entr_dt",
      "clm_paid_dt",
      "clm_rcvd_dt",
      "srvc_end_dt",
      "srvc_from_dt",
      "srvc_post_dt",
      "sbmtd_amt",
      "non_cvrd_amt",
      "alwd_amt",
      "paymnt_amt",
      "cob_tpl_amt",
      "coinsrn_amt",
      "cpay_amt",
      "ddctbl_amt",
      "ffs_eqvlnt_amt",
      "npi_billg_prov_id",
      "npi_pcp_prov_id",
      "npi_rndrg_prov_id",
      "non_cntrctd_hhrmls_negotiations_ind",
      "billg_prov_cntrctg_stts_ind",
      "rndrg_prov_cntrctg_stts_ind",
      "sccf_nm",
      "npi_site_prov_id")

    val i = 0;

    for (i <- 0 to 10) {
      val k = col_name(i)
      val result = sqlContext.sql(f"""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, $k from """ + dbname + f"""_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where length(trim(regexp_replace(coalesce($k, "")," ", "")))=0 """)

      if (result.count > 0) {
        println(f" $k -- Failed")
      } else {
        println(f" $k -- Success")
      }

    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validated Special Character checks for key Columns - 002") {
    val id = Array("002")
    val name = Array("Test case : Validated Special Character checks for key Columns")

    val col_name = Array(
      "bhi_home_plan_id",
      "clm_id",
      "clm_line_nbr",
      "trcblty_fld_cd")

    val i = 0;

    for (i <- 0 to 3) {
      val k = col_name(i)
      val result = sqlContext.sql(f"""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd from """ + dbname + f"""_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where $k RLIKE '[^A-z0-9]' """)

      if (result.count > 0) {
        println(f" $k -- Failed")
      } else {
        println(f" $k -- Success")
      }

    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validated Double Quote Character checks for other Columns - 003") {
    val id = Array("003")
    val name = Array("Test case : Validated Double Quote Character checks for other Columns")

    val col_name = Array(
      "adjstmnt_sqnc_nbr",
      "host_plan_id",
      "home_plan_prod_id",
      "acct_cd",
      "grp_cd",
      "subgrp_cd",
      "mbr_id",
      "clm_mbr_zip_cd",
      "clm_mbr_cntry_cd",
      "billg_prov_id",
      "billg_prov_spclty_cd",
      "billg_prov_zip_cd",
      "billg_prov_cntry_cd",
      "billg_prov_tax_id",
      "billg_prov_medcr_id",
      "billg_prov_last_nm",
      "billg_prov_frst_nm",
      "billg_prov_ntwk_cd",
      "pcp_prov_id",
      "pcp_prov_spclty_cd",
      "pcp_prov_zip_cd",
      "pcp_prov_cntry_cd",
      "rndrg_prov_id",
      "rndrg_prov_spclty_cd",
      "rndrg_prov_zip_cd",
      "rndrg_prov_cntry_cd",
      "rndrg_prov_type_cd",
      "rndrg_prov_medcr_id",
      "rndrg_prov_last_nm",
      "rndrg_prov_frst_nm",
      "rndrg_prov_ntwk_cd",
      "prncpal_icd9_diag_cd",
      "scndry_icd9_diag_cd_1",
      "scndry_icd9_diag_cd_2",
      "scndry_icd9_diag_cd_3",
      "cpt_hcpcs_codes",
      "proc_mdfr_cd",
      "authrzn_id",
      "bnft_paymnt_stts_cd",
      "ctgry_of_srvc_cd",
      "clm_paymnt_stts_cd",
      "clm_type_cd",
      "its_clm_ind",
      "plos_cd",
      "prmry_non_cvrd_rsn_cd",
      "non_cvrd_rsn_cd_2",
      "non_cvrd_rsn_cd_3",
      "non_cvrd_rsn_cd_4",
      "reimbmnt_type_cd",
      "sbmsn_type_cd",
      "totl_units_nbr",
      "adjdctd_dt",
      "clm_entr_dt",
      "clm_paid_dt",
      "clm_rcvd_dt",
      "srvc_end_dt",
      "srvc_from_dt",
      "srvc_post_dt",
      "sbmtd_amt",
      "non_cvrd_amt",
      "alwd_amt",
      "paymnt_amt",
      "cob_tpl_amt",
      "coinsrn_amt",
      "cpay_amt",
      "ddctbl_amt",
      "ffs_eqvlnt_amt",
      "npi_billg_prov_id",
      "npi_pcp_prov_id",
      "npi_rndrg_prov_id",
      "non_cntrctd_hhrmls_negotiations_ind",
      "billg_prov_cntrctg_stts_ind",
      "rndrg_prov_cntrctg_stts_ind",
      "sccf_nm",
      "prncpal_icd10_diag_cd",
      "scndry_icd10_diag_cd_1",
      "scndry_icd10_diag_cd_2",
      "scndry_icd10_diag_cd_3",
      "prncpal_hdr_icd10_diag_cd",
      "scndry_hdr_icd10_diag_cd_1",
      "scndry_hdr_icd10_diag_cd_2",
      "scndry_hdr_icd10_diag_cd_3",
      "scndry_hdr_icd10_diag_cd_4",
      "scndry_hdr_icd10_diag_cd_5",
      "scndry_hdr_icd10_diag_cd_6",
      "scndry_hdr_icd10_diag_cd_7",
      "scndry_hdr_icd10_diag_cd_8",
      "scndry_hdr_icd10_diag_cd_9",
      "scndry_hdr_icd10_diag_cd_10",
      "scndry_hdr_icd10_diag_cd_11",
      "npi_site_prov_id")

    val i = 0;

    for (i <- 0 to 58) {
      val k = col_name(i)
      val result = sqlContext.sql(f"""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, $k from """ + dbname + f"""_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where $k RLIKE '"' """)

      if (result.count > 0) {
        println(f" $k -- Failed")
      } else {
        println(f" $k -- Success")
      }

    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that all the records have the correct [BHI Home Plan ID] as per Anthem - 004") {
    val id = Array("004")
    val name = Array("Test case : Validate that all the records have the correct [BHI Home Plan ID] as per Anthem")

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where
    bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') """)

    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') ")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','ERR_ID','EXCLSN_ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where bhi_home_plan_id not in ('040','051','062','102','131','161','182','254','266','271','330','425','458','748') ")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','ERR_ID','EXCLSN_ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    }

  }

  //===========================================

  test("ClaimProfessionalExtract -Validate One record for each BHI Home Plan ID, Claim ID, Claim Line Number & Traceability - 005") {

    val id = Array("005")
    val name = Array("Test case : Validate One record for each BHI Home Plan ID, Claim ID, Claim Line Number & Traceability")

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, count(*) as count from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs group by bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd""")
    result.createOrReplaceTempView("resultDF")

    val invalid = sqlContext.sql("""select * from resultDF where count > 1 """)

    if (invalid.count > 0) {
      val a = invalid.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs group by bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd) where count > 1 ")
      val data = Array(" 'BHI HPID','Claim_ID','Claim Line Number','Traceability','COUNT'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from (select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, count(*) as count from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs group by bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd) where count > 1 ")
      val data = Array("'BHI HPID','Claim_ID','Claim Line Number','Traceability','COUNT' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    }

  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Claim Line Number should not be less than 000 or greater than 999 - 006") {
    val id = Array("006")
    val name = Array("Test case : Validate that Claim Line Number should not be less than 000 or greater than 999")

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where
    clm_line_nbr < 000 OR clm_line_nbr > 999  """)

    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where clm_line_nbr < 000 OR clm_line_nbr > 999 ")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','ERR_ID','EXCLSN_ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, err_id, exclsn_ind from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where clm_line_nbr < 000 OR clm_line_nbr > 999 ")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','ERR_ID','EXCLSN_ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    }

  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that BHI Home Plan ID + Traceability is present in Traceability Table - 007") {
    val id = Array("007")
    val name = Array("Test case : -Validate that BHI Home Plan ID + Traceability is present in Traceability Table")

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(trcblty_fld_cd))) as CONCAT_TGT from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(trcblty_fld_cd))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (elect distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc)")
      val data = Array("'Home_Plan_Id + Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(trcblty_fld_cd))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (elect distinct(concat( trim(bhi_home_plan_id) , trim(sor_cd))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_trcblty_rfrnc)")
      val data = Array("'Home_Plan_Id + Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  /*test("ClaimProfessionalExtract -Validate that Host Plan ID is present in Reference table - 008") {
    val id = Array("008")
    val name = Array("Test case : Validate that Host Plan ID is present in Reference table")



    val result1 = sqlContext.sql("""select distinct (trim(host_plan_id_cd )) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_host_plan_id_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(host_plan_id))  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)


    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(host_plan_id))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(host_plan_id) not in (select distinct (trim(host_plan_id_cd )) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_host_plan_id_inbnd)")
      val data = Array("'Host_Plan_ID' : No Invalid Values Found")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(host_plan_id))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(host_plan_id) not in (select distinct (trim(host_plan_id_cd )) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_host_plan_id_inbnd)")
      val data = Array("'Invalid Host_Plan_ID'")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }*/

  //===========================================

  test("CLaimProfessionalExtract -Validate that BHI Home Plan ID + Home Plan Product ID is present in Product Table - 008") {
    val id = Array("008")
    val name = Array("Test case : Validate that BHI Home Plan ID + Home Plan Product ID is present in Product Table")

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_SRC from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prod  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_TGT from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("CLaimProfessionalExtract -Validate that BHI Home Plan ID + Home Plan Product ID + Account ID + Group + SubGroup is present in PCC Table - 009") {
    val id = Array("009")
    val name = Array("Test case : Validate that BHI Home Plan ID + Home Plan Product ID + Account ID + Group + SubGroup is present in PCC Table")

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_id) ,  trim(grp_id) ,  trim(subgrp_id))) as CONCAT_SRC from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_cd) ,  trim(grp_cd) ,  trim(subgrp_cd))) as CONCAT_TGT from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_cd) ,  trim(grp_cd) ,  trim(subgrp_cd))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_id) ,  trim(grp_id) ,  trim(subgrp_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID + Account + Group + SubGroup' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_cd) ,  trim(grp_cd) ,  trim(subgrp_cd))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(acct_id) ,  trim(grp_id) ,  trim(subgrp_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prod_clnt_cntrct)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID + Account + Group + SubGroup'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("CLaimProfessionalExtract -Validate SubGroup='NOSUB' if Group='NOGRP' - 010") {
    val id = Array("010")
    val name = Array("Test case : Validate SubGroup='NOSUB' if Group='NOGRP'")

    val result = sqlContext.sql("""select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, subgrp_cd from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where grp_cd='NOGRP' and subgrp_cd!='NOSUB'""")

    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, subgrp_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where grp_cd='NOGRP' and subgrp_cd!='NOSUB'")
      val data = Array(" 'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','SUB_GROUP")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    } else {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd, subgrp_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where grp_cd='NOGRP' and subgrp_cd!='NOSUB'")
      val data = Array("'BHI HPID','Claim_ID','Claim_Line_Number','Traceability','SUB_GROUP : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    }

  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that BHI Home Plan ID + Home Plan Product ID + Member ID is present in Member Table - 011") {
    val id = Array("011")
    val name = Array("Test case : Validate that BHI Home Plan ID + Home Plan Product ID + Member ID is present in Member Table")

    val result1 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id))) as CONCAT_SRC from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp  """)

    val result2 = sqlContext.sql("""select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id ))) as CONCAT_TGT from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID + Member ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id ))) as CONCAT_TGT from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and CONCAT_TGT not in (select distinct(concat( trim(bhi_home_plan_id) , trim(home_plan_prod_id) ,  trim(mbr_id))) as CONCAT_SRC from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'BHI Home_Plan_Id + Home Plan Product ID + Member ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Member Zip Code is present in Reference table - 012") {
    val id = Array("012")
    val name = Array("Test case : Validate that Member Zip Code is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(zip_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(clm_mbr_zip_cd))  from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(clm_mbr_zip_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(clm_mbr_zip_cd) not in (select distinct (trim(zip_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd)")
      val data = Array("'Member_Zip_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(clm_mbr_zip_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(clm_mbr_zip_cd) not in (select distinct (trim(zip_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_zip_cd_inbnd)")
      val data = Array(" 'Invalid Member_Zip_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Member Country Code is present in Reference table - 013") {
    val id = Array("013")
    val name = Array("Test case : Validate that Member Country Code is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(cntry_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(clm_mbr_cntry_cd))  from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where (trim(clm_mbr_cntry_cd)) not in ('UN')  """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(clm_mbr_cntry_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(clm_mbr_cntry_cd) not in (select distinct (trim(cntry_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd)")
      val data = Array("'Member_Country_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(clm_mbr_cntry_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(clm_mbr_cntry_cd) not in (select distinct (trim(cntry_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_cntry_inbnd)")
      val data = Array(" 'Invalid Member_Country_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that ICD-9 Diagnosis Code - Principal is present in Diagnosis Reference table - 014") {
    val id = Array("014")
    val name = Array("Test case : Validate that ICD-9 Diagnosis Code - Principal is present in Diagnosis Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(diag_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_diag_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(prncpal_icd9_diag_cd))  from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(prncpal_icd9_diag_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(prncpal_icd9_diag_cd) not in (select distinct (trim(diag_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_diag_inbnd)")
      val data = Array("'ICD-9_Diagnosis_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(prncpal_icd9_diag_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(prncpal_icd9_diag_cd) not in (select distinct (trim(diag_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_diag_inbnd)")
      val data = Array(" 'Invalid ICD-9_Diagnosis_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  /*test("ClaimProfessionalExtract -Validate that ICD-10 Diagnosis Code - Principal is present in Reference table - 016") {
    val id = Array("016")
    val name = Array("Test case : Validate that ICD-10 Diagnosis Code - Principal is present in Reference table")



    val result1 = sqlContext.sql("""select distinct (trim(icd10_diag_cd)) from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_icd10_diag_inbnd where (trim(icd10_diag_cd)) not in ('', 'UN') """)

    val result2 = sqlContext.sql("""select distinct (trim(prncpal_icd10_diag_cd))  from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(prncpal_icd10_diag_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(prncpal_icd10_diag_cd not in (select distinct (trim(icd10_diag_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_icd_10diag_inbnd)")
      val data = Array("'ICD-10_Diagnosis_Code' : No Invalid Values Found")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(prncpal_icd10_diag_cd))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(prncpal_icd10_diag_cd not in (select distinct (trim(icd10_diag_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_icd_10diag_inbnd)")
      val data = Array("'Invalid ICD-10_Diagnosis_Code'")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }*/

  //===========================================

  test("ClaimProfessionalExtract -Validate that CPT and HCPCS Codes is present in Reference table - 015") {
    val id = Array("015")
    val name = Array("Test case : Validate that CPT and HCPCS Codes is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(proc_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_proc_cd_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(cpt_hcpcs_codes)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(cpt_hcpcs_codes)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(cpt_hcpcs_codes) not in (elect distinct (trim(proc_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_proc_cd_inbnd)")
      val data = Array("'CPT_HCPCS_Codes' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(cpt_hcpcs_codes)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(cpt_hcpcs_codes) not in (elect distinct (trim(proc_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_proc_cd_inbnd)")
      val data = Array("'Invalid CPT_HCPCS_Codes'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Benefit Payment Status Code has Valid Values - 016") {
    val id = Array("016")
    val name = Array("Test case : Validate that Benefit Payment Status Code has Valid Values")

    val result = sqlContext.sql("""select distinct bnft_paymnt_stts_cd, bhi_home_plan_id, clm_id,mbr_id, clm_line_nbr, trcblty_fld_cd from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs  where bnft_paymnt_stts_cd NOT IN ('Y','N','O')  """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct bnft_paymnt_stts_cd, bhi_home_plan_id, clm_id,mbr_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs  where bnft_paymnt_stts_cd NOT IN ('Y','N','O')")
      val data = Array("'Benefit_Payment_Status_Code','BHI HPID','Claim_ID','MBR_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct bnft_paymnt_stts_cd, bhi_home_plan_id, clm_id,mbr_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs  where bnft_paymnt_stts_cd NOT IN ('Y','N','O')")
      val data = Array("'Invalid Benefit_Payment_Status_Code','BHI HPID','Claim_ID','MBR_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Benefit Payment Status Code is present in Reference table - 017") {
    val id = Array("017")
    val name = Array("Test case : Validate that Benefit Payment Status Code is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(bnft_paymnt_stts_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(bnft_paymnt_stts_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(bnft_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(bnft_paymnt_stts_cd) not in (select distinct (trim(bnft_pymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bnft_pymnt_stts_cd_inbnd)")
      val data = Array("'Benefit_Payment_Status_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(bnft_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(bnft_paymnt_stts_cd) not in (select distinct (trim(bnft_pymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bnft_pymnt_stts_cd_inbnd)")
      val data = Array("'Invalid Benefit_Payment_Status_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Category of Service Code has Valid Values - 018") {
    val id = Array("018")
    val name = Array("Test case : Validate that Category of Service Code has Valid Values")

    val result = sqlContext.sql("""select distinct ctgry_of_srvc_cd, bhi_home_plan_id, clm_id, mbr_id, clm_line_nbr, trcblty_fld_cd from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs  where ctgry_of_srvc_cd NOT IN ('IP PROF','IP OTHER','OP PROF' ,'OP OTHER')   """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct ctgry_of_srvc_cd, bhi_home_plan_id, clm_id, mbr_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs  where ctgry_of_srvc_cd NOT IN ('IP PROF','IP OTHER','OP PROF' ,'OP OTHER') ")
      val data = Array("'Category_of_Service_Code','BHI HPID','Claim_ID','MBR_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct ctgry_of_srvc_cd, bhi_home_plan_id, clm_id, mbr_id , clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs  where ctgry_of_srvc_cd NOT IN ('IP PROF','IP OTHER','OP PROF' ,'OP OTHER') ")
      val data = Array("'Invalid Category_of_Service_Code','BHI HPID','Claim_ID','MBR_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Category of Service Code is present in Reference table - 019") {
    val id = Array("019")
    val name = Array("Test case : Validate that Category of Service Code is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(ctgry_of_srvc_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_ctgry_of_srvc_inbnd    """)

    val result2 = sqlContext.sql("""select distinct (trim(ctgry_of_srvc_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(ctgry_of_srvc_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(ctgry_of_srvc_cd) not in (select distinct (trim(ctgry_of_srvc_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_ctgry_of_srvc_inbnd ) ")
      val data = Array("'Category_of_Service_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(ctgry_of_srvc_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(ctgry_of_srvc_cd) not in (select distinct (trim(ctgry_of_srvc_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_ctgry_of_srvc_inbnd ) ")
      val data = Array("'Invalid Category_of_Service_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Claim Payment Status Code is present in Reference table - 020") {
    val id = Array("020")
    val name = Array("Test case : Validate that Claim Payment Status Code is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(clm_pymnt_stts_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_clm_pymnt_stts_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(clm_paymnt_stts_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(clm_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(clm_paymnt_stts_cd) not in (select distinct (trim(clm_pymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_clm_pymnt_stts_inbnd)")
      val data = Array("'Claim_Payment_Status_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(clm_paymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(clm_paymnt_stts_cd) not in (select distinct (trim(clm_pymnt_stts_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_clm_pymnt_stts_inbnd)")
      val data = Array("'Invalid Claim_Payment_Status_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that ITS Claim Indicator Code has Valid Values - 021") {
    val id = Array("021")
    val name = Array("Test case : Validate that ITS Claim Indicator Code has Valid Values")

    val result = sqlContext.sql("""select distinct its_clm_ind, bhi_home_plan_id, clm_id,mbr_id, clm_line_nbr, trcblty_fld_cd from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs  where its_clm_ind NOT IN ('Y','N') """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct its_clm_ind, bhi_home_plan_id, clm_id,mbr_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs  where its_clm_ind NOT IN ('Y','N')")
      val data = Array("'ITS_Claim_Indicator_Code','BHI HPID','Claim_ID','MBR_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct its_clm_ind, bhi_home_plan_id, clm_id,mbr_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs  where its_clm_ind NOT IN ('Y','N')")
      val data = Array("'Invalid ITS_Claim_Indicator_Code','BHI HPID','Claim_ID','MBR_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Place of Service Code is present in Reference table - 022") {
    val id = Array("022")
    val name = Array("Test case : Validate that Place of Service Code is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(place_of_srvc_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_place_of_srvc_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(plos_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(plos_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(plos_cd) not in (select distinct (trim(place_of_srvc_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_place_of_srvc_inbnd)")
      val data = Array("'Place_of_Service_Code' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(plos_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(plos_cd) not in (select distinct (trim(place_of_srvc_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_place_of_srvc_inbnd)")
      val data = Array("'Invalid Place_of_Service_Code'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Non-Covered Reason Code-Primary is present in Reference table - 023") {
    val id = Array("023")
    val name = Array("Test case : Validate that Non-Covered Reason Code-Primary is present in Reference table")

    val result1 = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd  """)

    val result2 = sqlContext.sql("""select distinct (trim(prmry_non_cvrd_rsn_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(prmry_non_cvrd_rsn_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(prmry_non_cvrd_rsn_cd) not in (select distinct (trim(non_cvrd_rsn_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd)")
      val data = Array("'Non_Covered_Reason_Code_Primary' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(prmry_non_cvrd_rsn_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(prmry_non_cvrd_rsn_cd) not in (select distinct (trim(non_cvrd_rsn_cd)) from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd)")
      val data = Array("'Invalid Non_Covered_Reason_Code_Primary'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Non-Covered Reason Code 2 is present in Reference table - 024") {
    val id = Array("024")
    val name = Array("Test case : Validate that Non-Covered Reason Code 2 is present in Reference table")

    //val result1 = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd  """)

    //val result2 = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd_2)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    //val result = result2.except(result1)
    val result = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd_2)) 
      from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs WHERE 
        trim(non_cvrd_rsn_cd_2)<>'00'""")
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(non_cvrd_rsn_cd_2)) from " + dbname + "_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs WHERE trim(non_cvrd_rsn_cd_2)<>'00'")
      val data = Array("'Non_Covered_Reason_Code_2' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(non_cvrd_rsn_cd_2)) from " + dbname + "_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs WHERE trim(non_cvrd_rsn_cd_2)<>'00'")
      val data = Array("'Invalid Non_Covered_Reason_Code_2'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Non-Covered Reason Code 3 is present in Reference table - 025") {
    val id = Array("025")
    val name = Array("Test case : Validate that Non-Covered Reason Code 3 is present in Reference table")

    //val result1 = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd  """)

    //val result2 = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd_3)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    //val result = result2.except(result1)
    val result = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd_3)) 
      from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs WHERE 
        trim(non_cvrd_rsn_cd_3)<>'00'""")
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(non_cvrd_rsn_cd_3)) from " + dbname + "_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs WHERE trim(non_cvrd_rsn_cd_3)<>'00'")
      val data = Array("'Non_Covered_Reason_Code_3' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(non_cvrd_rsn_cd_3)) from " + dbname + "_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs WHERE trim(non_cvrd_rsn_cd_3)<>'00'")
      val data = Array("'Invalid Non_Covered_Reason_Code_3'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Non-Covered Reason Code 4 is present in Reference table - 026") {
    val id = Array("026")
    val name = Array("Test case : Validate that Non-Covered Reason Code 4 is present in Reference table")

    //val result1 = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd)) from """ + dbname + """_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_non_cvrd_rsn_cd_inbnd  """)

    //val result2 = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd_4)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    //val result = result2.except(result1)
    val result = sqlContext.sql("""select distinct (trim(non_cvrd_rsn_cd_4)) 
      from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs WHERE 
        trim(non_cvrd_rsn_cd_4)<>'00'""")
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(non_cvrd_rsn_cd_4)) from " + dbname + "_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs WHERE trim(non_cvrd_rsn_cd_4)<>'00'")
      val data = Array("'Non_Covered_Reason_Code_4' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(non_cvrd_rsn_cd_4)) from " + dbname + "_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs WHERE trim(non_cvrd_rsn_cd_4)<>'00'")
      val data = Array("'Invalid Non_Covered_Reason_Code_4'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

/*  test("ClaimProfessionalExtract -Validate that Submitted Amount is equal to or less than '-0' - 027") {
    val id = Array("027")
    val name = Array("Test case : Validate that Submitted Amount is equal to or less than '-0'")

    val result = sqlContext.sql("""select sbmtd_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where sbmtd_amt < 0.00  """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select sbmtd_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where sbmtd_amt < 0.00 ")
      val data = Array("'Subitted_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select sbmtd_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where sbmtd_amt < 0.00 ")
      val data = Array("'Invalid Subitted_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Non-Covered Amount is equal to or less than '-0' - 028") {
    val id = Array("028")
    val name = Array("Test case : Validate that Non-Covered Amount is equal to or less than '-0'")

    val result = sqlContext.sql("""select non_cvrd_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where non_cvrd_amt < 0.00  """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select non_cvrd_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where non_cvrd_amt < 0.00 ")
      val data = Array(" 'Non-Covered_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability': No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select non_cvrd_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where non_cvrd_amt < 0.00 ")
      val data = Array("'Invalid Non-Covered_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Allowed Amount is equal to or less than '-0' - 029") {
    val id = Array("029")
    val name = Array("Test case : Validate that Allowed Amount is equal to or less than '-0'")

    val result = sqlContext.sql("""select alwd_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where alwd_amt < 0.00  """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select alwd_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where alwd_amt < 0.00  ")
      val data = Array("'Allowed_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select alwd_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where alwd_amt < 0.00  ")
      val data = Array("'Invalid Allowed_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Payment Amount is equal to or less than '-0' - 030") {
    val id = Array("030")
    val name = Array("Test case : Validate that Payment Amount is equal to or less than '-0'")

    val result = sqlContext.sql("""select paymnt_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where paymnt_amt < 0.00  """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select paymnt_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where paymnt_amt < 0.00 ")
      val data = Array("'Payment_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select paymnt_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where paymnt_amt < 0.00 ")
      val data = Array("'Invalid Payment_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Coinsurance Amount is equal to or less than '-0' - 031") {
    val id = Array("031")
    val name = Array("Test case : Validate that Coinsurance Amount is equal to or less than '-0'")

    val result = sqlContext.sql("""select coinsrn_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where coinsrn_amt < 0.00  """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select coinsrn_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where coinsrn_amt < 0.00 ")
      val data = Array("'Coinsurance_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select coinsrn_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where coinsrn_amt < 0.00 ")
      val data = Array("'Invalid Coinsurance_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Copay Amount is equal to or less than '-0' - 032") {
    val id = Array("032")
    val name = Array("Test case : Validate that Copay Amount is equal to or less than '-0'")

    val result = sqlContext.sql("""select cpay_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where cpay_amt < 0.00  """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select cpay_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where cpay_amt < 0.00  ")
      val data = Array("'Copay_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select cpay_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where cpay_amt < 0.00  ")
      val data = Array("'Invalid Copay_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Deductible Amount is equal to or less than '-0' - 033") {
    val id = Array("033")
    val name = Array("Test case : Validate that Deductible Amount is equal to or less than '-0'")

    val result = sqlContext.sql("""select ddctbl_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where ddctbl_amt < 0.00  """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select ddctbl_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where ddctbl_amt < 0.00  ")
      val data = Array(" 'Deductible_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability': No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select ddctbl_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where ddctbl_amt < 0.00  ")
      val data = Array("'Invalid Deductible_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Fee for Service Equivalent Amount is equal to or less than '-0' - 034") {
    val id = Array("034")
    val name = Array("Test case : Validate that Fee for Service Equivalent Amount is equal to or less than '-0'")

    val result = sqlContext.sql("""select ffs_eqvlnt_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where ffs_eqvlnt_amt < 0.00  """)

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select ffs_eqvlnt_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where ffs_eqvlnt_amt < 0.00  ")
      val data = Array("'Fee_for_Service_Equivalent_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability','Error_ID','Exclusion_IND' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select ffs_eqvlnt_amt, bhi_home_plan_id, clm_id, clm_line_nbr, trcblty_fld_cd,err_id,exclsn_ind   from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where ffs_eqvlnt_amt < 0.00  ")
      val data = Array(" 'Invalid Fee_for_Service_Equivalent_Amount','BHI HPID','Claim_ID','Claim_Line_Number','Traceability','Error_ID','Exclusion_IND'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }		*/

  //===========================================

  test("ClaimProfessionalExtract -Validate that Non-Contracted Hold Harmless Negotiations Indicator has Valid Values - 035") {
    val id = Array("035")
    val name = Array("Test case : Validate that Non-Contracted Hold Harmless Negotiations Indicator has Valid Values")

    val result = sqlContext.sql("""select non_cntrctd_hhrmls_negotiations_ind, bhi_home_plan_id, clm_id, mbr_id, clm_line_nbr, trcblty_fld_cd  from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where non_cntrctd_hhrmls_negotiations_ind NOT IN ('N','I','X')  """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select non_cntrctd_hhrmls_negotiations_ind, bhi_home_plan_id, clm_id, mbr_id, clm_line_nbr, trcblty_fld_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where non_cntrctd_hhrmls_negotiations_ind NOT IN ('N','I','X')  ")
      val data = Array("'Non-Contracted_Hold_Harmless_Negotiations_Indicator','BHI HPID','Claim_ID','MBR_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select non_cntrctd_hhrmls_negotiations_ind, bhi_home_plan_id, clm_id, mbr_id, clm_line_nbr, trcblty_fld_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where non_cntrctd_hhrmls_negotiations_ind NOT IN ('N','I','X')  ")
      val data = Array("'Invalid Non-Contracted_Hold_Harmless_Negotiations_Indicator','BHI HPID','Claim_ID','MBR_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Billing Provider Contracting Status Indicator has Valid Values - 036") {
    val id = Array("036")
    val name = Array("Test case : Validate that Billing Provider Contracting Status Indicator has Valid Values")

    val result = sqlContext.sql("""select billg_prov_cntrctg_stts_ind, bhi_home_plan_id, clm_id, mbr_id, clm_line_nbr, trcblty_fld_cd  from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where billg_prov_cntrctg_stts_ind NOT IN ('I','Y','N','C','P','O')  """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select billg_prov_cntrctg_stts_ind, bhi_home_plan_id, clm_id, mbr_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where billg_prov_cntrctg_stts_ind NOT IN ('I','Y','N','C','P','O') ")
      val data = Array("'Billing_Provider_Contracting_Status_Indicator','BHI HPID','Claim_ID','MBR_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select billg_prov_cntrctg_stts_ind, bhi_home_plan_id, clm_id, mbr_id, clm_line_nbr, trcblty_fld_cd  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where billg_prov_cntrctg_stts_ind NOT IN ('I','Y','N','C','P','O') ")
      val data = Array("'Invalid Billing_Provider_Contracting_Status_Indicator','BHI HPID','Claim_ID','MBR_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Rendering Provider Contracting Status Indicator has Valid Values - 037") {
    val id = Array("037")
    val name = Array("Test case : Validate that Rendering Provider Contracting Status Indicator has Valid Values")

    val result = sqlContext.sql("""select rndrg_prov_cntrctg_stts_ind, bhi_home_plan_id, clm_id, mbr_id, clm_line_nbr, trcblty_fld_cd  from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where rndrg_prov_cntrctg_stts_ind NOT IN ('I','Y','N','C','P','O')  """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select rndrg_prov_cntrctg_stts_ind, bhi_home_plan_id, clm_id, mbr_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where rndrg_prov_cntrctg_stts_ind NOT IN ('I','Y','N','C','P','O') ")
      val data = Array("'Rendering_Provider_Contracting_Status_Indicator','BHI HPID','Claim_ID','MBR_ID','Claim_Line_Number','Traceability' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select rndrg_prov_cntrctg_stts_ind, bhi_home_plan_id, clm_id, mbr_id, clm_line_nbr, trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where rndrg_prov_cntrctg_stts_ind NOT IN ('I','Y','N','C','P','O') ")
      val data = Array("'Invalid Rendering_Provider_Contracting_Status_Indicator','BHI HPID','Claim_ID','MBR_ID','Claim_Line_Number','Traceability'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that there are no Duplicates - 038") {
    val id = Array("038")
    val name = Array("Test case : Validate that there are no Duplicates")

    val result = sqlContext.sql("""select BHI_HOME_PLAN_ID, TRCBLTY_FLD_CD, CLM_ID, CLM_LINE_NBR, count(*) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs group by BHI_HOME_PLAN_ID, TRCBLTY_FLD_CD, CLM_ID, CLM_LINE_NBR having count(*) > 1""")

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select BHI_HOME_PLAN_ID, TRCBLTY_FLD_CD, CLM_ID, CLM_LINE_NBR, count(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs group by BHI_HOME_PLAN_ID, TRCBLTY_FLD_CD, CLM_ID, CLM_LINE_NBR having count(*) > 1")
      val data = Array("'There are no Duplicate records' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select BHI_HOME_PLAN_ID, TRCBLTY_FLD_CD, CLM_ID, CLM_LINE_NBR, count(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs group by BHI_HOME_PLAN_ID, TRCBLTY_FLD_CD, CLM_ID, CLM_LINE_NBR having count(*) > 1")
      val data = Array("'List of Duplicate records'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Member ID present in Member Extract Table - 039") {
    val id = Array("039")
    val name = Array("Test case : Validate that Member ID present in Member Extract Table")

    val result1 = sqlContext.sql("""select distinct (trim(mbr_id)) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp """)

    val result2 = sqlContext.sql("""select distinct (trim(mbr_id))  from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0  """)

    val result = result2.except(result1)
    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct (trim(mbr_id))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(mbr_id) not in (select distinct (trim(mbr_id)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'Member_ID not in Member Table' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct (trim(mbr_id))  from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where err_id = '0' and exclsn_ind = 0 and trim(mbr_id) not in (select distinct (trim(mbr_id)) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp)")
      val data = Array("'Invalid Member_ID not in Member Table'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that the table should not contain ITS Host claims data - 040") {
    val id = Array("040")
    val name = Array("Test case : Validate that the table should not contain ITS Host claims data")

    val result = sqlContext.sql("""SELECT E.clmadj_key FROM """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN """ + dbname + """_PCANDW1PH_nogbd_r000_in.CLM C ON E.clmadj_key= C.clm_adjstmnt_key AND C.CLM_ITS_HOST_CD  IN ('HOST', 'JAACL')""")

    if (result.take(1).isEmpty) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT E.clmadj_key FROM '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN '''+dbname+'''_PCANDW1PH_nogbd_r000_in.CLM C ON E.clmadj_key= C.clm_adjstmnt_key AND C.CLM_ITS_HOST_CD  IN ('HOST', 'JAACL')")
      val data = Array("'No ITS Host Claim data'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT E.clmadj_key FROM '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN '''+dbname+'''_PCANDW1PH_nogbd_r000_in.CLM C ON E.clmadj_key= C.clm_adjstmnt_key AND C.CLM_ITS_HOST_CD  IN ('HOST', 'JAACL')")
      val data = Array("'Check table contains the ITS Host Claim data'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that the Host Plan ID field in the file is populated with the default value  'HOM' - 041") {
    val id = Array("041")
    val name = Array("Test case : Validate that the Host Plan ID field in the file is populated with the default value  'HOM' ")

    val result = sqlContext.sql("""select distinct HOST_PLAN_ID from """ + dbname + """_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS""")
    result.createOrReplaceTempView("resultDF")

    val check = sqlContext.sql("""select * from resultDF where HOST_PLAN_ID='HOM'""")

    if (check.count == 1) {
      val a = check.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select * from (select distinct HOST_PLAN_ID from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS) where HOST_PLAN_ID='HOM'")
      val data = Array("HOM found in Host Plan ID")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = check.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select * from (select distinct HOST_PLAN_ID from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS) where HOST_PLAN_ID='HOM'")
      val data = Array("HOM not found in Host Plan ID")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that the Home Plan Product ID field is populated from HOME_PLAN_PROD_ID column of BCBSA_MBRSHP table as per the mapping sheet transformation. - 042") {
    val id = Array("042")
    val name = Array("Test case : Validate that the Home Plan Product ID field is populated from HOME_PLAN_PROD_ID column of BCBSA_MBRSHP table as per the mapping sheet transformation.")

    val result1 = sqlContext.sql("""select distinct HOME_PLAN_PROD_ID from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where MBR_ID='213206111'""")

    val result2 = sqlContext.sql("""select distinct HOME_PLAN_PROD_ID  from """ + dbname + """_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where MBR_ID='213206111'""")

    val x = result1.rdd.first().getString(0)
    val y = result2.rdd.first().getString(0)
    if (x == y) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct HOME_PLAN_PROD_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where MBR_ID='213206111'")
      val query2 = Array("Test Query : select distinct HOME_PLAN_PROD_ID  from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where MBR_ID='213206111")
      val data = Array("Home Plan Product ID present in Member table")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query1, 1)).union(sc.parallelize(query2, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct HOME_PLAN_PROD_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where MBR_ID='213206111'")
      val query2 = Array("Test Query : select distinct HOME_PLAN_PROD_ID  from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where MBR_ID='213206111")
      val data = Array(" Home Plan Product ID not present in Member table")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query1, 1)).union(sc.parallelize(query2, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that the Claim Member Zip Code field is populated from MBR_CURNT_PRMRY_ZIP_CD column of BCBSA_MBRSHP table as per the mapping sheet transformation. - 043") {
    val id = Array("043")
    val name = Array("Test case : Validate that the Claim Member Zip Code field is populated from MBR_CURNT_PRMRY_ZIP_CD column of BCBSA_MBRSHP table as per the mapping sheet transformation.")

    val result1 = sqlContext.sql("""select distinct CLM_MBR_ZIP_CD from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where MBR_ID='21822751'""")

    val result2 = sqlContext.sql("""select distinct MBR_CURNT_PRMRY_ZIP_CD from """ + dbname + """_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where MBR_ID='21822751'""")

    val x = result1.rdd.first().getString(0)
    val y = result2.rdd.first().getString(0)
    if (x == y) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct CLM_MBR_ZIP_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where MBR_ID='21822751'")
      val query2 = Array("Test Query : select distinct MBR_CURNT_PRMRY_ZIP_CD from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where MBR_ID='21822751'")
      val data = Array("Claim Member Zip Code present in Member table")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query1, 1)).union(sc.parallelize(query2, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct CLM_MBR_ZIP_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where MBR_ID='21822751'")
      val query2 = Array("Test Query : select distinct MBR_CURNT_PRMRY_ZIP_CD from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_mbrshp where MBR_ID='21822751'")
      val data = Array("Claim Member Zip Code not present in Member table")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query1, 1)).union(sc.parallelize(query2, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Non-Covered Reason Code 2 field in the file is populated as 00 as per the maping sheet transformation - 044") {
    val id = Array("044")
    val name = Array("Test case : Validate that Non-Covered Reason Code 2 field in the file is populated as 00 as per the maping sheet transformation ")

    val result = sqlContext.sql("""select distinct non_cvrd_rsn_cd_2 from """ + dbname + """_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS""")
    val x = result.rdd.first().getString(0)
    if (x == "00") {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_2 from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS")
      val data = Array("Non-Covered Reason Code 2 field is populated as 00")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_2 from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS")
      val data = Array("Non-Covered Reason Code 2 field is not populated as 00")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Non-Covered Reason Code 3 field in the file is populated as 00 as per the maping sheet transformation - 045") {
    val id = Array("045")
    val name = Array("Test case : Validate that Non-Covered Reason Code 3 field in the file is populated as 00 as per the maping sheet transformation")

    val result = sqlContext.sql("""select distinct non_cvrd_rsn_cd_3 from """ + dbname + """_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS""")
    val x = result.rdd.first().getString(0)
    if (x == "00") {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_3 from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS")
      val data = Array("Non-Covered Reason Code 3 field is populated as 00")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_3 from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS")
      val data = Array("Non-Covered Reason Code 3 field is not populated as 00")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Non-Covered Reason Code 4 field in the file is populated as 00 as per the maping sheet transformation - 046") {
    val id = Array("046")
    val name = Array("Test case : Validate that Non-Covered Reason Code 4 field in the file is populated as 00 as per the maping sheet transformation")

    val result = sqlContext.sql("""select distinct non_cvrd_rsn_cd_4 from """ + dbname + """_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS""")
    val x = result.rdd.first().getString(0)
    if (x == "00") {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_4 from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS")
      val data = Array("Non-Covered Reason Code 4 field is populated as 00")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct non_cvrd_rsn_cd_4 from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS")
      val data = Array("Non-Covered Reason Code 4 field is not populated as 00")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that NPI PCP Provider ID field in the file is populated as per the maping sheet transformation  - 047") {
    val id = Array("047")
    val name = Array("Test case : Validate that NPI PCP Provider ID field in the file is populated as per the maping sheet transformation")

    val result = sqlContext.sql("""select distinct npi_pcp_prov_id from """ + dbname + """_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS where npi_pcp_prov_id <> '9999999999'""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct npi_pcp_prov_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS where npi_pcp_prov_id <> '9999999999'")
      val data = Array("'NPI PCP Provider ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct npi_pcp_prov_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS where npi_pcp_prov_id <> '9999999999'")
      val data = Array("'Invalid NPI PCP Provider ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that SCCF field in the file should be populated from CLM_ITS_SCCF_NBR of CLM table - 048") {
    val id = Array("048")
    val name = Array("Test case : Validate that SCCF field in the file should be populated from CLM_ITS_SCCF_NBR of CLM table")

    val result = sqlContext.sql("""select * FROM """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where sccf_nm like '99999%'""")
    val result1 = sqlContext.sql("""select * FROM """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where host_plan_id='HOM'""")

    if (result.count == result1.count) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select * FROM '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where sccf_nm like '99999%'")
      val query2 = Array("Test Query : select * FROM '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where host_plan_id='HOM'")
      val data = Array("SCCF field is from CLM_ITS_SCCF_NBR of CLM table")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query1, 1)).union(sc.parallelize(query2, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select * FROM '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where sccf_nm like '99999%'")
      val query2 = Array("Test Query : select * FROM '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where host_plan_id='HOM'")
      val data = Array("SCCF field is not from CLM_ITS_SCCF_NBR of CLM table")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query1, 1)).union(sc.parallelize(query2, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - Validate if any rendering provider id is default when billing provider id is populated  - 049") {
    val id = Array("049")
    val name = Array("Test case : Validate if any rendering provider id is default when billing provider id is populated")

    val result = sqlContext.sql(""" select pos.BHI_HOME_PLAN_ID,pos.clm_id,pos.mbr_id,pos.clm_line_nbr,pos.BILLG_PROV_ID,pos.RNDRG_PROV_ID from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs pos where  pos.BILLG_PROV_ID  not like '%99999999999%' and  pos.RNDRG_PROV_ID  like '%99999999999%'""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select pos.BHI_HOME_PLAN_ID,pos.clm_id,pos.mbr_id,pos.clm_line_nbr,pos.BILLG_PROV_ID,pos.RNDRG_PROV_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs pos where  pos.BILLG_PROV_ID  not like '%99999999999%' and  pos.RNDRG_PROV_ID  like '%99999999999%'")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','Claim Line No','BILLG_PROV_ID','RNDRG_PROV_ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select pos.BHI_HOME_PLAN_ID,pos.clm_id,pos.mbr_id,pos.clm_line_nbr,pos.BILLG_PROV_ID,pos.RNDRG_PROV_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs pos where  pos.BILLG_PROV_ID  not like '%99999999999%' and  pos.RNDRG_PROV_ID  like '%99999999999%'")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','Claim Line No','BILLG_PROV_ID','RNDRG_PROV_ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - Validate if any Billing  provider id is default when Rendering  provider id is populated  - 050") {
    val id = Array("050")
    val name = Array("Test case : Validate if any Billing  provider id is default when Rendering  provider id is populated ")

    val result = sqlContext.sql(""" select pos.BHI_HOME_PLAN_ID,pos.clm_id,pos.mbr_id,pos.clm_line_nbr,pos.BILLG_PROV_ID,pos.RNDRG_PROV_ID from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs pos where  pos.BILLG_PROV_ID  like '%99999999999%' and  pos.RNDRG_PROV_ID not like '%99999999999%'""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select pos.BHI_HOME_PLAN_ID,pos.clm_id,pos.mbr_id,pos.clm_line_nbr,pos.BILLG_PROV_ID,pos.RNDRG_PROV_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs pos where  pos.BILLG_PROV_ID  like '%99999999999%' and  pos.RNDRG_PROV_ID not like '%99999999999%'")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','Claim Line No','BILLG_PROV_ID','RNDRG_PROV_ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select pos.BHI_HOME_PLAN_ID,pos.clm_id,pos.mbr_id,pos.clm_line_nbr,pos.BILLG_PROV_ID,pos.RNDRG_PROV_ID from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs pos where  pos.BILLG_PROV_ID  like '%99999999999%' and  pos.RNDRG_PROV_ID not like '%99999999999%'")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','Claim Line No','BILLG_PROV_ID','RNDRG_PROV_ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - Validate if Claim Payment Status has only values D and P  - 051") {
    val id = Array("051")
    val name = Array("Test case : Validate if Claim Payment Status has only values D and P ")

    val result = sqlContext.sql(""" select bhi_home_plan_id,clm_id,mbr_id,clm_line_nbr,CLM_PAYMNT_STTS_CD from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where CLM_PAYMNT_STTS_CD not in ('D','P')""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id,clm_line_nbr,CLM_PAYMNT_STTS_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where CLM_PAYMNT_STTS_CD not in ('D','P')")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','Claim Line No','CLM_PAYMNT_STTS_CD' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id,clm_line_nbr,CLM_PAYMNT_STTS_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where CLM_PAYMNT_STTS_CD not in ('D','P')")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','Claim Line No','CLM_PAYMNT_STTS_CD'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - Validate if Claim Type has Only values 3 and 5  - 052") {
    val id = Array("052")
    val name = Array("Test case : Validate if Claim Type has Only values 3 and 5 ")

    val result = sqlContext.sql(""" select bhi_home_plan_id,clm_id,mbr_id, CLM_LINE_NBR, CLM_TYPE_CD from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where CLM_TYPE_CD  not in ('3','5')""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id,CLM_LINE_NBR,CLM_TYPE_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where CLM_TYPE_CD  not in ('3','5')")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','Claim Line No','CLM_TYPE_CD' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id,CLM_LINE_NBR, CLM_TYPE_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where CLM_TYPE_CD  not in ('3','5')")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','Claim Line No','CLM_TYPE_CD'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - Validate that no FEP claims present in Extract - 053") {
    val id = Array("053")
    val name = Array("Test case : Validate that no FEP claims present in Extract")

    val result1 = sqlContext.sql(""" select  distinct stg.bhi_home_plan_id,stg.home_plan_prod_id,stg.mbr_id,stg.mbr_key,stg.clmadj_key,c.src_grp_nbr,coa.mbu_cf_cd
from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_PRFSNL_OTHR_SRVCS_stg stg inner join """ + dbname + """_pcandw1ph_nogbd_r000_in.clm  c on
c.clm_adjstmnt_key= stg.clmadj_key inner join """ + dbname + """_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa coa
on c.mbr_key= coa.mbr_key where c.src_grp_nbr='FEP' """)

    val result2 = sqlContext.sql(""" select  TRCBLTY_FLD_CD,COUNT(*) from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_PRFSNL_OTHR_SRVCS GROUP BY TRCBLTY_FLD_CD having TRCBLTY_FLD_CD 
in ("888","896") """)

    if (result1.count == 0 && result2.count == 0) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query1 : select  distinct stg.bhi_home_plan_id,stg.home_plan_prod_id,stg.mbr_id,stg.mbr_key,stg.clmadj_key,c.src_grp_nbr,coa.mbu_cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_PRFSNL_OTHR_SRVCS_stg stg inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm  c on c.clm_adjstmnt_key= stg.clmadj_key inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa coa on c.mbr_key= coa.mbr_key where c.src_grp_nbr='FEP' ")
      val query2 = Array("Test Query2 :  select  TRCBLTY_FLD_CD,COUNT(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFSNL_OTHR_SRVCS GROUP BY TRCBLTY_FLD_CD having TRCBLTY_FLD_CD  in ('888','896')")
      val data = Array(" Count of both the queries are Matching")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query1, 1)).union(sc.parallelize(query2, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query1 : select  distinct stg.bhi_home_plan_id,stg.home_plan_prod_id,stg.mbr_id,stg.mbr_key,stg.clmadj_key,c.src_grp_nbr,coa.mbu_cf_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_PRFSNL_OTHR_SRVCS_stg stg inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.clm  c on c.clm_adjstmnt_key= stg.clmadj_key inner join '''+dbname+'''_pcandw1ph_nogbd_r000_in.mbr_prod_enrlmnt_coa coa on c.mbr_key= coa.mbr_key where c.src_grp_nbr='FEP' ")
      val query2 = Array("Test Query2 :  select  TRCBLTY_FLD_CD,COUNT(*) from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_PRFSNL_OTHR_SRVCS GROUP BY TRCBLTY_FLD_CD having TRCBLTY_FLD_CD  in ('888','896')")
      val data = Array(" Count of both the queries are not Matching")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query1, 1)).union(sc.parallelize(query2, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -  ICD-9 Diagnosis Code - Principal is not defaulted to invalid value ('UN') or have nulls - 054") {
    val id = Array("054")
    val name = Array("Test case :  ICD-9 Diagnosis Code - Principal is not defaulted to invalid value ('UN') or have nulls")

    val result = sqlContext.sql(""" select bhi_home_plan_id,clm_id,mbr_id,CLM_LINE_NBR,prncpal_icd9_diag_cd from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where prncpal_icd9_diag_cd = "UN" or prncpal_icd9_diag_cd is NULL """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id,CLM_LINE_NBR,prncpal_icd9_diag_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where prncpal_icd9_diag_cd = 'UN' or prncpal_icd9_diag_cd is NULL")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','Claim Line No','Principle ICD9 DIAG CD' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select bhi_home_plan_id,clm_id,mbr_id,CLM_LINE_NBR,prncpal_icd9_diag_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where prncpal_icd9_diag_cd = 'UN' or prncpal_icd9_diag_cd is NULL")
      val data = Array("'BHI HomePlan ID','Claim ID','MBR ID','Claim Line No','Principle ICD9 DIAG CD'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - POS global filter check service rendering type - 055") {
    val id = Array("055")
    val name = Array("Test case : POS global filter check service rendering type ")

    val result = sqlContext.sql(""" select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM """ + dbname + """_PCANDW1PH_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E 
INNER JOIN """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.SRVC_RNDRG_TYPE_CD NOT IN('PHYSN','PANCL') """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.SRVC_RNDRG_TYPE_CD NOT IN('PHYSN','PANCL') ")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.SRVC_RNDRG_TYPE_CD NOT IN('PHYSN','PANCL') ")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - POS global filter check adjudication status cod - 056") {
    val id = Array("056")
    val name = Array("Test case : POS global filter check adjudication status cod ")

    val result = sqlContext.sql(""" select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM """ + dbname + """_PCANDW1PH_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E 
INNER JOIN """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.ADJDCTN_STTS_CD  IN (03, 10) """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.ADJDCTN_STTS_CD  IN (03, 10) ")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.ADJDCTN_STTS_CD  IN (03, 10) ")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - POS global filter check claims its host type - 057") {
    val id = Array("057")
    val name = Array("Test case : POS global filter check claims its host type ")

    val result = sqlContext.sql(""" select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM """ + dbname + """_PCANDW1PH_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E 
INNER JOIN """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.CLM_ITS_HOST_CD  in ('HOST', 'JAACL') """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.CLM_ITS_HOST_CD  in ('HOST', 'JAACL') ")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select  E.clmadj_key,E.CLM_ID,E.MBR_ID FROM '''+dbname+'''_PCANDW1PH_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.CLM_ITS_HOST_CD  in ('HOST', 'JAACL') ")
      val data = Array("'CLM Adjustment Key','Claim ID','Member ID'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - Claim type code field validation - 058") {
    val id = Array("058")
    val name = Array("Test case : Claim type code field validation ")

    val result = sqlContext.sql(""" select POS.clm_type_cd from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg POS 
      left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM CLM on trim(POS.clmadj_key)=trim(CLM.clm_adjstmnt_key) and 
      trim(POS.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.SRVC_RNDRG_TYPE_CD)="PHYSN" and POS.clm_type_cd="5" """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select POS.clm_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg POS left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM CLM on trim(POS.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(POS.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.SRVC_RNDRG_TYPE_CD)='PHYSN' and POS.clm_type_cd='5'")
      val data = Array("'clm_type_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select POS.clm_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg POS left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM CLM on trim(POS.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(POS.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM.SRVC_RNDRG_TYPE_CD)='PHYSN' and POS.clm_type_cd='5'")
      val data = Array("'clm_type_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - Submission type code field validation - 059") {
    val id = Array("059")
    val name = Array("Test case : Submission type code field validation ")

    val result = sqlContext.sql(""" select POS.sbmsn_type_cd from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg POS 
      left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM CLM on trim(POS.clmadj_key)=trim(CLM.clm_adjstmnt_key) and 
      trim(POS.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM_FORM_TYPE_CD) not in ('PA', 'EL', 'SC', 'WB') and 
      trim(POS.sbmsn_type_cd)="NA" """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select POS.sbmsn_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg POS left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM CLM on trim(POS.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(POS.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM_FORM_TYPE_CD) not in ('PA', 'EL', 'SC', 'WB') and trim(POS.sbmsn_type_cd)='NA'")
      val data = Array("'sbmsn_type_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select POS.sbmsn_type_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg POS left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM CLM on trim(POS.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(POS.trcblty_fld_cd)=trim(CLM.clm_sor_cd) where trim(CLM_FORM_TYPE_CD) not in ('PA', 'EL', 'SC', 'WB') and trim(POS.sbmsn_type_cd)='NA'")
      val data = Array("'sbmsn_type_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - Validate the authorization id transformation logic - 060") {
    val id = Array("060")
    val name = Array("Test case : Validate the authorization id transformation logic ")

    val result = sqlContext.sql(""" select POS.authrzn_id from """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs POS left outer join 
      (select PA_NBR as au_id from """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM where PA_NBR not in ('NA','N/A','') and PA_NBR not like '%UNK%' 
      union all select CLM_LINE_PA_NBR as au_id from """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM_LINE) CLM on trim(POS.authrzn_id)=trim(CLM.au_id) 
      where CLM.au_id is NULL """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select POS.authrzn_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs POS left outer join (select PA_NBR as au_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM where PA_NBR not in ('NA','N/A','') and PA_NBR not like '%UNK%' union all select CLM_LINE_PA_NBR as au_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM_LINE) CLM on trim(POS.authrzn_id)=trim(CLM.au_id) where CLM.au_id is NULL")
      val data = Array("'authrzn_id' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select POS.authrzn_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs POS left outer join (select PA_NBR as au_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM where PA_NBR not in ('NA','N/A','') and PA_NBR not like '%UNK%' union all select CLM_LINE_PA_NBR as au_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM_LINE) CLM on trim(POS.authrzn_id)=trim(CLM.au_id) where CLM.au_id is NULL")
      val data = Array("'authrzn_id'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - Procedure modifier should be a valid value if present in the lookup table - 061") {
    val id = Array("061")
    val name = Array("Test case : Procedure modifier should be a valid value if present in the lookup table ")

    val result = sqlContext.sql(""" select POS.proc_mdfr_cd from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg POS left outer join 
      """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM_LINE CLM on trim(POS.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(POS.trcblty_fld_cd)=trim(CLM.clm_sor_cd) 
      left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.bot_bcbsa_proc_mdfr_inclsn_inbnd INB on trim(POS.proc_mdfr_cd)=trim(INB.proc_mdfr_cd) 
      where length(trim(POS.proc_mdfr_cd))<>0 and INB.proc_mdfr_cd is NULL """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select POS.proc_mdfr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg POS left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM_LINE CLM on trim(POS.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(POS.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_proc_mdfr_inclsn_inbnd INB on trim(POS.proc_mdfr_cd)=trim(INB.proc_mdfr_cd) where length(trim(POS.proc_mdfr_cd))<>0 and INB.proc_mdfr_cd is NULL")
      val data = Array("'proc_mdfr_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select POS.proc_mdfr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg POS left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM_LINE CLM on trim(POS.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(POS.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_proc_mdfr_inclsn_inbnd INB on trim(POS.proc_mdfr_cd)=trim(INB.proc_mdfr_cd) where length(trim(POS.proc_mdfr_cd))<>0 and INB.proc_mdfr_cd is NULL")
      val data = Array("'proc_mdfr_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - Procedure modifier should be spaces if not present in lookup table - 062") {
    val id = Array("062")
    val name = Array("Test case : Procedure modifier should be spaces if not present in lookup table ")

    val result = sqlContext.sql(""" select POS.proc_mdfr_cd from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg POS left outer join 
      """ + dbname + """_pcandw1ph_nogbd_r000_in.CLM_LINE CLM on trim(POS.clmadj_key)=trim(CLM.clm_adjstmnt_key) and 
      trim(POS.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join """ + dbname + """_pcandw1ph_nogbd_r000_in.bot_bcbsa_proc_mdfr_inclsn_inbnd INB 
      on trim(POS.proc_mdfr_cd)=trim(INB.proc_mdfr_cd) where length(trim(POS.proc_mdfr_cd))=0 and INB.proc_mdfr_cd is not NULL """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select POS.proc_mdfr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg POS left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM_LINE CLM on trim(POS.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(POS.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_proc_mdfr_inclsn_inbnd INB on trim(POS.proc_mdfr_cd)=trim(INB.proc_mdfr_cd) where length(trim(POS.proc_mdfr_cd))=0 and INB.proc_mdfr_cd is not NULL")
      val data = Array("'proc_mdfr_cd' : No Invalid Values Found")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select POS.proc_mdfr_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg POS left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.CLM_LINE CLM on trim(POS.clmadj_key)=trim(CLM.clm_adjstmnt_key) and trim(POS.trcblty_fld_cd)=trim(CLM.clm_sor_cd) left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_in.bot_bcbsa_proc_mdfr_inclsn_inbnd INB on trim(POS.proc_mdfr_cd)=trim(INB.proc_mdfr_cd) where length(trim(POS.proc_mdfr_cd))=0 and INB.proc_mdfr_cd is not NULL")
      val data = Array("'proc_mdfr_cd'")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract - Validate that there are 14 BHI Home Plan ID  - 063 ") {

    val id = Array("063")
    val name = Array("Test case : Validate that there are 14 BHI Home Plan ID ")

    val result = sqlContext.sql(""" select count(distinct bhi_home_plan_id) from """ + dbname + """_PCANDW1PH_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs """)

    if (result.collectAsList.toString.contains("14")) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select count(distinct bhi_home_plan_id) from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs ")
      val data = Array("'Count' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //===========================================

  test("ClaimProfessionalExtract - To check that the PDR Logic is working as per the transformation - 064") {

    val id = Array("064")
    val name = Array("Test case : To check that the PDR Logic is working as per the transformation ")

    val result1 = sqlContext.sql(""" 
      select distinct A.clmadj_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clmadj_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  TRIM(A.BILLG_PROV_ID)= trim(ab.prov_nbr)
      and trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      """)

    val result2 = sqlContext.sql(""" 
      select distinct A.clmadj_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clmadj_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.npi_billg_prov_id)=trim(ab.prov_npi)
      and trim(A.billg_prov_tax_id)=trim(ab.fein_txt)
      and trim(A.billg_prov_zip_cd)=trim(ab.zip_cd)
      and trim(A.billg_prov_last_nm)=trim(ab.last_nm)
      """)

    val result3 = sqlContext.sql(""" 
      select distinct A.clmadj_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clmadj_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg EXT where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.npi_billg_prov_id)=trim(ab.prov_npi)
      and trim(A.billg_prov_tax_id)=trim(ab.fein_txt)
      and trim(A.billg_prov_zip_cd)=trim(ab.zip_cd)
      """)

    val result4 = sqlContext.sql(""" 
      select distinct A.clmadj_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clmadj_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.npi_billg_prov_id)=trim(ab.prov_npi)
      and trim(A.billg_prov_tax_id)=trim(ab.fein_txt)
      """)

    val result5 = sqlContext.sql(""" 
      select distinct A.clmadj_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clmadj_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.npi_billg_prov_id)=trim(ab.prov_npi)
      and trim(A.billg_prov_zip_cd)=trim(ab.zip_cd)
      and trim(A.billg_prov_last_nm)=trim(ab.last_nm)
      """)

    val result6 = sqlContext.sql(""" 
      select distinct A.clmadj_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clmadj_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.npi_billg_prov_id)=trim(ab.prov_npi)
      and trim(A.billg_prov_zip_cd)=trim(ab.zip_cd)
      """)

    val result7 = sqlContext.sql(""" 
      select distinct A.clmadj_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clmadj_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.npi_billg_prov_id)=trim(ab.prov_npi)
      """)

    val result8 = sqlContext.sql(""" 
      select distinct A.clmadj_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clmadj_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.billg_prov_tax_id)=trim(ab.fein_txt)
      and trim(A.billg_prov_zip_cd)=trim(ab.zip_cd)
      and trim(A.billg_prov_last_nm)=trim(ab.last_nm)
      """)

    val result9 = sqlContext.sql(""" 
      select distinct A.clmadj_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clmadj_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.billg_prov_tax_id)=trim(ab.fein_txt)
      and trim(A.billg_prov_zip_cd)=trim(ab.zip_cd)
      """)

    val result10 = sqlContext.sql(""" 
      select distinct A.clmadj_key,ab.prov_nbr,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id from
      (select distinct clmadj_key,npi_billg_prov_id,billg_prov_tax_id,billg_prov_zip_cd,billg_prov_last_nm,host_plan_id,billg_prov_cntrctg_stts_ind,billg_prov_id,Inn_cd,bcbsa_prod_id,bcbsa_ntwk_id 
      from """ + dbname + """_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg EXT 
      where ext.billg_prov_cntrctg_stts_ind ='C')A 
      inner join """ + dbname + """_PCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_PROV_PROD_NTWK_INBND AB
      on  trim(A.bcbsa_prod_id)=trim(ab.prod_id)
      and trim(A.bcbsa_ntwk_id)=trim(ab.NTWK_ID)
      and trim(A.billg_prov_tax_id)=trim(ab.fein_txt)
      """)

    if (result1.count == 0 && result2.count == 0 && result3.count == 0 && result4.count == 0 && result5.count == 0 && result6.count == 0 && result7.count == 0 && result8.count == 0 && result9.count == 0 && result10.count == 0) {
      val a = result10.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  All scenarios for PDR Logic ")
      val data = Array("'PDR Data' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result10.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  All scenarios for PDR Logic ")
      val data = Array("'PDR Data' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //===========================================

  test("ClaimProfessionalExtract - Referential integrity with member for Zipcode & Country Code combination  - 065 ") {

    val id = Array("065")
    val name = Array("Test case : Referential integrity with member for Zipcode & Country Code combination ")

    val result = sqlContext.sql(""" select *
              from """ + dbname + """_pcandw1ph_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS clm
              left outer join """ + dbname + """_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp mbr
              on trim(clm.clm_mbr_zip_cd)=trim(mbr.mbr_curnt_prmry_zip_cd) and
              trim(clm.mbr_id)=trim(mbr.mbr_id) and
              trim(clm.clm_mbr_cntry_cd)=trim(mbr.mbr_curnt_cntry_cd)
              where mbr.mbr_curnt_prmry_zip_cd is NULL
              limit 20 """)

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query :  select * from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS clm left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp mbr on trim(clm.clm_mbr_zip_cd)=trim(mbr.mbr_curnt_prmry_zip_cd) and trim(clm.mbr_id)=trim(mbr.mbr_id) and trim(clm.clm_mbr_cntry_cd)=trim(mbr.mbr_curnt_cntry_cd) where mbr.mbr_curnt_prmry_zip_cd is NULL ")
      val data = Array("'Count' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query :  select * from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS clm left outer join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_mbrshp mbr on trim(clm.clm_mbr_zip_cd)=trim(mbr.mbr_curnt_prmry_zip_cd) and trim(clm.mbr_id)=trim(mbr.mbr_id) and trim(clm.clm_mbr_cntry_cd)=trim(mbr.mbr_curnt_cntry_cd) where mbr.mbr_curnt_prmry_zip_cd is NULL ")
      val data = Array("'Count' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //===========================================

  test("ClaimProfessionalExtract - Validate Category of service is getting populated correctly, Scenario-1  - 066 ") {

    val id = Array("066")
    val name = Array("Test case : Validate Category of service is getting populated correctly, Scenario-1 ")

    val result = sqlContext.sql(s"""SELECT DISTINCT B.clm_id, A.ETG_PROV_TYPE_CD AS ETG_PROV_TYPE_CD,
      B.plos_cd as PLACE_OF_SRVC_CD,B.ctgry_of_srvc_cd,b.rndrg_prov_spclty_cd
FROM ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_PROV_TYPE_INBND A 
INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs B
ON A.PROV_TYPE_CD = B.RNDRG_PROV_TYPE_CD 
where TRIM(a.ETG_PROV_TYPE_CD )= '0' AND B.PLOS_CD 
IN ('03','04','05','06','07','08','09','11','12','14','15','16','17','18','19','20','22',
'23','24','41','42','49','50','53','57','60','62','65','71','72','81','99') 
and  B.ctgry_of_srvc_cd <> 'OP PROF'""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"""Test Query : SELECT DISTINCT B.clm_id, A.ETG_PROV_TYPE_CD AS ETG_PROV_TYPE_CD,
      B.plos_cd as PLACE_OF_SRVC_CD,B.ctgry_of_srvc_cd,b.rndrg_prov_spclty_cd
FROM ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_PROV_TYPE_INBND A 
INNER JOIN ${dbname}__pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs B
ON A.PROV_TYPE_CD = B.RNDRG_PROV_TYPE_CD 
where TRIM(a.ETG_PROV_TYPE_CD )= '0' AND B.PLOS_CD 
IN ('03','04','05','06','07','08','09','11','12','14','15','16','17','18','19','20','22',
'23','24','41','42','49','50','53','57','60','62','65','71','72','81','99') 
and  B.ctgry_of_srvc_cd <> 'OP PROF'""")
      val data = Array("'ETG_PROV_TYPE_CD' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"""Test Query : SELECT DISTINCT B.clm_id, A.ETG_PROV_TYPE_CD AS ETG_PROV_TYPE_CD,
      B.plos_cd as PLACE_OF_SRVC_CD,B.ctgry_of_srvc_cd,b.rndrg_prov_spclty_cd
FROM ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_PROV_TYPE_INBND A 
INNER JOIN ${dbname}__pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs B
ON A.PROV_TYPE_CD = B.RNDRG_PROV_TYPE_CD 
where TRIM(a.ETG_PROV_TYPE_CD )= '0' AND B.PLOS_CD 
IN ('03','04','05','06','07','08','09','11','12','14','15','16','17','18','19','20','22',
'23','24','41','42','49','50','53','57','60','62','65','71','72','81','99') 
and  B.ctgry_of_srvc_cd <> 'OP PROF'""")
      val data = Array("'ETG_PROV_TYPE_CD' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimProfessionalExtract - Validate Category of service is getting populated correctly, Scenario-2  - 067") {

    val id = Array("067")
    val name = Array("Test case : Validate Category of service is getting populated correctly, Scenario-2")

    val result = sqlContext.sql(s"""SELECT DISTINCT B.clm_id,A.ETG_PROV_TYPE_CD AS ETG_PROV_TYPE_CD,B.plos_cd as PLACE_OF_SRVC_CD,
B.ctgry_of_srvc_cd,b.rndrg_prov_spclty_cd
FROM ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_PROV_TYPE_INBND A 
INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs B
ON A.PROV_TYPE_CD = B.RNDRG_PROV_TYPE_CD 
where TRIM(a.ETG_PROV_TYPE_CD )= '0' AND B.PLOS_CD 
IN ('13','21','25','26','31','32','33','34','51','52','54','55','56','61') 
and B.ctgry_of_srvc_cd <> 'IP PROF'""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"""Test Query : SELECT DISTINCT B.clm_id,A.ETG_PROV_TYPE_CD AS ETG_PROV_TYPE_CD,B.plos_cd as PLACE_OF_SRVC_CD,
B.ctgry_of_srvc_cd,b.rndrg_prov_spclty_cd
FROM ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_PROV_TYPE_INBND A 
INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs B
ON A.PROV_TYPE_CD = B.RNDRG_PROV_TYPE_CD 
where TRIM(a.ETG_PROV_TYPE_CD )= '0' AND B.PLOS_CD 
IN ('13','21','25','26','31','32','33','34','51','52','54','55','56','61') 
and B.ctgry_of_srvc_cd <> 'IP PROF'""")
      val data = Array("'ETG_PROV_TYPE_CD' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"""Test Query : SELECT DISTINCT B.clm_id,A.ETG_PROV_TYPE_CD AS ETG_PROV_TYPE_CD,B.plos_cd as PLACE_OF_SRVC_CD,
B.ctgry_of_srvc_cd,b.rndrg_prov_spclty_cd
FROM ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_PROV_TYPE_INBND A 
INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs B
ON A.PROV_TYPE_CD = B.RNDRG_PROV_TYPE_CD 
where TRIM(a.ETG_PROV_TYPE_CD )= '0' AND B.PLOS_CD 
IN ('13','21','25','26','31','32','33','34','51','52','54','55','56','61') 
and B.ctgry_of_srvc_cd <> 'IP PROF'""")
      val data = Array("'ETG_PROV_TYPE_CD' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  test("ClaimProfessionalExtract - Validate Category of service is getting populated correctly, Scenario-3  - 068") {

    val id = Array("068")
    val name = Array("Test case : Validate Category of service is getting populated correctly, Scenario-3")

    val result = sqlContext.sql(s"""SELECT DISTINCT B.clm_id, A.ETG_PROV_TYPE_CD AS ETG_PROV_TYPE_CD,
      B.plos_cd as PLACE_OF_SRVC_CD,B.ctgry_of_srvc_cd,b.rndrg_prov_spclty_cd
FROM ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_PROV_TYPE_INBND A 
INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs B
ON A.PROV_TYPE_CD = B.RNDRG_PROV_TYPE_CD 
where TRIM(a.ETG_PROV_TYPE_CD ) IN ('1','2') AND B.PLOS_CD 
IN ('03','04','05','06','07','08','09','11','12','14','15','16','17','18','19','20','22',
'23','24','41','42','49','50','53','57','60','62','65','71','72','81','99') 
and  B.ctgry_of_srvc_cd <> 'OP OTHER'""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"""Test Query : SELECT DISTINCT B.clm_id, A.ETG_PROV_TYPE_CD AS ETG_PROV_TYPE_CD,
      B.plos_cd as PLACE_OF_SRVC_CD,B.ctgry_of_srvc_cd,b.rndrg_prov_spclty_cd
FROM ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_PROV_TYPE_INBND A 
INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs B
ON A.PROV_TYPE_CD = B.RNDRG_PROV_TYPE_CD 
where TRIM(a.ETG_PROV_TYPE_CD ) IN ('1','2') AND B.PLOS_CD 
IN ('03','04','05','06','07','08','09','11','12','14','15','16','17','18','19','20','22',
'23','24','41','42','49','50','53','57','60','62','65','71','72','81','99') 
and  B.ctgry_of_srvc_cd <> 'OP OTHER'""")
      val data = Array("'ETG_PROV_TYPE_CD' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"""Test Query : SELECT DISTINCT B.clm_id, A.ETG_PROV_TYPE_CD AS ETG_PROV_TYPE_CD,
      B.plos_cd as PLACE_OF_SRVC_CD,B.ctgry_of_srvc_cd,b.rndrg_prov_spclty_cd
FROM ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_PROV_TYPE_INBND A 
INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs B
ON A.PROV_TYPE_CD = B.RNDRG_PROV_TYPE_CD 
where TRIM(a.ETG_PROV_TYPE_CD ) IN ('1','2') AND B.PLOS_CD 
IN ('03','04','05','06','07','08','09','11','12','14','15','16','17','18','19','20','22',
'23','24','41','42','49','50','53','57','60','62','65','71','72','81','99') 
and  B.ctgry_of_srvc_cd <> 'OP OTHER'""")
      val data = Array("'ETG_PROV_TYPE_CD' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================

  test("ClaimProfessionalExtract - Validate Category of service is getting populated correctly, Scenario-4  - 069") {

    val id = Array("069")
    val name = Array("Test case : Validate Category of service is getting populated correctly, Scenario-4")

    val result = sqlContext.sql(s"""SELECT DISTINCT B.clm_id, A.ETG_PROV_TYPE_CD AS ETG_PROV_TYPE_CD,B.plos_cd as PLACE_OF_SRVC_CD,
B.ctgry_of_srvc_cd,b.rndrg_prov_spclty_cd
FROM ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_PROV_TYPE_INBND A 
INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs B
ON A.PROV_TYPE_CD = B.RNDRG_PROV_TYPE_CD 
where TRIM(a.ETG_PROV_TYPE_CD ) IN ('1','2') AND B.PLOS_CD 
IN ('13','21','25','26','31','32','33','34','51','52','54','55','56','61') 
and B.ctgry_of_srvc_cd <> 'IP OTHER'""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"""Test Query : SELECT DISTINCT B.clm_id, A.ETG_PROV_TYPE_CD AS ETG_PROV_TYPE_CD,B.plos_cd as PLACE_OF_SRVC_CD,
B.ctgry_of_srvc_cd,b.rndrg_prov_spclty_cd
FROM ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_PROV_TYPE_INBND A 
INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs B
ON A.PROV_TYPE_CD = B.RNDRG_PROV_TYPE_CD 
where TRIM(a.ETG_PROV_TYPE_CD ) IN ('1','2') AND B.PLOS_CD 
IN ('13','21','25','26','31','32','33','34','51','52','54','55','56','61') 
and B.ctgry_of_srvc_cd <> 'IP OTHER'""")
      val data = Array("'ETG_PROV_TYPE_CD' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"""Test Query : SELECT DISTINCT B.clm_id, A.ETG_PROV_TYPE_CD AS ETG_PROV_TYPE_CD,B.plos_cd as PLACE_OF_SRVC_CD,
B.ctgry_of_srvc_cd,b.rndrg_prov_spclty_cd
FROM ${dbname}_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_PROV_TYPE_INBND A 
INNER JOIN ${dbname}_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs B
ON A.PROV_TYPE_CD = B.RNDRG_PROV_TYPE_CD 
where TRIM(a.ETG_PROV_TYPE_CD ) IN ('1','2') AND B.PLOS_CD 
IN ('13','21','25','26','31','32','33','34','51','52','54','55','56','61') 
and B.ctgry_of_srvc_cd <> 'IP OTHER'""")
      val data = Array("'ETG_PROV_TYPE_CD' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }
  
  //==========================================

  test("ClaimProfessionalExtract - validating the Medicare group 195331 exclusion  - 070") {

    val id = Array("070")
    val name = Array("Test case : validating the Medicare group 195331 exclusion")

    val result = sqlContext.sql(s"""select  bhi_home_plan_id,clm_id  from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where grp_cd='195331' limit 10""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array(s"""Test Query : select  bhi_home_plan_id,clm_id  from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where grp_cd='195331' limit 10""")
      val data = Array("'ETG_PROV_TYPE_CD' : Valid")
      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array(s"""Test Query : select  bhi_home_plan_id,clm_id  from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs where grp_cd='195331' limit 10""")
      val data = Array("'ETG_PROV_TYPE_CD' : Invalid")

      sc.parallelize(id, 1).union(sc.parallelize(name, 1)).union(sc.parallelize(query, 1)).union(sc.parallelize(status, 1)).union(sc.parallelize(data, 1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/" + env + f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_" + subj + "_" + prcss + "_" + id.toList.mkString("") + "_" + status.toList.mkString("") + "_" + currdate) + "_.dat"
      assert(1 == 2)
    }

  }

  //==========================================
  /*
  test("ClaimProfessionalExtract -Validate that the table should have data based on the condition CLM.SRVC_RNDRG_TYPE_CD IN('PHYSN','PANCL') - 043") {
    val id = Array("043")
    val name = Array("Test case : Validate that the table should have data based on the condition CLM.SRVC_RNDRG_TYPE_CD IN('PHYSN','PANCL')")



    val result = sqlContext.sql("""SELECT E.clmadj_key FROM """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN """+dbname+"""_PCANDW1PH_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.SRVC_RNDRG_TYPE_CD IN('PHYSN','PANCL')""")

    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT E.clmadj_key FROM '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN '''+dbname+'''_PCANDW1PH_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.SRVC_RNDRG_TYPE_CD IN('PHYSN','PANCL')")
      val data = Array("'Records with PHYSN and PANCL in SRVC_RNDRG_TYPE_CD column'")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT E.clmadj_key FROM '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN '''+dbname+'''_PCANDW1PH_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.SRVC_RNDRG_TYPE_CD IN('PHYSN','PANCL')")
      val data = Array("'There are no records with PHYSN and PANCL in SRVC_RNDRG_TYPE_CD column. Check the table'")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that the table should not include any claim that is not settled or is in progress/pending status - 044") {
    val id = Array("044")
    val name = Array("Test case : Validate that the table should not include any claim that is not settled or is in progress/pending status")



    val result = sqlContext.sql("""SELECT E.clmadj_key FROM """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN """+dbname+"""_PCANDW1PH_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.ADJDCTN_STTS_CD IN ('03', '10')""")

    if (result.count == 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : SELECT E.clmadj_key FROM '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN '''+dbname+'''_PCANDW1PH_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.ADJDCTN_STTS_CD IN ('03', '10')")
      val data = Array("'No Records having claims in Progress/Pending Status'")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : SELECT E.clmadj_key FROM '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg E INNER JOIN '''+dbname+'''_PCANDW1PH_nogbd_r000_in.CLM C ON E.clmadj_key= C.CLM_ADJSTMNT_KEY AND C.ADJDCTN_STTS_CD IN ('03', '10')")
      val data = Array("'Invalid records having claims in Progress/Pending Status'")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Traceability Field is populated is populated as per mapping sheet transformation - 045") {
    val id = Array("045")
    val name = Array("Test case : Validate that Traceability Field is populated is populated as per mapping sheet transformation")



    val result1 = sqlContext.sql("""select distinct TRCBLTY_FLD_CD from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key = '3209053A51F7A1CB64EC3E6BEBB34745'""")

    val result2 = sqlContext.sql("""select distinct CLM_SOR_CD  from  """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm WHERE CLM_ADJSTMNT_KEY = '3209053A51F7A1CB64EC3E6BEBB34745'""")

    val x = result1.rdd.first().getString(0)
    val y = result2.rdd.first().getString(0)
    if (x == y) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct TRCBLTY_FLD_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key = '3209053A51F7A1CB64EC3E6BEBB34745'")
      val query2 = Array("Test Query : select distinct CLM_SOR_CD  from  '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm WHERE CLM_ADJSTMNT_KEY = '3209053A51F7A1CB64EC3E6BEBB34745'")
      val data = Array(" Traceability code present in Claim table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct TRCBLTY_FLD_CD from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key = '3209053A51F7A1CB64EC3E6BEBB34745'")
      val query2 = Array("Test Query : select distinct CLM_SOR_CD  from  '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm WHERE CLM_ADJSTMNT_KEY = '3209053A51F7A1CB64EC3E6BEBB34745'")
      val data = Array(" Traceability code not present in Claim table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================

  test("ClaimProfessionalExtract -Validate that Adjustment Sequence Number is populated is populated as per mapping sheet transformation - 046") {
    val id = Array("046")
    val name = Array("Test case : Validate that Adjustment Sequence Number is populated is populated as per mapping sheet transformation")



    val result1 = sqlContext.sql("""select distinct ADJSTMNT_SQNC_NBR from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='3209053A51F7A1CB64EC3E6BEBB34745'""")

    val result2 = sqlContext.sql("""select distinct CLM_ADJSTMNT_NBR from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm where clm_adjstmnt_key='3209053A51F7A1CB64EC3E6BEBB34745'""")

    val x = result1.rdd.first().getString(0)
    val y = result2.rdd.first().getString(0)
    if (x == y) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct ADJSTMNT_SQNC_NBR from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='3209053A51F7A1CB64EC3E6BEBB34745'")
      val query2 = Array("Test Query : select distinct CLM_ADJSTMNT_NBR from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm where clm_adjstmnt_key='3209053A51F7A1CB64EC3E6BEBB34745'")
      val data = Array("Adjustment Sequence Number present in Claim table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct ADJSTMNT_SQNC_NBR from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='3209053A51F7A1CB64EC3E6BEBB34745'")
      val query2 = Array("Test Query : select distinct CLM_ADJSTMNT_NBR from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm where clm_adjstmnt_key='3209053A51F7A1CB64EC3E6BEBB34745'")
      val data = Array("Adjustment Sequence Number not present in Claim table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

  //===========================================

   test("ClaimProfessionalExtract -Validate that Claim Line Number is populated is populated as per mapping sheet transformation - 047") {
    val id = Array("047")
    val name = Array("Test case : Validate that Claim Line Number is populated is populated as per mapping sheet transformation")



    val result1 = sqlContext.sql("""select distinct CLM_LINE_NBR from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='67DC905D393EC28EDB7755FDA238D5C7'""")

    val result2 = sqlContext.sql("""select CASE WHEN CLM_SOR_CD <> '824' AND LENGTH (TRIM (CLM_LINE_NBR)) = '4' THEN SUBSTR((TRIM(CLM_LINE_NBR)),2,4) WHEN CLM_SOR_CD = '824' THEN ROW_NUMBER() OVER (PARTITION BY CLM_ADJSTMNT_KEY ORDER BY CLM_LINE_NBR) ELSE TRIM(CLM_LINE_NBR) END AS CLM_LINE_NBR from """+dbname+"""_PCANDW1PH_nogbd_r000_IN.clm_line where clm_adjstmnt_key='67DC905D393EC28EDB7755FDA238D5C7'""")
    result2.createOrReplaceTempView("result2DF")

    val result3 = sqlContext.sql(""" select distinct clm_line_nbr from result2DF""")
    val x = result1.rdd.first().getString(0)
    val y = result3.rdd.first().getString(0)
    if (x == y) {
      val a = result1.limit(10).rdd
      val b = result3.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct CLM_LINE_NBR from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='67DC905D393EC28EDB7755FDA238D5C7'")
      val query2 = Array("Test Query : select distinct clm_line_nbr from (select CASE WHEN CLM_SOR_CD <> '824' AND LENGTH (TRIM (CLM_LINE_NBR)) = '4' THEN SUBSTR((TRIM(CLM_LINE_NBR)),2,4) WHEN CLM_SOR_CD = '824' THEN ROW_NUMBER() OVER (PARTITION BY CLM_ADJSTMNT_KEY ORDER BY CLM_LINE_NBR) ELSE TRIM(CLM_LINE_NBR) END AS CLM_LINE_NBR from CLM_LINE where clm_adjstmnt_key='67DC905D393EC28EDB7755FDA238D5C7')")
      val data = Array("Claim Line Number present in Claim table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result3.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct CLM_LINE_NBR from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='67DC905D393EC28EDB7755FDA238D5C7'")
      val query2 = Array("Test Query : select distinct clm_line_nbr from (select CASE WHEN CLM_SOR_CD <> '824' AND LENGTH (TRIM (CLM_LINE_NBR)) = '4' THEN SUBSTR((TRIM(CLM_LINE_NBR)),2,4) WHEN CLM_SOR_CD = '824' THEN ROW_NUMBER() OVER (PARTITION BY CLM_ADJSTMNT_KEY ORDER BY CLM_LINE_NBR) ELSE TRIM(CLM_LINE_NBR) END AS CLM_LINE_NBR from CLM_LINE where clm_adjstmnt_key='67DC905D393EC28EDB7755FDA238D5C7')")
      val data = Array("Claim Line Number not present in Claim table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

	//===========================================

    test("ClaimProfessionalExtract -Validate that CPT and HCPCS Codes field is populated from CLM_LINE table using HLTH_SRVC_CD /SCNDRY_HLTH_SRVC_CD - 051") {
    val id = Array("051")
    val name = Array("Test case : Validate that CPT and HCPCS Codes field is populated from CLM_LINE table using HLTH_SRVC_CD /SCNDRY_HLTH_SRVC_CD ")



    val result = sqlContext.sql("""select case when HLTH_SRVC_TYPE_CD in ('HCPCS', 'CPT4', 'UNK') and HLTH_SRVC_CD='UNK' then SCNDRY_HLTH_SRVC_CD else HLTH_SRVC_CD end,HLTH_SRVC_TYPE_CD,HLTH_SRVC_CD,SCNDRY_HLTH_SRVC_CD,HLTH_SRVC_CD from """+dbname+"""_PCANDW1PH_nogbd_r000_IN.clm_line""")

    if (result.count > 0) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select case when HLTH_SRVC_TYPE_CD in ('HCPCS', 'CPT4', 'UNK') and HLTH_SRVC_CD='UNK' then SCNDRY_HLTH_SRVC_CD else HLTH_SRVC_CD end,HLTH_SRVC_TYPE_CD,HLTH_SRVC_CD,SCNDRY_HLTH_SRVC_CD,HLTH_SRVC_CD from '''+dbname+'''_PCANDW1PH_nogbd_r000_IN.clm_line")
      val data = Array("CPT and HCPCS Codes field is populated from CLM_LINE")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select case when HLTH_SRVC_TYPE_CD in ('HCPCS', 'CPT4', 'UNK') and HLTH_SRVC_CD='UNK' then SCNDRY_HLTH_SRVC_CD else HLTH_SRVC_CD end,HLTH_SRVC_TYPE_CD,HLTH_SRVC_CD,SCNDRY_HLTH_SRVC_CD,HLTH_SRVC_CD from '''+dbname+'''_PCANDW1PH_nogbd_r000_IN.clm_line")
      val data = Array("CPT and HCPCS Codes field is not populated from CLM_LINE")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

    test("ClaimProfessionalExtract -Validate that Reimbursement Type Code field in the file is populated from CLM_REIMB_MTHD_CD of CLM table- 055") {
    val id = Array("055")
    val name = Array("Test case : Validate that Reimbursement Type Code field in the file is populated from CLM_REIMB_MTHD_CD of CLM table")



    val result1 = sqlContext.sql(""" select distinct reimbmnt_type_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS where reimbmnt_type_cd <> 'UN'""")
    val result2 = sqlContext.sql(""" select distinct clm_reimb_mthd_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm""")

    val result = result1.except(result2)
    if (result.count < 1) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct reimbmnt_type_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS where reimbmnt_type_cd <> 'UN' and reimbmnt_type_cd not in (distinct clm_reimb_mthd_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm)")
      val data = Array("Reimbursement Type Code field is CLM_REIMB_MTHD_CD of CLM table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct reimbmnt_type_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS where reimbmnt_type_cd <> 'UN' and reimbmnt_type_cd not in (distinct clm_reimb_mthd_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm)")
      val data = Array("Reimbursement Type Code field is not CLM_REIMB_MTHD_CD of CLM table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

    test("ClaimProfessionalExtract -Validate that Submission Type Code field in the file is populated from CLM_FORM_TYPE_CD from CLM table- 056") {
    val id = Array("056")
    val name = Array("Test case : Validate that Submission Type Code field in the file is populated from CLM_FORM_TYPE_CD from CLM table")



    val result1 = sqlContext.sql(""" select distinct sbmsn_type_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS where sbmsn_type_cd <> 'UN'""")
    val result2 = sqlContext.sql(""" select distinct clm_form_type_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm""")

    val result = result1.except(result2)
    if (result.count < 1) {
      val a = result.limit(10).rdd
      val status = Array("SUCCESS")
      val query = Array("Test Query : select distinct sbmsn_type_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS where sbmsn_type_cd <> 'UN' and sbmsn_type_cd not in (select distinct clm_form_type_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm)")
      val data = Array("Submission Type Code field is CLM_FORM_TYPE_CD of CLM table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result.limit(10).rdd
      val status = Array("FAILED")
      val query = Array("Test Query : select distinct sbmsn_type_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_PRFSNL_OTHR_SRVCS where sbmsn_type_cd <> 'UN' and sbmsn_type_cd not in (select distinct clm_form_type_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm)")
      val data = Array("Submission Type Code field is not CLM_FORM_TYPE_CD of CLM table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

    test("ClaimProfessionalExtract -Validate that Adjudicated Date field in the file is populated from ADJDCTN_DT of CLM table - 057") {
    val id = Array("057")
    val name = Array("Test case : Validate that Adjudicated Date field in the file is populated from ADJDCTN_DT of CLM table")



    val result1 = sqlContext.sql(""" select adjdctd_dt from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'""")
    val result2 = sqlContext.sql(""" select adjdctn_dt from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D'""")

    val x = result1.rdd.first().getTimestamp(0)
    val y = result2.rdd.first().getTimestamp(0)

    if (x == y) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select adjdctd_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select adjdctn_dt from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val data = Array("Adjudicated Date field is from ADJDCTN_DT of CLM table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select adjdctd_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select adjdctn_dt from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val data = Array("Adjudicated Date field is not from ADJDCTN_DT of CLM table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

   test("ClaimProfessionalExtract -Validate that Claim Enter Date field in the file is populated from CLM_SYS_ENTRY_DT of CLM table - 058") {
    val id = Array("058")
    val name = Array("Test case : Validate that Claim Enter Date field in the file is populated from CLM_SYS_ENTRY_DT of CLM table")



    val result1 = sqlContext.sql(""" select distinct clm_entr_dt from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'""")
    val result2 = sqlContext.sql(""" select distinct clm_sys_entry_dt from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm where clm_adjstmnt_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'""")

    val x = result1.rdd.first().getTimestamp(0)
    val y = result2.rdd.first().getTimestamp(0)

    if (x == y) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct clm_entr_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'")
      val query2 = Array("Test Query : select distinct clm_sys_entry_dt from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm where clm_adjstmnt_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'")
      val data = Array("Claim Enter date field is from CLM_SYS_ENTRY_DT of CLM table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct clm_entr_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'")
      val query2 = Array("Test Query : select distinct clm_sys_entry_dt from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm where clm_adjstmnt_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'")
      val data = Array(" Claim Enter date field is not from CLM_SYS_ENTRY_DT of CLM table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

   test("ClaimProfessionalExtract -Validate that Claim Paid Date field in the file is populated from GL_POST_DT of CLM_PAID table - 059") {
    val id = Array("059")
    val name = Array("Test case : Validate that Claim Paid Date field in the file is populated from GL_POST_DT of CLM_PAID table")



    val result1 = sqlContext.sql(""" select distinct clm_paid_dt from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='0A42B4F34CE756C09B222AB1F08C077E'""")
    val result2 = sqlContext.sql(""" select distinct gl_post_dt from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm_paid where clm_adjstmnt_key='0A42B4F34CE756C09B222AB1F08C077E'""")

    val x = result1.rdd.first().getTimestamp(0)
    val y = result2.rdd.first().getTimestamp(0)

    if (x == y) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct clm_paid_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='0A42B4F34CE756C09B222AB1F08C077E'")
      val query2 = Array("Test Query : select distinct gl_post_dt from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_paid where clm_adjstmnt_key='0A42B4F34CE756C09B222AB1F08C077E'")
      val data = Array("Claim Paid date field is from GL_POST_DT of CLM_PAID table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct clm_paid_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='0A42B4F34CE756C09B222AB1F08C077E'")
      val query2 = Array("Test Query : select distinct gl_post_dt from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_paid where clm_adjstmnt_key='0A42B4F34CE756C09B222AB1F08C077E'")
      val data = Array("Claim Paid date field is not from GL_POST_DT of CLM_PAID table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

  test("ClaimProfessionalExtract -Validate that Claim Received Date field in the file is populated from CLM_RCVD_DT of CLM table - 060") {
    val id = Array("060")
    val name = Array("Test case : Validate that Claim Received Date field in the file is populated from CLM_RCVD_DT of CLM table")



    val result1 = sqlContext.sql(""" select distinct clm_rcvd_dt from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'""")
    val result2 = sqlContext.sql(""" select distinct clm_rcvd_dt from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D'""")

    val x = result1.rdd.first().getTimestamp(0)
    val y = result2.rdd.first().getTimestamp(0)

    if (x == y) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct clm_rcvd_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select distinct clm_rcvd_dt from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val data = Array("Claim Received date field is from CLM_RCVD_DT of CLM table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct clm_rcvd_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select distinct clm_rcvd_dt from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val data = Array("Claim Received date field is not from CLM_RCVD_DT of CLM table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

  test("ClaimProfessionalExtract -Validate that First Date of Service in the file is populated from CLM_LINE_SRVC_STRT_DT of CLM_LINE table - 061") {
    val id = Array("061")
    val name = Array("Test case : Validate that First Date of Service in the file is populated from CLM_LINE_SRVC_STRT_DT of CLM_LINE table")



    val result1 = sqlContext.sql(""" select distinct srvc_from_dt from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'""")
    val result2 = sqlContext.sql(""" select distinct clm_line_srvc_strt_dt from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D'""")

    val x = result1.rdd.first().getTimestamp(0)
    val y = result2.rdd.first().getTimestamp(0)

    if (x == y) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct srvc_from_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select distinct clm_line_srvc_strt_dt from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val data = Array("First Date of Service field is from CLM_LINE_SRVC_STRT_DT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct srvc_from_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select distinct clm_line_srvc_strt_dt from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val data = Array("First Date of Service field is not from CLM_LINE_SRVC_STRT_DT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

  test("ClaimProfessionalExtract -Validate that End Date of Service in the file is populated from CLM_LINE_SRVC_END_DT of CLM_LINE table - 062") {
    val id = Array("062")
    val name = Array("Test case : Validate that End Date of Service in the file is populated from CLM_LINE_SRVC_END_DT of CLM_LINE table")



    val result1 = sqlContext.sql(""" select distinct srvc_end_dt from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'""")
    val result2 = sqlContext.sql(""" select distinct clm_line_srvc_end_dt from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'""")

    val x = result1.rdd.first().getTimestamp(0)
    val y = result2.rdd.first().getTimestamp(0)

    if (x == y) {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct srvc_end_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'")
      val query2 = Array("Test Query : select distinct clm_line_srvc_end_dt from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'")
      val data = Array("End Date of Service field is from CLM_LINE_SRVC_END_DT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val a = result1.limit(10).rdd
      val b = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct srvc_end_dt from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'")
      val query2 = Array("Test Query : select distinct clm_line_srvc_end_dt from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'")
      val data = Array("End Date of Service field is not from CLM_LINE_SRVC_END_DT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).union(b.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

  test("ClaimProfessionalExtract -Validate that Submitted Amount field in the file is populated from BILLD_CHRG_AMT of CLM_LINE table - 063") {
    val id = Array("063")
    val name = Array("Test case : Validate that Submitted Amount field in the file is populated from BILLD_CHRG_AMT of CLM_LINE table")



    val result1 = sqlContext.sql(""" select distinct sbmtd_amt, clm_line_nbr from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'""")
    val result2 = sqlContext.sql(""" select distinct billd_chrg_amt, clm_line_nbr from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D' and BILLD_CHRG_AMT>=0
AND NON_CVRD_AMT>=0
AND ALWD_AMT>=0
AND PAID_AMT>=0
AND COB_SVNGS_AMT>=0
AND COINSRN_AMT>=0
AND CPAY_AMT>=0
AND DDCTBL_AMT>=0""")

    val x = result1.rdd.first().getDecimal(0)
    val y = result2.rdd.first().getDecimal(0)

    val a = result1.rdd.first().getString(1)
    val b = result2.rdd.first().getString(1)

    if (x == y && a == b) {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct sbmtd_amt, clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select distinct billd_chrg_amt, clm_line_nbr from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("Submitted Amount field is from BILLD_CHRG_AMT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct sbmtd_amt, clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select distinct billd_chrg_amt, clm_line_nbr from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("Submitted Amount field is not from BILLD_CHRG_AMT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

  test("ClaimProfessionalExtract -Validate that Allowed Amount field in the file is populated from ALWD_AMT of CLM_LINE table  - 064") {
    val id = Array("064")
    val name = Array("Test case : Validate that Allowed Amount field in the file is populated from ALWD_AMT of CLM_LINE table")



    val result1 = sqlContext.sql(""" select distinct alwd_amt, clm_line_nbr from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'""")
    val result2 = sqlContext.sql(""" select distinct alwd_amt, clm_line_nbr from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D' and BILLD_CHRG_AMT>=0
AND NON_CVRD_AMT>=0
AND ALWD_AMT>=0
AND PAID_AMT>=0
AND COB_SVNGS_AMT>=0
AND COINSRN_AMT>=0
AND CPAY_AMT>=0
AND DDCTBL_AMT>=0""")

    val x = result1.rdd.first().getDecimal(0)
    val y = result2.rdd.first().getDecimal(0)

    val a = result1.rdd.first().getString(1)
    val b = result2.rdd.first().getString(1)
    if (x == y && a == b) {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct alwd_amt, clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select distinct alwd_amt, clm_line_nbr from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("Allowed Amount field is from ALWD_AMT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct alwd_amt, clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select distinct alwd_amt, clm_line_nbr from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("Allowed Amount field is not from ALWD_AMT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

  test("ClaimProfessionalExtract -Validate that Payment Amount field in the file is populated from PAID_AMT of CLM_LINE table  - 065") {
    val id = Array("065")
    val name = Array("Test case : Validate that Payment Amount field in the file is populated from PAID_AMT of CLM_LINE table")



    val result1 = sqlContext.sql("""select distinct paymnt_amt, clm_line_nbr from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='234F4358958316508CE36E8557375F43'""")
    val result2 = sqlContext.sql("""select distinct paid_amt, clm_line_nbr from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='234F4358958316508CE36E8557375F43' and BILLD_CHRG_AMT>=0
AND NON_CVRD_AMT>=0
AND ALWD_AMT>=0
AND PAID_AMT>=0
AND COB_SVNGS_AMT>=0
AND COINSRN_AMT>=0
AND CPAY_AMT>=0
AND DDCTBL_AMT>=0""")

    val x = result1.rdd.first().getDecimal(0)
    val y = result2.rdd.first().getDecimal(0)

    val a = result1.rdd.first().getString(1)
    val b = result2.rdd.first().getString(1)
    if (x == y && a == b) {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct paymnt_amt, clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='234F4358958316508CE36E8557375F43'")
      val query2 = Array("Test Query : select distinct paid_amt, clm_line_nbr from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='234F4358958316508CE36E8557375F43' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("Payment Amount field is from PAID_AMT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct paymnt_amt, clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='234F4358958316508CE36E8557375F43'")
      val query2 = Array("Test Query : select distinct paid_amt, clm_line_nbr from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='234F4358958316508CE36E8557375F43' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("Payment Amount field is not from PAID_AMT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

  test("ClaimProfessionalExtract -Validate that COB / TPL Amount field in the file is populated from COB_SVNGS_AMT of CLM_LINE table  - 066") {
    val id = Array("066")
    val name = Array("Test case : Validate that COB / TPL Amount field in the file is populated from COB_SVNGS_AMT of CLM_LINE table")



    val result1 = sqlContext.sql("""select distinct cob_tpl_amt,clm_line_nbr from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'""")
    val result2 = sqlContext.sql("""select distinct cob_svngs_amt,clm_line_nbr from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D' and BILLD_CHRG_AMT>=0
AND NON_CVRD_AMT>=0
AND ALWD_AMT>=0
AND PAID_AMT>=0
AND COB_SVNGS_AMT>=0
AND COINSRN_AMT>=0
AND CPAY_AMT>=0
AND DDCTBL_AMT>=0""")

    val x = result1.rdd.first().getDecimal(0)
    val y = result2.rdd.first().getDecimal(0)

    val a = result1.rdd.first().getString(1)
    val b = result2.rdd.first().getString(1)
    if (x == y && a == b) {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct cob_tpl_amt,clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select distinct cob_svngs_amt,clm_line_nbr from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("COB / TPL Amount field is from COB_SVNGS_AMT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct cob_tpl_amt,clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select distinct cob_svngs_amt,clm_line_nbr from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("COB / TPL Amount field is not from COB_SVNGS_AMT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

  test("ClaimProfessionalExtract -Validate that Coinsurance Amount field in the file is populated from COINSRN_AMT of CLM_LINE table  - 067") {
    val id = Array("067")
    val name = Array("Test case : Validate that Coinsurance Amount field in the file is populated from COINSRN_AMT of CLM_LINE table")



    val result1 = sqlContext.sql("""select distinct coinsrn_amt,clm_line_nbr from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='234F4358958316508CE36E8557375F43'""")
    val result2 = sqlContext.sql("""select distinct coinsrn_amt,clm_line_nbr from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='234F4358958316508CE36E8557375F43' and BILLD_CHRG_AMT>=0
AND NON_CVRD_AMT>=0
AND ALWD_AMT>=0
AND PAID_AMT>=0
AND COB_SVNGS_AMT>=0
AND COINSRN_AMT>=0
AND CPAY_AMT>=0
AND DDCTBL_AMT>=0""")

    val x = result1.rdd.first().getDecimal(0)
    val y = result2.rdd.first().getDecimal(0)

    val a = result1.rdd.first().getString(1)
    val b = result2.rdd.first().getString(1)
    if (x == y && a == b) {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct coinsrn_amt,clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='234F4358958316508CE36E8557375F43'")
      val query2 = Array("Test Query : select distinct coinsrn_amt,clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='234F4358958316508CE36E8557375F43' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("Coinsurance Amount field is from COINSRN_AMT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct coinsrn_amt,clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='234F4358958316508CE36E8557375F43'")
      val query2 = Array("Test Query : select distinct coinsrn_amt,clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='234F4358958316508CE36E8557375F43' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("Coinsurance Amount field is not from COINSRN_AMT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

  test("ClaimProfessionalExtract -Validate that Copay Amount field in the file is populated from CPAY_AMT of CLM_LINE table  - 068") {
    val id = Array("068")
    val name = Array("Test case : Validate that Copay Amount field in the file is populated from CPAY_AMT of CLM_LINE table")



    val result1 = sqlContext.sql("""select distinct cpay_amt,clm_line_nbr from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'""")
    val result2 = sqlContext.sql("""select distinct cpay_amt,clm_line_nbr from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='ECC4C7FAB9B6DACD8152AE4EC0383A89' and BILLD_CHRG_AMT>=0
AND NON_CVRD_AMT>=0
AND ALWD_AMT>=0
AND PAID_AMT>=0
AND COB_SVNGS_AMT>=0
AND COINSRN_AMT>=0
AND CPAY_AMT>=0
AND DDCTBL_AMT>=0""")

    val x = result1.rdd.first().getDecimal(0)
    val y = result2.rdd.first().getDecimal(0)

    val a = result1.rdd.first().getString(1)
    val b = result2.rdd.first().getString(1)
    if (x == y && a == b) {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct cpay_amt,clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'")
      val query2 = Array("Test Query : select distinct cpay_amt,clm_line_nbr from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='ECC4C7FAB9B6DACD8152AE4EC0383A89' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("Copay Amount field is from CPAY_AMT of CLM_LINE tabl")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct cpay_amt,clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='ECC4C7FAB9B6DACD8152AE4EC0383A89'")
      val query2 = Array("Test Query : select distinct cpay_amt,clm_line_nbr from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='ECC4C7FAB9B6DACD8152AE4EC0383A89' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("Copay Amount field is not from CPAY_AMT of CLM_LINE tabl")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }

   //===========================================

  test("ClaimProfessionalExtract -Validate that Deductible Amount field in the file is populated from DDCTBL_AMT from CLM_LINE table  - 069") {
    val id = Array("069")
    val name = Array("Test case : Validate that Deductible Amount field in the file is populated from DDCTBL_AMT from CLM_LINE table")



    val result1 = sqlContext.sql("""select distinct ddctbl_amt,clm_line_nbr from """+dbname+"""_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'""")
    val result2 = sqlContext.sql("""select distinct ddctbl_amt,clm_line_nbr from """+dbname+"""_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D' and BILLD_CHRG_AMT>=0
AND NON_CVRD_AMT>=0
AND ALWD_AMT>=0
AND PAID_AMT>=0
AND COB_SVNGS_AMT>=0
AND COINSRN_AMT>=0
AND CPAY_AMT>=0
AND DDCTBL_AMT>=0""")

    val x = result1.rdd.first().getDecimal(0)
    val y = result2.rdd.first().getDecimal(0)

    val a = result1.rdd.first().getString(1)
    val b = result2.rdd.first().getString(1)
    if (x == y && a == b) {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("SUCCESS")
      val query1 = Array("Test Query : select distinct ddctbl_amt,clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select distinct ddctbl_amt,clm_line_nbr from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("Deductible Amount field is from DDCTBL_AMT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
     assert(1==1)
    } else {
      val p = result1.limit(10).rdd
      val q = result2.limit(10).rdd
      val status = Array("FAILED")
      val query1 = Array("Test Query : select distinct ddctbl_amt,clm_line_nbr from '''+dbname+'''_pcandw1ph_nogbd_r000_sg.bcbsa_prfsnl_othr_srvcs_stg where clmadj_key='CF896E00C79A4BB50C1F38B84CF29B2D'")
      val query2 = Array("Test Query : select distinct ddctbl_amt,clm_line_nbr from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.clm_line where clm_adjstmnt_key='CF896E00C79A4BB50C1F38B84CF29B2D' and BILLD_CHRG_AMT>=0 AND NON_CVRD_AMT>=0 AND ALWD_AMT>=0 AND PAID_AMT>=0 AND COB_SVNGS_AMT>=0 AND COINSRN_AMT>=0 AND CPAY_AMT>=0 AND DDCTBL_AMT>=0")
      val data = Array("Deductible Amount field is not from DDCTBL_AMT of CLM_LINE table")

      sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query1,1)).union(sc.parallelize(query2,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(p.map(_.toString)).union(q.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Extract_Tables/POS/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
      assert(1==2)
    }
  }
   */

}