package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Error_MemberDemographic_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Error_MemberDemographic_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_Error_MemberDemographic_TGT(dbname : String, env: String) extends FunSuite  {

	   val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())

     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Error"
      val prcss = "MemberDemographic"

   test("Member Demo Error-Check Error code when Member Primary State is not contained in the list of valid State codes - 001") {

     val id = Array("001")
     val name = Array("Test case : Check Error code when Member Primary State is not contained in the list of valid State codes")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id 
        where mbr_prmry_st_cd NOT IN('AE','AK','AZ','CO','DE','FL','IL','KS','KY','ME','MH','MN','MT','ND','NJ','NM','NV','NY','OR','PW','RI','VT','WA','WV','WY','0','99','AL','AR','CA','DC','FM','GU','IA','ID','LA','MI','MO','NE','NH','PR','SC','TN','VI','AA','AP','AS','CT','GA','HI','IN','MA','MD','MP','MS','NC','OH','OK','PA','SD','TX','UT','VA','WI')""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where mbr_prmry_st_cd NOT IN('AE','AK','AZ','CO','DE','FL','IL','KS','KY','ME','MH','MN','MT','ND','NJ','NM','NV','NY','OR','PW','RI','VT','WA','WV','WY','0','99','AL','AR','CA','DC','FM','GU','IA','ID','LA','MI','MO','NE','NH','PR','SC','TN','VI','AA','AP','AS','CT','GA','HI','IN','MA','MD','MP','MS','NC','OH','OK','PA','SD','TX','UT','VA','WI')")
       val data = Array("'ErrorCode' : No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where mbr_prmry_st_cd NOT IN('AE','AK','AZ','CO','DE','FL','IL','KS','KY','ME','MH','MN','MT','ND','NJ','NM','NV','NY','OR','PW','RI','VT','WA','WV','WY','0','99','AL','AR','CA','DC','FM','GU','IA','ID','LA','MI','MO','NE','NH','PR','SC','TN','VI','AA','AP','AS','CT','GA','HI','IN','MA','MD','MP','MS','NC','OH','OK','PA','SD','TX','UT','VA','WI')")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Member Primary Zip +4 not in correct numeric format - 002") {

     val id = Array("002")
     val name = Array("Test case : Check Error code when Member Primary Zip +4 not in correct numeric format")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id 
        where mbr_prmry_zip_plus4_cd RLIKE '[^0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("310") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where mbr_prmry_zip_plus4_cd RLIKE '[^0-9]'")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where mbr_prmry_zip_plus4_cd RLIKE '[^0-9]'")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Member Primary Phone Number not in correct numeric format - 003") {

     val id = Array("003")
     val name = Array("Test case : Check Error code when Member Primary Phone Number not in correct numeric format")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id 
        where mbr_prmry_phone_nbr RLIKE '[^0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("310") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where mbr_prmry_phone_nbr RLIKE '[^0-9]'")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where mbr_prmry_phone_nbr RLIKE '[^0-9]'")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  /*test("Member Demo Error-Check Error code when Member Secondary State is not contained in the list of valid State codes. - 004") {

     val id = Array("004")
     val name = Array("Test case : Check Error code when Member Secondary State is not contained in the list of valid State codes")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id 
        where mbr_scndry_st_cd NOT IN('')""")

     if (result.count == 0 || (result.collectAsList.toString.contains("409") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }*/
  
  //============================================================

  test("Member Demo Error-Check Error code when Member Participation Code is not contained in the list of valid State codes - 005") {

     val id = Array("005")
     val name = Array("Test case : Check Error code when Member Participation Code is not contained in the list of valid State codes")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id 
        where mbr_parn_cd NOT IN('Y','N','A','D','I')""")

    if (result.count == 0 || (result.collectAsList.toString.contains("306") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where mbr_parn_cd NOT IN('Y','N','A','D','I')")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where mbr_parn_cd NOT IN('Y','N','A','D','I')")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Demographic Void Indicator does not equal to 'Y' and 'N' - 006") {

      val id = Array("006")
     val name = Array("Test case : Check Error code when Demographic Void Indicator does not equal to 'Y' and 'N'")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id 
        where trim(dmgrphc_void_ind)<>'Y' and trim(dmgrphc_void_ind)<>'N'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("305") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where trim(dmgrphc_void_ind)<>'Y' and trim(dmgrphc_void_ind)<>'N'")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where trim(dmgrphc_void_ind)<>'Y' and trim(dmgrphc_void_ind)<>'N'")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when ITS Subscrib-er ID first three bytes are not alpha-betic (A:Z) - 007") {

      val id = Array("007")
     val name = Array("Test case : Check Error code when ITS Subscrib-er ID first three bytes are not alpha-betic (A:Z)")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id 
        where substr(its_sbscrbr_id,1,3) rlike '[^a-zA-Z]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("305") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where substr(its_sbscrbr_id,1,3) rlike '[^a-zA-Z]'")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where substr(its_sbscrbr_id,1,3) rlike '[^a-zA-Z]'")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Demo-graphic Begin Date not in correct date format - 008") {

     val id = Array("008")
     val name = Array("Test case : Check Error code when Demo-graphic Begin Date not in correct date format")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id 
        where LENGTH(efctv_dt)<>19""")

    if (result.count == 0 || (result.collectAsList.toString.contains("308") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where LENGTH(efctv_dt)<>19")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where LENGTH(efctv_dt)<>19")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  test("Member Demo Error-Check Error code when Demo-graphic End Date not in correct date format - 009") {

     val id = Array("009")
     val name = Array("Test case : Check Error code when Demo-graphic End Date not in correct date format")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id 
        where LENGTH(exprtn_dt)<>19""")

    if (result.count == 0 || (result.collectAsList.toString.contains("308") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where LENGTH(exprtn_dt)<>19")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where LENGTH(exprtn_dt)<>19")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Demographic End Date is before Demographic Begin Date - 010") {

     val id = Array("010")
     val name = Array("Test case : Check Error code when Demographic End Date is before Demographic Begin Date")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id 
        where exprtn_dt< efctv_dt""")

    if (result.count == 0 || (result.collectAsList.toString.contains("315") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where exprtn_dt< efctv_dt")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id  where exprtn_dt< efctv_dt")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  /* test("Member Demo Error-Check Error code when Demo-graphic Begin Date] not in correct date format - 011") {

     val id = Array("011")
     val name = Array("Test case : Check Error code when Demo-graphic Begin Date] not in correct date format")

      
 val invalidFormat = udf((s: String) => FormatChecker.invalidFormat(s))
 
 
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id 
        where trim(efctv_dt)<>'Y' and trim(efctv_dt)<>'N'""")

    assert(result.count == 0 || result.collectAsList.toString.contains("308"))

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when  Demo-graphic End Date not in correct date format - 012") {

     val id = Array("012")
     val name = Array("Test case : Check Error code when  Demo-graphic End Date not in correct date format")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id 
        where trim(custom_network_indicator)<>'Y' and trim(custom_network_indicator)<>'N'""")

    assert(result.count == 0 || result.collectAsList.toString.contains("308"))

  }*/

  //============================================================

  test("Member Demo Error-Check bhi_home_plan_id column values not located in reference table - 013") {

     val id = Array("013")
     val name = Array("Test case : Check bhi_home_plan_id column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result2 = sqlContext.sql("""select distinct a.bhi_home_plan_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306'""")

    val result = result1.intersect(result2)
     
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') and bhi_home_plan_id in (select distinct a.bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306')")
       val data = Array("'bhi_home_plan_id': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') and bhi_home_plan_id in (select distinct a.bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306')")
       val data = Array("'bhi_home_plan_id'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when bhi_home_plan_id column values not located in reference table - 014") {

     val id = Array("014")
     val name = Array("Test case : Check Error code when bhi_home_plan_id column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_in.rfrnc_bcbsa_bhi_home_plan_id_inbnd where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check CNSSTNT_MBR_ID column values not located in reference table - 015") {

     val id = Array("015")
     val name = Array("Test case : Check CNSSTNT_MBR_ID column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct cnsstnt_mbr_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP""")

    val result2 = sqlContext.sql("""select distinct a.cnsstnt_mbr_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='cnsstnt_mbr_id' and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct cnsstnt_mbr_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP where cnsstnt_mbr_id in (select distinct a.cnsstnt_mbr_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='cnsstnt_mbr_id' and b.err_cd='306')")
       val data = Array("'cnsstnt_mbr_id': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct cnsstnt_mbr_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP where cnsstnt_mbr_id in (select distinct a.cnsstnt_mbr_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='cnsstnt_mbr_id' and b.err_cd='306')")
       val data = Array("'cnsstnt_mbr_id'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when CNSSTNT_MBR_ID column values not located in reference table - 016") {

     val id = Array("016")
     val name = Array("Test case : Check Error code when CNSSTNT_MBR_ID column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct cnsstnt_mbr_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('cnsstnt_mbr_id') and a.cnsstnt_mbr_id NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('cnsstnt_mbr_id') and a.cnsstnt_mbr_id NOT IN (select distinct cnsstnt_mbr_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP)")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
     
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('cnsstnt_mbr_id') and a.cnsstnt_mbr_id NOT IN (select distinct cnsstnt_mbr_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP)")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Member Primary Zip Code column values not located in reference table - 017") {

     val id = Array("017")
     val name = Array("Test case : Check Member Primary Zip Code column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct zip_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_in.mlsa_zip_cd_hist_inbnd""")

    val result2 = sqlContext.sql("""select distinct a.mbr_prmry_zip_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='mbr_prmry_zip_cd' and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct zip_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.mlsa_zip_cd_hist_inbnd where zip_cd in (select distinct a.mbr_prmry_zip_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='mbr_prmry_zip_cd' and b.err_cd='306')")
       val data = Array("'Primary Zip Code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct zip_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.mlsa_zip_cd_hist_inbnd where zip_cd in (select distinct a.mbr_prmry_zip_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='mbr_prmry_zip_cd' and b.err_cd='306')")
       val data = Array("'Primary Zip Code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Member Primary Zip column values not located in reference table - 018") {

     val id = Array("018")
     val name = Array("Test case : Check Error code when Member Primary Zip column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct zip_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_in.mlsa_zip_cd_hist_inbnd""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('mbr_prmry_zip_cd') and a.mbr_prmry_zip_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('mbr_prmry_zip_cd') and a.mbr_prmry_zip_cd NOT IN (select distinct zip_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.mlsa_zip_cd_hist_inbnd)")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('mbr_prmry_zip_cd') and a.mbr_prmry_zip_cd NOT IN (select distinct zip_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.mlsa_zip_cd_hist_inbnd)")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  /* test("Member Demo Error-Check Member Secondary Zip Codecolumn values not located in reference table - 019") {

     val id = Array("019")
     val name = Array("Test case : Check Member Secondary Zip Codecolumn values not located in reference table")


    val result1 = sqlContext.sql("""select distinct mbr_scndry_zip_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP""")

    val result2 = sqlContext.sql("""select distinct a.mbr_scndry_zip_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='mbr_prmry_zip_cd' and b.err_cd='306'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }*/
  
  //============================================================

  test("Member Demo Error-Check Demographic Member Confidentiality Code column values not located in reference table - 020") {

     val id = Array("020")
     val name = Array("Test case : Check Demographic Member Confidentiality Code column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct mbr_cnfdntlty_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_mbr_cnfdntlty_cd_inbnd""")

    val result2 = sqlContext.sql("""select distinct a.dmgrphc_mbr_cnfdntlty_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='dmgrphc_mbr_cnfdntlty_cd' and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_mbr_cnfdntlty_cd_inbnd where mbr_cnfdntlty_cd in (select distinct a.dmgrphc_mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='dmgrphc_mbr_cnfdntlty_cd' and b.err_cd='306')")
       val data = Array("'dmgrphc_mbr_cnfdntlty_cd': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_mbr_cnfdntlty_cd_inbnd where mbr_cnfdntlty_cd in (select distinct a.dmgrphc_mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='dmgrphc_mbr_cnfdntlty_cd' and b.err_cd='306')")
       val data = Array("'dmgrphc_mbr_cnfdntlty_cd'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when dmgrphc_mbr_cnfdntlty_cd column values not located in reference table - 021") {

     val id = Array("021")
     val name = Array("Test case : Check Error code when dmgrphc_mbr_cnfdntlty_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct mbr_cnfdntlty_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_mbr_cnfdntlty_cd_inbnd""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('dmgrphc_mbr_cnfdntlty_cd') and a.dmgrphc_mbr_cnfdntlty_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id  where b.clmn_nm=UPPER('dmgrphc_mbr_cnfdntlty_cd') and a.dmgrphc_mbr_cnfdntlty_cd NOT IN (select distinct mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_mbr_cnfdntlty_cd_inbnd)")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id  where b.clmn_nm=UPPER('dmgrphc_mbr_cnfdntlty_cd') and a.dmgrphc_mbr_cnfdntlty_cd NOT IN (select distinct mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_mbr_cnfdntlty_cd_inbnd)")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check  Out-of-Area (OOA) Member Code column values not located in reference table - 022") {

     val id = Array("022")
     val name = Array("Test case : Check  Out-of-Area (OOA) Member Code column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct mbr_ooa_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_ooa_cd_inbnd""")

    val result2 = sqlContext.sql("""select distinct a.ooa_mbr_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='ooa_mbr_cd' and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct mbr_ooa_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_ooa_cd_inbnd where mbr_ooa_cd in (select distinct a.ooa_mbr_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='ooa_mbr_cd' and b.err_cd='306')")
       val data = Array("'Out-of-Area (OOA) Member Code': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct mbr_ooa_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_ooa_cd_inbnd where mbr_ooa_cd in (select distinct a.ooa_mbr_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_DMGRPHC_ERR' and b.clmn_nm='ooa_mbr_cd' and b.err_cd='306')")
       val data = Array("'Out-of-Area (OOA) Member Code'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when OOA column values not located in reference table - 023") {

     val id = Array("023")
     val name = Array("Test case : Check Error code when OOA column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct mbr_ooa_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_ooa_cd_inbnd""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('ooa_mbr_cd') and a.ooa_mbr_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('ooa_mbr_cd') and a.ooa_mbr_cd NOT IN (select distinct mbr_ooa_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_ooa_cd_inbnd)")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('ooa_mbr_cd') and a.ooa_mbr_cd NOT IN (select distinct mbr_ooa_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_ooa_cd_inbnd)")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }

  //============================================================

  test("Member Demo Error-Check Error code when bhi_home_plan_id column has spaces - 024") {

     val id = Array("024")
     val name = Array("Test case : Check Error code when bhi_home_plan_id column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when CNSSTNT_MBR_ID column has spaces - 025") {

     val id = Array("025")
     val name = Array("Test case : Check Error code when CNSSTNT_MBR_ID column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.cnsstnt_mbr_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.cnsstnt_mbr_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.cnsstnt_mbr_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when mbr_prfx_txt column has spaces - 026") {

     val id = Array("026")
     val name = Array("Test case : Check Error code when mbr_prfx_txt column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_prfx_txt, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prfx_txt, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prfx_txt, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  test("Member Demo Error-Check Error code when Member Last Name column has spaces - 027") {

     val id = Array("027")
     val name = Array("Test case : Check Error code when Member Last Name column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_last_nm, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_last_nm, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_last_nm, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Member First Name column has spaces - 028") {

     val id = Array("028")
     val name = Array("Test case : Check Error code when Member First Name column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_frst_nm, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_frst_nm, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_frst_nm, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Member Primary Street Address 1 column has spaces - 029") {

     val id = Array("029")
     val name = Array("Test case : Check Error code when Member Primary Street Address 1 column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_prmry_str_adrs_1_txt, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prmry_str_adrs_1_txt, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prmry_str_adrs_1_txt, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Member Primary City column has spaces - 030") {

     val id = Array("030")
     val name = Array("Test case : Check Error code when Member Primary City column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_prmry_city_nm, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prmry_city_nm, ''),' ', ''))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prmry_city_nm, ''),' ', ''))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Member Primary State column has spaces - 031") {

     val id = Array("031")
     val name = Array("Test case : Check Error code when Member Primary State column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_prmry_st_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prmry_st_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prmry_st_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Member Primary Zip Code column has spaces - 032") {

     val id = Array("032")
     val name = Array("Test case : Check Error code when Member Primary Zip Code column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_prmry_zip_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prmry_zip_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prmry_zip_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Member Primary Zip Code + 4 column has spaces - 033") {

     val id = Array("033")
     val name = Array("Test case : Check Error code when Member Primary Zip Code + 4 column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_prmry_zip_plus4_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prmry_zip_plus4_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prmry_zip_plus4_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Member Primary Phone Number column has spaces - 034") {

     val id = Array("034")
     val name = Array("Test case : Check Error code when Member Primary Phone Number column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_prmry_phone_nbr, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prmry_phone_nbr, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_prmry_phone_nbr, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Member Secondary State column has spaces - 035") {

     val id = Array("035")
     val name = Array("Test case : Check Error code when Member Secondary State column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_scndry_st_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_scndry_st_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_scndry_st_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Host Plan Override column has spaces - 036") {

     val id = Array("036")
     val name = Array("Test case : Check Error code when Host Plan Override column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.host_plan_ovrd_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.host_plan_ovrd_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.host_plan_ovrd_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Member Participation Code column has spaces - 037") {

     val id = Array("037")
     val name = Array("Test case : Check Error code when Member Participation Code column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_parn_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_parn_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_parn_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when ITS Subscriber ID column has spaces - 038") {

     val id = Array("038")
     val name = Array("Test case : Check Error code when ITS Subscriber ID column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.its_sbscrbr_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.its_sbscrbr_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.its_sbscrbr_id, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Demographic Member Confidentiality Code column has spaces - 039") {

     val id = Array("039")
     val name = Array("Test case : Check Error code when Demographic Member Confidentiality Code column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.dmgrphc_mbr_cnfdntlty_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.dmgrphc_mbr_cnfdntlty_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.dmgrphc_mbr_cnfdntlty_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Demo Error-Check Error code when Out-of-Area (OOA) Member Code column has spaces - 040") {

     val id = Array("040")
     val name = Array("Test case : Check Error code when Out-of-Area (OOA) Member Code column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.ooa_mbr_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.ooa_mbr_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode': No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_DMGRPHC_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.ooa_mbr_cd, ''),' ', '')))=0")
       val data = Array("'ErrorCode'")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/MemberDemographic/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }

}