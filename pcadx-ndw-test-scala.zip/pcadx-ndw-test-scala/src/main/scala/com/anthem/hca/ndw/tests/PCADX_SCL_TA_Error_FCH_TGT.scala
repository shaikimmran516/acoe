package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Error_FCH_TGT {
 
  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Error_FCH_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}


 class PCADX_SCL_TA_Error_FCH_TGT(dbname : String, env: String) extends FunSuite{

     val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())
     
     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Error"
      val prcss = "FacilityHeader"

  test("Facility Header Error-Check bhi_home_plan_id column values not located in reference table - 001") {

     val id = Array("001")
     val name = Array("Test case : Check bhi_home_plan_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result2 = sqlContext.sql("""select distinct a.bhi_home_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bhi_home_plan_id') and b.err_cd='306'""")

    val result = result1.intersect(result2)
    
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') where bhi_home_plan_id in (select distinct a.bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') where bhi_home_plan_id in (select distinct a.bhi_home_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check Error code when bhi_home_plan_id column values not located in reference table - 002") {

    val id = Array("002")
     val name = Array("Test case : Check Error code when bhi_home_plan_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check trcblty_fld_cd column values not located in reference table - 003") {

     val id = Array("003")
     val name = Array("Test case : Check trcblty_fld_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,sor_cd) as trcblty_fld_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT""")

    val result2 = sqlContext.sql("""select distinct concat(a.bhi_home_plan_id,a.trcblty_fld_cd) as trcblty_fld_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('trcblty_fld_cd') and b.err_cd='306'""")
        
    val result = result1.intersect(result2)

    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,sor_cd) as trcblty_fld_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT where concat(bhi_home_plan_id,sor_cd) in (select distinct concat(a.bhi_home_plan_id,a.trcblty_fld_cd) as trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('trcblty_fld_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,sor_cd) as trcblty_fld_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT where concat(bhi_home_plan_id,sor_cd) in (select distinct concat(a.bhi_home_plan_id,a.trcblty_fld_cd) as trcblty_fld_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('trcblty_fld_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check host_plan_id column values not located in reference table - 004") {

     val id = Array("004")
     val name = Array("Test case : Check host_plan_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct host_plan_id_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOST_PLAN_ID_INBND""")

    val result2 = sqlContext.sql("""select distinct a.host_plan_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('host_plan_id') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct host_plan_id_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOST_PLAN_ID_INBND where host_plan_id_cd in (select distinct a.host_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('host_plan_id') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct host_plan_id_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOST_PLAN_ID_INBND where host_plan_id_cd in (select distinct a.host_plan_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('host_plan_id') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check Error code when host_plan_id column values not located in reference table - 005") {

    val id = Array("005")
     val name = Array("Test case : Check Error code when host_plan_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct host_plan_id_cd from """+dbname+"""_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOST_PLAN_ID_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('host_plan_id') and a.host_plan_id NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('host_plan_id') and a.host_plan_id NOT IN (select distinct host_plan_id_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOST_PLAN_ID_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('host_plan_id') and a.host_plan_id NOT IN (select distinct host_plan_id_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_in.RFRNC_BCBSA_HOST_PLAN_ID_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check acct_nbr column values not located in reference table - 006") {

    val id = Array("006")
     val name = Array("Test case : Check acct_nbr column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,home_plan_prod_id,acct_id,group,sub_group) as acct_id from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT""")

    val result2 = sqlContext.sql("""select distinct concat(a.home_plan_cd,a.home_plan_prod_id,a.acct_nbr,a.grp_nm,a.subgrp_nm) as acct_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id 
        where b.clmn_nm=UPPER('acct_nbr') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,home_plan_prod_id,acct_id,group,sub_group) as acct_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT where concat(bhi_home_plan_id,home_plan_prod_id,acct_id,group,sub_group) in (select distinct concat(a.home_plan_cd,a.home_plan_prod_id,a.acct_nbr,a.grp_nm,a.subgrp_nm) as acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id  where b.clmn_nm=UPPER('acct_nbr') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,home_plan_prod_id,acct_id,group,sub_group) as acct_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT where concat(bhi_home_plan_id,home_plan_prod_id,acct_id,group,sub_group) in (select distinct concat(a.home_plan_cd,a.home_plan_prod_id,a.acct_nbr,a.grp_nm,a.subgrp_nm) as acct_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id  where b.clmn_nm=UPPER('acct_nbr') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check mbr_id column values not located in reference table - 007") {

     val id = Array("007")
     val name = Array("Test case : Check mbr_id column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,home_plan_prod_id,mbr_id) as mbr_id from """+dbname+"""_pCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP""")

    val result2 = sqlContext.sql("""select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id,a.mbr_id) as mbr_id from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('mbr_id') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,home_plan_prod_id,mbr_id) as mbr_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP where concat(bhi_home_plan_id,home_plan_prod_id,mbr_id) in (select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id,a.mbr_id) as mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('mbr_id') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,home_plan_prod_id,mbr_id) as mbr_id from '''+dbname+'''_pCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP where concat(bhi_home_plan_id,home_plan_prod_id,mbr_id) in (select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id,a.mbr_id) as mbr_id from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('mbr_id') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //===========================================================

  test("Facility Header Error-Check clm_mbr_zip_cd column values not located in reference table - 008") {

    val id = Array("008")
     val name = Array("Test case : Check clm_mbr_zip_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct zip_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ZIP_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.clm_mbr_zip_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('clm_mbr_zip_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct zip_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ZIP_CD_INBND where zip_cd in (select distinct a.clm_mbr_zip_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_zip_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct zip_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ZIP_CD_INBND where zip_cd in (select distinct a.clm_mbr_zip_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_zip_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check Error code when clm_mbr_zip_cd column values not located in reference table - 009") {

     val id = Array("009")
     val name = Array("Test case : Check Error code when clm_mbr_zip_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct zip_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ZIP_CD_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('clm_mbr_zip_cd') and a.clm_mbr_zip_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_zip_cd') and a.clm_mbr_zip_cd NOT IN (select distinct zip_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ZIP_CD_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_zip_cd') and a.clm_mbr_zip_cd NOT IN (select distinct zip_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ZIP_CD_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check clm_mbr_cntry_cd column values not located in reference table - 010") {

     val id = Array("010")
     val name = Array("Test case : Check clm_mbr_cntry_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct cntry_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRY_INBND""")

    val result2 = sqlContext.sql("""select distinct a.clm_mbr_cntry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('clm_mbr_cntry_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct cntry_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRY_INBND where cntry_cd in (select distinct a.clm_mbr_cntry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_cntry_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct cntry_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRY_INBND where cntry_cd in (select distinct a.clm_mbr_cntry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_cntry_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check Error code when clm_mbr_cntry_cd column values not located in reference table - 011") {

     val id = Array("011")
     val name = Array("Test case : Check Error code when clm_mbr_cntry_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct cntry_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRY_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('clm_mbr_cntry_cd') and a.clm_mbr_cntry_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_cntry_cd') and a.clm_mbr_cntry_cd NOT IN (select distinct cntry_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRY_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_mbr_cntry_cd') and a.clm_mbr_cntry_cd NOT IN (select distinct cntry_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CNTRY_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check prncpal_icd9_diag_cd column values not located in reference table - 012") {

     val id = Array("012")
     val name = Array("Test case : Check prncpal_icd9_diag_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct diag_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_DIAG_INBND""")

    val result2 = sqlContext.sql("""select distinct a.prncpal_icd9_diag_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('prncpal_icd9_diag_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct diag_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_DIAG_INBND where diag_cd in (select distinct a.prncpal_icd9_diag_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('prncpal_icd9_diag_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct diag_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_DIAG_INBND where diag_cd in (select distinct a.prncpal_icd9_diag_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('prncpal_icd9_diag_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check Error code when prncpal_icd9_diag_cd column values not located in reference table - 013") {

     val id = Array("013")
     val name = Array("Test case : Check Error code when prncpal_icd9_diag_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct diag_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_DIAG_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('prncpal_icd9_diag_cd') and a.prncpal_icd9_diag_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('prncpal_icd9_diag_cd') and a.prncpal_icd9_diag_cd NOT IN (select distinct diag_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_DIAG_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('prncpal_icd9_diag_cd') and a.prncpal_icd9_diag_cd NOT IN (select distinct diag_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_DIAG_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check prncpal_icd10_diag_cd column values not located in reference table - 014") {

     val id = Array("014")
     val name = Array("Test case : Check prncpal_icd10_diag_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct icd_10_diag_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ICD_10_DIAG_INBND""")

    val result2 = sqlContext.sql("""select distinct a.prncpal_icd10_diag_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('prncpal_icd10_diag_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct icd_10_diag_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ICD_10_DIAG_INBND where icd_10_diag_cd in (select distinct a.prncpal_icd10_diag_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('prncpal_icd10_diag_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct icd_10_diag_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ICD_10_DIAG_INBND where icd_10_diag_cd in (select distinct a.prncpal_icd10_diag_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('prncpal_icd10_diag_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check Error code when prncpal_icd10_diag_cd column values not located in reference table - 015") {

     val id = Array("015")
     val name = Array("Test case : Check Error code when prncpal_icd10_diag_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct icd_10_diag_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ICD_10_DIAG_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('prncpal_icd10_diag_cd') and a.prncpal_icd10_diag_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('prncpal_icd10_diag_cd') and a.prncpal_icd10_diag_cd NOT IN (select distinct icd_10_diag_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ICD_10_DIAG_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('prncpal_icd10_diag_cd') and a.prncpal_icd10_diag_cd NOT IN (select distinct icd_10_diag_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_ICD_10_DIAG_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check bnft_paymnt_stts_cd column values not located in reference table - 016") {

     val id = Array("016")
     val name = Array("Test case : Check bnft_paymnt_stts_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bnft_paymnt_stts_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd""")

    val result2 = sqlContext.sql("""select distinct a.bnft_paymnt_stts_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bnft_paymnt_stts_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct bnft_paymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd where bnft_paymnt_stts_cd in (select distinct a.bnft_paymnt_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('bnft_paymnt_stts_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct bnft_paymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd where bnft_paymnt_stts_cd in (select distinct a.bnft_paymnt_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('bnft_paymnt_stts_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check Error code when bnft_paymnt_stts_cd column values not located in reference table - 017") {

     val id = Array("017")
     val name = Array("Test case : Check Error code when bnft_paymnt_stts_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct bnft_paymnt_stts_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bnft_paymnt_stts_cd') and a.bnft_paymnt_stts_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bnft_paymnt_stts_cd') and a.bnft_paymnt_stts_cd NOT IN (select distinct bnft_paymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('bnft_paymnt_stts_cd') and a.bnft_paymnt_stts_cd NOT IN (select distinct bnft_paymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_bnft_paymnt_stts_inbnd)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check srvc_ctgry_cd column values not located in reference table - 018") {

     val id = Array("018")
     val name = Array("Test case : Check srvc_ctgry_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct ctgry_of_srvc_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CTGRY_OF_SRVC_INBND""")

    val result2 = sqlContext.sql("""select distinct a.srvc_ctgry_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('srvc_ctgry_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct ctgry_of_srvc_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CTGRY_OF_SRVC_INBND where ctgry_of_srvc_cd in (select distinct a.srvc_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('srvc_ctgry_cd') and b.err_cd='306)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct ctgry_of_srvc_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CTGRY_OF_SRVC_INBND where ctgry_of_srvc_cd in (select distinct a.srvc_ctgry_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('srvc_ctgry_cd') and b.err_cd='306)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check Error code when srvc_ctgry_cd column values not located in reference table - 019") {

     val id = Array("019")
     val name = Array("Test case : Check Error code when srvc_ctgry_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct ctgry_of_srvc_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CTGRY_OF_SRVC_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('srvc_ctgry_cd') and a.srvc_ctgry_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('srvc_ctgry_cd') and a.srvc_ctgry_cd NOT IN (select distinct ctgry_of_srvc_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CTGRY_OF_SRVC_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('srvc_ctgry_cd') and a.srvc_ctgry_cd NOT IN (select distinct ctgry_of_srvc_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CTGRY_OF_SRVC_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check clm_paymnt_stts_cd column values not located in reference table - 020") {

     val id = Array("020")
     val name = Array("Test case : Check clm_paymnt_stts_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct clm_paymnt_stts_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CLM_PaYMNT_STTS_INBND""")

    val result2 = sqlContext.sql("""select distinct a.clm_paymnt_stts_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('clm_paymnt_stts_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct clm_paymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CLM_PAYMNT_STTS_INBND where clm_paymnt_stts_cd in (select distinct a.clm_paymnt_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_paymnt_stts_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct clm_paymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CLM_PAYMNT_STTS_INBND where clm_paymnt_stts_cd in (select distinct a.clm_paymnt_stts_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_paymnt_stts_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check Error code when clm_paymnt_stts_cd column values not located in reference table - 021") {

    val id = Array("021")
     val name = Array("Test case : Check Error code when clm_paymnt_stts_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct clm_paymnt_stts_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CLM_PAYMNT_STTS_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('clm_paymnt_stts_cd') and a.clm_paymnt_stts_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_paymnt_stts_cd') and a.clm_paymnt_stts_cd NOT IN (select distinct clm_paymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CLM_PAYMNT_STTS_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('clm_paymnt_stts_cd') and a.clm_paymnt_stts_cd NOT IN (select distinct clm_paymnt_stts_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_CLM_PAYMNT_STTS_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check non_cvrd_rsn_cd_1 column values not located in reference table - 022") {

     val id = Array("022")
     val name = Array("Test case : Check non_cvrd_rsn_cd_1 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.non_cvrd_rsn_cd_1 from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.non_cvrd_rsn_cd_1 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id  where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.non_cvrd_rsn_cd_1 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id  where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check Error code when non_cvrd_rsn_cd_1 column values not located in reference table - 023") {

     val id = Array("023")
     val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_1 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_1 NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_1 NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_1 NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check non_cvrd_rsn_cd_2 column values not located in reference table - 024") {

     val id = Array("024")
     val name = Array("Test case : Check non_cvrd_rsn_cd_2 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.non_cvrd_rsn_cd_2 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.non_cvrd_rsn_cd_2 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.non_cvrd_rsn_cd_2 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check Error code when non_cvrd_rsn_cd_2 column values not located in reference table - 025") {

     val id = Array("025")
     val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_2 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_2 NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_2 NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_2 NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check non_cvrd_rsn_cd_3 column values not located in reference table - 026") {

    val id = Array("026")
     val name = Array("Test case : Check non_cvrd_rsn_cd_3 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.non_cvrd_rsn_cd_3 from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.non_cvrd_rsn_cd_3 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check Error code when non_cvrd_rsn_cd_3 column values not located in reference table- 027") {

     val id = Array("027")
     val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_3 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_3 NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_3 NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_3 NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check non_cvrd_rsn_cd_4 column values not located in reference table - 028") {

     val id = Array("028")
     val name = Array("Test case : Check non_cvrd_rsn_cd_4 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.non_cvrd_rsn_cd_4 from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.non_cvrd_rsn_cd_4 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND where non_cvrd_rsn_cd in (select distinct a.non_cvrd_rsn_cd_4 from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check Error code when non_cvrd_rsn_cd_4 column values not located in reference table - 029") {

    val id = Array("029")
     val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_4 column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct non_cvrd_rsn_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_4 NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_4 NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and a.non_cvrd_rsn_cd_4 NOT IN (select distinct non_cvrd_rsn_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.RFRNC_BCBSA_NON_CVRD_RSN_CD_INBND)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check plos_cd column values not located in reference table - 030") {

     val id = Array("030")
     val name = Array("Test case : Check plos_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct place_of_srvc_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_place_of_srvc_inbnd""")

    val result2 = sqlContext.sql("""select distinct a.plos_cd from """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join
        """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id
        where b.clmn_nm=UPPER('plos_cd') and b.err_cd='306'""")

    val result = result1.intersect(result2)
        
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct place_of_srvc_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_place_of_srvc_inbnd where place_of_srvc_cd in (select distinct a.plos_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('plos_cd') and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct place_of_srvc_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_place_of_srvc_inbnd where place_of_srvc_cd in (select distinct a.plos_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a join '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id where b.clmn_nm=UPPER('plos_cd') and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error-Check Error code when plos_cd column values not located in reference table -  031") {

     val id = Array("031")
     val name = Array("Test case : Check Error code when plos_cd column values not located in reference table")

    val result1 = sqlContext.sql("""select distinct place_of_srvc_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_place_of_srvc_inbnd""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('plos_cd') and a.plos_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('plos_cd') and a.plos_cd NOT IN (select distinct place_of_srvc_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_place_of_srvc_inbnd)")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err a on a.err_id=b.err_id where b.clmn_nm=UPPER('plos_cd') and a.plos_cd NOT IN (select distinct place_of_srvc_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_in.rfrnc_bcbsa_place_of_srvc_inbnd)")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }

  //============================================================

  test("Facility Header Error-Check Error code when adjstmnt_sqnc_nbr not in correct nu-meric format - 032") {

    val id = Array("032")
     val name = Array("Test case : Check Error code when adjstmnt_sqnc_nbr not in correct nu-meric format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('adjstmnt_sqnc_nbr') and b.adjstmnt_sqnc_nbr rlike '[^0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("310") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('adjstmnt_sqnc_nbr') and b.adjstmnt_sqnc_nbr rlike '[^0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('adjstmnt_sqnc_nbr') and b.adjstmnt_sqnc_nbr rlike '[^0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check Error code when srvc_ctgry_cd is equal to 'IP PROF','OP PROF','IP OTH-ER','OP OTH-ER','PHARM' - 033") {

     val id = Array("033")
     val name = Array("Test case : Check Error code when srvc_ctgry_cd is equal to 'IP PROF','OP PROF','IP OTH-ER','OP OTH-ER','PHARM'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('srvc_ctgry_cd') and b.srvc_ctgry_cd IN ('IP PROF','OP PROF','IP OTH-ER','OP OTH-ER','PHARM')""")

    if (result.count == 0 || (result.collectAsList.toString.contains("305") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('srvc_ctgry_cd') and b.srvc_ctgry_cd IN ('IP PROF','OP PROF','IP OTH-ER','OP OTH-ER','PHARM')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('srvc_ctgry_cd') and b.srvc_ctgry_cd IN ('IP PROF','OP PROF','IP OTH-ER','OP OTH-ER','PHARM')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check Error code when non_cvrd_rsn_cd_1 is not equal to '00','70','D' - 034") {

   val id = Array("034")
     val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_1 is not equal to '00','70','D'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and  b.non_cvrd_rsn_cd_1 NOT IN ('00','70','D')""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and  b.non_cvrd_rsn_cd_1 NOT IN ('00','70','D')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and  b.non_cvrd_rsn_cd_1 NOT IN ('00','70','D')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error-Check Error code when non_cvrd_rsn_cd_2 is not equal to '00','70','D' - 035") {

    val id = Array("035")
     val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_2 is not equal to '00','70','D'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and  b.non_cvrd_rsn_cd_2 NOT IN ('00','70','D') and a.clmn_nm='NON_CVRD_RSN_CD_1,NON_CVRD_RSN_CD_2,NON_CVRD_RSN_CD_3,NON_CVRD_RSN_CD_4'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and  b.non_cvrd_rsn_cd_2 NOT IN ('00','70','D') and a.clmn_nm='NON_CVRD_RSN_CD_1,NON_CVRD_RSN_CD_2,NON_CVRD_RSN_CD_3,NON_CVRD_RSN_CD_4'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and  b.non_cvrd_rsn_cd_2 NOT IN ('00','70','D') and a.clmn_nm='NON_CVRD_RSN_CD_1,NON_CVRD_RSN_CD_2,NON_CVRD_RSN_CD_3,NON_CVRD_RSN_CD_4'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
   test("Facility Header Error-Check Error code when non_cvrd_rsn_cd_3 is not equal to '00','70','D' - 036") {

    val id = Array("036")
     val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_3 is not equal to '00','70','D'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and  b.non_cvrd_rsn_cd_3 NOT IN ('00','70','D') and a.clmn_nm='NON_CVRD_RSN_CD_1,NON_CVRD_RSN_CD_2,NON_CVRD_RSN_CD_3,NON_CVRD_RSN_CD_4'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and  b.non_cvrd_rsn_cd_3 NOT IN ('00','70','D') and a.clmn_nm='NON_CVRD_RSN_CD_1,NON_CVRD_RSN_CD_2,NON_CVRD_RSN_CD_3,NON_CVRD_RSN_CD_4'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and  b.non_cvrd_rsn_cd_3 NOT IN ('00','70','D') and a.clmn_nm='NON_CVRD_RSN_CD_1,NON_CVRD_RSN_CD_2,NON_CVRD_RSN_CD_3,NON_CVRD_RSN_CD_4'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Header Error-Check Error code when non_cvrd_rsn_cd_4 is not equal to '00','70','D' - 037") {

   val id = Array("037")
     val name = Array("Test case : Check Error code when non_cvrd_rsn_cd_4 is not equal to '00','70','D'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and  b.non_cvrd_rsn_cd_4 NOT IN ('00','70','D') and a.clmn_nm='NON_CVRD_RSN_CD_1,NON_CVRD_RSN_CD_2,NON_CVRD_RSN_CD_3,NON_CVRD_RSN_CD_4'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and  b.non_cvrd_rsn_cd_4 NOT IN ('00','70','D') and a.clmn_nm='NON_CVRD_RSN_CD_1,NON_CVRD_RSN_CD_2,NON_CVRD_RSN_CD_3,NON_CVRD_RSN_CD_4'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_rsn_cd_1,non_cvrd_rsn_cd_2,non_cvrd_rsn_cd_3,non_cvrd_rsn_cd_4') and  b.non_cvrd_rsn_cd_4 NOT IN ('00','70','D') and a.clmn_nm='NON_CVRD_RSN_CD_1,NON_CVRD_RSN_CD_2,NON_CVRD_RSN_CD_3,NON_CVRD_RSN_CD_4'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Header Error-Check Error code when frst_srvc_dt not in correct date format - 038") {

    val id = Array("038")
     val name = Array("Test case : Check Error code when frst_srvc_dt not in correct date format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('frst_srvc_dt') and  LENGTH(b.frst_srvc_dt)<>19""")

    if (result.count == 0 || (result.collectAsList.toString.contains("308") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('frst_srvc_dt') and  LENGTH(b.frst_srvc_dt)<>19")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('frst_srvc_dt') and  LENGTH(b.frst_srvc_dt)<>19")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Header Error-Check Error code when last_srvc_dt not in correct date format - 039") {

   val id = Array("039")
     val name = Array("Test case : Check Error code when last_srvc_dt not in correct date format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('last_srvc_dt') and  LENGTH(b.last_srvc_dt)<>19""")

    if (result.count == 0 || (result.collectAsList.toString.contains("308") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('last_srvc_dt') and  LENGTH(b.last_srvc_dt)<>19")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('last_srvc_dt') and  LENGTH(b.last_srvc_dt)<>19")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Header Error-Check Error code when last_srvc_dt < frst_srvc_dt - 040") {

   val id = Array("040")
     val name = Array("Test case : Check Error code when last_srvc_dt < frst_srvc_dt")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('last_srvc_dt') and  b.last_srvc_dt < b.frst_srvc_dt""")

    if (result.count == 0 || (result.collectAsList.toString.contains("309") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('last_srvc_dt') and  b.last_srvc_dt < b.frst_srvc_dt")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('last_srvc_dt') and  b.last_srvc_dt < b.frst_srvc_dt")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Header Error-Check Error code when stmnt_from_dt not in correct date format - 041") {

    val id = Array("041")
     val name = Array("Test case : Check Error code when stmnt_from_dt not in correct date format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('stmnt_from_dt') and  LENGTH(b.stmnt_from_dt)<>19""")

    if (result.count == 0 || (result.collectAsList.toString.contains("308") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('stmnt_from_dt') and  LENGTH(b.stmnt_from_dt)<>19")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('stmnt_from_dt') and  LENGTH(b.stmnt_from_dt)<>19")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Header Error-Check Error code when stmnt_thru_dt not in correct date format - 042") {

   val id = Array("042")
     val name = Array("Test case : Check Error code when stmnt_thru_dt not in correct date format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('stmnt_thru_dt') and  LENGTH(b.stmnt_thru_dt)<>19""")

    if (result.count == 0 || (result.collectAsList.toString.contains("308") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('stmnt_thru_dt') and  LENGTH(b.stmnt_thru_dt)<>19")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('stmnt_thru_dt') and  LENGTH(b.stmnt_thru_dt)<>19")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Header Error-Check Error code when non_cvrd_days_for_paymnt_nbr not in correct nu-meric format - 043") {

    val id = Array("043")
     val name = Array("Test case : Check Error code when non_cvrd_days_for_paymnt_nbr not in correct nu-meric format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_days_for_paymnt_nbr') and  b.non_cvrd_days_for_paymnt_nbr rlike '[^0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("310") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_days_for_paymnt_nbr') and  b.non_cvrd_days_for_paymnt_nbr rlike '[^0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_days_for_paymnt_nbr') and  b.non_cvrd_days_for_paymnt_nbr rlike '[^0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Header Error-Check Error code when sbmtd_amt not in correct decimal format - 044") {

    val id = Array("044")
     val name = Array("Test case : Check Error code when sbmtd_amt not in correct decimal format")
      
    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('sbmtd_amt') and  b.sbmtd_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('sbmtd_amt') and  b.sbmtd_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('sbmtd_amt') and  b.sbmtd_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
    test("Facility Header Error-Check Error code when sbmtd_amt is less than or equal to -0 - 045") {

    val id = Array("045")
     val name = Array("Test case : Check Error code when sbmtd_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('sbmtd_amt') and  b.sbmtd_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('sbmtd_amt') and  b.sbmtd_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('sbmtd_amt') and  b.sbmtd_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
    
    test("Facility Header Error-Check Error code when non_cvrd_amt not in correct decimal format - 046") {

    val id = Array("046")
     val name = Array("Test case : Check Error code when non_cvrd_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_amt') and  b.non_cvrd_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_amt') and  b.non_cvrd_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_amt') and  b.non_cvrd_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
   
  test("Facility Header Error-Check Error code when non_cvrd_amt is less than or equal to -0 - 047") {

     val id = Array("047")
     val name = Array("Test case : Check Error code when non_cvrd_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_amt') and  b.non_cvrd_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_amt') and  b.non_cvrd_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_amt') and  b.non_cvrd_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
   test("Facility Header Error-Check Error code when non_cvrd_amt is equals +0000000000 - 048") {

     val id = Array("048")
     val name = Array("Test case : Check Error code when non_cvrd_amt is equals +0000000000")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('non_cvrd_amt') and  b.non_cvrd_amt = +0000000000""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_amt') and  b.non_cvrd_amt = +0000000000")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('non_cvrd_amt') and  b.non_cvrd_amt = +0000000000")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Header Error-Check Error code when alwd_amt not in correct decimal format - 049") {

    val id = Array("049")
     val name = Array("Test case : Check Error code when alwd_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('alwd_amt') and  b.alwd_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('alwd_amt') and  b.alwd_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('alwd_amt') and  b.alwd_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
  test("Facility Header Error-Check Error code when alwd_amt is less than or equal to -0 - 050") {

    val id = Array("050")
     val name = Array("Test case : Check Error code when alwd_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('alwd_amt') and  b.alwd_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('alwd_amt') and  b.alwd_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('alwd_amt') and  b.alwd_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
  //============================================================
  
   test("Facility Header Error-Check Error code when paymnt_amt not in correct decimal format - 051") {

    val id = Array("051")
     val name = Array("Test case : Check Error code when paymnt_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('paymnt_amt') and  b.paymnt_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('paymnt_amt') and  b.paymnt_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('paymnt_amt') and  b.paymnt_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
    test("Facility Header Error-Check Error code when paymnt_amt is less than or equal to -0 - 052") {

    val id = Array("052")
     val name = Array("Test case : Check Error code when paymnt_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('paymnt_amt') and  b.paymnt_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('paymnt_amt') and  b.paymnt_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('paymnt_amt') and  b.paymnt_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
    
   test("Facility Header Error-Check Error code when cob_tpl_amt not in correct decimal format - 053") {

    val id = Array("053")
     val name = Array("Test case : Check Error code when cob_tpl_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('cob_tpl_amt') and  b.cob_tpl_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('cob_tpl_amt') and  b.cob_tpl_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('cob_tpl_amt') and  b.cob_tpl_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
    test("Facility Header Error-Check Error code when cob_tpl_amt is less than or equal to -0 - 054") {

    val id = Array("054")
     val name = Array("Test case : Check Error code when cob_tpl_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('cob_tpl_amt') and  b.cob_tpl_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('cob_tpl_amt') and  b.cob_tpl_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('cob_tpl_amt') and  b.cob_tpl_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
    
   test("Facility Header Error-Check Error code when coinsrn_amt not in correct decimal format - 055") {

     val id = Array("055")
     val name = Array("Test case : Check Error code when coinsrn_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('coinsrn_amt') and  b.coinsrn_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('coinsrn_amt') and  b.coinsrn_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('coinsrn_amt') and  b.coinsrn_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
  test("Facility Header Error-Check Error code when coinsrn_amt is less than or equal to -0 - 056") {

    val id = Array("056")
     val name = Array("Test case : Check Error code when coinsrn_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('coinsrn_amt') and  b.coinsrn_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('coinsrn_amt') and  b.coinsrn_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('coinsrn_amt') and  b.coinsrn_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
   test("Facility Header Error-Check Error code when cpay_amt not in correct decimal format - 057") {

    val id = Array("057")
     val name = Array("Test case : Check Error code when cpay_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('cpay_amt') and  b.cpay_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('cpay_amt') and  b.cpay_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('cpay_amt') and  b.cpay_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Header Error-Check Error code when cpay_amt is less than or equal to -0 - 058") {

    val id = Array("058")
     val name = Array("Test case : Check Error code when cpay_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('cpay_amt') and  b.cpay_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('cpay_amt') and  b.cpay_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('cpay_amt') and  b.cpay_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
    
    test("Facility Header Error-Check Error code when ddctbl_amt not in correct decimal format - 059") {

     val id = Array("059")
     val name = Array("Test case : Check Error code when ddctbl_amt not in correct decimal format")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('ddctbl_amt') and  b.ddctbl_amt rlike '[a-zA-Z0-9]'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("311") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('ddctbl_amt') and  b.ddctbl_amt rlike '[a-zA-Z0-9]'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('ddctbl_amt') and  b.ddctbl_amt rlike '[a-zA-Z0-9]'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
    //============================================================
    
   test("Facility Header Error-Check Error code when ddctbl_amt is less than or equal to -0 - 060") {

     val id = Array("060")
     val name = Array("Test case : Check Error code when ddctbl_amt is less than or equal to -0")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('ddctbl_amt') and  b.ddctbl_amt <= -0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("312") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('ddctbl_amt') and  b.ddctbl_amt <= -0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('ddctbl_amt') and  b.ddctbl_amt <= -0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
    
    test("Facility Header Error-Check Error code when billg_prov_cntrctg_stts_ind is not equal to 'Y','N','C','P','I','S' - 061") {

     val id = Array("061")
     val name = Array("Test case : Check Error code when billg_prov_cntrctg_stts_ind is not equal to 'Y','N','C','P','I','S'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('billg_prov_cntrctg_stts_ind') and  b.billg_prov_cntrctg_stts_ind NOT IN ('Y','N','C','P','I','S')""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('billg_prov_cntrctg_stts_ind') and  b.billg_prov_cntrctg_stts_ind NOT IN ('Y','N','C','P','I','S')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('billg_prov_cntrctg_stts_ind') and  b.billg_prov_cntrctg_stts_ind NOT IN ('Y','N','C','P','I','S')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
    
    test("Facility Header Error-Check Error code when rndrg_prov_cntrctg_stts_ind is not equal to 'Y','N','C','P','I','S' - 062") {

     val id = Array("062")
     val name = Array("Test case : Check Error code when rndrg_prov_cntrctg_stts_ind is not equal to 'Y','N','C','P','I','S'")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id 
        where a.clmn_nm=UPPER('rndrg_prov_cntrctg_stts_ind') and  b.rndrg_prov_cntrctg_stts_ind NOT IN ('Y','N','C','P','I','S')""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('rndrg_prov_cntrctg_stts_ind') and  b.rndrg_prov_cntrctg_stts_ind NOT IN ('Y','N','C','P','I','S')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id  where a.clmn_nm=UPPER('rndrg_prov_cntrctg_stts_ind') and  b.rndrg_prov_cntrctg_stts_ind NOT IN ('Y','N','C','P','I','S')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }

  //============================================================

  test("Facility Header Error- Check Error code when home_plan_cd column has spaces - 063") {

    val id = Array("063")
     val name = Array("Test case : Check Error code when home_plan_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('bhi_home_plan_id') and length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('bhi_home_plan_id') and length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('bhi_home_plan_id') and length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error- Check Error code when clm_id column has spaces - 064") {

   val id = Array("064")
     val name = Array("Test case : Check Error code when clm_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('clm_id') and length(trim(regexp_replace(coalesce(b.clm_id, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_id') and length(trim(regexp_replace(coalesce(b.clm_id, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_id') and length(trim(regexp_replace(coalesce(b.clm_id, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }

  //============================================================
  
  test("Facility Header Error- Check Error code when trcblty_fld_cd column has spaces - 065") {

    val id = Array("065")
     val name = Array("Test case : Check Error code when trcblty_fld_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('trcblty_fld_cd') and length(trim(regexp_replace(coalesce(b.trcblty_fld_cd, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('trcblty_fld_cd') and length(trim(regexp_replace(coalesce(b.trcblty_fld_cd, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('trcblty_fld_cd') and length(trim(regexp_replace(coalesce(b.trcblty_fld_cd, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when host_plan_id column has spaces - 066") {

    val id = Array("066")
     val name = Array("Test case : Check Error code when host_plan_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('trcblty_fld_cd') and length(trim(regexp_replace(coalesce(b.trcblty_fld_cd, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('trcblty_fld_cd') and length(trim(regexp_replace(coalesce(b.trcblty_fld_cd, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('trcblty_fld_cd') and length(trim(regexp_replace(coalesce(b.trcblty_fld_cd, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when home_plan_prod_id column has spaces - 067") {

    val id = Array("067")
     val name = Array("Test case : Check Error code when home_plan_prod_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('home_plan_prod_id') and length(trim(regexp_replace(coalesce(b.home_plan_prod_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('home_plan_prod_id') and length(trim(regexp_replace(coalesce(b.home_plan_prod_id, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('home_plan_prod_id') and length(trim(regexp_replace(coalesce(b.home_plan_prod_id, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error- Check Error code when acct_nbr column has spaces - 068") {

    val id = Array("068")
     val name = Array("Test case : Check Error code when acct_nbr column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('acct_nbr') and length(trim(regexp_replace(coalesce(b.acct_nbr, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('acct_nbr') and length(trim(regexp_replace(coalesce(b.acct_nbr, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('acct_nbr') and length(trim(regexp_replace(coalesce(b.acct_nbr, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when grp_nm column has spaces - 069") {

    val id = Array("069")
     val name = Array("Test case : Check Error code when grp_nm column has spaces ")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('grp_nm') and length(trim(regexp_replace(coalesce(b.grp_nm, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('grp_nm') and length(trim(regexp_replace(coalesce(b.grp_nm, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('grp_nm') and length(trim(regexp_replace(coalesce(b.grp_nm, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when subgrp_nm column has spaces - 070") {

   val id = Array("070")
     val name = Array("Test case : Check Error code when subgrp_nm column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('subgrp_nm') and length(trim(regexp_replace(coalesce(b.subgrp_nm, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('subgrp_nm') and length(trim(regexp_replace(coalesce(b.subgrp_nm, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('subgrp_nm') and length(trim(regexp_replace(coalesce(b.subgrp_nm, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error- Check Error code when mbr_id column has spaces - 071") {

     val id = Array("071")
     val name = Array("Test case : Check Error code when mbr_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('mbr_id') and length(trim(regexp_replace(coalesce(b.mbr_id, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('mbr_id') and length(trim(regexp_replace(coalesce(b.mbr_id, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('mbr_id') and length(trim(regexp_replace(coalesce(b.mbr_id, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when clm_mbr_cntry_cd column has spaces - 072") {

    val id = Array("072")
     val name = Array("Test case : Check Error code when clm_mbr_cntry_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('clm_mbr_cntry_cd') and length(trim(regexp_replace(coalesce(b.clm_mbr_cntry_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_mbr_cntry_cd') and length(trim(regexp_replace(coalesce(b.clm_mbr_cntry_cd, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_mbr_cntry_cd') and length(trim(regexp_replace(coalesce(b.clm_mbr_cntry_cd, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when billg_prov_id column has spaces - 073") {

    val id = Array("073")
     val name = Array("Test case : Check Error code when billg_prov_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('billg_prov_id') and length(trim(regexp_replace(coalesce(b.billg_prov_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('billg_prov_id') and length(trim(regexp_replace(coalesce(b.billg_prov_id,''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('billg_prov_id') and length(trim(regexp_replace(coalesce(b.billg_prov_id, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when rndrg_prov_id column has spaces - 074") {

     val id = Array("074")
     val name = Array("Test case : Check Error code when rndrg_prov_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('rndrg_prov_id') and length(trim(regexp_replace(coalesce(b.rndrg_prov_id, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('rndrg_prov_id') and length(trim(regexp_replace(coalesce(b.rndrg_prov_id, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('rndrg_prov_id') and length(trim(regexp_replace(coalesce(b.rndrg_prov_id, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when bnft_paymnt_stts_cd column has spaces - 075") {

    val id = Array("075")
     val name = Array("Test case : Check Error code when bnft_paymnt_stts_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('bnft_paymnt_stts_cd') and length(trim(regexp_replace(coalesce(b.bnft_paymnt_stts_cd, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('bnft_paymnt_stts_cd') and length(trim(regexp_replace(coalesce(b.bnft_paymnt_stts_cd, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('bnft_paymnt_stts_cd') and length(trim(regexp_replace(coalesce(b.bnft_paymnt_stts_cd, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when srvc_ctgry_cd column has spaces - 076") {

    val id = Array("076")
     val name = Array("Test case : Check Error code when srvc_ctgry_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('srvc_ctgry_cd') and length(trim(regexp_replace(coalesce(b.srvc_ctgry_cd, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('srvc_ctgry_cd') and length(trim(regexp_replace(coalesce(b.srvc_ctgry_cd, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('srvc_ctgry_cd') and length(trim(regexp_replace(coalesce(b.srvc_ctgry_cd, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when clm_paymnt_stts_cd column has spaces - 077") {

    val id = Array("077")
     val name = Array("Test case : Check Error code when clm_paymnt_stts_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('clm_paymnt_stts_cd') and length(trim(regexp_replace(coalesce(b.clm_paymnt_stts_cd, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_paymnt_stts_cd') and length(trim(regexp_replace(coalesce(b.clm_paymnt_stts_cd, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('clm_paymnt_stts_cd') and length(trim(regexp_replace(coalesce(b.clm_paymnt_stts_cd, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when plos_cd column has spaces - 078") {

    val id = Array("078")
     val name = Array("Test case : Check Error code when plos_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('plos_cd') and length(trim(regexp_replace(coalesce(b.plos_cd, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('plos_cd') and length(trim(regexp_replace(coalesce(b.plos_cd, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('plos_cd') and length(trim(regexp_replace(coalesce(b.plos_cd, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error- Check Error code when sbmtd_amt column has spaces - 079") {

    val id = Array("079")
     val name = Array("Test case : Check Error code when sbmtd_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('sbmtd_amt') and length(trim(regexp_replace(coalesce(b.sbmtd_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('sbmtd_amt') and length(trim(regexp_replace(coalesce(b.sbmtd_amt, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('sbmtd_amt') and length(trim(regexp_replace(coalesce(b.sbmtd_amt, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }

  //============================================================
  
  test("Facility Header Error- Check Error code when non_cvrd_amt column has spaces - 080") {

    val id = Array("080")
     val name = Array("Test case : Check Error code when non_cvrd_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('non_cvrd_amt') and length(trim(regexp_replace(coalesce(b.non_cvrd_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('non_cvrd_amt') and length(trim(regexp_replace(coalesce(b.non_cvrd_amt, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('non_cvrd_amt') and length(trim(regexp_replace(coalesce(b.non_cvrd_amt, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when alwd_amt column has spaces - 081") {

    val id = Array("081")
     val name = Array("Test case : Check Error code when alwd_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('alwd_amt') and length(trim(regexp_replace(coalesce(b.alwd_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('alwd_amt') and length(trim(regexp_replace(coalesce(b.alwd_amt, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('alwd_amt') and length(trim(regexp_replace(coalesce(b.alwd_amt, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when paymnt_amt column has spaces - 082") {

    val id = Array("082")
     val name = Array("Test case : Check Error code when paymnt_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('paymnt_amt') and length(trim(regexp_replace(coalesce(b.paymnt_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('paymnt_amt') and length(trim(regexp_replace(coalesce(b.paymnt_amt, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('paymnt_amt') and length(trim(regexp_replace(coalesce(b.paymnt_amt, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
  
  test("Facility Header Error- Check Error code when cob_tpl_amt column has spaces - 083") {

    val id = Array("083")
     val name = Array("Test case : Check Error code when cob_tpl_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('cob_tpl_amt') and length(trim(regexp_replace(coalesce(b.cob_tpl_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('cob_tpl_amt') and length(trim(regexp_replace(coalesce(b.cob_tpl_amt, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('cob_tpl_amt') and length(trim(regexp_replace(coalesce(b.cob_tpl_amt, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================

  test("Facility Header Error- Check Error code when coinsrn_amt column has spaces - 084") {

    val id = Array("084")
     val name = Array("Test case : Check Error code when coinsrn_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('coinsrn_amt') and length(trim(regexp_replace(coalesce(b.coinsrn_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('coinsrn_amt') and length(trim(regexp_replace(coalesce(b.coinsrn_amt, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('coinsrn_amt') and length(trim(regexp_replace(coalesce(b.coinsrn_amt, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
  
  //============================================================
 
   test("Facility Header Error- Check Error code when cpay_amt column has spaces - 085") {

    val id = Array("085")
     val name = Array("Test case : Check Error code when cpay_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('cpay_amt') and length(trim(regexp_replace(coalesce(b.cpay_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('cpay_amt') and length(trim(regexp_replace(coalesce(b.cpay_amt, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('cpay_amt') and length(trim(regexp_replace(coalesce(b.cpay_amt, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Header Error- Check Error code when ddctbl_amt column has spaces - 086") {

    val id = Array("086")
     val name = Array("Test case : Check Error code when ddctbl_amt column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('ddctbl_amt') and length(trim(regexp_replace(coalesce(b.ddctbl_amt, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('ddctbl_amt') and length(trim(regexp_replace(coalesce(b.ddctbl_amt, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('ddctbl_amt') and length(trim(regexp_replace(coalesce(b.ddctbl_amt, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
   test("Facility Header Error- Check Error code when billg_prov_cntrctg_stts_ind column has spaces - 087") {

    val id = Array("087")
     val name = Array("Test case : Check Error code when billg_prov_cntrctg_stts_ind column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('billg_prov_cntrctg_stts_ind') and length(trim(regexp_replace(coalesce(b.billg_prov_cntrctg_stts_ind, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('billg_prov_cntrctg_stts_ind') and length(trim(regexp_replace(coalesce(b.billg_prov_cntrctg_stts_ind, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('billg_prov_cntrctg_stts_ind') and length(trim(regexp_replace(coalesce(b.billg_prov_cntrctg_stts_ind, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
   
    test("Facility Header Error- Check Error code when rndrg_prov_cntrctg_stts_ind column has spaces - 088") {

    val id = Array("088")
     val name = Array("Test case : Check Error code when rndrg_prov_cntrctg_stts_ind column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('rndrg_prov_cntrctg_stts_ind') and length(trim(regexp_replace(coalesce(b.rndrg_prov_cntrctg_stts_ind, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('rndrg_prov_cntrctg_stts_ind') and length(trim(regexp_replace(coalesce(b.rndrg_prov_cntrctg_stts_ind, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('rndrg_prov_cntrctg_stts_ind') and length(trim(regexp_replace(coalesce(b.rndrg_prov_cntrctg_stts_ind, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
    
    //============================================================
    
   test("Facility Header Error- Check Error code when sccf_id column has spaces - 089") {

    val id = Array("089")
     val name = Array("Test case : Check Error code when sccf_id column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('sccf_id') and length(trim(regexp_replace(coalesce(b.sccf_id, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('sccf_id') and length(trim(regexp_replace(coalesce(b.sccf_id, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('sccf_id') and length(trim(regexp_replace(coalesce(b.sccf_id, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }
   
   //============================================================
     
   test("Facility Header Error- Check Error code when prncpal_icd10_diag_cd column has spaces - 090") {

    val id = Array("090")
     val name = Array("Test case : Check Error code when prncpal_icd10_diag_cd column has spaces")

    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pCANDW1PH_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id
        where a.clmn_nm=UPPER('prncpal_icd10_diag_cd') and length(trim(regexp_replace(coalesce(b.prncpal_icd10_diag_cd, "")," ", "")))=0 """)

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('prncpal_icd10_diag_cd') and length(trim(regexp_replace(coalesce(b.prncpal_icd10_diag_cd, ''),' ', '')))=0 ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)
    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pCANDW1PH_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err b on a.err_id=b.err_id where a.clmn_nm=UPPER('prncpal_icd10_diag_cd') and length(trim(regexp_replace(coalesce(b.prncpal_icd10_diag_cd, ''),' ', '')))=0 ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/FacilityClaimHeader/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)
    }

  }

}