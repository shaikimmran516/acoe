package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession

import org.apache.spark.sql.SparkSession
import java.io.File
import org.apache.spark.sql.DataFrame
import com.anthem.hca.ndw.utils.PCADX_SCL_TA_Utilities._
import java.text.SimpleDateFormat
import org.apache.spark.sql.SaveMode
import java.util.Calendar
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel
import java.util.Date
import java.text.SimpleDateFormat



object PCADX_SCL_TA_L2_FinancialBalancing_TGT {


  
def main(args: Array[String]) {
  


val dbname: String = args(0)
val SUBJ_AREA_NM: String=args(1)
val PRCS_NM: String=args(2)


val appName = "Datapipe from L2 cases for Financial Balancing" // we will make this generic going forward

val warehouseLocation = new File("/user/hive/warehouse").getAbsolutePath
val options = Map("path" -> "/user/hive/warehouse")

val spark = SparkSession
.builder()
.appName(appName)
.config("spark.sql.warehouse.dir", warehouseLocation)
.enableHiveSupport()
.getOrCreate()

spark.conf.set("spark.sql.hive.caseSensitiveInferenceMode","INFER_ONLY")
spark.conf.set("spark.sql.crossJoin.enabled","true")
spark.conf.set("spark.sql.hive.convertMetastoreParquet", "false")

import spark.implicits._
val home_plan_id =spark.sql("select distinct bhi_home_plan_id from "+dbname+"_pcandw1ph_nogbd_r000_wh.bot_bcbsa_plan_sbmsn")
val  home_plan=home_plan_id.select("bhi_home_plan_id").collect().map(_(0)).toList

spark.sql("SELECT SUM(COALESCE(alwd_amt,0))  AS ALLWD,  SUM(COALESCE(SBMTD_AMT,0))  AS SBMTD,  SUM(COALESCE(non_cvrd_amt,0))  AS NON_COV,  SUM(COALESCE(paymnt_amt,0))  AS PMT,bhi_home_plan_id    FROM  (  SELECT alwd_amt, sbmtd_amt, non_cvrd_amt, paymnt_amt,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FH  UNION ALL    SELECT alwd_amt, sbmtd_amt, non_cvrd_amt, paymnt_amt,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs POS ) b  group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("TotalFCHPOSAmounts")

spark.sql("SELECT SUM(COALESCE(alwd_amt,0))  AS ALLWD,  SUM(COALESCE(SBMTD_AMT,0))  AS SBMTD,  SUM(COALESCE(non_cvrd_amt,0))  AS NON_COV,  SUM(COALESCE(paymnt_amt,0))  AS PMT ,bhi_home_plan_id   FROM  (  SELECT alwd_amt, sbmtd_amt, non_cvrd_amt, paymnt_amt  ,bhi_home_plan_id FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err FH  UNION ALL    SELECT alwd_amt, sbmtd_amt, non_cvrd_amt, paymnt_amt,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs_err POS  ) b    group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("ErrorFCHPOSAmounts")

spark.sql("select sum(SBMTD_AMT) SBMTD_AMT,sum(alwd_amt) alwd_amt,sum(non_cvrd_amt) non_cvrd_amt,sum(paymnt_amt) paymnt_amt,BHI_HOME_PLAN_ID,CLM_ID,trcblty_fld_cd from "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl  group by BHI_HOME_PLAN_ID,CLM_ID,trcblty_fld_cd").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("IPOPFD")

spark.sql("select SBMTD_AMT,alwd_amt,non_cvrd_amt,paymnt_amt,BHI_HOME_PLAN_ID,CLM_ID,trcblty_fld_cd,srvc_ctgry_cd from "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  ").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("IPOPFH")

spark.sql("SELECT SUM(COALESCE(alwd_amt,0))  AS ALLWD,  SUM(COALESCE(SBMTD_AMT,0))  AS SBMTD,  SUM(COALESCE(non_cvrd_amt,0))  AS NON_COV,  SUM(COALESCE(paymnt_amt,0))  AS PMT,bhi_home_plan_id    FROM  (  SELECT alwd_amt, sbmtd_amt, non_cvrd_amt, paymnt_amt,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm_err PH ) b  group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("ErrorPharmacyAmounts") 

spark.sql("SELECT SUM(COALESCE(alwd_amt,0))  AS ALLWD,  SUM(COALESCE(SBMTD_AMT,0))  AS SBMTD,  SUM(COALESCE(non_cvrd_amt,0))  AS NON_COV,  SUM(COALESCE(paymnt_amt,0))  AS PMT,bhi_home_plan_id    FROM  (  SELECT alwd_amt, sbmtd_amt, non_cvrd_amt, paymnt_amt,bhi_home_plan_id  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm PH ) b  group by bhi_home_plan_id").persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("TotalPharmacyAmounts") 


// Rule 1-4
home_plan.foreach(bhi_home_plan_id => {
var sqlbshow=(" select a.ALLWD*100/(b.ALLWD) as ALLWD,a.SBMTD*100/(b.SBMTD) as SBMTD,a.NON_COV*100/(b.NON_COV) as NON_COV,a.PMT*100/(b.PMT) as PMT from(SELECT SUM(COALESCE(alwd_amt,0))  AS ALLWD,  SUM(COALESCE(SBMTD_AMT,0))  AS SBMTD,  SUM(COALESCE(non_cvrd_amt,0))  AS NON_COV,  SUM(COALESCE(paymnt_amt,0))  AS PMT    FROM  (  SELECT alwd_amt, sbmtd_amt, non_cvrd_amt, paymnt_amt  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr_err FH where  bhi_home_plan_id='"+bhi_home_plan_id +"'  UNION ALL    SELECT alwd_amt, sbmtd_amt, non_cvrd_amt, paymnt_amt  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs_err POS where   bhi_home_plan_id='"+bhi_home_plan_id +"' ) b   ) a join  (SELECT SUM(COALESCE(alwd_amt,0))  AS ALLWD,  SUM(COALESCE(SBMTD_AMT,0))  AS SBMTD,  SUM(COALESCE(non_cvrd_amt,0))  AS NON_COV,  SUM(COALESCE(paymnt_amt,0))  AS PMT    FROM  (  SELECT alwd_amt, sbmtd_amt, non_cvrd_amt, paymnt_amt  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FH where  bhi_home_plan_id='"+bhi_home_plan_id +"'  UNION ALL    SELECT alwd_amt, sbmtd_amt, non_cvrd_amt, paymnt_amt  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_prfsnl_othr_srvcs POS where   bhi_home_plan_id='"+bhi_home_plan_id +"') b ) b ")

var sqlb=(" select a.ALLWD*100/(b.ALLWD) as ALLWD,a.SBMTD*100/(b.SBMTD) as SBMTD,a.NON_COV*100/(b.NON_COV) as NON_COV,a.PMT*100/(b.PMT) as PMT from( SELECT * from ErrorFCHPOSAmounts where  bhi_home_plan_id='"+bhi_home_plan_id +"'  ) a join  ( SELECT * from TotalFCHPOSAmounts where   bhi_home_plan_id='"+bhi_home_plan_id +"'	) b ")

var b=spark.sql(sqlb).withColumn("sql",lit(sqlbshow))


//Rule 5

var sqlashow=(" select ABS(CAST((SBMTD_FH - SBMTD_FD)/(CAST((CAST(SBMTD_FH AS DECIMAL(23,2)) + CAST(SBMTD_FD AS DECIMAL(23,2))) AS DECIMAL(23,2)) / CAST(CAST(2 AS DECIMAL(10,0)) AS DECIMAL(23,2)))  AS DECIMAL(23,2))*100) as v_SBMTD_FH_FD_IP_OP FROM  (  SELECT  SUM(COALESCE(FH.SBMTD_AMT,0)) As SBMTD_FH ,SUM(COALESCE(FD.SBMTD_AMT,0)) As SBMTD_FD  FROM  "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr FH  left outer JOIN (select sum(SBMTD_AMT) SBMTD_AMT,BHI_HOME_PLAN_ID,CLM_ID,trcblty_fld_cd from "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where  bhi_home_plan_id='"+bhi_home_plan_id +"' group by BHI_HOME_PLAN_ID,CLM_ID,trcblty_fld_cd)  FD ON FH.BHI_HOME_PLAN_ID = FD.BHI_HOME_PLAN_ID  AND FH.CLM_ID = FD.CLM_ID AND FH.trcblty_fld_cd = FD.trcblty_fld_cd where TRIM(FH.srvc_ctgry_cd) IN ('OP FAC','IP ACUTE', 'IP NON-ACUTE') and  FH.bhi_home_plan_id='"+bhi_home_plan_id +"') b  ")

var sqla=(" select ABS(CAST((SBMTD_FH - SBMTD_FD)/(CAST((CAST(SBMTD_FH AS DECIMAL(23,2)) + CAST(SBMTD_FD AS DECIMAL(23,2))) AS DECIMAL(23,2)) / CAST(CAST(2 AS DECIMAL(10,0)) AS DECIMAL(23,2)))  AS DECIMAL(23,2))*100) as v_SBMTD_FH_FD_IP_OP FROM  (  SELECT  SUM(COALESCE(FH.SBMTD_AMT,0)) As SBMTD_FH ,SUM(COALESCE(FD.SBMTD_AMT,0)) As SBMTD_FD  FROM (select * from IPOPFH where  bhi_home_plan_id='"+bhi_home_plan_id +"') FH  left outer JOIN (select * from IPOPFD where  bhi_home_plan_id='"+bhi_home_plan_id +"' )  FD ON FH.BHI_HOME_PLAN_ID = FD.BHI_HOME_PLAN_ID  AND FH.CLM_ID = FD.CLM_ID AND FH.trcblty_fld_cd = FD.trcblty_fld_cd where TRIM(srvc_ctgry_cd) IN ('OP FAC','IP ACUTE', 'IP NON-ACUTE') ) b  ")

var a=spark.sql(sqla).withColumn("sql",lit(sqlashow))



//Rule 6-9

var sqlcshow=(" select ABS(CAST((SBMTD_FH - SBMTD_FD)/(CAST((CAST(SBMTD_FH AS DECIMAL(23,2)) + CAST(SBMTD_FD AS DECIMAL(23,2))) AS DECIMAL(23,2)) / CAST(CAST(2 AS DECIMAL(10,0)) AS DECIMAL(23,2)))  AS DECIMAL(23,2))*100) as v_SBMTD_FH_FD,ABS(CAST((alwd_amt_FH - alwd_amt_FD)/(CAST((CAST(alwd_amt_FH AS DECIMAL(23,2)) + CAST(alwd_amt_FD AS DECIMAL(23,2))) AS DECIMAL(23,2)) / CAST(CAST(2 AS DECIMAL(10,0)) AS DECIMAL(23,2)))  AS DECIMAL(23,2))*100) as v_alwd_amt_FH_FD,ABS(CAST((non_cvrd_amt_FH - non_cvrd_amt_FD)/(CAST((CAST(non_cvrd_amt_FH AS DECIMAL(23,2)) + CAST(non_cvrd_amt_FD AS DECIMAL(23,2))) AS DECIMAL(23,2)) / CAST(CAST(2 AS DECIMAL(10,0)) AS DECIMAL(23,2)))  AS DECIMAL(23,2))*100) as v_non_cvrd_amt_FH_FD,ABS(CAST((paymnt_amt_FH - paymnt_amt_FD)/(CAST((CAST(paymnt_amt_FH AS DECIMAL(23,2)) + CAST(paymnt_amt_FD AS DECIMAL(23,2))) AS DECIMAL(23,2)) / CAST(CAST(2 AS DECIMAL(10,0)) AS DECIMAL(23,2)))  AS DECIMAL(23,2))*100) as v_paymnt_amt_FH_FD FROM  (  SELECT  SUM(COALESCE(FH.SBMTD_AMT,0)) As SBMTD_FH ,SUM(COALESCE(FD.SBMTD_AMT,0)) As SBMTD_FD ,SUM(COALESCE(FH.alwd_amt,0)) As alwd_amt_FH ,SUM(COALESCE(FD.alwd_amt,0)) As alwd_amt_FD,SUM(COALESCE(FH.non_cvrd_amt,0)) As non_cvrd_amt_FH ,SUM(COALESCE(FD.non_cvrd_amt,0)) As non_cvrd_amt_FD,SUM(COALESCE(FH.paymnt_amt,0)) As paymnt_amt_FH ,SUM(COALESCE(FD.paymnt_amt,0)) As paymnt_amt_FD FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_hdr  FH  left outer JOIN (select sum(SBMTD_AMT) SBMTD_AMT,sum(alwd_amt) alwd_amt,sum(non_cvrd_amt) non_cvrd_amt,sum(paymnt_amt) paymnt_amt,BHI_HOME_PLAN_ID,CLM_ID,trcblty_fld_cd from "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_fclty_clm_dtl where  bhi_home_plan_id='"+bhi_home_plan_id +"' group by BHI_HOME_PLAN_ID,CLM_ID,trcblty_fld_cd) FD ON FH.BHI_HOME_PLAN_ID = FD.BHI_HOME_PLAN_ID  AND FH.CLM_ID = FD.CLM_ID AND FH.trcblty_fld_cd = FD.trcblty_fld_cd where TRIM(FH.srvc_ctgry_cd) IN ('OP FAC' ) AND  FH.bhi_home_plan_id='"+bhi_home_plan_id +"') b  ")

var sqlc=(" select ABS(CAST((SBMTD_FH - SBMTD_FD)/(CAST((CAST(SBMTD_FH AS DECIMAL(23,2)) + CAST(SBMTD_FD AS DECIMAL(23,2))) AS DECIMAL(23,2)) / CAST(CAST(2 AS DECIMAL(10,0)) AS DECIMAL(23,2)))  AS DECIMAL(23,2))*100) as v_SBMTD_FH_FD,ABS(CAST((alwd_amt_FH - alwd_amt_FD)/(CAST((CAST(alwd_amt_FH AS DECIMAL(23,2)) + CAST(alwd_amt_FD AS DECIMAL(23,2))) AS DECIMAL(23,2)) / CAST(CAST(2 AS DECIMAL(10,0)) AS DECIMAL(23,2)))  AS DECIMAL(23,2))*100) as v_alwd_amt_FH_FD,ABS(CAST((non_cvrd_amt_FH - non_cvrd_amt_FD)/(CAST((CAST(non_cvrd_amt_FH AS DECIMAL(23,2)) + CAST(non_cvrd_amt_FD AS DECIMAL(23,2))) AS DECIMAL(23,2)) / CAST(CAST(2 AS DECIMAL(10,0)) AS DECIMAL(23,2)))  AS DECIMAL(23,2))*100) as v_non_cvrd_amt_FH_FD,ABS(CAST((paymnt_amt_FH - paymnt_amt_FD)/(CAST((CAST(paymnt_amt_FH AS DECIMAL(23,2)) + CAST(paymnt_amt_FD AS DECIMAL(23,2))) AS DECIMAL(23,2)) / CAST(CAST(2 AS DECIMAL(10,0)) AS DECIMAL(23,2)))  AS DECIMAL(23,2))*100) as v_paymnt_amt_FH_FD FROM  (  SELECT  SUM(COALESCE(FH.SBMTD_AMT,0)) As SBMTD_FH ,SUM(COALESCE(FD.SBMTD_AMT,0)) As SBMTD_FD ,SUM(COALESCE(FH.alwd_amt,0)) As alwd_amt_FH ,SUM(COALESCE(FD.alwd_amt,0)) As alwd_amt_FD,SUM(COALESCE(FH.non_cvrd_amt,0)) As non_cvrd_amt_FH ,SUM(COALESCE(FD.non_cvrd_amt,0)) As non_cvrd_amt_FD,SUM(COALESCE(FH.paymnt_amt,0)) As paymnt_amt_FH ,SUM(COALESCE(FD.paymnt_amt,0)) As paymnt_amt_FD FROM (select * from IPOPFH where  bhi_home_plan_id='"+bhi_home_plan_id +"' )  FH  left outer JOIN (select * from IPOPFD where  bhi_home_plan_id='"+bhi_home_plan_id +"' ) FD ON FH.BHI_HOME_PLAN_ID = FD.BHI_HOME_PLAN_ID  AND FH.CLM_ID = FD.CLM_ID AND FH.trcblty_fld_cd = FD.trcblty_fld_cd where TRIM(srvc_ctgry_cd) IN ('OP FAC' ) ) b  ")

var c=spark.sql(sqlc).withColumn("sql",lit(sqlcshow))

//Rule 10-13

var sqldshow=(" select a.ALLWD*100/(b.ALLWD) as ALLWD_PH,a.SBMTD*100/(b.SBMTD) as SBMTD_PH,CAST(a.NON_COV AS DECIMAL(23,2))*100/(CAST(b.NON_COV AS DECIMAL(23,2))) as NON_COV_PH,a.PMT*100/(b.PMT) as PMT_PH from (SELECT SUM(COALESCE(alwd_amt,0))  AS ALLWD,  SUM(COALESCE(SBMTD_AMT,0))  AS SBMTD,  SUM(COALESCE(non_cvrd_amt,0))  AS NON_COV,  SUM(COALESCE(paymnt_amt,0))  AS PMT    FROM  (  SELECT alwd_amt, sbmtd_amt, non_cvrd_amt, paymnt_amt  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm PH where  bhi_home_plan_id='"+bhi_home_plan_id +"' and EXCLSN_IND=1 ) b  ) a join (SELECT SUM(COALESCE(alwd_amt,0))  AS ALLWD,  SUM(COALESCE(SBMTD_AMT,0))  AS SBMTD,  SUM(COALESCE(non_cvrd_amt,0))  AS NON_COV,  SUM(COALESCE(paymnt_amt,0))  AS PMT    FROM  (  SELECT alwd_amt, sbmtd_amt, non_cvrd_amt, paymnt_amt  FROM "+dbname+"_pcandw1ph_nogbd_r000_ou.bcbsa_phrmcy_clm PH where  bhi_home_plan_id='"+bhi_home_plan_id +"') b  ) b   ")

var sqld=(" select a.ALLWD*100/(b.ALLWD) as ALLWD_PH,a.SBMTD*100/(b.SBMTD) as SBMTD_PH,CAST(a.NON_COV AS DECIMAL(23,2))*100/(CAST(b.NON_COV AS DECIMAL(23,2))) as NON_COV_PH,a.PMT*100/(b.PMT) as PMT_PH from (SELECT * from ErrorPharmacyAmounts where  bhi_home_plan_id='"+bhi_home_plan_id +"'  ) a join (SELECT * from TotalPharmacyAmounts where  bhi_home_plan_id='"+bhi_home_plan_id +"')  b   ")

var d=spark.sql(sqld).withColumn("sql",lit(sqldshow))

var e=output(spark, TestIDGen(spark,ReportOutput(spark,dbname,a).union(ReportOutput(spark,dbname,b)).union(ReportOutput(spark,dbname,c)).union(ReportOutput(spark,dbname,d))),SUBJ_AREA_NM,PRCS_NM, bhi_home_plan_id.toString())

e.write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_RSLT")
//e(1).write.mode("append").insertInto(dbname+"_pcandw1ph_nogbd_r000_wh.AUDT_TA_ERR_THRSHLD_SQL")


})



}
  
  

}