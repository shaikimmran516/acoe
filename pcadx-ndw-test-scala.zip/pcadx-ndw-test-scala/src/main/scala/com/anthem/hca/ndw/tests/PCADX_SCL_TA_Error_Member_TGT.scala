package com.anthem.hca.ndw.tests

//import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import java.io.File
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite
//import org.scalatest.Assertions._
import com.holdenkarau.spark.testing.SharedSparkContext
import com.holdenkarau.spark.testing.RDDComparisons
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.databricks.spark.csv
import java.util.Calendar
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import org.joda.time._

object PCADX_SCL_TA_Error_Member_TGT {

  def main(args: Array[String]) {

    (new PCADX_SCL_TA_Error_Member_TGT(args(0), args(1))).execute(color = true, durations = true, shortstacks = true, stats = true)
  }

}

class PCADX_SCL_TA_Error_Member_TGT(dbname : String, env: String) extends FunSuite  {

	   val now = Calendar.getInstance().getTime()
     val formatter = new SimpleDateFormat("yyyyMMddHHmmss")
     val formatter1 = new SimpleDateFormat("yyyy-MM-dd")
     val currdate = formatter.format(new Date())
     val currdate1 = formatter1.format(new Date())

     val sc = SparkContext.getOrCreate()
     sc.setLogLevel("ERROR")
     val sqlContext = SparkSession.builder().appName("NDW App").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()
     
      import sqlContext.implicits._
      import sqlContext.sql
      
      val subj = "Error"
      val prcss = "Member"

 test("Member Error-Check Error code when Member Date of Birth ex-ceeds CURRENT_DATE - 001") {

     val id = Array("001")
     val name = Array("Test case : Check Error code when Member Date of Birth ex-ceeds CURRENT_DATE")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id
        where mbr_brth_dt > FROM_UNIXTIME(UNIX_TIMESTAMP())""")

    if (result.count == 0 || (result.collectAsList.toString.contains("309") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id where mbr_brth_dt > FROM_UNIXTIME(UNIX_TIMESTAMP())")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id where mbr_brth_dt > FROM_UNIXTIME(UNIX_TIMESTAMP())")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Error-Check Error code when Member Date of Birth not in correct date format - 002") {

     val id = Array("002")
     val name = Array("Test case : Check Error code when Member Date of Birth not in correct date format")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id
        where LENGTH(mbr_brth_dt)<>19""")

    if (result.count == 0 || (result.collectAsList.toString.contains("309") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id where LENGTH(mbr_brth_dt)<>19")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id where LENGTH(mbr_brth_dt)<>19")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Error-Check Error code when Coverage Begin Date not in correct date format - 003") {

     val id = Array("003")
     val name = Array("Test case : Check Error code when Coverage Begin Date not in correct date format")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id
        where LENGTH(cvrg_bgn_dt)<>19""")

    if (result.count == 0 || (result.collectAsList.toString.contains("308") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id where LENGTH(cvrg_bgn_dt)<>19")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id where LENGTH(cvrg_bgn_dt)<>19")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Error-Check Error code when Coverage End Date not in correct date format - 004") {

     val id = Array("004")
     val name = Array("Test case : Check Error code when Coverage End Date not in correct date format")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id
        where LENGTH(cvrg_end_dt)<>19""")

    if (result.count == 0 || (result.collectAsList.toString.contains("412") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id where LENGTH(cvrg_end_dt)<>19")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id where LENGTH(cvrg_end_dt)<>19")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  test("Member Error-Check Error code when Coverage End Date is before Coverage Begin Date - 005") {

     val id = Array("005")
     val name = Array("Test case : Check Error code when Coverage End Date is before Coverage Begin Date")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id
        where cvrg_end_dt < cvrg_bgn_dt""")

    if (result.count == 0 || (result.collectAsList.toString.contains("411") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id where cvrg_end_dt < cvrg_bgn_dt")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id where cvrg_end_dt < cvrg_bgn_dt")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Error-Check Error code when acct_id Length > 14 - 006") {

     val id = Array("006")
     val name = Array("Test case : Check Error code when acct_id Length > 14")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(b.acct_id) > 14""")

    if (result.count == 0 || (result.collectAsList.toString.contains("A201") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(b.acct_id) > 14")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(b.acct_id) > 14")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Error-Check Error code when grp_id Length > 14 - 007") {

      val id = Array("007")
     val name = Array("Test case : Check Error code when grp_id Length > 14")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(b.grp_id) > 14""")

    if (result.count == 0 || (result.collectAsList.toString.contains("A201") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(b.grp_id) > 14")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(b.grp_id) > 14")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Error- Check Error code when phrmcy_bnft_ind does not equal to 'Y' and 'N' - 008") {

     val id = Array("008")
     val name = Array("Test case : Check Error code when phrmcy_bnft_ind does not equal to 'Y' and 'N'")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where trim(b.phrmcy_bnft_ind)<>'Y' and trim(b.phrmcy_bnft_ind)<>'N'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(b.phrmcy_bnft_ind)<>'Y' and trim(b.phrmcy_bnft_ind)<>'N'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(b.phrmcy_bnft_ind)<>'Y' and trim(b.phrmcy_bnft_ind)<>'N'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Error- Check Error code when mh_cd_bnft_ind does not equal to 'Y' and 'N' - 009") {

     val id = Array("009")
     val name = Array("Test case : Check Error code when mh_cd_bnft_ind does not equal to 'Y' and 'N'")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where trim(b.phrmcy_bnft_ind)<>'Y' and trim(b.phrmcy_bnft_ind)<>'N'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where trim(b.phrmcy_bnft_ind)<>'Y' and trim(b.phrmcy_bnft_ind)<>'N'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key  where trim(b.phrmcy_bnft_ind)<>'Y' and trim(b.phrmcy_bnft_ind)<>'N'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Error- Check Error code when mdcl_bnft_ind does not equal to 'Y' and 'N' - 010") {

     val id = Array("010")
     val name = Array("Test case : Check Error code when mdcl_bnft_ind does not equal to 'Y' and 'N'")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where trim(b.phrmcy_bnft_ind)<>'Y' and trim(b.phrmcy_bnft_ind)<>'N'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(b.phrmcy_bnft_ind)<>'Y' and trim(b.phrmcy_bnft_ind)<>'N'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(b.phrmcy_bnft_ind)<>'Y' and trim(b.phrmcy_bnft_ind)<>'N'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  test("Member Error- Check Error code when hosp_bnft_ind does not equal to 'Y' and 'N' - 011") {

     val id = Array("011")
     val name = Array("Test case : Check Error code when hosp_bnft_ind does not equal to 'Y' and 'N' ")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where trim(b.phrmcy_bnft_ind)<>'Y' and trim(b.phrmcy_bnft_ind)<>'N'""")

    if (result.count == 0 || (result.collectAsList.toString.contains("307") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(b.phrmcy_bnft_ind)<>'Y' and trim(b.phrmcy_bnft_ind)<>'N'")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where trim(b.phrmcy_bnft_ind)<>'Y' and trim(b.phrmcy_bnft_ind)<>'N'")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }

  //============================================================

  test("Member Error-Check bhi_home_plan_id column values not located in reference table - 012") {

     val id = Array("012")
     val name = Array("Test case : Check bhi_home_plan_id column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result2 = sqlContext.sql("""select distinct a.bhi_home_plan_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306'""")

    val result = result1.intersect(result2)
    
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') and bhi_home_plan_id in (select distinct a.bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748') and bhi_home_plan_id in (select distinct a.bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='bhi_home_plan_id' and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  test("Member Error-Check Error code when bhi_home_plan_id column values not located in reference table - 013") {

     val id = Array("013")
     val name = Array("Test case : Check Error code when bhi_home_plan_id column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('bhi_home_plan_id') and a.bhi_home_plan_id NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

 /* test("Member Error- Check mbr_curnt_prmry_zip_cd column values not located in reference table - 014") {

     val id = Array("014")
     val name = Array("Test case : Check mbr_curnt_prmry_zip_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct zip_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_ZIP_CD_INBND""")

    val result2 = sqlContext.sql("""select distinct a.mbr_curnt_prmry_zip_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_curnt_prmry_zip_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================
   
  test("Member Error-Transform- Check Error code when mbr_curnt_cntry_cd column values not located in reference table - 015") {

     val id = Array("015")
     val name = Array("Test case : Check Error code when mbr_curnt_cntry_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct cntry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_CNTRY_INBND""")

    val result2 = sqlContext.sql("""select distinct a.mbr_curnt_cntry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_curnt_cntry_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }*/
  
  //============================================================

  test("Member Error- Check mbr_gndr_cd column values not located in reference table - 016") {

     val id = Array("016")
     val name = Array("Test case : Check mbr_gndr_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct gndr_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_GNDR""")

    val result2 = sqlContext.sql("""select distinct a.mbr_gndr_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_gndr_cd' and b.err_cd='306'""")

    val result = result1.intersect(result2)
    
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct gndr_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_GNDR where gndr_cd in (select distinct a.mbr_gndr_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join  '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_gndr_cd' and b.err_cd='306') ")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct gndr_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_GNDR where gndr_cd in (select distinct a.mbr_gndr_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join  '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_gndr_cd' and b.err_cd='306') ")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  test("Member Error-Check Error code when mbr_gndr_cd column values not located in reference table - 017") {

     val id = Array("017")
     val name = Array("Test case : Check Error code when mbr_gndr_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('mbr_gndr_cd') and a.mbr_gndr_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('mbr_gndr_cd') and a.mbr_gndr_cd NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('mbr_gndr_cd') and a.mbr_gndr_cd NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member Error-Check Error code when mbr_cnfdntlty_cd column values not located in reference table - 018") {

     val id = Array("018")
     val name = Array("Test case : Check Error code when mbr_cnfdntlty_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct mbr_cnfdntlty_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_MBR_CNFDNTLTY_CD""")

    val result2 = sqlContext.sql("""select distinct a.mbr_cnfdntlty_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_cnfdntlty_cd' and b.err_cd='306'""")

    val result = result1.intersect(result2)
    
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_MBR_CNFDNTLTY_CD where mbr_cnfdntlty_cd in (select distinct a.mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_cnfdntlty_cd' and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_MBR_CNFDNTLTY_CD where mbr_cnfdntlty_cd in (select distinct a.mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_cnfdntlty_cd' and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
   test("Member Error-Check Error code when mbr_cnfdntlty_cd column values not located in reference table - 019") {

     val id = Array("019")
     val name = Array("Test case : Check Error code when mbr_cnfdntlty_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('mbr_cnfdntlty_cd') and a.mbr_cnfdntlty_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('mbr_cnfdntlty_cd') and a.mbr_cnfdntlty_cd NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
     
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('mbr_cnfdntlty_cd') and a.mbr_cnfdntlty_cd NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
   
   //============================================================

  test("Member Error-Check Error code when acct_id column values not located in reference table - 020") {

     val id = Array("020")
     val name = Array("Test case : Check Error code when acct_id column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,home_plan_prod_id,acct_id,grp_id,subgrp_id) as acct_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_PROD_CLNT_CNTRCT""")

    val result2 = sqlContext.sql("""select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id,a.acct_id,a.grp_id,a.subgrp_id) as acct_id from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='acct_id' and b.err_cd='306'""")

    val result = result1.intersect(result2)
    
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,home_plan_prod_id,acct_id,grp_id,subgrp_id) as acct_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.BCBSA_PROD_CLNT_CNTRCT where acct_id in (select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id,a.acct_id,a.grp_id,a.subgrp_id) as acct_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='acct_id' and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct concat(bhi_home_plan_id,home_plan_prod_id,acct_id,grp_id,subgrp_id) as acct_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.BCBSA_PROD_CLNT_CNTRCT where acct_id in (select distinct concat(a.bhi_home_plan_id,a.home_plan_prod_id,a.acct_id,a.grp_id,a.subgrp_id) as acct_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='acct_id' and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================  
  
  /*test("Member Error- Check mbr_rltnshp_cd column values not located in reference table - 021") {

     val id = Array("021")
     val name = Array("Test case : Check mbr_rltnshp_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct mbr_rltnshp_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_MBR_RLTNSHP_INBND""")

    val result2 = sqlContext.sql("""select distinct a.mbr_rltnshp_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_rltnshp_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================
   
  test("Member Error- Check enrlmnt_elgblty_stts_cd column values not located in reference table - 022") {

     val id = Array("022")
     val name = Array("Test case : Check enrlmnt_elgblty_stts_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct enrlmnt_elgblty_stts_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_ENRLMNT_ELGBLTY_STTS_INBND""")

    val result2 = sqlContext.sql("""select distinct a.enrlmnt_elgblty_stts_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='enrlmnt_elgblty_stts_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }*/
  
  //============================================================
  
  test("Member Error- Check mbr_mdcl_cob_cd column values not located in reference table - 023") {

     val id = Array("023")
     val name = Array("Test case : Check mbr_mdcl_cob_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct mbr_mdcl_cob_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_MBR_MDCL_COB""")

    val result2 = sqlContext.sql("""select distinct a.mbr_mdcl_cob_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_mdcl_cob_cd' and b.err_cd='306'""")

    val result = result1.intersect(result2)
    
   if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct mbr_mdcl_cob_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_MBR_MDCL_COB where mbr_mdcl_cob_cd in (select distinct a.mbr_mdcl_cob_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_mdcl_cob_cd' and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct mbr_mdcl_cob_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_MBR_MDCL_COB where mbr_mdcl_cob_cd in (select distinct a.mbr_mdcl_cob_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_mdcl_cob_cd' and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
   test("Member Error-Check Error code when mbr_mdcl_cob_cd column values not located in reference table - 024") {

     val id = Array("024")
     val name = Array("Test case : Check Error code when mbr_mdcl_cob_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('mbr_mdcl_cob_cd') and a.mbr_mdcl_cob_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('mbr_mdcl_cob_cd') and a.mbr_mdcl_cob_cd NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('mbr_mdcl_cob_cd') and a.mbr_mdcl_cob_cd NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
   
   //============================================================

 /* test("Member Error- Check mbr_phrmcy_cob_cd column values not located in reference table - 025") {

     val id = Array("025")
     val name = Array("Test case : Check mbr_phrmcy_cob_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct mbr_phrmcy_cob_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_MBR_RX_COB_INBND""")

    val result2 = sqlContext.sql("""select distinct a.mbr_phrmcy_cob_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mbr_phrmcy_cob_cd' and b.err_cd='306'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================

  test("Member Error- Check ddctbl_ctgry_cd column values not located in reference table - 026") {

     val id = Array("026")
     val name = Array("Test case : Check ddctbl_ctgry_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct daw_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_DCTBL_CTGRY_INBND""")

    val result2 = sqlContext.sql("""select distinct a.ddctbl_ctgry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='ddctbl_ctgry_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================
   
  test("Member Error-Transform- Check Error code when mh_cd_enrlmnt_bnft_cd column values not located in reference table - 027") {

     val id = Array("027")
     val name = Array("Test case : Check Error code when mh_cd_enrlmnt_bnft_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct prcp_type_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_MH_CD_ENRLMNT_BNFT_XWALK_INBND""")

    val result2 = sqlContext.sql("""select distinct a.mh_cd_enrlmnt_bnft_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='mh_cd_enrlmnt_bnft_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }*/
   
   //============================================================

  test("Member Error- Check fclty_bnfts_bhi_ntwk_ctgry_cd column values not located in reference table - 028") {

     val id = Array("028")
     val name = Array("Test case : Check fclty_bnfts_bhi_ntwk_ctgry_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct mbr_cnfdntlty_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_mbr_cnfdntlty_cd""")

    val result2 = sqlContext.sql("""select distinct a.fclty_bnfts_bhi_ntwk_ctgry_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='fclty_bnfts_bhi_ntwk_ctgry_cd' and b.err_cd='306'""")

    val result = result1.intersect(result2)
    
    if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_mbr_cnfdntlty_cd where mbr_cnfdntlty_cd in (select distinct a.fclty_bnfts_bhi_ntwk_ctgry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='fclty_bnfts_bhi_ntwk_ctgry_cd' and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_mbr_cnfdntlty_cd where mbr_cnfdntlty_cd in (select distinct a.fclty_bnfts_bhi_ntwk_ctgry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='fclty_bnfts_bhi_ntwk_ctgry_cd' and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  test("Member Error-Check Error code when fclty_bnfts_bhi_ntwk_ctgry_cd column values not located in reference table - 029") {

     val id = Array("029")
     val name = Array("Test case : Check Error code when fclty_bnfts_bhi_ntwk_ctgry_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('fclty_bnfts_bhi_ntwk_ctgry_cd') and a.fclty_bnfts_bhi_ntwk_ctgry_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id  where b.clmn_nm=UPPER('fclty_bnfts_bhi_ntwk_ctgry_cd') and a.fclty_bnfts_bhi_ntwk_ctgry_cd NOT IN select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
    
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id  where b.clmn_nm=UPPER('fclty_bnfts_bhi_ntwk_ctgry_cd') and a.fclty_bnfts_bhi_ntwk_ctgry_cd NOT IN select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  test("Member Error-Reject- Check Error code when prfsnl_bnfts_bhi_ntwk_ctgry_cd column values not located in reference table - 030") {

     val id = Array("030")
     val name = Array("Test case : Check Error code when prfsnl_bnfts_bhi_ntwk_ctgry_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct mbr_cnfdntlty_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_mbr_cnfdntlty_cd""")

    val result2 = sqlContext.sql("""select distinct a.prfsnl_bnfts_bhi_ntwk_ctgry_cd from """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='prfsnl_bnfts_bhi_ntwk_ctgry_cd' and b.err_cd='306'""")

    val result = result1.intersect(result2)
    
   if (result.count == 0) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select distinct mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_mbr_cnfdntlty_cd where mbr_cnfdntlty_cd in (select distinct a.prfsnl_bnfts_bhi_ntwk_ctgry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='prfsnl_bnfts_bhi_ntwk_ctgry_cd' and b.err_cd='306')")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select distinct mbr_cnfdntlty_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_mbr_cnfdntlty_cd where mbr_cnfdntlty_cd in (select distinct a.prfsnl_bnfts_bhi_ntwk_ctgry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='prfsnl_bnfts_bhi_ntwk_ctgry_cd' and b.err_cd='306')")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  test("Member Error-Check Error code when prfsnl_bnfts_bhi_ntwk_ctgry_cd column values not located in reference table - 031") {

     val id = Array("031")
     val name = Array("Test case : Check Error code when prfsnl_bnfts_bhi_ntwk_ctgry_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct bhi_home_plan_id from """+dbname+"""_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id
     where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748')""")

    val result3 = sqlContext.sql("""select DISTINCT b.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log b join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id
        where b.clmn_nm=UPPER('prfsnl_bnfts_bhi_ntwk_ctgry_cd') and a.prfsnl_bnfts_bhi_ntwk_ctgry_cd NOT IN ("$result1")""")

    if (result3.count == 0 || (result3.collectAsList.toString.contains("306") && result3.count() == 1)) {
       val a = result3.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('prfsnl_bnfts_bhi_ntwk_ctgry_cd') and a.prfsnl_bnfts_bhi_ntwk_ctgry_cd NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result3.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT b.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a on a.err_id=b.err_id where b.clmn_nm=UPPER('prfsnl_bnfts_bhi_ntwk_ctgry_cd') and a.prfsnl_bnfts_bhi_ntwk_ctgry_cd NOT IN (select distinct bhi_home_plan_id from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.rfrnc_bcbsa_bhi_home_plan_id where bhi_home_plan_id in ('040','051','062','102','131','161','182','266','271','254','330','458','425','748'))")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
 /* test("Member Error- Check fclty_bnf'''+dbname+'''_plan_ntwk_ctgry_cd column values not located in reference table - 032") {

     val id = Array("032")
     val name = Array("Test case : Check fclty_bnf'''+dbname+'''_plan_ntwk_ctgry_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,fclty_bnf'''+dbname+'''_plan_ntwk_ctgry_cd) as fclty_bnf'''+dbname+'''_plan_ntwk_ctgry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.bcbsa_prfx_rfrnc""")

    val result2 = sqlContext.sql("""select distinct concat(a.bhi_home_plan_id,a.fclty_bnf'''+dbname+'''_plan_ntwk_ctgry_cd) as fclty_bnf'''+dbname+'''_plan_ntwk_ctgry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='fclty_bnf'''+dbname+'''_plan_ntwk_ctgry_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================
   
  test("Member Error- Check prfsnl_bnf'''+dbname+'''_plan_ntwk_ctgry_cd column values not located in reference table - 033") {

      val id = Array("033")
     val name = Array("Test case : Check prfsnl_bnf'''+dbname+'''_plan_ntwk_ctgry_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct concat(bhi_home_plan_id,prfsnl_bnf'''+dbname+'''_plan_ntwk_ctgry_cd) as prfsnl_bnf'''+dbname+'''_plan_ntwk_ctgry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.bcbsa_prfx_rfrnc""")

    val result2 = sqlContext.sql("""select distinct concat(a.bhi_home_plan_id,a.prfsnl_bnf'''+dbname+'''_plan_ntwk_ctgry_cd) as prfsnl_bnf'''+dbname+'''_plan_ntwk_ctgry_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='fclty_bnf'''+dbname+'''_plan_ntwk_ctgry_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================
   
  test("Member Error-Check phrmcy_crv_out_sbmsn_ind column values not located in reference table - 034") {

     val id = Array("034")
     val name = Array("Test case : Check phrmcy_crv_out_sbmsn_ind column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct phrmcy_crv_out_sbmsn_ind from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_RX_CRV_OT_SUB_IND_XWALK_INBND""")

    val result2 = sqlContext.sql("""select distinct a.phrmcy_crv_out_sbmsn_ind from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='phrmcy_crv_out_sbmsn_ind' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================
   
  test("Member Error- Check phrmcy_bnft_tiers_nbr_txt column values not located in reference table - 035") {

     val id = Array("035")
     val name = Array("Test case : Check phrmcy_bnft_tiers_nbr_txt column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct phrmcy_bnft_tier_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_RX_BNFT_TR_XWALK_INBND""")

    val result2 = sqlContext.sql("""select distinct a.phrmcy_bnft_tiers_nbr_txt from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='phrmcy_bnft_tiers_nbr_txt' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================
   
  test("Member Error- Check gov_sbsdy_ind column values not located in reference table - 036") {

     val id = Array("036")
     val name = Array("Test case : Check gov_sbsdy_ind column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct gov_sbsdy_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_GOV_SBSDS_IND_XWALK_INBND""")

    val result2 = sqlContext.sql("""select distinct a.gov_sbsdy_ind from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='gov_sbsdy_ind' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }
  
  //============================================================
   
  test("Member Error- Check csr_type_cd column values not located in reference table - 037") {

     val id = Array("037")
     val name = Array("Test case : Check csr_type_cd column values not located in reference table")


    val result1 = sqlContext.sql("""select distinct csr_type_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_wh.RFRNC_BCBSA_COST_SHRG_RDCTN_TYPE_INBND""")

    val result2 = sqlContext.sql("""select distinct a.csr_type_cd from '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR a join
        '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where b.tbl_nm='BCBSA_MBRSHP_ERR' and b.clmn_nm='csr_type_cd' and b.err_cd='409'""")

    assert(result1.intersect(result2).take(1).isEmpty)

  }*/

  //============================================================

  test("Member_Space Error- Check Error code when bhi_home_plan_id column has spaces - 038") {

   
     val id = Array("038")
     val name = Array("Test case : Check Error code when bhi_home_plan_id column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.bhi_home_plan_id, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

test("Member_Space Error- Check Error code when home_plan_prod_id column has spaces - 039") {

     val id = Array("039")
     val name = Array("Test case : Check Error code when home_plan_prod_id column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.home_plan_prod_id, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.home_plan_prod_id, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.home_plan_prod_id, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }

  //============================================================

  test("Member_Space Error-Check Error code when mbr_id column has spaces - 040") {

     val id = Array("040")
     val name = Array("Test case : Check Error code when mbr_id column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_id, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_id, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_id, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member_Space Error-Check Error code when cnsstnt_mbr_id column has spaces - 041") {

     val id = Array("041")
     val name = Array("Test case : Check Error code when cnsstnt_mbr_id column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.cnsstnt_mbr_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.cnsstnt_mbr_id, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_id, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

 /* test("Member_Space Error-Check Error code when mbr_curnt_cntry_cd column has spaces - 042") {

     val id = Array("042")
     val name = Array("Test case : Check Error code when mbr_curnt_cntry_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_curnt_cntry_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }*/
  
  //============================================================

  test("Member_Space Error-Reject- Check Error code when mbr_gndr_cd column has spaces - 043") {

    val id = Array("043")
     val name = Array("Test case : Check Error code when mbr_gndr_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_gndr_cd, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_gndr_cd, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_gndr_cd, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member_Space Error-Check Error code when mbr_cnfdntlty_cd column has spaces - 044") {

     val id = Array("044")
     val name = Array("Test case : Check Error code when mbr_cnfdntlty_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_cnfdntlty_cd, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_cnfdntlty_cd, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.mbr_cnfdntlty_cd, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member_Space Error-Check Error code when acct_id column has spaces - 045") {

     val id = Array("045")
     val name = Array("Test case : Check Error code when acct_id column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.acct_id, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.acct_id, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.acct_id, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member_Space Error- Check Error code when grp_id column has spaces - 046") {

     val id = Array("046")
     val name = Array("Test case : Check Error code when grp_id column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.grp_id, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.grp_id, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.grp_id, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

  test("Member_Space Error-Check Error code when subgrp_id column has spaces - 047") {

     val id = Array("047")
     val name = Array("Test case : Check Error code when subgrp_id column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.subgrp_id, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.subgrp_id, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.subgrp_id, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================

 /* test("Member_Space Error-Check Error code when mbr_rltnshp_cd column has spaces - 048") {

     val id = Array("048")
     val name = Array("Test case : Check Error code when mbr_rltnshp_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_rltnshp_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }*/
  
  //============================================================
  
  test("Member_Space Error- Check Error code when sbscrbr_home_plan_prod_id column has spaces - 049") {

     val id = Array("049")
     val name = Array("Test case : Check Error code when sbscrbr_home_plan_prod_id column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.sbscrbr_home_plan_prod_id, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sbscrbr_home_plan_prod_id, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sbscrbr_home_plan_prod_id, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  test("Member_Space Error- Check Error code when sbscrbr_id column has spaces - 050") {

     val id = Array("050")
     val name = Array("Test case : Check Error code when sbscrbr_id column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.sbscrbr_id, "")," ", "")))=0""")

     if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sbscrbr_id, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sbscrbr_id, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  /*test("Member_Space Error- Check Error code when enrlmnt_elgblty_stts_cd column has spaces - 051") {

     val id = Array("051")
     val name = Array("Test case : Check Error code when enrlmnt_elgblty_stts_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.enrlmnt_elgblty_stts_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }*/
  
  //============================================================
  
  test("Member_Space Error- Check Error code when mbr_mdcl_cob_cd column has spaces - 052") {

     val id = Array("052")
     val name = Array("Test case : Check Error code when mbr_mdcl_cob_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_mdcl_cob_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sbscrbr_id, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
     
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.sbscrbr_id, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
 /* test("Member_Space Error- Check Error code when mbr_phrmcy_cob_cd column has spaces - 053") {

      val id = Array("053")
     val name = Array("Test case : Check Error code when mbr_phrmcy_cob_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mbr_phrmcy_cob_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1))

  }
  
  //============================================================
   
  test("Member_Space Error- Check Error code when ddctbl_ctgry_cd column has spaces - 054") {

     val id = Array("054")
     val name = Array("Test case :  Check Error code when ddctbl_ctgry_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.ddctbl_ctgry_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }
  
  //============================================================

  test("Member_Space Error- Check Error code when mh_cd_enrlmnt_bnft_cd column has spaces - 055") {

     val id = Array("055)
     val name = Array("Test case : Check Error code when mh_cd_enrlmnt_bnft_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.mh_cd_enrlmnt_bnft_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }*/
  
  //============================================================
  
  test("Member_Space Error-Reject- Check Error code when fclty_bnfts_bhi_ntwk_ctgry_cd column has spaces - 056") {

     val id = Array("056")
     val name = Array("Test case : Check Error code when fclty_bnfts_bhi_ntwk_ctgry_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.fclty_bnfts_bhi_ntwk_ctgry_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.fclty_bnfts_bhi_ntwk_ctgry_cd, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.fclty_bnfts_bhi_ntwk_ctgry_cd, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
  test("Member_Space Error- Check Error code when prfsnl_bnfts_bhi_ntwk_ctgry_cd column has spaces - 057") {

     val id = Array("057")
     val name = Array("Test case : Check Error code when prfsnl_bnfts_bhi_ntwk_ctgry_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from """+dbname+"""_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        """+dbname+"""_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.prfsnl_bnfts_bhi_ntwk_ctgry_cd, "")," ", "")))=0""")

    if (result.count == 0 || (result.collectAsList.toString.contains("303") && result.count() == 1)) {
       val a = result.limit(10).rdd
       val status = Array("SUCCESS")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.prfsnl_bnfts_bhi_ntwk_ctgry_cd, ''),' ', '')))=0")
       val data = Array(": No Invalid Values Found")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 1)

    } else {
      
       val a = result.limit(10).rdd
       val status = Array("FAILED")
       val query = Array("Test Query : select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key where length(trim(regexp_replace(coalesce(b.prfsnl_bnfts_bhi_ntwk_ctgry_cd, ''),' ', '')))=0")
       val data = Array("")
      
       sc.parallelize(id,1).union(sc.parallelize(name,1)).union(sc.parallelize(query,1)).union(sc.parallelize(status,1)).union(sc.parallelize(data,1)).union(a.map(_.toString)).repartition(1).saveAsTextFile(f"/"+env+f"/hdfsapp/ve2/pca/ndw1/phi/no_gbd/r000/audit/ta/Error_Tables/Member/$currdate1/" + "PCADX_TA_"+ subj +"_"+ prcss +"_"+ id.toList.mkString("") +"_"+ status.toList.mkString("") +"_"+ currdate) +"_.dat"
       assert(1 == 2)

    }

  }
  
  //============================================================
  
 /* test("Member_Space Error- Check Error code when fclty_bnf'''+dbname+'''_plan_ntwk_ctgry_cd column has spaces - 058") {

     val id = Array("058")
     val name = Array("Test case : Check Error code when fclty_bnf'''+dbname+'''_plan_ntwk_ctgry_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.fclty_bnf'''+dbname+'''_plan_ntwk_ctgry_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }
  
  //============================================================
   
  test("Member_Space Error- Check Error code when prfsnl_bnf'''+dbname+'''_plan_ntwk_ctgry_cd column has spaces - 059") {

     val id = Array("059")
     val name = Array("Test case : Check Error code when prfsnl_bnf'''+dbname+'''_plan_ntwk_ctgry_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.prfsnl_bnf'''+dbname+'''_plan_ntwk_ctgry_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }
  
  //============================================================
  
  test("Member_Space Error- Check Error code when phrmcy_crv_out_sbmsn_ind column has spaces - 060") {

     val id = Array("060")
     val name = Array("Test case : Check Error code when phrmcy_crv_out_sbmsn_ind column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.phrmcy_crv_out_sbmsn_ind, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }
  
  //============================================================
  
  test("Member_Space Error- Check Error code when phrmcy_bnft_tiers_nbr_txt column has spaces - 061") {

     val id = Array("061")
     val name = Array("Test case : Check Error code when phrmcy_bnft_tiers_nbr_txt column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.phrmcy_bnft_tiers_nbr_txt, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }
  
  //============================================================
  
  test("Member_Space Error- Check Error code when gov_sbsdy_ind column has spaces - 062") {

     val id = Array("062")
     val name = Array("Test case : Check Error code when gov_sbsdy_ind column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.gov_sbsdy_ind, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }
  
  //============================================================
  
  test("Member_Space Error- Check Error code when csr_type_cd column has spaces - 063") {

     val id = Array("063")
     val name = Array("Test case :  Check Error code when csr_type_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.csr_type_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }
  
  //============================================================
  
  test("Member_Space Error- Check Error code when qhp_id column has spaces - 064") {

     val id = Array("064")
     val name = Array("Test case : Check Error code when qhp_id column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.qhp_id, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }
  
  //============================================================
  
  test("Member_Space Error- Check Error code when nlo_acct_type_cd column has spaces - 065") {

     val id = Array("065")
     val name = Array("Test case : Check Error code when nlo_acct_type_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.nlo_acct_type_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }
  
  //============================================================
  
  test("Member_Space Error- Check Error code when nlo_plan_type_cd column has spaces - 066") {

     val id = Array("066")
     val name = Array("Test case : Check Error code when nlo_plan_type_cd column has spaces")


    val result = sqlContext.sql("""select DISTINCT a.err_cd from '''+dbname+'''_pcandw1ph_nogbd_r000_wh.audt_err_log a join
        '''+dbname+'''_PCANDW1PH_nogbd_r000_ou.BCBSA_MBRSHP_ERR b on a.err_id=b.err_id and a.load_log_key=b.load_log_key
        where length(trim(regexp_replace(coalesce(b.nlo_plan_type_cd, "")," ", "")))=0""")

    assert(result.count == 0 || (result.collectAsList.toString.contains("407") && result.count() == 1))

  }*/ 

}